# 52 — Owner decision: run the POC session on R7, or wait for R8

> **DECIDED (trail 161): "Run R8 first."** The owner declined the residual-risk path and elected the
> higher-assurance one — the same call he made at trail 151. The POC session stays blocked until R8
> passes an executed re-check. This document is closed; it is retained for the reasoning, not as an
> open question.

**This is the owner's call, not the gate's.** The security gate's verdict is settled and Fable does not soften it: R7 **FAILS**, three findings, all confirmed. The gate stays open until R8 passes an executed re-check. What follows is a separate question the gate does not answer — *whether the owner should sit down with the current build anyway* — and it has been his to make since trail 151.

## What is actually still broken

Three things. In plain terms:

1. **The "do not restart me" note can fail to get written.** If the disk breaks in a specific way, the stub stops itself and tries to leave a note saying so. If writing that note also fails, restarting the stub clears the stop. It tells you the note failed to save — but the message right next to that says "restarting won't clear this," which is untrue in that case.
2. **A scratch file can be left behind uncounted.** If a fault lands in a window of roughly a microsecond, a temp file exists on disk but the stub thinks nothing was created, so it doesn't clean up or lock down.
3. **One kind of error escapes on the cleanup path.** After a successful undo, an unusual error type slips past the handler and leaks one capture allowance out of 5,000. Ctrl-C at exactly the wrong instant is the realistic way to hit it.

## What none of them can do

- **None can double-fire a real action.** That was R4's defect — one approval fanning out into multiple real side effects — and it is fixed and independently re-verified.
- **None can leak a secret or grant authority to a provider.** The authority model, the redaction boundary and the concurrency work are all closed.
- **None can corrupt the comparison data.** Captures, measurements and the receipt contract are unaffected; the measurement validator ran 160/160 clean.

All three need either a genuine disk failure or a fault landing in a sub-millisecond window, on a local session that gets deleted afterward.

## Fable's recommendation

**Finish R8 first — but it is a preference, not a blocker.**

Reasons to wait: R8 is three small fixes on a build that is otherwise clean, and **two of them make the stub less likely to lock up on you mid-session** for no good reason. That is a direct quality-of-session benefit, not just a compliance one. It also costs one relay cycle.

Reasons not to wait: none of the three findings can hurt you or corrupt the results, and the actual goal — comparing n8n against Zapier — is not affected by any of them.

**Either choice is defensible. Say the word and it happens:**

- *"Run R8 first"* → the packet is built and ready to relay; no further input needed.
- *"I'll run the session now"* → the session is unblocked on the owner's stated residual risk, R8 proceeds in parallel, and the three known defects go into the runbook so a mid-session lockup is recognisable rather than mysterious.

## One thing that is being fixed regardless

`run_all.sh` currently prints **`HARNESS FAIL`** when an optional Node dependency is merely unavailable, while every security check underneath it passed. That would read to anyone as something being broken. It is a non-gating item in R8 (`51_` item E) and it is in there specifically because the owner will run that script himself.
