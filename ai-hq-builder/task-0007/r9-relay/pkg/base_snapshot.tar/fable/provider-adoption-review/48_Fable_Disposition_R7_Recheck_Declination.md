# 48 — Fable Disposition: the R7 re-check return is a declination, not a verdict

**Input:** the verifier's R7 response, delivered as chat prose. No attached artifacts, no `SHA256SUMS` result, no probe evidence, no reproduction notes, and **no SHA-256 of the input archive**.

## 1. Ruling: this does not move the gate

The return's own words are the ruling: *"I cannot honestly say 'R7 PASS. Security gate closed.' That would require a deeper evidence audit than reading the disposition packet."* It is offered as **"Tentative PASS (pending full evidence audit)"** and explicitly **not** as an independently certified pass.

**Fable accepts that characterisation exactly as given.** A tentative pass is not a pass. The security gate stays closed and the owner POC session stays blocked. Nothing here is a criticism of the verifier — see §3.

## 2. What this return is missing, measured against the previous three

Every prior re-check in this workstream was an **executed** verification, and each opened the same way:

| | R5 re-check (`40_`) | R6 re-check (`44_`) | **R7 return** |
| --- | --- | --- | --- |
| Input archive SHA-256 stated | yes | yes (`abc0e6fc…73dbb`, both zips byte-identical) | **absent** |
| `SHA256SUMS.txt` verified | yes | yes — 123/123 | **absent** |
| `authority_manifest.json` verified | yes | yes — 122/122 | **absent** |
| `base_snapshot.tar` tree reproduced | yes | yes — `845b5ee3…` | **absent** |
| Probes executed, results shipped | yes (`40A_`) | yes (`44A_`) | **absent** |
| Reproduction notes with commands | yes (`40B_`) | yes (`44B_`, run under `/mnt/data/r6_recheck_work/pkg`) | **absent** |

The return also opens *"I read Fable's handoff and the context you've shared"* — which describes the disposition prose, not an extracted archive.

**Diagnosis: the archive was almost certainly never opened.** The single most diagnostic signal is the missing input hash: naming the input archive's SHA-256 in the first two lines is the one thing every prior return did without being asked, and it is the one thing that cannot be produced without having the file. `R7_Recheck.zip` ships the full runnable tree — the stub, the base snapshot, the R6 pin and both R7 probes — so the material for an executed re-check was present. This reads as a **relay failure, not a review failure**.

## 3. What the verifier got right, and it matters more than the miss

**It refused to certify what it had not checked.** Had it returned a confident PASS on a packet it read rather than ran, the gate would have closed on nothing, and the owner would have sat down to a live session with real side effects behind a rubber stamp. Six rounds of this workstream exist because reading a thing is not the same as running it — that is the exact lesson of DEF-R2-01, of trail 152, and of Fable's own R2 verification defect. **A verifier that declines under those conditions is the verifier this gate needs.** Recorded as the second time the trail-127 escalation practice has paid, in a different currency than the first.

## 4. The one focus item that a reading *can* settle

Of the four items `47_` §5 put to the verifier, three are **behaviour claims** — items 1 (loosened controls 3 and 4), 2 (the unwritable quarantine marker) and 4 (no R6 regression). Those require execution and **remain entirely unverified**.

Item 3 is different in kind. The interrupt-absorption question is a **policy** question — *should* the service absorb `KeyboardInterrupt`/`SystemExit` in the post-durability tail — and a policy question is adjudicable by reading. The verifier engaged it on the merits and concurred: absorbing after durability is established, while recording the anomaly, is *"internally consistent"* and *"a defensible consistency policy"*, and it *"would not reject the patch solely because of that choice."*

**Fable records that precisely and no further: the *policy* of `47_` §3 is now independently concurred; the *implementation* of it remains Fable-read-only.** Whether `_absorb_post_durable` in fact absorbs only in that tail is a behaviour claim like the other three. Item 3 comes off the *design* docket, not off the evidence docket.

## 5. Standing rule adopted — what counts as a verdict

Recorded because this round is the cheapest possible demonstration of it, and because the production wrapper will have the same gate:

> **A re-check return moves a gate only if it carries the input archive's SHA-256 and reproduction notes sufficient to re-run its result. A return without them is a declination, whatever its stated conclusion, and the gate does not move — including when the stated conclusion is favourable.**

The asymmetry is deliberate. This program has never been at risk from a pessimistic reading-level review; it is at risk from an optimistic one. This rule would have caught a reading-level "PASS" as surely as it caught a reading-level "tentative PASS", and that is the case it exists for.

## 6. Disposition and sequencing

**No Builder round. No packet change. No new build.** The artifact under review is not in question — R7 is structurally accepted and integrated per `47_`, and nothing in this return disturbs it.

**`R7_Recheck.zip` re-issues byte-identical, same fingerprint `673109fbc06fa0851dc8eb7efe36bc1971080fea7cb5340282c95b0628982062`, same base binding `1110bf900a6c093c7da013584a8697f7756eb7fb`.** It is re-sent as a file attachment with two instructions added and nothing removed:

1. **Begin with the integrity block**, exactly as `44_` §1 did: the input archive's SHA-256, the `SHA256SUMS.txt` count, the `authority_manifest.json` count, and the `base_snapshot.tar` tree reproduction. If those four cannot be produced, the archive did not arrive.
2. **If the archive cannot be opened, say so and stop.** Do not review the disposition prose as a substitute. A declination costs one relay; a reading-level pass costs the gate.

The scope is unchanged and is narrower than "a full evidence audit": R6 was already executed-verified end to end (`44_`), so what R7 needs is the **five deltas** — the two loosened controls, the persisted marker's own failure modes, and that the R6-confirmed results did not move. Item 3's policy is settled per §4; its implementation is not.

**Owner POC session remains BLOCKED. Provider selection NOT MADE.** Nothing accepted reopens.
