# Open Questions and Phase 2 Backlog

## Gate

Phase 2 should not begin until the audit consensus is accepted. The entries below remain unresolved or provisional; they are not omissions from the packet.

## Phase 2 parent topic — Decision Engine

| Work area | Question to resolve |
| --- | --- |
| Inputs | What event schema represents thoughts, emails, calls, failures, completions, data changes, and agent outputs? |
| Understanding | What context must be assembled before classification? |
| Classification | How are current-topic change, observation, child, sibling, parent, blocker, rule/skill/preference candidate, and irrelevant input distinguished? |
| Recommendation | How should alternatives, confidence, rationale, and later calibration be represented? |
| Policy evaluation | How do deterministic rules constrain or approve model recommendations? |
| Attention | What qualifies as critical interrupt, Needs Attention, hub update, or briefing? |
| Routing | How are owner mode, hierarchy, dependencies, scope, urgency, risk, and permissions applied? |
| Execution authority | When may the system act, prepare, queue, delegate, or require owner action? |
| Verification | What evidence proves execution and completion? |
| Learning | How are decisions, reasons, reversals, and outcomes used without silently changing policy? |
| Fold-back | How do outcomes update parent state and close the branch? |

## Other unresolved design areas

- Exact Business, Personal, and Operating System HQ taxonomy.
- Exact Discord categories, channel types, forum tags, permissions, and mobile formatting.
- Operational state database and event schema.
- Gbrain or alternative memory-provider evaluation and contract testing.
- MCP authorization, data sensitivity, and write-action boundaries.
- Mailroom classification and response policy.
- Critical interrupt criteria and quiet-hour behavior.
- Voice, screenshots, attachments, and structured input handling.
- Security, secret management, account isolation, backup, and disaster recovery.
- Model routing, subscription use, API budgets, and provider failover.
- Final Mac purchase timing, configuration, and accessories.
