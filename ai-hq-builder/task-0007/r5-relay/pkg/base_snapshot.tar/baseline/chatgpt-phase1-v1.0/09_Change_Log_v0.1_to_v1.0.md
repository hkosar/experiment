# Change Log — Specification v0.1 to Phase 1 Baseline v1.0

## Added

- Phase 1 audit gate and consensus protocol.
- Attention model separating critical interrupt, Needs Attention, hub update, and briefing.
- Genuine-tradeoff interview and decision-prompt standard.
- Delegation, scoped reminder policies, completion claims, verification, owner-accepted completion, and reconciliation.
- Hybrid functional HQ plus authoritative system-hub model.
- Discord lightweight-pilot versus purpose-built application boundary.
- Split ownership between operational records and coordination state.
- M4 Max hardware baseline and M3 Ultra decision rule.
- Phase 2 Decision Engine backlog.
- Standalone design principles, ADRs, glossary/object model, requirements register, and decision trail.

## Changed

- Status changed from working discovery draft to consolidated candidate baseline pending audit.
- Blocker override changed from generic advisory behavior to strong informational friction.
- Next recommended topic changed from Business HQ taxonomy to audit consensus followed by Decision Engine discovery.
- Requirements register expanded and supersedes informal R-number references from the live conversation.

## Preserved as provisional

- Exact HQ/channel taxonomy.
- Gbrain or other memory-provider choice.
- Critical-interrupt details and notification timing.
- Data/MCP write authority.
- Final hardware purchase configuration and timing.
