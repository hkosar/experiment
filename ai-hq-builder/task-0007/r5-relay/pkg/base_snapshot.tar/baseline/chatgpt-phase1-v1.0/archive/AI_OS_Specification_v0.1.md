# AI Operating System — System Design Specification

**Version:** 0.1

**Status:** Working draft; Discovery Phase 1 consolidated

**Date:** July 24, 2026

**Purpose:** Define a Discord-first, platform-independent operating model that converts unstructured thought into organized, durable, executable work across business and personal domains.

> **Working north star:** Allow natural, nonlinear input while the system enforces organized execution, preserves context, manages protocol, and guides the owner to the next useful decision.

# Document Control

- **Document type:** System design specification and discovery baseline
- **Version:** 0.1
- **Status:** Working draft; not yet an implementation contract
- **Primary operator:** One owner/operator for the foreseeable future
- **Primary interface:** Discord-first; core operating model remains platform-independent
- **Primary domains:** Business and Personal, presented together but prioritized separately
- **Source material:** Discovery interview and current-state workflow description
- **Change rule:** Future design decisions should update this document or its version-controlled successor rather than remain only in chat history.

> **How to use this draft:** Treat this document as the parent hub for the design initiative. Future interview topics should either confirm, modify, or add to this specification, then fold their conclusions back into the next version.

## Contents

- 1. Executive Summary
- 2. Design Intent, Scope, and Non-Goals
- 3. User and Current Operating Context
- 4. Target Experience
- 5. Conceptual Architecture
- 6. Information Architecture and Object Model
- 7. Topic Lifecycle, State, and Fold-Back
- 8. Interaction, Routing, and Focus Management
- 9. Navigation, Dashboards, and Presentation
- 10. Learning, Preferences, Rules, and Skills
- 11. Automation, Approval, and Verification Harness
- 12. Application Development Operating Model
- 13. Business Operations, Data, Leads, and Calls
- 14. Personal Operating Domain
- 15. Memory, Context, and Knowledge Architecture
- 16. Discord-First Platform Strategy
- 17. Recommended MVP and Rollout
- 18. Success Measures, Risks, and Guardrails
- 19. Open Design Questions and Interview Backlog
- Appendix A. Consolidated Requirements
- Appendix B. Glossary

# 1. Executive Summary

The current workflow uses capable cloud models and development tools, but continuity, organization, monitoring, and protocol are held together manually by the owner. Planning, implementation, review, context handoffs, status awareness, and prioritization are split across long browser sessions, Cursor, local processes, email, and personal memory. The owner is therefore acting as both vision owner and orchestration layer.

The target system is a persistent AI operating environment with one familiar front door, durable structured state, recursive project hubs, model-independent workflows, and a learning layer that proposes improvements without silently changing behavior. Discord is the preferred first interface because it is familiar and continuously available on phone and PC, but Discord must remain a presentation layer rather than the authoritative system of record.

The design supports three connected operating loops:

| Loop | Purpose | Representative outcome |
| --- | --- | --- |
| Think to Plan | Convert incomplete notes, interruptions, and exploratory conversation into structured decisions and executable plans. | A vague meeting note becomes an initiative with scoped topics, decisions, and a deployment plan. |
| Build to Operate to Improve | Create applications, operate the business through their data and workflows, then feed observed problems back into application and process development. | Lead and call data produces coaching insight, identifies a workflow gap, and opens an improvement topic. |
| System Self-Improvement | Observe recurring preferences, skills, protocol deviations, and successful automation patterns, then mature them through the same governed workflow used for other work. | Repeated requests for click-by-click guidance become a reviewed, scoped skill rather than an informal chat preference. |

> **Primary design outcome:** The owner should be free to think associatively and interrupt naturally. The coordinator is responsible for classification, preservation, routing, stage management, protocol, visibility, and return-to-work context.

## 1.1 First-draft architecture in one view

```text
OWNER ON PHONE OR PC
        |
        v
DISCORD-FIRST EXECUTIVE EXPERIENCE
Reception | Executive Desk | HQs | Project Hubs | Approvals
        |
        v
COORDINATOR AND WORKFLOW ENGINE
Classify | Route | Stage | Prioritize | Link | Fold Back | Coach
        |
        +--------------------+--------------------+
        |                    |                    |
        v                    v                    v
MODEL WORKERS          BUSINESS SYSTEMS      PERSONAL SYSTEMS
Planner/Builder/       Apps, MCP data,        Travel, home,
Reviewer/Auditor       leads, calls, email    writing, planning
        |                    |                    |
        +--------------------+--------------------+
                             |
                             v
DURABLE STATE AND MEMORY
Operational database | Git | artifacts | semantic knowledge layer
```

## 1.2 Key strategic distinction

This is not only a system that builds applications. It is also a system that can use those applications and their connected data as an operational cockpit. A lead application can be designed and maintained by the development workflow while its live data is simultaneously summarized, monitored, reviewed, and converted into new process or development topics.

This closed loop is a core source of future leverage:

```text
BUSINESS ACTIVITY
    -> DATA AND TRANSCRIPTS
    -> INSIGHT AND HUMAN JUDGMENT
    -> PROCESS OR APPLICATION CHANGE
    -> VALIDATED RELEASE
    -> MEASURED BUSINESS ACTIVITY
```

# 2. Design Intent, Scope, and Non-Goals

## 2.1 Design intent

- Replace manual cross-tool orchestration with a persistent coordinator and explicit workflow state.
- Make resumption effortless after interruptions, device changes, travel, or overnight execution.
- Permit messy, nonlinear, incomplete input without requiring the owner to classify it first.
- Preserve one main hub for situational awareness while allowing deep navigation into branches when needed.
- Separate Business and Personal operating queues while presenting both in one unified executive frame.
- Use automated technical verification rather than treating a non-technical owner as a ceremonial implementation approver.
- Learn preferences, skills, automation boundaries, and routing judgment through governed evidence and review.
- Remain portable across model providers, memory providers, and front-end platforms.

## 2.2 In scope for the first design program

- Discord information architecture and clickable prototype.
- Executive Desk, Reception, HQ, project hub, topic, task, approval, and closeout experiences.
- Recursive parent-child organization and fold-back behavior.
- Application development workflow using multiple models and tools.
- Business data access, email triage, leads, advertisements, calls, transcripts, and operational insight.
- Personal planning and assistance as a separate operating domain.
- Context, memory, rules, skills, preferences, and observation governance.
- Automation policy learning, evidence, approval, and technical verification.
- A staged implementation plan that can be prepared before purchasing or commissioning the final host computer.

## 2.3 Explicit non-goals for Version 0.1

- Final selection of Gbrain or any other knowledge-memory provider.
- Final Discord channel count, permissions, bot commands, or visual formatting.
- Autonomous access to production systems, banking, sensitive communications, or destructive actions.
- A complete local-model strategy or distributed worker-computer network.
- Final agent prompts, model assignments, or subscription routing rules.
- A claim that every discovered feature belongs in the first implementation release.

> **Design discipline:** The operating model should be defined independently of Discord, OpenClaw, Gbrain, Claude, Codex, or any other vendor. Implementation must adapt to provider capabilities, but provider limitations should not silently become the business operating model.

# 3. User and Current Operating Context

## 3.1 Primary user profile

| Dimension | Observed need |
| --- | --- |
| Ownership | One owner/operator is expected to administer and use the private system for a long period. Employees may use applications produced by it, but not the private development and executive environment. |
| Strengths | Problem definition, broad systems thinking, process design, desired outcomes, business acceptance, and result review. |
| Constraints | Organization, detail maintenance, priority classification, repetitive no-progress sessions, protocol upkeep, and technical implementation verification. |
| Input style | Natural, associative, frequently interrupted, often delivered as raw notes or word-vomit rather than a prepared specification. |
| Interview preference | Narrow, comparative, this-or-that, multi-select, or bounded scenario questions; avoid broad open-ended prompts unless a contextual exception is justified. |
| Learning preference | Layman-oriented explanations, click-by-click execution guidance, visible progress, and automation of safe steps rather than delegation back to the user. |
| Device pattern | Frequent switching between PC and mobile, including periods when only mobile status and approval are practical. |

## 3.2 Current AI and development workflow

The present process is powerful but fragmented. The following stage mapping is based on the current description and should be treated as a current-state inventory rather than a final architecture:

| Stage | Current tool or model label | Current operating issue |
| --- | --- | --- |
| Ideation | Claude Code Opus 4.8 | Exploration occurs in long sessions with state trapped in conversation. |
| Design | Claude Code Opus 4.8 | Design and implementation context can blend without a formal handoff record. |
| Develop Plan | Claude Code 'Fable' as currently described | Plan quality depends on manually re-establishing context. |
| Execution | Claude Code Opus 4.8 managing Sonnet agents | The owner monitors multiple windows and remains the dispatcher. |
| Debugging | Cursor | Local editor, indexing, build, and security tooling add PC load and another context boundary. |
| Launch Testing | Hyperagent with Codex connection | Independent review exists, but evidence and feedback must be manually routed. |

The underlying lifecycle is sound: ideation, design, planning, execution, debugging, and validation. The system should preserve that intent while replacing tool-specific stage names with role-based abstractions so future models can be substituted without redesigning the workflow.

## 3.3 Current friction

- Three or four active projects may run in very long chat sessions without durable, structured project state.
- Manual context compaction is deferred because there is no obvious stopping point; handoff messages are created only after the context becomes visibly unusable or after deployment.
- Overnight prompts may make substantial progress, time out, fail, or wait for input without a durable checkpoint or consolidated status view.
- Progress is hidden inside narrative agent output rather than represented as verified milestones and current state.
- The PC becomes a bottleneck because browser sessions, Cursor, indexing, language servers, builds, tests, and security scanning remain local even when model inference is cloud-based.
- Email requires manual priority and effort classification, so messages accumulate until processed in large batches.
- Calls, visitors, and business-process questions interrupt development without a reliable pause-and-resume mechanism.
- The owner cannot confidently see active work while away from the workstation and therefore feels pressure to return and babysit sessions.
- Protocol and housekeeping are skipped when the user must administer them personally.

# 4. Target Experience

## 4.1 Reception

Reception is the universal front door. The owner can submit a question, raw note, meeting fragment, instruction, link, screenshot, voice transcription, business issue, or personal request without choosing a destination first.

> **Reception rule:** The user produces thoughts. The system organizes them. Classification is an operating-system responsibility, not an entry requirement.

## 4.2 Executive Desk

The Executive Desk is the global home view used whenever the owner reconnects. It combines broad situational awareness with immediate resumption context.

```text
EXECUTIVE DESK

RECENT CONTEXT
- Last active hub and topic
- What changed since the owner left
- Suggested next action

BUSINESS PRIORITY LIST
- Needs owner
- Active / waiting / blocked
- To-do and to-did

PERSONAL PRIORITY LIST
- Needs owner
- Active / waiting / blocked
- To-do and to-did

BACKGROUND ACTIVITY
- Working
- Completed
- Failed or stalled

NAVIGATION
- Business HQs
- Personal HQs
- Operating System HQ
```

Business and Personal remain separate queues so the owner decides which mode to enter only once. Both are visible within one dashboard frame so neither domain disappears from awareness.

## 4.3 Tiered hub experience

Information is presented recursively. The owner can operate at the global level, enter an HQ, inspect a project hub, open a grouped branch, or enter a focused topic. The same structural pattern and summary format applies at each level.

```text
Executive Desk
  -> Business HQ
     -> Application Development HQ
        -> AI Operating System project hub
           -> Memory Architecture topic
              -> Context Compression task
```

The owner is expected to live primarily in the relevant hub summary, monitor child activity, and enter deeper branches only when a decision, review, or close inspection is useful.

## 4.4 Status without babysitting

The system must clearly distinguish the following conditions:

| Status | Meaning |
| --- | --- |
| Working | A worker has recent confirmed activity and is executing a bounded stage. |
| Waiting | The topic is intentionally waiting on another dependency, time, or queued resource. |
| Needs Owner | A business judgment, approval, clarification, or exception is required. |
| Blocked | Progress cannot continue until another topic or dependency resolves. |
| Paused | Work is deliberately suspended with a preserved return state. |
| Failed | Execution stopped unexpectedly and requires retry, repair, or escalation. |
| Completed | Local work is complete; fold-back and archive state must still be visible. |

> **Visibility requirement:** The owner should never need to open a worker chat solely to determine whether work is progressing, waiting, blocked, failed, completed, or waiting for the owner.

# 5. Conceptual Architecture

## 5.1 Layered architecture

| Layer | Responsibility | Illustrative components |
| --- | --- | --- |
| Executive Experience | What the owner sees and uses. | Reception, Executive Desk, HQ views, project hubs, topic summaries, approvals, mobile/desktop rendering. |
| Operating Model | How work is organized and governed. | Domains, HQs, initiatives, topics, tasks, stages, statuses, focus, fold-back, protocol, to-do/to-did. |
| Coordination and Intelligence | How input becomes routed work and model activity. | Coordinator, recommendation engine, workflow engine, specialist agents, model router, schedulers. |
| Durable State and Memory | What survives sessions, compaction, provider changes, and time. | Operational database, topic checkpoints, decision records, Git, artifacts, semantic memory/knowledge graph. |
| Integration | How external data and actions enter the system. | MCP servers, email, calendar, internal web tools, lead systems, call transcripts, ad platforms, GitHub. |
| Infrastructure | Where services execute and how they are reached. | Dedicated Mac host, cloud models, optional local models, containers, secure networking, backups. |

## 5.2 Source-of-truth separation

| Information type | Recommended authoritative store | Why |
| --- | --- | --- |
| Topic hierarchy, stage, status, assignment, approvals, events | Structured operational database | Requires exact state, queries, rollups, and deterministic transitions. |
| Application code, architecture docs, plans, tests, releases | Git repository | Versioned, auditable, reviewable, and tied to implementation. |
| Semantic relationships, recurring knowledge, observations, preferences, skills | Gbrain or equivalent knowledge-memory layer | Supports retrieval and relationship discovery, but should not be the sole transaction-state store. |
| Conversation and interaction history | Discord/OpenClaw transcripts with references | Useful evidence and continuity, but too unstructured to be the only project record. |
| Files, reports, screenshots, call audio, data extracts | Controlled artifact storage with metadata | Supports provenance, permissions, retention, and linking to topics. |

> **Memory-provider position:** Gbrain may become critical, but the design should first define the memory contract the operating system requires. Gbrain is a candidate implementation of that contract, not the owner of every type of state.

## 5.3 Three operating capabilities

| Capability | What it does |
| --- | --- |
| Create | Designs, builds, tests, launches, and maintains applications and processes. |
| Operate | Uses connected data and applications to brief, classify, monitor, prompt, analyze, and assist daily work. |
| Improve | Observes outcomes and behavior, proposes process/rule/skill/application changes, and routes those proposals through governed workflows. |

# 6. Information Architecture and Object Model

## 6.1 Structural hierarchy

```text
DOMAIN
  -> HQ / CATEGORY
     -> INITIATIVE OR PROJECT
        -> TOPIC OR GROUP
           -> TASK OR FOCUSED ISSUE
```

| Level | Purpose | Examples |
| --- | --- | --- |
| Domain | Separates broad operating context and permissions. | Business; Personal; Operating System. |
| HQ / Category | Central management area for a recurring functional domain. | Application Development HQ; Data HQ; Leads and Calls HQ; Preferences HQ; Skills HQ. |
| Initiative / Project | Committed outcome with a goal and eventual stable or completed state. | Deploy AI Operating System; Houseboat Business; Customer Portal improvement. |
| Topic / Group | Focused body of discovery, design, planning, execution, or review; may also supervise children. | Memory Architecture; Security Bugs; Mobile Presentation. |
| Task / Focused Issue | Concrete executable or decidable unit within a topic. | Choose context checkpoint schema; fix authentication timeout. |

## 6.2 Recursive hub model

Every meaningful object can present a hub-style summary and can supervise children. A topic is therefore both a focused conversation and, when needed, a small project hub.

```text
Houseboat Business
  -> Lead Generation
     -> Advertising Performance
     -> Incoming Call Review
        -> Call Rating Prompt
        -> Handling Insight
     -> Follow-Up Automation

AI Operating System
  -> Discord Interface
  -> Global Rules
  -> Memory Architecture
     -> Context Compression
     -> Topic Checkpoints
  -> Application Audit
     -> Interface Bugs
     -> Data Bugs
     -> Security Bugs
```

## 6.3 Persistent object types

| Object | Definition | Important metadata |
| --- | --- | --- |
| Observation | Weak evidence that something may matter; it does not change behavior by itself. | Source, date, category, confidence, related topics, repetition count. |
| Topic | A body of work or thought that deserves durable context and lifecycle management. | Parent, children, type, stage, status, focus, owner, summary, next action. |
| Task | A concrete action, check, or decision inside a topic. | Assignee, state, due/priority, evidence, completion criteria. |
| Decision | An explicit choice with rationale and impact. | Decision maker, alternatives, reason, affected objects, reversal path. |
| Rule | Approved operating constraint or required behavior. | Scope, strength, status, last applied, dependencies, review date. |
| Preference | Approved user preference that shapes experience but may permit exceptions. | Scope, confidence, last applied, exception history, review date. |
| Skill | Approved reusable procedure or ability invoked in recurring situations. | Trigger, inputs, steps, outputs, validation, scope, usage history. |
| Artifact | A durable output linked to work. | Version, owner, provenance, location, related topic, retention. |
| Event | A timestamped change or activity used in recent-history views and audits. | Actor, action, object, previous/new state, evidence. |

## 6.4 Broader categorization

Topic and state are not sufficient by themselves. Every object also belongs to a broader category and may have subcategories. This supports domain-specific HQs, filtered dashboards, permissions, memory retrieval, and reporting.

- Business versus Personal is the top-level example.
- Business may contain Application Development, Data, Sales and Leads, Operations, Communications, and Company Knowledge.
- Operating System may contain Rules, Preferences, Skills, Automation Policies, Integrations, and System Health.
- Knowledge can be categorized by communication style, formatting, existing applications, business processes, people, data sources, and other future taxonomies.

# 7. Topic Lifecycle, State, and Fold-Back

## 7.1 Stage is state, not location

A topic remains the same topic while its stage changes. The owner does not move between separate Discovery, Design, or Planning locations. The coordinator maintains stage labels as understanding evolves.

```text
Discovery -> Design -> Planning -> Execution -> Validation -> Integration -> Archived
       \         ^          \          ^
        \--------|-----------\---------|

Stages may be skipped, repeated, or revisited when new information changes the work.
```

| Stage | Purpose |
| --- | --- |
| Discovery | Clarify the issue, evidence, desired outcome, boundaries, and unknowns. |
| Design | Define structure, user experience, architecture, process, or operating approach when design is required. |
| Planning | Convert the selected approach into sequenced actions, responsibilities, dependencies, and validation criteria. |
| Execution | Perform implementation, data work, drafting, analysis, or other production activity. |
| Validation | Test, review, audit, compare, or otherwise establish whether the result is acceptable. |
| Integration | Fold the accepted outcome into the parent, update records and artifacts, and recalculate status and next action. |
| Archived | Remove the topic from active workload while retaining history, evidence, and reactivation capability. |

## 7.2 Stage, status, and focus are independent

| Dimension | Question answered | Examples |
| --- | --- | --- |
| Stage | How mature is the work? | Discovery; Planning; Validation. |
| Status | What is happening operationally? | Working; Waiting; Needs Owner; Blocked; Completed. |
| Focus | How prominent is it in the current interaction? | Foreground; Background; Queued; Parked. |

A topic can therefore be in Planning, working in the background, while another topic is in Discovery and is the foreground focus.

## 7.3 Topic kickoff

When a new topic is created, its initial message must preserve enough context for future continuation without reconstructing the origin conversation.

```text
TOPIC
Responsive Presentation Strategy

ORIGIN
Raised during Discord architecture discussion after noting that desktop and mobile
have different formatting constraints.

WHY THIS EXISTS
The system needs one source of truth with device-appropriate presentation.

CURRENT UNDERSTANDING
Duplicated channels would create synchronization and maintenance problems.

OPEN QUESTIONS
- What can Discord render differently by context?
- When would a companion dashboard justify leaving Discord?

PARENT / RELATED
AI Operating System -> Discord Interface

INITIAL STAGE
Discovery

RECOMMENDED NEXT
Compare Discord-only, Discord Activity, and companion-web approaches.
```

## 7.4 Fold-back

A child topic is not fully complete until its accepted outcome is integrated into its parent. Fold-back maintains low active-topic counts and prevents a hub from accumulating unresolved fragments.

```text
Child work complete
  -> validation evidence attached
  -> closeout summary generated
  -> impact on parent identified
  -> parent summary, decisions, plans, or artifacts updated
  -> follow-up topics created only when justified
  -> child moves to To-Did / archive
  -> parent suggested-next and stability recalculated
```

| Closeout element | Required content |
| --- | --- |
| Outcome | What was decided, created, corrected, or learned. |
| Evidence | Tests, audits, comparisons, reviews, or reasoning supporting the outcome. |
| Parent impact | Exactly what changes in the parent goal, plan, architecture, rules, or state. |
| Unresolved items | Anything deliberately left open. |
| New topics | Any justified follow-up work and its placement. |
| Return state | Where the parent resumes and what the next action becomes. |

## 7.5 Stable state and housekeeping

A hub is stable when completed children are integrated, blockers are resolved or intentionally accepted, summaries match current reality, and the next action is valid. A project with dozens of active topics indicates unintegrated work or excessive branching and should trigger a housekeeping review.

The user should not be responsible for housekeeping. The coordinator should surface unintegrated children, stale topics, missing closeouts, duplicated work, and unresolved decisions, then guide the corrective action.

# 8. Interaction, Routing, and Focus Management

## 8.1 Interruptions are routing events

An interruption should not force the owner to choose between losing an idea and derailing the current work. The coordinator evaluates the new input, preserves it, recommends placement, and either continues or creates a linked branch.

| Classification | Typical behavior | Example |
| --- | --- | --- |
| Immediate change | Apply within the current topic and continue. | Rename a section or correct an obvious wording issue. |
| Observation / parked item | Preserve as evidence or future consideration; no active topic yet. | A formatting preference may be emerging. |
| Child topic | Create a local branch required to complete the current topic. | Design a cost display inside the Discord interface. |
| Sibling or parent topic | Create work that affects a broader area or multiple branches. | Usage and cost tracking affects several interfaces and services. |
| Blocking topic | Create a linked topic and recommend resolving it before continuing. | Memory ownership must be decided before finalizing context-resumption behavior. |

## 8.2 Recommendation with alternatives

Multiple classifications may be valid. The coordinator should present its recommendation and the meaningful alternatives, allow the owner to choose, and learn from the rationale when the choice differs.

```text
ROUTING RECOMMENDATION

Recommended: Create sibling topic under AI Operating System
Reason: The issue affects multiple Discord components and future dashboards.

Other valid options:
- Keep inside the current Discord Interface topic
- Create a child topic for cost display only

Choose:
[Use recommendation] [Current topic] [Child topic]
```

The learning target is not a fixed answer such as always create a child. It is the owner’s judgment about scope, impact, urgency, and appropriate granularity.

## 8.3 Blocking behavior

Blocking is advisory but explicit. The owner may override, but the system must state why the blocker exists and the likely consequences.

```text
BLOCKER IDENTIFIED

This issue must be resolved before the current recommendation can be trusted.
Linked topic: Memory Architecture

Why it blocks:
The current design assumes a durable context owner that has not been selected.

If you continue anyway:
- Some work may be invalidated.
- Expected rework: medium.
- Context-loss risk remains unresolved.

[Open blocker] [Continue anyway] [Park current topic]
```

## 8.4 Focus and return

One topic is normally foreground, while several others may work in the background. When a blocker requires a focus switch, the system records the pause point and later returns the owner to the exact parent context with the new resolution integrated.

- Record where the owner was and why the topic paused.
- Record which child or sibling must resolve.
- Carry the accepted outcome back to the original topic.
- State what changed because of that outcome.
- Present a direct return link and the next action.

## 8.5 Protocol coaching

The system should actively protect approved protocol because the owner has stated that self-managed process will be skipped. Coaching should focus on meaningful deviations, not generic productivity commentary.

- Detect attempts to bypass required discovery, validation, fold-back, or approval gates.
- Explain the consequence of the deviation and offer an override when permitted.
- Ask why when the owner repeatedly chooses a different classification, scope, or process so the recommendation model improves.
- Do not flood the owner with workflow-management coaching that is already obvious from the dashboard.

# 9. Navigation, Dashboards, and Presentation

## 9.1 Breadcrumb-first navigation

Every coordinator response should show a compact breadcrumb so the owner remains oriented while moving among levels and topics.

```text
Business > Application Development > AI Operating System > Memory Architecture
```

Full navigation controls should appear on operational messages such as summaries, blockers, approvals, handoffs, and closeouts. Ordinary conversation should remain visually light.

## 9.2 Required navigation directions

- Up to the parent hub.
- Down into children and focused tasks.
- Sideways to related topics and sibling dependencies.
- Back to the previously visited location.
- Directly to the global Executive Desk or the nearest HQ.
- Directly to anything that needs the owner and a clear statement of why.

## 9.3 Standard project-hub view

```text
AI OPERATING SYSTEM

GOAL
Create a persistent AI operating environment accessible from phone and PC.

STAGE / STATUS
Design | Active

RECENT EVENTS
- Memory Architecture identified a blocker.
- Global Rules advanced to Design.
- Mobile Presentation topic was created.

SUGGESTED NEXT
Resolve Memory Architecture because it affects context and resumption.

NEEDS OWNER
2 decisions

ACTIVE BRANCHES
- Discord Interface        Design       Working
- Global Rules             Design       Background
- Memory Architecture      Discovery    Needs Owner
- Installation Plan        Planning     Waiting

TO-DO
Memory Architecture
  -> Choose authoritative checkpoint owner

TO-DID
- Defined Reception
- Defined recursive topic model
- Defined fold-back behavior

[Full summary] [Recent log] [Open needs-owner] [View hierarchy]
```

## 9.4 Layered to-do and to-did

The default task list should show the topic and its immediate action together, rather than presenting a flat list of tasks or only topic names.

```text
TO-DO

Memory Architecture
  -> Choose the authoritative memory source

Discord Interface
  -> Review compact mobile summary format

Installation Plan
  -> Waiting on architecture decision

TO-DID

Topic Lifecycle
  -> Stage/status/focus model consolidated
```

## 9.5 Device presentation

Mobile and desktop should display the same underlying state through different render profiles. Duplicated channels or mirrored records should be avoided because they create synchronization and maintenance risk.

| Mobile default | Desktop default |
| --- | --- |
| Compact status, needs-owner items, suggested next, short event log, direct action links. | Full branch table, richer recent log, detailed summary, artifacts, history, and related-topic map. |
| Short cards and progressive disclosure. | Expanded tables and comparative views. |
| Approval and routing decisions. | Detailed technical evidence and artifact inspection. |

A companion dashboard is justified only when Discord cannot provide the required information density, visualization, filtering, or interaction. It should be an extension opened by direct links, not a competing home platform.

# 10. Learning, Preferences, Rules, and Skills

## 10.1 Observations are intentionally weak

The system may automatically observe patterns, but an observation must not silently become a rule, preference, or skill. Observations enter a proposal queue and may mature into a topic when evidence or importance justifies discussion.

```text
OBSERVATION
The owner requested click-by-click technical guidance.

EVIDENCE
11 comparable interactions.

POSSIBLE INTERPRETATION
A reusable guided-deployment skill may be useful.

CURRENT EFFECT
None. Existing behavior remains unchanged.

RECOMMENDATION
Create Skill Topic in Discovery.
```

## 10.2 Shared workflow for system changes

Preferences, rules, skills, and automation policies use the same topic workflow as other work:

```text
Observation or manual proposal
  -> proposal queue
  -> topic created in Discovery
  -> scope and impact review
  -> Design / Planning as applicable
  -> validation or peer/model audit
  -> implementation
  -> active registry
  -> usage monitoring and periodic review
  -> inactive/archive/delete decision
```

## 10.3 Scope is mandatory

Every rule, preference, skill, and automation policy must declare where it applies. Candidate scopes include:

- Global
- Business or Personal
- Interview and discovery work
- Application development
- Writing and communication
- Discord presentation
- Email handling
- Specific HQ, initiative, project, topic type, application, or user population

The system should be able to identify a contextual exception without silently violating the active rule. It may ask to use a one-time exception or reopen the preference topic to refine the rule harness.

## 10.4 Lifecycle and decay

| State | Meaning |
| --- | --- |
| Proposed | An observation or user request has created a candidate topic; no operating effect. |
| Active | Approved and currently used within declared scope. |
| Inactive | Preserved but not applied; may be reactivated. |
| Archived | Retained for history and evidence but removed from normal operational views. |
| Deleted | Permanently removed when retention is unnecessary or harmful; should not be the default. |

A configurable inactivity threshold, initially proposed as 90 days, should trigger review rather than automatic deletion. The review should consider last application, continuing relevance, overlap, contradictions, recommendations, and whether the item should remain active, become inactive, merge with another item, or archive.

## 10.5 Recommendation-learning loop

```text
Evidence and observations
  -> coordinator recommendation with alternatives
  -> owner decision
  -> optional reason when the decision differs
  -> later outcome and reversal evidence
  -> calibrated future recommendations
```

Rejected ideas are useful evidence. The system may ask why a proposal was rejected and whether it should continue exploring improvements in that area or stop proposing similar changes until conditions change.

## 10.6 Knowledge organization

The learning layer should support broad knowledge categories and subcategories such as formatting, speech pattern, interview style, existing applications, business processes, data sources, people, decision history, and model/tool behavior. The taxonomy must be navigable through HQs while also supporting semantic retrieval across categories.

# 11. Automation, Approval, and Verification Harness

## 11.1 Approval should match the owner’s actual judgment

| Stage or decision type | Owner value | Preferred control |
| --- | --- | --- |
| Problem definition and desired outcome | High | Direct owner participation and approval. |
| Business process design and user behavior | High | Direct owner participation, comparisons, and acceptance criteria. |
| Architecture and implementation mechanics | Limited | Independent technical review, tests, and evidence; owner receives consequences in layman terms. |
| Result review and business acceptance | High | Owner reviews visible behavior, process effect, and whether the original problem is solved. |
| Production-risk actions | High consequence even when technical knowledge is limited | Explicit approval with business impact, verification evidence, rollback, and residual risk. |

## 11.2 Approval harness

The system should not ask the owner to certify technical details the owner cannot verify. Technical acceptance should come from a harness that may include:

- Independent model or peer review.
- Automated tests and regression checks.
- Static analysis, linting, type checking, and security scanning.
- Dependency and license checks.
- Database migration and rollback testing.
- Staging deployment and user-path validation.
- Comparison with the approved plan and scope.
- Audit evidence and explicit remaining risk.

```text
DECISION REQUIRED

Business effect
New quotes default to 30-day expiration; existing quotes remain unchanged.

Technical recommendation
Add a nullable expiration field and calculate it for new quotes.

Verification
- Architecture review: passed
- Security review: passed
- Migration test: passed
- Rollback test: passed

What the owner is approving
Business behavior and rollout effect, not the database implementation.

[Approve behavior] [Change behavior] [Open technical evidence]
```

## 11.3 Action-class automation policies

Automation should be learned separately by action class and scope. Initial policies may be conservative, then expand through accumulated evidence rather than one-off success.

| Action class | Initial policy | Potential mature policy |
| --- | --- | --- |
| Update internal topic status | Automatic | Automatic. |
| Create local child task | Automatic within approved scope | Automatic with event log. |
| Fold validated documentation into parent | Review initially | Automatic after repeated clean outcomes. |
| Add dependency or change architecture | Approval required | Likely remains approval-required. |
| Deploy to staging | Approval initially | Automatic after harness passes for low-risk applications. |
| Deploy to production | Approval required | Scope-specific; likely manual for customer-facing or sensitive systems. |
| Modify production data | Approval required | Manual except narrowly defined, reversible maintenance actions. |

When evidence is sufficient, the system creates an Automation Policy topic in Discovery. It does not silently widen authority.

## 11.4 Branching authority

A topic may create local supporting children automatically when the work is within scope, reversible, low risk, and necessary to complete the parent. It escalates upward when the discovered work changes parent assumptions, affects siblings, expands cost or time materially, creates a new category, or introduces external consequences.

# 12. Application Development Operating Model

## 12.1 Role-based lifecycle

The current stage model should be preserved while model names are configured separately. This avoids redesign whenever a provider or model changes.

| Lifecycle role | Purpose | Current mapping to validate |
| --- | --- | --- |
| Ideator | Explore the problem, goals, opportunity, and constraints. | Claude Code Opus 4.8. |
| Designer | Define user experience, system/process design, and architecture options. | Claude Code Opus 4.8. |
| Planner | Produce implementation-ready plan, dependencies, tests, and rollback. | Claude Code 'Fable' as currently described. |
| Builder | Execute the approved plan using bounded workers and isolated work areas. | Claude Code Opus 4.8 managing Sonnet agents. |
| Debugger | Diagnose failures, correct defects, and rerun validation. | Cursor. |
| Launch Auditor | Perform independent review, launch testing, and evidence package. | Hyperagent with Codex connection. |

Model/provider assignments are configuration, not workflow identity. A future planner or reviewer can change without changing the lifecycle or Discord organization.

## 12.2 Standard application pipeline

```text
Problem / idea
  -> Discovery and ideation
  -> Design
  -> Implementation plan
  -> Owner approves business behavior and scope
  -> Build in isolated branch/worktree
  -> Automated checks
  -> Debugging loop as needed
  -> Independent launch audit
  -> Owner reviews outcome
  -> Merge/deploy according to action policy
  -> Fold release and lessons into application hub
```

## 12.3 Parallel development and grouped branches

A project hub may spawn grouped topics for audits, features, or categories. The owner can manage at the group level or enter a specific defect when useful.

```text
Customer Portal
  -> Launch Audit
     -> Interface Issues
        -> Mobile navigation defect
        -> Quote card overflow
     -> Data and Logic Issues
     -> Performance Issues
     -> Security Issues
        -> Authentication timeout
        -> Missing authorization check
```

Results continually fold upward: focused issue to group, group to audit, audit to application hub. The application hub remains the principal place for status, recent events, suggested next, and stable-state assessment.

## 12.4 Context and artifact requirements

- Every build topic has an objective, approved scope, definition of done, branch/worktree, current checkpoint, tests, and next action.
- Plans, architecture decisions, and closeout summaries become repository artifacts rather than remaining only in chat.
- Review findings route directly to the responsible builder topic and retain reviewer independence.
- Worker sessions may be replaced without replacing the visible topic or losing the task state.
- The owner can monitor and approve from mobile, then inspect detailed evidence from PC when needed.

# 13. Business Operations, Data, Leads, and Calls

## 13.1 Business operating system, not only development system

The development workflow creates and maintains applications, but the larger system should also operate through those applications and their data. Business HQs can summarize performance, collect judgments, prompt actions, identify patterns, and create improvement topics.

## 13.2 Data HQ

Data HQ is the central operating area for global data imports, data connections, data-quality issues, source health, permissions, lineage, and topics that affect multiple business systems.

| Data HQ view | Representative content |
| --- | --- |
| Connections | Internal web tool MCP, CRM/lead source, call platform, advertising sources, email, application databases. |
| Health | Last sync, failures, stale data, schema changes, authentication status. |
| Permissions | Read/write boundaries, sensitive fields, approved actions, audit requirements. |
| Data topics | Missing call linkage, duplicate leads, attribution logic, transcript quality, metric definitions. |
| Global definitions | Authoritative customer, lead, call, campaign, employee, quote, order, and application identifiers. |

## 13.3 Lead, advertising, and call example

```text
Advertising and lead data arrives
  -> lead and call records are linked
  -> call transcript is available
  -> owner or employee receives a focused rating prompt
  -> rating and handling insight are stored
  -> trends appear in Leads and Calls HQ
  -> system identifies coaching, process, or application opportunity
  -> improvement topic enters Discovery
  -> approved change is built and deployed
  -> performance is measured again
```

The private AI operating system remains owner-only. An employee may rate a call or use a business application without accessing the owner’s private Discord, development topics, rules, or administrative controls.

## 13.4 MCP and connected company data

MCP or an equivalent tool interface can expose selected company data and actions to the coordinator and specialist agents. The first integration should be read-only and narrowly scoped. Write actions should be introduced by action class, evidence, and explicit approval policy.

- Every tool call should declare the source, requested action, permissions, and affected topic.
- Business data access should be logged and auditable.
- Sensitive fields should be minimized and domain-separated.
- Application development agents should not automatically inherit all operational data access.
- Operational insight topics should link back to the data and evidence that created them.

## 13.5 Mailroom

Mailroom should triage work and personal email separately while presenting both through the Executive Desk. It should classify importance, estimated effort, required action, deadline, topic/project relationship, and whether a draft or workflow can be prepared.

```text
WORK EMAIL
Customer complaint
Priority: High
Estimated owner effort: 5-10 minutes
Recommended action: Respond today
Related project: Customer Portal
Draft available: Yes

PERSONAL EMAIL
Mortgage broker requested documents
Priority: High
Estimated owner effort: 15 minutes
Recommended action: Complete tonight
```

# 14. Personal Operating Domain

## 14.1 Scope

The system must remain flexible enough to support personal planning without turning the private operating system into a business-only tool. Representative personal uses include travel planning, house search, cooking, personal writing, administrative tasks, and health-related questions.

## 14.2 Separation model

| Shared | Separated |
| --- | --- |
| Reception and overall Executive Desk frame. | Priority lists, topic hierarchy, memory, permissions, connected accounts, and sensitive records. |
| Navigation principles and workflow engine. | Business and Personal HQs, rules that have domain-specific scope, and data retention policies. |
| Skills that are explicitly global. | Operational data, application repositories, employee information, personal health or financial information. |

The user should be able to choose Business or Personal mode once, then work inside that priority list without evaluating the domain of every line item.

## 14.3 Personal HQ candidates

- Personal Administration HQ
- Travel HQ
- Home and Property HQ
- Personal Writing and Communication HQ
- Health and Wellness HQ with stricter privacy and action limits
- Personal Research and Purchases HQ

These are candidates for later interview, not approved channel or database structures.

# 15. Memory, Context, and Knowledge Architecture

## 15.1 Context should be invisible operationally

The owner should not decide when to compact a conversation or write a handoff message. Context management should occur behind the visible topic while preserving the same Discord location and project identity.

## 15.2 Required memory layers

| Layer | Purpose | Retention behavior |
| --- | --- | --- |
| Live worker context | Recent conversation, file reads, tool output, and immediate reasoning. | Temporary; compacted, pruned, or replaced as needed. |
| Topic checkpoint | Objective, original commitment, decisions, completed work, current state, next action, branch/files, and blockers. | Durable and refreshed at meaningful milestones. |
| Hub summary | Integrated state of children, recent events, suggested next, needs-owner, to-do/to-did, and stable-state assessment. | Durable and recalculated from child events and fold-back. |
| Semantic knowledge | Relevant observations, preferences, skills, relationships, historical decisions, and cross-topic knowledge. | Long-lived, searchable, scoped, and reviewable. |
| Artifact and event archive | Full plans, code, tests, transcripts, reports, evidence, and change history. | Retained according to provenance, sensitivity, and policy. |

## 15.3 Compaction and session replacement

```text
Worker context approaches limit
  -> refresh topic checkpoint
  -> preserve durable decisions and unresolved questions
  -> compact older dialogue or start a fresh worker session
  -> load global rules, scoped preferences/skills, topic checkpoint,
     relevant parent summary, repository/artifacts, and retrieved knowledge
  -> continue in the same visible topic
```

The task should survive even when a model session times out, fails, or is replaced. The operational record, not the model transcript, owns the current state.

## 15.4 Gbrain or provider-of-choice contract

Before selecting a knowledge provider, the design should specify the capabilities required from it:

- Store observations with provenance, date, category, confidence, and related objects.
- Represent relationships among people, applications, processes, rules, skills, decisions, and topics.
- Retrieve relevant knowledge by semantic meaning and explicit category.
- Respect Business, Personal, project, and sensitivity scopes.
- Track last applied, usage count, status, review date, and conflicts for rules/preferences/skills.
- Support inactive and archived states without deleting history.
- Expose references back to the authoritative topic, decision, artifact, or event.
- Permit export and migration so knowledge is not trapped in one provider.

> **Implementation rule:** The knowledge layer should enrich decisions and retrieval. It should not be allowed to overwrite authoritative workflow state or approved rules without the governed topic process.

# 16. Discord-First Platform Strategy

## 16.1 Why Discord is the preferred first interface

- The owner already understands Discord navigation and keeps it open for other purposes.
- It is available on phone, PC, and browser, reducing the initial interaction learning curve.
- Channels, forum-style posts, threads, links, bots, notifications, and permissions can represent an initial prototype.
- A manual clickable mockup can be built before the backend, host, and agent integrations exist.

Platform familiarity is a valid design advantage. Another platform should be selected only when a specific capability justifies the additional learning and migration cost.

## 16.2 Discord should remain a thin executive layer

Discord should display and control the system, not become its only database. A small number of permanent entrances should be used, while projects and topics are generated as linked posts, threads, or bot-rendered views backed by structured state.

## 16.3 Provisional server information architecture

```text
FRONT OFFICE
- reception
- executive-desk
- approvals
- alerts
- mailroom

BUSINESS
- business-hq
- application-development-hq
- data-hq
- leads-and-calls-hq
- operations-hq

PERSONAL
- personal-hq
- personal topic areas as discovered

OPERATING SYSTEM
- rules-hq
- preferences-hq
- skills-hq
- automation-hq
- system-health
```

This is a conceptual map, not a recommendation to create all channels immediately. The final prototype should minimize permanent channels and use bot-created topic views to prevent channel sprawl.

## 16.4 One visible coordinator

The default visible relationship should be between the owner and one coordinator identity. Specialist agents and providers may work behind the coordinator. The topic card can show the active role or provider without requiring the owner to visit separate Claude, Codex, reviewer, or researcher channels.

## 16.5 Companion dashboard boundary

A companion dashboard should be deferred until a Discord limitation is demonstrated. Valid reasons may include dense branch maps, advanced filtering, drag-and-drop planning, complex charts, timelines, architectural diagrams, or large audit evidence. Every off-platform view should be opened from a direct in-text link and return the user to the correct Discord hub or topic.

# 17. Recommended MVP and Rollout

## 17.1 Phase 0 — Design baseline and clickable prototype

- Review and revise this specification through bounded interview rounds.
- Define Business, Personal, and Operating System HQ taxonomy.
- Create a manual Discord prototype with Reception, Executive Desk, one HQ, one project hub, and several nested topics.
- Simulate interruption routing, blocker creation, focus switching, fold-back, to-do/to-did, recent events, and mobile presentation.
- Validate the experience before selecting backend tools or purchasing the final host.

## 17.2 Phase 1 — Durable state and navigation

- Create the structured operational data model.
- Implement Discord bot rendering for hubs, topics, breadcrumbs, status, and links.
- Support manual topic creation, stage/status changes, recent events, and closeout.
- No autonomous model work is required to prove the operating experience.

## 17.3 Phase 2 — One application-development workflow

- Migrate one pilot application and its repository to the dedicated host.
- Implement Ideator, Designer, Planner, Builder, Debugger, and Launch Auditor roles.
- Automate checkpoints, build/test evidence, reviewer feedback, and fold-back.
- Reach or exceed current productivity on the pilot before adding new domains.

## 17.4 Phase 3 — Learning and knowledge

- Add observation capture and candidate topics for preferences, skills, rules, and automation policies.
- Integrate Gbrain or another provider against the defined memory contract.
- Implement usage tracking, contextual exceptions, inactivity review, and active/inactive/archive states.

## 17.5 Phase 4 — Business operations

- Connect the internal company tool through read-only MCP or equivalent interfaces.
- Create Data HQ, Mailroom, Leads and Calls HQ, and the first operational dashboards.
- Implement call-transcript rating, insight, and improvement-topic loops.
- Introduce write actions only through scoped automation policies and evidence.

## 17.6 Phase 5 — Personal domain and expansion

- Add personal HQs, data boundaries, and selected integrations.
- Add local models or retired worker computers only for proven workloads.
- Consider a companion web dashboard only for demonstrated Discord limitations.

> **Hardware sequencing:** The final host computer should be the deployment target for a prepared design, scripts, accounts, prototype, pilot repository, and validation checklist—not the beginning of discovery.

# 18. Success Measures, Risks, and Guardrails

## 18.1 Success measures

| Measure | Target direction |
| --- | --- |
| Time to resume after interruption or device switch | Decreases; user reaches current state and next action without rereading long chat history. |
| Ideas lost before classification | Approaches zero for captured input. |
| Active topics without a current checkpoint | Approaches zero. |
| Manual context handoff messages written by owner | Approaches zero. |
| Jobs with visible working/waiting/blocked/failed status | Approaches 100 percent. |
| Completed child topics not folded back | Low and automatically surfaced. |
| Approvals where owner can make a meaningful judgment | Increases; ceremonial technical approvals decrease. |
| Protocol steps administered manually by owner | Decreases. |
| Work and personal priority decisions per session | Owner chooses domain once rather than per item. |
| Application changes tied back to measured business insight | Increases over time. |

## 18.2 Principal risks and mitigations

| Risk | Mitigation |
| --- | --- |
| Topic and channel sprawl | Observation threshold, recursive fold-back, stable-state review, minimal permanent Discord channels. |
| Automation exceeds trust | Action-class policies, evidence thresholds, explicit scopes, reversible actions, independent verification. |
| False technical confidence | Harness-based evidence, independent review, layman impact summaries, residual-risk statements. |
| Memory contamination across domains | Business/Personal scopes, permission separation, provenance, authoritative-store boundaries. |
| Notification overload | Needs-owner filtering, scheduled summaries, compact breadcrumbs, event importance thresholds. |
| Vendor lock-in | Role-based model configuration, memory contract, structured operational store, exportable artifacts and Git. |
| System becomes a hobby instead of a tool | Pilot application success gate; defer local-model network, broad integrations, and complex dashboards. |
| User overrides protocol repeatedly | Explain consequences, request rationale, log deviations, revisit rule/skill/topic design. |
| Discord reaches presentation limits | Progressive disclosure and direct-linked companion view only when a specific limitation is proven. |

# 19. Open Design Questions and Interview Backlog

Discovery is not complete. The next interview program should use one or two bounded comparison questions per round, state the design objective, show what the answer changes, and avoid broad requests to enumerate an entire day or life domain.

## 19.1 Priority interview topics

| Priority | Design topic | Decision required |
| --- | --- | --- |
| 1 | Business HQ taxonomy | Which permanent Business HQs are needed, what belongs in each, and which should be views rather than channels. |
| 2 | Executive Desk information density | Exact mobile and desktop card order, default collapsed sections, and recent-event thresholds. |
| 3 | Topic-creation threshold | When evidence remains an observation versus becoming a child, sibling, parent-level, or blocking topic. |
| 4 | Priority and suggested-next model | How urgency, value, effort, risk, dependency, work/personal mode, and owner energy affect recommendations. |
| 5 | Application development harness | Definition of done, approval points, evidence, rollback, audit, and tool/model role configuration. |
| 6 | Memory contract and Gbrain fit | Required schemas, retrieval, provenance, review, decay, portability, and integration constraints. |
| 7 | Data and MCP authorization | Read/write boundaries, sensitive fields, app-specific access, logging, and action classes. |
| 8 | Leads, ads, and calls operating loop | Sources, call-rating experience, metrics, insights, employee role, and improvement routing. |
| 9 | Mailroom | Priority/effort classification, drafting, follow-up, work/personal separation, and escalation. |
| 10 | Personal HQ scope | Which personal use cases justify permanent structures versus ad hoc topics. |
| 11 | Discord prototype | Permanent entrances, forum/thread behavior, navigation link format, and mock workflows. |
| 12 | Notification policy | Immediate alerts versus digest, mobile push behavior, quiet periods, and failures. |

## 19.2 Recommended next design topic

> **Recommendation:** Use this document as the parent hub, then open a focused Business HQ Taxonomy topic. That topic should identify the smallest useful set of permanent HQs before the Discord prototype is built. Its conclusions should fold back into Version 0.2.

# Appendix A. Consolidated Requirements

The following register supersedes the informal requirement numbering used during conversation. Status is Confirmed unless marked Provisional.

| ID | Requirement |
| --- | --- |
| EX-01 | Reception accepts unstructured input without prior classification. |
| EX-02 | The Executive Desk presents recent context, recent events, suggested next, and a full summary path. |
| EX-03 | Business and Personal priority lists remain segregated inside one unified dashboard frame. |
| EX-04 | One visible coordinator represents specialist agents and providers. |
| EX-05 | The owner can operate interchangeably from phone and PC. |
| EX-06 | Mobile and desktop render the same structured data differently; duplicated channels are not the default. |
| EX-07 | Progress is represented through verified stages, status, blockers, and next actions rather than narrative text alone. |
| EX-08 | The owner receives layman-oriented consequences and click-by-click guidance when performing technical work. |
| EX-09 | The interface uses compact breadcrumbs on coordinator messages and richer navigation on operational messages. |
| EX-10 | Every focused view provides direct routes to parent, children, related topics, prior location, and hub. |
| ORG-01 | The hierarchy supports Domain, HQ/Category, Initiative/Project, Topic/Group, and Task/Focused Issue. |
| ORG-02 | Every meaningful object can act as a recursive hub with children and an integrated summary. |
| ORG-03 | Categories and subcategories coexist with hierarchy, stage, status, and focus. |
| ORG-04 | To-do and to-did lists use a layered topic-plus-next-action format. |
| ORG-05 | A hub with excessive unresolved children triggers housekeeping review. |
| ORG-06 | Employees use purpose-built applications, not the private owner operating environment. |
| WF-01 | Topics persist while stage labels change; stages are state rather than separate locations. |
| WF-02 | Stages may skip, repeat, or move backward as understanding changes. |
| WF-03 | Stage, operational status, and interaction focus are independent dimensions. |
| WF-04 | Every new topic receives a context-preserving kickoff record. |
| WF-05 | Every completed child produces a closeout package and folds accepted outcomes into its parent. |
| WF-06 | Blocking topics are advisory but explicit; owner override remains possible with consequences shown. |
| WF-07 | The system preserves pause, return, and impact state during focus switches. |
| WF-08 | One topic is normally foreground while multiple topics may work in background or queue. |
| WF-09 | Interjections are classified as immediate change, observation, child, sibling/parent, or blocker. |
| WF-10 | When multiple classifications are valid, the system recommends one and presents meaningful alternatives. |
| WF-11 | The system requests rationale selectively when the owner chooses differently, then calibrates future recommendations. |
| WF-12 | The coordinator manages protocol and housekeeping rather than relying on the owner to administer them. |
| LRN-01 | Observations may be automatic but are weak evidence with no immediate operating effect. |
| LRN-02 | Preferences, rules, skills, and automation policies use the same governed topic workflow. |
| LRN-03 | Every preference, rule, skill, and policy declares scope. |
| LRN-04 | The coordinator may propose a contextual exception or reopen a preference topic rather than silently violate a rule. |
| LRN-05 | Active, inactive, archived, and deleted states are supported; deletion is not the default. |
| LRN-06 | Inactivity triggers review rather than automatic removal; 90 days is a provisional initial threshold. |
| LRN-07 | Rejected ideas and owner rationale remain learning evidence. |
| LRN-08 | Knowledge is organized by categories and subcategories while supporting semantic retrieval. |
| AUT-01 | Approval requirements are learned and configured by action class and scope. |
| AUT-02 | Automation expands through accumulated evidence and a reviewed policy topic, not silent adoption. |
| AUT-03 | Technical verification uses tests, independent review, security checks, staging, rollback, and plan comparison. |
| AUT-04 | Owner approvals focus on problem, process, business effect, outcome, and consequential risk. |
| AUT-05 | Local child tasks may be created automatically within scope; cross-cutting or high-impact work escalates. |
| AUT-06 | The owner may override recommendations when allowed; the system records reason and consequences. |
| APP-01 | Application stages are role-based so models and providers can be replaced independently. |
| APP-02 | Plans, decisions, tests, reviews, and closeouts become durable repository or artifact records. |
| APP-03 | Independent review remains separate from the builder. |
| APP-04 | Worker sessions can fail, compact, or be replaced without losing the visible topic or operational state. |
| BUS-01 | The system both builds applications and operates the business through connected applications and data. |
| BUS-02 | Data HQ manages global connections, health, permissions, definitions, and cross-system data topics. |
| BUS-03 | Lead, ad, call, transcript, rating, insight, and improvement workflows form a closed operational loop. |
| BUS-04 | MCP or equivalent access begins read-only and expands through scoped action policies. |
| BUS-05 | Mailroom triages work and personal email separately while presenting both in the Executive Desk. |
| PER-01 | Personal use remains a first-class domain rather than an afterthought. |
| PER-02 | Personal and Business memory, permissions, records, and priority queues remain separated. |
| MEM-01 | Operational state, Git artifacts, semantic knowledge, transcripts, and files have separate authoritative stores. |
| MEM-02 | The topic checkpoint is the durable resumption record outside live model context. |
| MEM-03 | Context compaction and worker replacement occur behind the same visible topic. |
| MEM-04 | The knowledge provider must support provenance, scope, relationships, usage, status, review, and export. |
| PLAT-01 | Discord is the preferred first interface because of familiarity and cross-device availability. |
| PLAT-02 | Discord is not the sole database or source of truth. |
| PLAT-03 | A companion dashboard is added only for demonstrated Discord limitations. |
| PLAT-04 | The operating model remains portable across Discord, model providers, memory providers, and host infrastructure. |

# Appendix B. Glossary

| Term | Working definition |
| --- | --- |
| Reception | Universal, low-friction entry point for any business or personal input. |
| Executive Desk | Global reconnect and control view combining context, separate priority lists, recent events, suggested next, and navigation. |
| HQ | Central management area for a recurring operational domain, category, or registry. |
| Initiative / Project | Committed outcome that supervises related topics and seeks a stable or completed state. |
| Topic | Durable body of thought or work that retains context while moving among stages. |
| Task | Concrete action, check, or decision within a topic. |
| Observation | Unconfirmed evidence that may later justify a preference, skill, rule, policy, or work topic. |
| Stage | Maturity of work: Discovery, Design, Planning, Execution, Validation, Integration, or Archived. |
| Status | Operational condition: Working, Waiting, Needs Owner, Blocked, Paused, Failed, or Completed. |
| Focus | Interaction prominence: Foreground, Background, Queued, or Parked. |
| Fold-back | Integration of a completed child outcome into its parent summary, decisions, plans, and next action. |
| Stable state | Condition in which accepted child outcomes are integrated, blockers and needs-owner items are handled, and the hub summary matches reality. |
| Rule | Approved required behavior or operating constraint. |
| Preference | Approved user-experience preference with defined scope and possible exceptions. |
| Skill | Approved reusable procedure or ability with trigger, inputs, steps, outputs, and validation. |
| Harness | Deterministic checks, permissions, tests, reviews, evidence, and rollback that make automation trustworthy. |
| To-Did | Completed work presented as visible progress and retained history. |

> **End of Version 0.1:** This draft is the first consolidated parent record. It is intentionally incomplete. The next versions should be driven by bounded interview topics and fold their conclusions back into this document.
