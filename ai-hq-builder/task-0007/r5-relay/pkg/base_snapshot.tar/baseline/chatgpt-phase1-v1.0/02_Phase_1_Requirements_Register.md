# Phase 1 Requirements Register

**Status:** Candidate baseline pending audit

| ID | Requirement | Status | Audit disposition |
| --- | --- | --- | --- |
| APP-01 | Application stages are role-based so models and providers can be replaced independently. | Confirmed Phase 1 | Pending audit |
| APP-02 | Plans, decisions, tests, reviews, and closeouts become durable repository or artifact records. | Confirmed Phase 1 | Pending audit |
| APP-03 | Independent review remains separate from the builder. | Confirmed Phase 1 | Pending audit |
| APP-04 | Worker sessions can fail, compact, or be replaced without losing the visible topic or operational state. | Confirmed Phase 1 | Pending audit |
| ATT-01 | Critical interruption is reserved for immediate physical, legal, financial, security, or comparably consequential danger. | Confirmed Phase 1 | Pending audit |
| ATT-02 | Needs Attention requests a response through badges, mentions, and queues without forcibly switching the foreground topic. | Confirmed Phase 1 | Pending audit |
| ATT-03 | Successful background completion and useful non-blocking improvements appear as hub updates; safe retries and first overdue reminders default to briefing. | Confirmed Phase 1 | Pending audit |
| AUD-01 | Phase 1 must pass independent multi-agent audit and owner-approved consensus before Decision Engine discovery begins. | Confirmed Phase 1 | Pending audit |
| AUD-02 | Critical audit findings must be resolved; high-severity findings must be resolved or explicitly accepted with rationale. | Confirmed Phase 1 | Pending audit |
| AUT-01 | Approval requirements are learned and configured by action class and scope. | Confirmed Phase 1 | Pending audit |
| AUT-02 | Automation expands through accumulated evidence and a reviewed policy topic, not silent adoption. | Confirmed Phase 1 | Pending audit |
| AUT-03 | Technical verification uses tests, independent review, security checks, staging, rollback, and plan comparison. | Confirmed Phase 1 | Pending audit |
| AUT-04 | Owner approvals focus on problem, process, business effect, outcome, and consequential risk. | Confirmed Phase 1 | Pending audit |
| AUT-05 | Local child tasks may be created automatically within scope; cross-cutting or high-impact work escalates. | Confirmed Phase 1 | Pending audit |
| AUT-06 | The owner may override recommendations when allowed; strong informational friction explains likely consequences before the override is accepted. | Confirmed Phase 1 | Pending audit |
| AUT-07 | Delegation transfers execution but not accountability; the coordinator tracks the assignment through closeout. | Confirmed Phase 1 | Pending audit |
| AUT-08 | Delegation and follow-up policies are scoped by person, assignment type, sensitivity, and consequence. | Confirmed Phase 1 | Pending audit |
| AUT-09 | A completion claim resolves as verified completion, owner-accepted completion, or needs review. | Confirmed Phase 1 | Pending audit |
| AUT-10 | Automatic verification begins as read-only evidence inspection; employee-facing corrective follow-up requires owner control unless a scoped policy authorizes it. | Confirmed Phase 1 | Pending audit |
| AUT-11 | Completed work is reconciled against later evidence without erasing the original To-Did history. | Confirmed Phase 1 | Pending audit |
| BUS-01 | The system both builds applications and operates the business through connected applications and data. | Confirmed Phase 1 | Pending audit |
| BUS-02 | Data HQ manages global connections, health, permissions, definitions, and cross-system data topics. | Confirmed Phase 1 | Pending audit |
| BUS-03 | Lead, ad, call, transcript, rating, insight, and improvement workflows form a closed operational loop. | Confirmed Phase 1 | Pending audit |
| BUS-04 | MCP or equivalent access begins read-only and expands through scoped action policies. | Confirmed Phase 1 | Pending audit |
| BUS-05 | Mailroom triages work and personal email separately while presenting both in the Executive Desk. | Confirmed Phase 1 | Pending audit |
| BUS-06 | Business uses a hybrid organization: functional HQs provide cross-system views while major systems retain authoritative hubs. | Confirmed Phase 1 | Pending audit |
| BUS-07 | Discord is the lightweight pilot and attention layer; purpose-built applications provide full structured workspaces and operational records. | Confirmed Phase 1 | Pending audit |
| BUS-08 | Business applications own operational facts; the AI operating system owns coordination, attention, assignments, decisions, and verification state. | Confirmed Phase 1 | Pending audit |
| BUS-09 | Linked functional views do not create competing copies of source records. | Confirmed Phase 1 | Pending audit |
| DEC-01 | Decision Engine discovery is the Phase 2 parent topic and must separate intelligent recommendations from approved policy decisions as a hypothesis to test. | Confirmed Phase 1 | Pending audit |
| EX-01 | Reception accepts unstructured input without prior classification. | Confirmed Phase 1 | Pending audit |
| EX-02 | The Executive Desk presents recent context, recent events, suggested next, and a full summary path. | Confirmed Phase 1 | Pending audit |
| EX-03 | Business and Personal priority lists remain segregated inside one unified dashboard frame. | Confirmed Phase 1 | Pending audit |
| EX-04 | One visible coordinator represents specialist agents and providers. | Confirmed Phase 1 | Pending audit |
| EX-05 | The owner can operate interchangeably from phone and PC. | Confirmed Phase 1 | Pending audit |
| EX-06 | Mobile and desktop render the same structured data differently; duplicated channels are not the default. | Confirmed Phase 1 | Pending audit |
| EX-07 | Progress is represented through verified stages, status, blockers, and next actions rather than narrative text alone. | Confirmed Phase 1 | Pending audit |
| EX-08 | The owner receives layman-oriented consequences and click-by-click guidance when performing technical work. | Confirmed Phase 1 | Pending audit |
| EX-09 | The interface uses compact breadcrumbs on coordinator messages and richer navigation on operational messages. | Confirmed Phase 1 | Pending audit |
| EX-10 | Every focused view provides direct routes to parent, children, related topics, prior location, and hub. | Confirmed Phase 1 | Pending audit |
| HW-01 | The current hardware baseline is M4 Max Mac Studio with 64GB unified memory and 1-2TB storage, subject to revalidation immediately before purchase. | Confirmed Phase 1 | Pending audit |
| INT-01 | Decision prompts expose genuine tradeoffs, calibrate boundaries, or state an expert default; they do not use an obvious progressive-completeness ladder. | Confirmed Phase 1 | Pending audit |
| LRN-01 | Observations may be automatic but are weak evidence with no immediate operating effect. | Confirmed Phase 1 | Pending audit |
| LRN-02 | Preferences, rules, skills, and automation policies use the same governed topic workflow. | Confirmed Phase 1 | Pending audit |
| LRN-03 | Every preference, rule, skill, and policy declares scope. | Confirmed Phase 1 | Pending audit |
| LRN-04 | The coordinator may propose a contextual exception or reopen a preference topic rather than silently violate a rule. | Confirmed Phase 1 | Pending audit |
| LRN-05 | Active, inactive, archived, and deleted states are supported; deletion is not the default. | Confirmed Phase 1 | Pending audit |
| LRN-06 | Inactivity triggers review rather than automatic removal; 90 days is a provisional initial threshold. | Confirmed Phase 1 | Pending audit |
| LRN-07 | Rejected ideas and owner rationale remain learning evidence. | Confirmed Phase 1 | Pending audit |
| LRN-08 | Knowledge is organized by categories and subcategories while supporting semantic retrieval. | Confirmed Phase 1 | Pending audit |
| MEM-01 | Operational state, Git artifacts, semantic knowledge, transcripts, and files have separate authoritative stores. | Confirmed Phase 1 | Pending audit |
| MEM-02 | The topic checkpoint is the durable resumption record outside live model context. | Confirmed Phase 1 | Pending audit |
| MEM-03 | Context compaction and worker replacement occur behind the same visible topic. | Confirmed Phase 1 | Pending audit |
| MEM-04 | The knowledge provider must support provenance, scope, relationships, usage, status, review, and export. | Confirmed Phase 1 | Pending audit |
| ORG-01 | The hierarchy supports Domain, HQ/Category, Initiative/Project, Topic/Group, and Task/Focused Issue. | Confirmed Phase 1 | Pending audit |
| ORG-02 | Every meaningful object can act as a recursive hub with children and an integrated summary. | Confirmed Phase 1 | Pending audit |
| ORG-03 | Categories and subcategories coexist with hierarchy, stage, status, and focus. | Confirmed Phase 1 | Pending audit |
| ORG-04 | To-do and to-did lists use a layered topic-plus-next-action format. | Confirmed Phase 1 | Pending audit |
| ORG-05 | A hub with excessive unresolved children triggers housekeeping review. | Confirmed Phase 1 | Pending audit |
| ORG-06 | Employees use purpose-built applications, not the private owner operating environment. | Confirmed Phase 1 | Pending audit |
| PER-01 | Personal use remains a first-class domain rather than an afterthought. | Confirmed Phase 1 | Pending audit |
| PER-02 | Personal and Business memory, permissions, records, and priority queues remain separated. | Confirmed Phase 1 | Pending audit |
| PLAT-01 | Discord is the preferred first interface because of familiarity and cross-device availability. | Confirmed Phase 1 | Pending audit |
| PLAT-02 | Discord is not the sole database or source of truth. | Confirmed Phase 1 | Pending audit |
| PLAT-03 | A companion dashboard is added only for demonstrated Discord limitations. | Confirmed Phase 1 | Pending audit |
| PLAT-04 | The operating model remains portable across Discord, model providers, memory providers, and host infrastructure. | Confirmed Phase 1 | Pending audit |
| WF-01 | Topics persist while stage labels change; stages are state rather than separate locations. | Confirmed Phase 1 | Pending audit |
| WF-02 | Stages may skip, repeat, or move backward as understanding changes. | Confirmed Phase 1 | Pending audit |
| WF-03 | Stage, operational status, and interaction focus are independent dimensions. | Confirmed Phase 1 | Pending audit |
| WF-04 | Every new topic receives a context-preserving kickoff record. | Confirmed Phase 1 | Pending audit |
| WF-05 | Every completed child produces a closeout package and folds accepted outcomes into its parent. | Confirmed Phase 1 | Pending audit |
| WF-06 | Blocking is advisory but explicit; an override requires a consequence summary and explicit acknowledgment for ordinary design work. | Confirmed Phase 1 | Pending audit |
| WF-07 | The system preserves pause, return, and impact state during focus switches. | Confirmed Phase 1 | Pending audit |
| WF-08 | One topic is normally foreground while multiple topics may work in background or queue. | Confirmed Phase 1 | Pending audit |
| WF-09 | Interjections are classified as immediate change, observation, child, sibling/parent, or blocker. | Confirmed Phase 1 | Pending audit |
| WF-10 | When multiple classifications are genuinely valid, the system recommends one, presents meaningful alternatives, and records the owner selection. | Confirmed Phase 1 | Pending audit |
| WF-11 | The system requests rationale selectively when the owner chooses differently, then calibrates future recommendations. | Confirmed Phase 1 | Pending audit |
| WF-12 | The coordinator manages protocol and housekeeping rather than relying on the owner to administer them. | Confirmed Phase 1 | Pending audit |
