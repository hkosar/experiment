# Phase 1 Vocabulary and Object Model

## Structural hierarchy

```text
Domain
  -> HQ / Category
     -> Initiative / Project / Authoritative System Hub
        -> Topic / Group
           -> Task / Focused Issue
```

The hierarchy is recursive: any meaningful object may supervise children and maintain an integrated summary.

## Core terms

| Term | Definition |
| --- | --- |
| Reception | Low-friction universal entry point; the user does not classify before capture. |
| Executive Desk | Global reconnect view with recent context, separate Business/Personal priorities, Needs Attention, background work, and navigation. |
| HQ | Recurring operational management area with a dashboard, registry, summaries, and linked views. |
| Authoritative system hub | Canonical home for one major application or business system. |
| Initiative / Project | Committed outcome seeking a stable or completed state. |
| Topic | Durable body of thought or work that retains identity as stage/status/focus change. |
| Task | Concrete action, check, or decision within a topic. |
| Observation | Weak evidence with no immediate operating effect. |
| Stage | Maturity: Discovery, Design, Planning, Execution, Validation, Integration, Archived. |
| Status | Operational condition: Working, Waiting, Needs Attention, Blocked, Paused, Failed, Completed. |
| Focus | Interaction prominence: Foreground, Background, Queued, Parked. |
| Fold-back | Integration of accepted child outcomes into the parent’s state, artifacts, and suggested next action. |
| Stable state | Children integrated, blockers handled, summary accurate, and next action valid. |
| Preference | Scoped approved experience preference. |
| Rule | Scoped approved required behavior or constraint. |
| Skill | Scoped reusable process with trigger, steps, outputs, and validation. |
| Harness | Deterministic tests, permissions, reviews, evidence, and rollback supporting trustworthy automation. |
| To-Did | Completed work retained as visible progress and history. |
