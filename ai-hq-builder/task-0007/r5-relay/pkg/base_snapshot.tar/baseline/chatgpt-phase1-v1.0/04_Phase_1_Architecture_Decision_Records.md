# Phase 1 Architecture Decision Records

**Status:** Candidate baseline pending audit

## ADR-001 — Discord-first executive interface

**Status:** Accepted for Phase 1

### Decision

Use Discord as the preferred initial front door because it is familiar, cross-device, and already part of the owner’s life. Keep authoritative state outside Discord.

### Alternatives considered

A custom web application, Slack, email-first interaction.

### Consequences

Lower adoption friction; Discord limitations may justify linked companion views later.

## ADR-002 — Recursive hub-and-branch model

**Status:** Accepted for Phase 1

### Decision

Use the same hub pattern at Executive Desk, HQ, project, topic/group, and task levels. Children fold accepted results into parents.

### Alternatives considered

Flat task lists; one channel per project; separate object models at every level.

### Consequences

Scales navigation and preserves context, but requires disciplined summaries and parent-child state.

## ADR-003 — Persistent topics with mutable stage

**Status:** Accepted for Phase 1

### Decision

A topic remains the same conversational/work object while Discovery, Design, Planning, Execution, Validation, and Integration labels change or repeat.

### Alternatives considered

Separate stage folders or new conversations for each stage.

### Consequences

Preserves continuity and matches nonlinear work.

## ADR-004 — Separate Business and Personal queues

**Status:** Accepted for Phase 1

### Decision

Present both domains on one Executive Desk but keep priority, permissions, memory, and records separated.

### Alternatives considered

One fully mixed priority list; completely separate applications.

### Consequences

Owner selects mode once rather than on every line while retaining unified awareness.

## ADR-005 — Hybrid Business organization

**Status:** Accepted for Phase 1

### Decision

Use functional HQs for cross-system oversight and authoritative system hubs for each major application or operating system.

### Alternatives considered

Function-only or system-only organization.

### Consequences

Avoids duplication while supporting both operational and application perspectives.

## ADR-006 — Split ownership of truth

**Status:** Accepted for Phase 1

### Decision

Business applications own operational facts. The AI operating system owns attention, coordination, assignment, policy, and verification state.

### Alternatives considered

Duplicate all business records inside the AI OS; keep AI OS notification-only.

### Consequences

Prevents competing truth while allowing active management.

## ADR-007 — Governed system learning

**Status:** Accepted for Phase 1

### Decision

Observations may be automatic, but preferences, rules, skills, and automation changes must enter a scoped topic workflow before becoming active.

### Alternatives considered

Silent self-modification; manual-only learning.

### Consequences

Supports improvement without unpredictable behavior.

## ADR-008 — Evidence-based automation expansion

**Status:** Accepted for Phase 1

### Decision

Automation authority expands by action class and scope after repeated successful outcomes and policy review.

### Alternatives considered

Static manual approval forever; automatic expansion after one success.

### Consequences

Balances autonomy and trust.

## ADR-009 — Attention without forced interruption

**Status:** Accepted for Phase 1

### Decision

Use Needs Attention, hub updates, and briefings for most events. Reserve forced interruption for critical consequences.

### Alternatives considered

Interrupt on every decision; digest everything.

### Consequences

Protects focus while preserving awareness.

## ADR-010 — Strong informational friction for blocker overrides

**Status:** Accepted for Phase 1

### Decision

Show reasons, consequences, and likely invalidated work before permitting a blocker override.

### Alternatives considered

Low-friction override; unbreakable workflow gate.

### Consequences

Supports owner authority while preventing impulsive protocol abandonment.

## ADR-011 — M4 Max host baseline

**Status:** Provisional until purchase

### Decision

Use M4 Max 64GB and 1-2TB as the current host target. Reconsider M3 Ultra if large local inference is a production requirement.

### Alternatives considered

Cheap retired mini PC; M3 Ultra from the outset.

### Consequences

Balances cloud-first orchestration, local capacity, cost, and future expansion.

## ADR-012 — Audit gate before Decision Engine

**Status:** Accepted

### Decision

Freeze the Phase 1 candidate baseline, run independent audits, synthesize consensus, and only then begin Phase 2.

### Alternatives considered

Continue discovery without consolidation; accept Phase 1 without review.

### Consequences

Prevents contradictions from propagating into the system kernel.
