# Consensus Synthesis Template

## Overall recommendation

- [ ] Accept Phase 1 as Version 1.1
- [ ] Accept after listed changes
- [ ] Do not begin Phase 2

## Critical findings

| Finding | Auditor(s) | Consensus disposition | Required change | Owner decision |
| --- | --- | --- | --- | --- |

## High findings

| Finding | Auditor(s) | Consensus disposition | Required change or accepted risk | Owner decision |
| --- | --- | --- | --- | --- |

## Genuine disagreements

| Issue | Position A and cost | Position B and cost | Synthesis recommendation |
| --- | --- | --- | --- |

## Changes to apply together

- Operating Manual:
- Requirements Register:
- ADRs:
- Glossary/Object Model:
- Backlog:
- Conversation Decision Trail addendum:

## Phase 2 gate

- [ ] No unresolved Critical findings.
- [ ] High findings resolved or explicitly accepted.
- [ ] Owner approved consensus.
- [ ] Version 1.1 published.
- [ ] Decision Engine parent topic may open.
