# Source Notes

External factual verification was intentionally minimized because this packet primarily consolidates owner requirements and design reasoning.

Hardware baseline was checked against:

- Apple, “Mac Studio — Technical Specifications,” accessed July 24, 2026.
- Apple Newsroom, “Apple unveils new Mac Studio ... featuring M4 Max and M3 Ultra,” March 5, 2025; accessed July 24, 2026.

The hardware recommendation must be revalidated immediately before purchase.
