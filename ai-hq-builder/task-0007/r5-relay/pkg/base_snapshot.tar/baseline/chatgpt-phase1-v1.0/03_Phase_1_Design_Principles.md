# Phase 1 Design Principles

| ID | Principle |
| --- | --- |
| DP-001 | The user produces thoughts; the system organizes them. |
| DP-002 | Convert scattered thinking into organized, durable execution. |
| DP-003 | Preserve uncertainty until sufficient evidence supports classification or commitment. |
| DP-004 | Separate information from presentation; mobile and desktop are views of the same state. |
| DP-005 | Business and Personal remain separate priority queues inside one unified status frame. |
| DP-006 | Topics persist while stage, status, and focus change. |
| DP-007 | Allow one foreground context and multiple visible background contexts without losing return state. |
| DP-008 | Every branch preserves origin context and accepted results fold back upward. |
| DP-009 | Optimize for resumption and situational awareness, not notification volume. |
| DP-010 | Embed navigation so the owner can move up, down, sideways, and back through the idea network. |
| DP-011 | Recommendations explain alternatives and improve from owner rationale and later outcomes. |
| DP-012 | Observations are evidence, not automatic rules. |
| DP-013 | Rules, preferences, skills, and automation policies mature through the same governed workflow. |
| DP-014 | Automation expands through demonstrated trust, scope, evidence, and review. |
| DP-015 | Use technical verification harnesses where owner expertise is not a meaningful approval control. |
| DP-016 | Delegation transfers execution, not accountability. |
| DP-017 | Protocol is maintained by the system; permitted overrides require visible consequences. |
| DP-018 | Decision prompts must expose real tradeoffs rather than obvious answer ladders. |
| DP-019 | Discord is the familiar executive interface, not the sole source of truth. |
| DP-020 | Models, memory providers, and tools are replaceable role implementations, not permanent workflow identities. |
