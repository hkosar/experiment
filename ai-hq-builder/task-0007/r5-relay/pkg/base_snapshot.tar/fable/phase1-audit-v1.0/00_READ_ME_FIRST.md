# READ ME FIRST — Fable Phase 1 Review and Version 1.1 Packet

## Status

**Version 1.3 is the ACCEPTED operating baseline** — v1.1 accepted 2026-07-25 (decision-trail entry 53; AUD-01 gate passed) and the v1.2 layer (CP-v1.2-A) released by two-step compare-and-swap (trail entry 59) and accepted by the owner 2026-07-27 (trail entry 65, echoing receipt commit `19c3612974b86413bd8eecac333bb7b3ad9d2c5e`). The v1.1 process record: 7-role independent audit → adversarial verification → consensus synthesis → owner realignment → 10-scenario experience walkthrough → ChatGPT peer verification (zero dissents) → H-08 canonical-state erratum. The v1.3 layer (CP-v1.2-B, TASK-0002 — the Nate Herk adoption) was released (trail entry 72) and **accepted by the owner 2026-07-28 (trail entry 73)**. **Phase 2 (Decision Engine discovery) is OPEN.**

## Recommended reading order

1. `01_Fable_Consulting_Assessment.md` — the verdict and what the findings mean, in concept language.
2. `10_Concept_Experience_Walkthrough.md` — ten day-in-the-life scenarios; the owner-facing review surface where decisions D1–D9 live in context.
3. `04_Proposed_Operating_Manual_v1.1.md` — the revised baseline (all changes marked *(v1.1)* with consensus IDs).
4. `07_Change_Log_v1.0_to_v1.1.md` — everything that changed and why, plus the scenario regression check.
5. `02_Consensus_Issue_Register.md` / `.csv` — all 49 consensus entries + G-01..G-03, with verifier and manager dispositions.
6. `05_Requirements_Register_v1.1.md` / `.csv` — the authoritative requirement register: **104 accepted v1.1 + 7 accepted v1.2 (trail entry 65) + 14 accepted v1.3 (trail entry 73) = 125 accepted rows**.
7. `03_Auditor_Reports/` — the seven independent audit reports, refuted-findings record, and the verifier's response verbatim.
8. `06_Decision_Trail_Addendum.md` — entries 41+ continuing the original conversation decision trail.
9. `08_Peer_Review_Response_for_ChatGPT.md` — the document that went to the verifier (Rev 2).
10. `09_Deferred_Inspiration_Backlog.md` / `09a` — the parked v1.2 ideas-pass material.

## Authority order (v1.1)

1. Owner-accepted decisions (decision trail entries, most recent first).
2. Proposed Operating Manual v1.1 (upon owner acceptance, simply "the Manual").
3. Requirements Register v1.1.
4. Consensus Issue Register dispositions.
5. The v1.0 baseline packet (`baseline/chatgpt-phase1-v1.0/`), historical.

Conflicts are findings, never silently resolved — unchanged from the v1.0 rule.

## Program governance

Fable — architect/designer, project manager, stage-gate approver. ChatGPT — independent verifier. Claude Opus 5 — builder (owner-confirmed standing substitution, trail entry 69). Sonnet — reader/context librarian. Hunter — owner and final authority. Gate rule: verifier feedback → implementation → Fable approval → owner acceptance of owner-level decisions. Full boundaries: Manual section 20A.

## What v1.1 acceptance unlocked (accepted 2026-07-25, trail entry 53)

Acceptance published v1.1 as the operating baseline and passed the AUD-01 gate. **Filename note:** `04_Proposed_Operating_Manual_v1.1.md` is a historical filename retained to avoid link churn — its contents are the accepted baseline, not a proposal.

**Current gate state:** TASK-0001 and TASK-0002 are CLOSED with all owner events recorded (v1.2 trail entry 65; v1.3 trail entry 73); TOPIC-0001 (the v1.2 ideas pass) is closed. **Phase 2 — Decision Engine discovery — is OPEN** (release, receipt, and owner-acceptance gates all satisfied). Backlog: the GOV-01/§20A.1 standing-role refresh to Claude Opus 5 (governed change; trail entry 69 governs meanwhile).
