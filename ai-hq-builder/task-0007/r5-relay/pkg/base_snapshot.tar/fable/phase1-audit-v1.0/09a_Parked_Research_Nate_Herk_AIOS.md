# Parked Research — Nate Herk's "AI Operating System" (AIS-OS)

**Status:** Parked for the v1.2 ideas pass. **This document was NOT an input to the Phase 1 audit** (owner chose audit-first sequencing; independence preserved).

**Provenance:** Researched 2026-07-25 by a background research agent (web search + direct fetch of his GitHub repositories). Facts about his personal results are self-reported unless noted.

---

## (a) Who he is

- **Real name:** Nate Herkelman ("Nate Herk"), mid-20s, Chicago-based. University of Iowa (Business Analytics + Marketing). Former Business Intelligence Analyst at Goldman Sachs; left corporate November 2024.
- **Channel:** YouTube "Nate Herk | AI Automation" (~860K subscribers, ~458 videos, ~44.5M views). X: @nateherk. GitHub: `nateherkai`.
- **Businesses:** Founder of Uppit AI; co-founded TrueHorizon AI agency (exited Dec 2025); founder of the AI Automation Society community on Skool (~325–350K free members) plus paid AIS+ tier.
- **Arc:** Made his name with n8n agent tutorials in 2024–2025, pivoted hard to Claude Code content from late 2025 through 2026. Claims to run his whole business "largely from a single tool: Claude Code."

## (b) Inventory of his AI HQ system

His term is **"AI Operating System" (AIOS)**; secondary framing: **"second brain."**

| # | Artifact | Date | Source |
|---|---|---|---|
| 1 | "Ultimate Assistant" n8n precursor — Telegram-triggered hub agent routing to Email/Calendar/Contact/Content sub-agents | ~Feb 2025 | YouTube `9FuNtfsnRNo` |
| 2 | "I Built an AI Operating System in Claude Code (Here's How to Sell It)" — first AIOS video | Feb 2026 | YouTube `-GV1MRNB4hQ` |
| 3 | "Master 95% of Claude Code in 36 Mins" — WAT framework (Workflows/Agent/Tools) | ~Feb–Mar 2026 | YouTube |
| 4 | "Build & Sell with Claude Code (10+ Hour Course)" | ~mid-Mar 2026 | YouTube `mpALXah_PBg` |
| 5 | "I Built Karpathy's LLM Wiki in Claude Code (No Vector DB)" — raw/wiki pattern in Obsidian | ~Apr 6, 2026 | YouTube `dNxrKVcKS1E` |
| 6 | **Main artifact: "Build & Sell Claude Code Operating Systems (2+ Hour Course)"** + free **AIS-OS starter repo** (github.com/nateherkai/AIS-OS, 991★, MIT) + written X guide | **May 1, 2026** | YouTube `bCljOfCH8Ms` |
| 7 | "I Turned Claude Opus 4.8 Into My Entire AI Operating System" — personal AIOS tour | ~early Jun 2026 | YouTube `0WDkwMxj13s` |
| 8 | "I Turned Claude Into the Ultimate Second Brain" — his **Herk2** project | ~Jun 10, 2026 | YouTube `8QQ_INxAhRs` |
| 9 | "Every Level of a Claude Second Brain Explained" — 5-level framework | ~Jun 17, 2026 | YouTube `DTCyvo6cC54` |
| 10 | "Fable 5 + Karpathy's LLM Wiki is Basically Cheating" — multi-wiki AIOS memory | ~Jul 3, 2026 | YouTube `hQvwMj7IJe4` |
| Support | `token-dashboard` (Claude Code token/cost analytics, 646★); `a-bunch-of-skills` (skill-builder, infographic-builder, visualizations) | Apr–Jun 2026 | GitHub `nateherkai` |

## (c) Detailed architecture

### The two governing frameworks (both trademarked, © 2026 Nate Herk)

**The Four Cs of an AIOS™** (architecture layers, strict dependency order: Context → Connections + Capabilities in parallel → Cadence last):
1. **Context** — what the AI knows about you: business, voice, team, finances, goals. Non-skippable.
2. **Connections** — what live data it can reach (files, Slack, inbox, spreadsheets — "your important business data isn't on the web").
3. **Capabilities** — short phrases trigger multi-step workflows producing artifacts (skills/agents).
4. **Cadence** — runs on schedule without being asked; "don't automate workflows that don't work manually."

**The Three Ms of AI™** (operator brain):
- **Mindset:** *Default Shift* ("how could AI assist?" before any manual task; if not 100%, do the first 30%), *Function Breakdown* (decompose roles into automatable tasks), *Curiosity Rule* (no "dark code" you can't explain), *Expect the Dip* (~20% productivity loss for 1–2 weeks, then ~2x).
- **Method (5-step pipeline):** Find the Constraint ("if 500 clients arrived tomorrow, what breaks first?") → **EAD** (Eliminate/Automate/Delegate, with the **60/30/10 Golden Rule**: ~60% deterministic, 30% AI-assisted, 10% manual) → Map the Process (Trigger, Data Sources, Transformations, Decision Points, Destination) → **Autonomy Spectrum L0–L4** (Manual / Suggested / Drafted / Supervised / Autonomous; default to lowest that works) → Tie to a KPI ("if it doesn't move a number, why build it?").
- **Machine:** BUILD — Lego Principle (one input/one output units, deterministic first), Assembly Line (specialized models per function), Validation Chain (test each step with real upstream data before chaining). OPERATE — **Bike Method** (Phase 1 manual with observation → Phase 2 100% human review → Phase 3 monitored autonomy → Phase 4 unsupervised; start at 10% volume; confidence thresholds route auto-send / draft queue / human escalation), **Intern Rule** (AI gets its own identity/accounts, read-only default, no personal credentials, audit trail, minimal API scopes), **Kill Switch** (kill automations costing more than they save). Governing principles: *Boring is Beautiful*, *Deterministic finishes; AI evolves*.

### The AIS-OS repo structure (his distributed template, MIT)

```
AIS-OS/
├── CLAUDE.md                    # personalized operating manual ("router")
├── EXPANSIONS.md                # growth roadmap
├── aios-intake.md               # editable source-of-truth for /onboard
├── connections.md               # registry of all reachable systems
├── context/                     # about-me.md, about-business.md, priorities.md
├── references/
│   ├── 3ms-framework.md
│   └── voice.md                 # pasted raw writing samples
├── decisions/log.md             # append-only decision record
├── archives/                    # inactive materials (incl. dated intake backups)
└── .claude/skills/{onboard,audit,level-up}/SKILL.md
```

**CLAUDE.md contents (structure):** identity ("You function as a personal AIOS — a thinking partner… learning companion, not a tool that dispenses answers"), pointer to the 3Ms reference, the three commands, an Information Architecture map of the folders, communication style ("match register from `references/voice.md`… never adopt this voice for external communications without explicit approval and draft review"), and working principles (surface action items before status; answer without restating; suggest logging consequential decisions; **flag manual tasks repeated 3+ times at next `/level-up`**; default posture "where could AI reduce manual effort?").

**The three skills:**
- **`/onboard`** (Day 1, ~15 min, idempotent): 7-question interview hard-capped at 7 (identity/offer/ICP; **raw pasted writing samples — refuses typed ones**; 90-day priorities with numbers/deadlines demanded; where revenue lands; where you communicate; where recordings/notes/docs live; what task eats your week). Scaffolds the context files, a 7-row `connections.md`, and fills all placeholders in CLAUDE.md. No API keys on Day 1.
- **`/audit`** (Day 7, then weekly): read-only **Four-Cs gap report scored 0–100** (25 pts per C). Gaps ranked by **leverage = points lost × impact multiplier (1–4x; 4x = "business blindness," zero Tier-1 domains reachable)**. Output: total score + stage (Foundation/Built/Compounding/Autonomous), scorecard, 3–5 strengths, top 3 gaps with concrete next steps. ~60-second target.
- **`/level-up`** (Day 14, then weekly): 3-phase interview shipping **exactly one automation per week**. Phase 1 Mindset (what did you do 3+ times; drudgery; intern-delegable; constraint; growth lever) → ranked candidates. Phase 2 Method (the 5-step pipeline; stops if the user can't articulate all 5 process elements or name a KPI). Phase 3 Machine handoff, options ordered by Boring-is-Beautiful: **prompt-only template → deterministic skill (script, no AI) → AI-assisted skill (one AI call) → sub-agent (last resort)**. Output contract: one `decisions/log.md` entry + one scaffolded artifact + one-screen summary.

**`connections.md` registry:** 7 Tier-1 domains (Revenue/Financials, Customer interactions, Calendar, Communication, Project/task tracking, Meeting intelligence, Knowledge/files) × columns (tool, mechanism, auth status, last-verified). Mechanisms: `mcp` | `script` | `export` | `key+ref` | `not yet connected`. Rule: **"When you wire a new tool, also save `references/{tool}-api.md`"** (endpoints, auth, standard queries — research captured once).

**`decisions/log.md` format:** append-only; `## YYYY-MM-DD — description` + **Decision / Why / Alternatives considered / Owner**; rationale over facts.

**`EXPANSIONS.md` growth path:** add `projects/`, `templates/`, `brand-assets/`, `references/sops/`, `scripts/`, `.claude/agents/`, and **sub-OS folders** (e.g. `youtube-os/`) for verticals with distinct data ecosystems, each with its own scoped operating manual and skills. **Three-Question Test before adding any folder:** conceptually distinct? accessed 3+ times/month? would a future skill route into it? "Two yeses = add. One yes = wait." Maintenance cadences: decisions after each decision; archives quarterly; connections registry per new tool; CLAUDE.md quarterly review.

### His personal system (from the video tours)

- **Connections he actually runs:** ClickUp, Google Workspace (Gmail/Calendar), QuickBooks, Slack, YouTube data. Canonical demo: bulk-updated tracking links across 300+ YouTube video descriptions via API.
- **Memory = Karpathy-style LLM wikis, not vector DBs.** Pattern: `raw/` (source dumps) + `wiki/` (LLM-organized cross-linked markdown) + `index.md` (page inventory/summaries) + `log.md` (activity record) + routing rules in CLAUDE.md, with **Obsidian as the graph/backlink front end**. Ingestion ladder: **Inbox → Raw → Wiki**. He runs **multiple wikis feeding one AIOS** (YouTube wiki, meetings/personal wiki). Community-reported result: 383 scattered files → compact wiki, **~95% token reduction** vs. dumping raw files (navigation by index + links instead of similarity search).
- **Agents:** an "executive assistant" agent that reads the second brain when it needs context; sub-agents reserved for multi-step research/writing on cheaper models.
- **Cadence:** Claude Code **Routines** (Anthropic-cloud scheduled runs — works with laptop closed); calls agentic scheduled tasks "10x more powerful" than deterministic cron. Cadence deliberately last in build order.
- **The 5 Levels of a Claude second brain:** L1 = CLAUDE.md router file + clean folders; L2 = LLM wiki; L3 = semantic search; L4 = knowledge graph; L5 = always-on autonomous sync. Key stances: **his own Herk2 sits at Level 2**; "the goal isn't to climb to level 5 — find the lowest level that solves your pain"; "more autonomy = more complexity and fragility."
- **Portability doctrine:** moved the entire OS into a different agent CLI as a test — it adjusted in ~2 minutes; maintains two parallel copies. Thesis: the durable asset is the context files + connection architecture + capability modules + cadence logic, not the harness.

## (d) Best ideas, ranked by transferability to a Claude-native AI HQ

1. **Connections registry with per-tool reference docs** (`connections.md` + `references/{tool}-api.md`, auth-freshness column). Solves silent MCP/auth rot and re-research waste. His single most stealable operational artifact.
2. **The LLM-wiki memory pattern over RAG** (raw/ → wiki/ + index.md + routing rules, multiple wikis per domain feeding one OS). 100% Claude-native — files + Claude Code. The strongest context-management trick in his system.
3. **Cadence-last dependency order** (Context → Connections/Capabilities → Cadence) and "never automate a workflow that doesn't work manually."
4. **The weekly `/audit` + `/level-up` ritual pair** — a *system that maintains the system*: one read-only structural gap scan, one interview that ships exactly one artifact per week and writes a decision-log entry. The one-artifact-per-week constraint and KPI stop-rule prevent sprawl.
5. **Escalation ladder for capabilities:** prompt template → deterministic script skill → one-AI-call skill → sub-agent last; plus Autonomy Spectrum L0–L4 with lowest-level default and the Bike Method rollout.
6. **Raw-pasted voice samples with a refusal rule** ("never adopt this voice for external comms without explicit approval and draft review").
7. **Append-only `decisions/log.md`** (Decision/Why/Alternatives/Owner) + "suggest logging consequential decisions" as a standing instruction.
8. **The Three-Question folder test** and quarterly review/archive sweeps — concrete anti-entropy rules.
9. **"Flag manual tasks repeated 3+ times"** as a standing instruction — the assistant generates its own automation backlog.
10. **Sub-OS folders per vertical** with scoped operating manuals — keeps business-HQ and life-HQ from polluting each other's context.
11. **Portability discipline** — plain markdown/scripts; periodically boot the OS in a second harness as a fire drill.
12. **Intern Rule security posture** (own identity/accounts for the agent, read-only defaults, minimal scopes, audit trail) — right idea, shallow implementation.
13. Lower-transfer but notable: 60/30/10 automation split, Assembly-Line model specialization, token-usage dashboards, the 5-levels rubric for deciding how much memory machinery to build.

## (e) Weaknesses / gaps / criticisms

- **The starter kit is thinking-scaffolding, not a working HQ.** AIS-OS ships zero connections, zero cadence, no agents. The gap between his demoed personal system and the free template is large; the full build lives partly behind his paid community.
- **Marketing-hype criticism is well documented** (ScamRisk, Ippei reviews): revenue claims likely driven by course/community sales rather than the automation model he teaches; "limited depth for students aiming to build complex or high-ticket automation."
- **Trademark/attribution friction:** the 3Ms™ and 4Cs™ are trademarked with mandatory attribution headers stamped into every generated artifact — unusual for an MIT kit.
- **Maintenance burden is real and acknowledged:** weekly audit + weekly level-up + quarterly reviews; system health depends on ritual adherence. (Directly relevant to this owner's stated constraint: self-administered protocol gets skipped.)
- **Security/privacy depth is thin.** The Intern Rule is a checklist, not a threat model; his `/audit` skill actually *requires* write capability to score Connections fully.
- **Single-operator bias:** multi-user, team permissions, and shared-state problems unaddressed.
- **No substantive technical teardown found** — coverage is overwhelmingly amplification; treat "10x productivity" claims as self-reported.
