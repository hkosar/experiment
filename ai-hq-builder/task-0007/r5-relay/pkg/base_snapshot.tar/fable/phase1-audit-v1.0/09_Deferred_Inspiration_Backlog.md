# Deferred Inspiration Backlog

**Status:** Intentionally deferred by owner decision. Not an input to the Phase 1 audit.

## Owner sequencing decision (2026-07-25)

The owner explicitly chose **"Audit first, ideas later"**: complete the full audit → consensus → v1.1 cycle on the existing ChatGPT Phase 1 baseline before evaluating any outside ideas. Outside inspiration targets a later revision pass (working label: **v1.2 ideas pass**).

This preserves the audit's independence: the baseline was judged on its own terms, not against competing designs.

## Parked inspiration sources

| # | Source | Status | Location |
| --- | --- | --- | --- |
| 1 | **Nate Herk's "AI Operating System" (AIS-OS)** — published Claude Code-native personal OS template, plus his 3Ms/4Cs frameworks, LLM-wiki memory pattern, and weekly audit/level-up ritual. | Research complete; parked. Held out of the Phase 1 audit. | `09a_Parked_Research_Nate_Herk_AIOS.md` |
| 2 | **Owner upload set #1** (2 documents, project not yet identified) | Awaiting owner attachment. | — |

## Rules for the v1.2 ideas pass

1. The purpose is **selective adoption**, not redesign: "take the best parts of their ideas and see how it can improve what we are building here" (owner, 2026-07-25). A fundamental alteration is permitted only if an adopted idea genuinely earns it.
2. Every candidate idea is evaluated against the accepted v1.1 baseline and dispositioned explicitly: adopt / adapt / reject, with rationale recorded in the decision trail.
3. Adopted ideas enter through the same change discipline as audit findings: update the Operating Manual, requirements register, ADRs, and change log together.

## Trigger to open the pass

The v1.2 ideas pass opens when (a) the v1.1 consensus baseline is owner-accepted, and (b) the owner attaches the remaining upload set.
