# Consensus Issue Register — Phase 1 Audit (re-tiered)

**How to read this:** 49 consensus issues merged from 74 verified findings across 7 independent auditors (1 finding refuted in adversarial verification — see `03_Auditor_Reports/refuted_findings.md`). Re-tiered per owner realignment of 2026-07-25: these are overwhelmingly *completion* items for a concept in drafting, not defects of the concept. Severity labels retain the packet's audit rubric for traceability. Open decisions D1–D8 are presented in context in `10_Concept_Experience_Walkthrough.md`.

| Tier | Entries |
| --- | --- |
| Tier 1 — Concept consistency (make the draft say one thing) | 22: C-06, C-07, C-08, C-09, C-10, C-11, C-12, C-13, C-16, C-17, C-23, C-24, C-25, C-26, C-34, C-35, C-36, C-37, C-38, C-41, C-42, C-47 |
| Tier 2 — Protection layer (identity, trust, evidence, resilience) | 11: C-01, C-02, C-14, C-15, C-19, C-20, C-21, C-22, C-39, C-40, C-49 |
| Tier 3 — Sequencing for owner attention (nothing cut from the vision) | 10: C-03, C-04, C-05, C-28, C-29, C-30, C-44, C-45, C-46, C-48 |
| Tier 4 — Build backlog (legitimate, but build-phase | 6: C-18, C-27, C-31, C-32, C-33, C-43 |


## Tier 1 — Concept consistency (make the draft say one thing)

### C-06 [High] — Five stores lack ownership matrix and shared identity contract

- **Sources:** F-ARCH-04, F-ARCH-12
- **Affected:** MEM-01, MEM-04, LRN-02, BUS-09, PLAT-04; Manual 5.2, 6.3, 10.2, 12.4, 13.5, 15.2, 15.4; ADR-006; doc 06 DB-schema deferral
- **Problem:** Several core object types have no single authoritative store: Decisions appear in Git, checkpoints, and the semantic layer; rules/preferences/skills are assigned to a semantic layer that is simultaneously forbidden from owning approved rules; topic checkpoints and the 10.2 'active registry' are assigned nowhere. No cross-store identity or reference contract exists even though every mechanism (knowledge back-references, Discord threads, Git artifacts, 'related topics') presumes stable IDs. Phase 2's central hypothesis — deterministic policy constraining model recommendations — cannot be designed without knowing where authoritative policy state lives.
- **Consensus recommendation:** Add an ownership matrix to v1.1 mapping every 6.3 object type (plus Checkpoint, Automation Policy, registry entries) to exactly one authoritative store, others holding derived copies or references: operational DB owns Decisions, registry state, checkpoints, and events; Git owns code and versioned design artifacts; the semantic layer holds only derived projections with back-references. Add one requirement: every persistent object carries a globally unique, store-independent ID minted by the operational DB, referenced by all other stores and surfaces, surviving archive and merge via aliases.
- **Disposition:** Proposed for v1.1 (expert default; batch D8)
- **Owner decision & rationale:** _pending walkthrough review_

### C-07 [High] — State vocabulary contradicts itself across authoritative documents

- **Sources:** F-ARCH-01, F-ARCH-07, F-UX-08, F-UX-09, F-WFDS-10
- **Affected:** Doc 05 Status/Focus rows; Manual 4.4, 4.5, 7.1-7.2, 8.2-8.3, 9.3, 10.4, 11.7, Appendix B; WF-03, ATT-02
- **Problem:** Doc 05 substitutes the attention level 'Needs Attention' into the status enum where the Manual defines 'Needs Owner'; the Manual's own mock views use undefined values ('Active', focus value 'Background' in a status column); Paused/Parked and Waiting/Queued semantically overlap; 'Archived' and 'status' are overloaded between topics and rule lifecycles; no legal stage-status-focus combination matrix exists; and owner-facing prompts expose raw ontology jargon. This is the kernel vocabulary Phase 2 turns into a schema, and it currently conflates the status dimension with the attention dimension the whole interaction model declares independent.
- **Consensus recommendation:** Publish one canonical state table in v1.1: a single status enum (standardize 'Needs Owner'; 'Needs Attention' reserved exclusively for the attention level), a single attention-level enum, and an explicit mapping rule between them; collapse stored focus to Foreground/Background with Parked/Queued derived from Paused/Waiting; rename rule lifecycle states (Proposed/Active/Inactive/Retired) to stop overloading 'status' and 'Archived'; publish a legal stage-x-status matrix; require plain-language rendering of all owner-facing classification choices with ontology terms as secondary metadata; correct doc 05, 11.7, and all hub mocks to the canonical terms.
- **Disposition:** Proposed for v1.1 (expert default; batch D8)
- **Owner decision & rationale:** _pending walkthrough review_

### C-08 [High] — Frozen five-way classification contradicts the Phase 2 backlog

- **Sources:** F-WFDS-01
- **Affected:** WF-09, WF-10, DEC-01; Manual 8.1; doc 06 Classification row
- **Problem:** WF-09 confirms a five-way interjection set that is neither complete nor a decidable partition: blocking is orthogonal to placement, and inputs unrelated to the hierarchy, inputs belonging to a different existing topic, plain answerable questions, and rule/preference candidates are all missing. Doc 06's own Phase 2 question reopens an eight-way set, so the baseline contains a Confirmed requirement Phase 2 must contradict, corrupting the packet's authority order.
- **Consensus recommendation:** Reword WF-09 as a provisional minimum set and restructure classification into orthogonal dimensions — placement (current / child / sibling / parent / other-existing-topic / new-unrelated), relationship (blocking / non-blocking), and disposition (apply-now / park-as-observation / answer-and-discard) — explicitly assigning the final taxonomy to Phase 2 so the requirement and backlog agree.
- **Disposition:** Proposed for v1.1 (expert default; batch D8)
- **Owner decision & rationale:** _pending walkthrough review_

### C-09 [High] — Fixed five-level hierarchy and recursive supervision never reconciled

- **Sources:** F-ARCH-03
- **Affected:** ORG-01 vs ORG-02; Manual 4.3, 6.1-6.3, 12.3; WF-04, WF-05; doc 05 hierarchy
- **Problem:** The fixed Domain->HQ->Initiative->Topic->Task hierarchy and the 'every meaningful object can supervise children' model conflict: the packet types the same object as both task and topic, and its own example nests four levels beneath a project. Whether Tasks can have children, and whether kickoff and closeout protocol applies at every recursion depth, is undefined — so Phase 2 routing has no stable target and either every leaf inherits crushing protocol or coverage becomes arbitrary.
- **Consensus recommendation:** State in v1.1 that the structure is an arbitrary-depth tree in which levels are roles, not fixed slots: Domain and HQ anchor; nodes below are Initiative-, Topic-, or Task-typed; node type determines obligations (Topics require kickoff/checkpoint/closeout; Tasks are leaves carrying only state and completion criteria and may not supervise children). Define the task-to-topic promotion rule for when a task needs children.
- **Disposition:** Proposed for v1.1 (expert default; batch D8)
- **Owner decision & rationale:** _pending walkthrough review_

### C-10 [High] — Parent hub status and stage rollup is undefined

- **Sources:** F-ARCH-02
- **Affected:** Manual 9.3, 4.4, 7.2; ORG-02; ADR-002; Decision Trail 26
- **Problem:** Every hub must display stage and status, but no rule exists for a parent whose children disagree (one Blocked, one Working, one Needs Owner) or span multiple stages. The manual's own hub mock invents 'Active' — a value outside the enum — and the decision trail claims 'inherited status' that is specified nowhere. The Executive Desk and HQ dashboards, the owner's primary awareness surface, would show implementation-defined state at exactly the level he actually watches.
- **Consensus recommendation:** Define deterministic rollup in v1.1: a derived headline status computed from children by a stated precedence order (Failed > Blocked > Needs Owner > Working > Waiting > Paused > Completed) combined with an aggregate per-status count profile on the hub, plus a distinct own-work status; state explicitly whether hub-level stage is intrinsic or derived.
- **Disposition:** Proposed for v1.1 (expert default; batch D8)
- **Owner decision & rationale:** _pending walkthrough review_

### C-11 [High] — No correction primitives: routing must be right first try

- **Sources:** F-WFDS-07, F-UX-01
- **Affected:** Manual 6.3, 7, 8.1-8.2, 18.1; WF-09/10/11; ORG-02; INT-01, DP-001
- **Problem:** The workflow model has creation, fold-back, and archival but no re-parent, merge, split, or reclassify operation, and no owner gesture for 'this is in the wrong place.' Routing is probabilistic and the owner will accept wrong defaults on mobile, so misfiled topics are statistically certain — yet the only remedy is destructive recreate-and-abandon, quietly making hierarchy coherence contingent on near-perfect first-shot classification. The absence of cheap repair also blocks any safe act-by-default tier for low-impact routing, and 18.1 measures no routing-prompt load.
- **Consensus recommendation:** Add re-parent, merge, split, and reclassify as first-class coordinator operations with event-trail preservation; expose a one-line owner command ('wrong place') that triggers a re-routing recommendation; feed corrections into the WF-11 calibration loop as high-value evidence; add routing-prompts-per-captured-input to 18.1. The related act-with-receipt default for trivial-ambiguous routing is a recorded owner tradeoff (see disagreement on routing default) and should be decided once these primitives exist.
- **Disposition:** Owner decision D4 — presented in walkthrough scenario 3 (routing default; correction primitives themselves are batch defaults)
- **Owner decision & rationale:** _pending walkthrough review_

### C-12 [High] — System-generated owner obligations have no aggregate governance

- **Sources:** F-WFDS-05, F-UX-02, F-UX-13
- **Affected:** ATT-01-03; Manual 4.5, 7.5, 10.2, 10.4, 11.6-11.7, 18.1-18.2; WF-12; ORG-05
- **Problem:** Phase 1 creates at least five recurring owner review streams — proposal queue, 90-day inactivity reviews, housekeeping reviews, needs-review closeouts, and reconciliation items — yet none is classified into the attention model and no cap, batching, aging, escalation, or consolidation rule bounds total load. Only the first overdue event has defined behavior, no owner correction affordance ('this shouldn't have pinged me') feeds calibration, and 18.1 measures none of the interaction burden. For an owner with a documented queue-neglect pattern, the Needs Owner queue becomes the new neglected inbox or the system becomes its own interruption source.
- **Consensus recommendation:** Define a single governed system-review digest as the default surfacing vehicle for all system-generated review items; classify each item type into an attention level; cap items per digest; define an aging/escalation ladder that consolidates stale Needs Owner items into one aging card rather than N badges; add an owner correction affordance captured as observations feeding attention calibration; add attention-level/importance to the Phase 2 event schema work; add owner-review-load, queue-age distribution, override rate, and approval dwell measures to 18.1.
- **Disposition:** Proposed for v1.1 (expert default; batch D8)
- **Owner decision & rationale:** _pending walkthrough review_

### C-13 [High] — No owner-facing search or recall-by-description primitive

- **Sources:** F-UX-05
- **Affected:** EX-10; Manual 9.2, 13.3, 15.2
- **Problem:** The system's core promise is filing content the owner did not place, yet all six required navigation directions are structural (up/down/sideways/back/desk/needs-owner). An ADD owner who is a self-described weak detail-maintainer cannot relocate last Tuesday's auto-filed interjection by browsing hierarchy — that is precisely the recall burden he cannot carry. The semantic layer is 'searchable' only as memory architecture, never as an executive affordance, so captured items are effectively lost or re-entered as duplicates.
- **Consensus recommendation:** Add a requirement: from any surface, the owner can retrieve any topic, task, decision, or artifact by free-text or semantic description ('the houseboat ad idea from last week') and receive results with breadcrumbs and direct links. Treat recall-by-description as a first-class navigation direction alongside the six structural ones, so Wave 1 bot rendering cannot ship structural links only.
- **Disposition:** Proposed for v1.1 (expert default; batch D8)
- **Owner decision & rationale:** _pending walkthrough review_

### C-16 [High] — Checkpoint recovery undefined for ungraceful worker death

- **Sources:** F-APPDEV-02
- **Affected:** APP-04, MEM-02/03; Manual 3.3, 6.3, 12.1, 15.2-15.3
- **Problem:** The only specified checkpoint trigger is the graceful one (context approaching limit); there is no cadence, milestone-commit requirement, or event capture for crash, timeout, or overnight stall — the owner's motivating pain. The checkpoint is authored by the same degrading worker with no fidelity check against the repository, the object model contains no Worker/Session primitive to record which session holds which task, and the Builder's nested sub-agents are unrepresented. The flagship resumption promise fails in exactly the overnight-failure scenario that motivated it.
- **Consensus recommendation:** Add a Worker Session primitive to the object model (heartbeat, last-confirmed state); require checkpoint refresh at every stage transition and at a bounded work interval, plus incremental commits to the topic branch so the worktree is the recovery substrate; define a resume procedure in which a replacement worker reconciles the checkpoint against the branch and event log before continuing, flagging divergence as Needs Review.
- **Disposition:** Proposed for v1.1 (expert default; batch D8)
- **Owner decision & rationale:** _pending walkthrough review_

### C-17 [High] — Role and stage taxonomies unreconciled; no handoff artifact contracts

- **Sources:** F-APPDEV-01
- **Affected:** APP-01, APP-02, WF-02; Manual 3.2, 7.1, 12.1-12.4, 17.3
- **Problem:** The six lifecycle roles and seven topic stages are parallel taxonomies never mapped to each other — Debugger has no stage, Integration has no role, and nothing states which role owns a build topic per stage or who advances the stage. Only the plan-to-build transition has partial artifact content; Ideator-to-Designer, Designer-to-Planner, defect records, and the launch-audit evidence package are undefined, unlike the fully specified kickoff and closeout records. Wave 2 commits to implementing all six roles against improvised handoffs, reproducing today's context-reconstruction failure with agents instead of the owner.
- **Consensus recommendation:** Before Phase 2, publish (a) an explicit role-to-stage mapping for build topics including who advances the stage, and (b) per-transition artifact contracts analogous to the kickoff record: ideation brief, design record, implementation plan schema (scope, definition of done, tests, rollback), build report, defect record, and launch-audit evidence package — folded into APP-02 so each transition produces a named repository artifact.
- **Disposition:** Proposed for v1.1 (expert default; batch D8)
- **Owner decision & rationale:** _pending walkthrough review_

### C-23 [Medium] — Recurring work and timer events unmodeled; runtime model unstated

- **Sources:** F-ARCH-05, F-CLAUDE-04
- **Affected:** Manual 4.5, 5.1, 6.3, 7.1, 7.5, 10.4, 13.8; WF-12, ORG-05, ATT-03; doc 06 Inputs row
- **Problem:** Briefings, Mailroom cycles, 90-day reviews, and housekeeping all recur, but the only lifecycle defined terminates at Archived and no Scheduled/Recurring Job object or timer-event class exists (schedulers appear only as an unmodeled 5.1 component). The manual also reads as a continuously attentive coordinator when the real runtime is event-driven turns plus scheduled firings, and the Phase 2 input enumeration omits timer/sweep events entirely — the class most of the system's obligations depend on.
- **Consensus recommendation:** State the runtime model explicitly in Section 5: the coordinator is event-driven intelligence over durable state, invoked by (a) owner/agent messages, (b) system events, and (c) scheduled sweeps. Add a Scheduled/Recurring Job object (owner of briefings, triage cycles, reviews, with per-run Events) and a timer/sweep event class to 6.3 and to the Phase 2 input-schema question; map briefings, overdue checks, decay reviews, and housekeeping to named sweep schedules.
- **Disposition:** Proposed for v1.1 (expert default; batch D8)
- **Owner decision & rationale:** _pending walkthrough review_

### C-24 [Medium] — No precedence semantics for conflicting rules and preferences

- **Sources:** F-WFDS-03
- **Affected:** LRN-02/03/04; Manual 10.3-10.4, 14.2, 15.4; DEC-01; doc 06 Policy-evaluation row
- **Problem:** Scoped rules, preferences, and skills can collide (global skills vs domain rules, overlapping scopes) and the provider must track conflicts, but nothing resolves them at application time: narrower-beats-broader is nowhere stated, and the no-silent-violation rule is written for rule-vs-context exceptions, not rule-vs-rule collisions. The Phase 2 policy-evaluation question as worded covers only rules constraining recommendations.
- **Consensus recommendation:** Adopt a minimal v1.1 precedence baseline — a rule outranks a preference; narrower scope outranks broader; equal-rank unresolved conflicts must surface to the owner, never be silently chosen — and add rule-vs-rule/scope precedence explicitly to the Phase 2 policy-evaluation backlog item.
- **Disposition:** Proposed for v1.1 (expert default; batch D8)
- **Owner decision & rationale:** _pending walkthrough review_

### C-25 [Medium] — Fold-back semantics incomplete: actor, terminal state, fan-out, re-baselining

- **Sources:** F-ARCH-06, F-WFDS-09
- **Affected:** WF-05, WF-07, DP-008; Manual 4.4, 7.4, 8.1, 8.4, 11.3-11.4, 12.3, 18.1; ADR-002; doc 05
- **Problem:** A child can be Completed but unintegrated, yet no status, flag, or stage rule represents 'awaiting fold-back', making the headline 18.1 fold-back metric uncountable, and the acceptance actor is defined for only one action class. Fan-out when one blocker blocks multiple topics is unstated (8.4 handles only the single original topic), and no downward propagation or re-validation exists when a parent decision changes under running children.
- **Consensus recommendation:** Define the acceptance actor per action class (coordinator-automatic, coordinator-with-review, owner); represent awaiting-integration explicitly (a status value, or a stated rule that Completed status plus non-Integration stage is the countable backlog state); generalize wording from single-parent fold-back to registered dependents, with blocked topics receiving resolutions as resume events; add a defined re-validation Event when a superseded parent decision is referenced by child checkpoints. Detailed mechanics remain Phase 2 fold-back work — the correction prevents the tree-only, single-dependent phrasing from anchoring the Decision Engine.
- **Disposition:** Proposed for v1.1 (expert default; batch D8)
- **Owner decision & rationale:** _pending walkthrough review_

### C-26 [Medium] — EX-06 device rendering is Discord-infeasible; no presentation contract

- **Sources:** F-UX-12, F-FEAS-05, F-CLAUDE-02
- **Affected:** EX-06, PLAT-01/02/04, DP-004, ADR-001; Manual 2.3, 4.5, 9.1, 9.3, 9.5, 16.2-16.5, 17.1
- **Problem:** A Discord bot cannot detect the reading device or serve per-device payloads for one message, yet EX-06/9.5's 'render profiles' language reads as platform-selected views and stands Confirmed; the mocked composite views also press against hard message/embed/component limits at realistic volume. No platform-independent minimum presentation contract exists, so Wave 1 would quietly downgrade the attention model to whatever Discord supports — the failure 2.3 explicitly forbids.
- **Consensus recommendation:** Reword EX-06/DP-004 as compact-first with progressive disclosure: every operational message renders compact with explicit expansion affordances identical on all devices; true device-specific profiles live only at the already-defined companion-dashboard boundary (PLAT-03/16.5). Add a minimum presentation-capability contract any front end must satisfy (persistent ordered needs-owner queue, per-attention-class notification control, stable deep links, always-current hub summary, mobile completion of every decision type) and a Wave 0 exit criterion testing the Desk and one hub at realistic volume (30+ topics, 10+ events/day) on a phone, with declared fallbacks where primitives are missing.
- **Disposition:** Proposed for v1.1 (expert default; batch D8)
- **Owner decision & rationale:** _pending walkthrough review_

### C-34 [Medium] — Observation maturation thresholds undefined; 18.2 cites nonexistent threshold

- **Sources:** F-WFDS-02
- **Affected:** LRN-01, DP-003; Manual 10.1-10.2, 4.5, 18.2
- **Problem:** No criteria define when an observation becomes a proposal, how many proposals may surface per period, or what happens to observations that never mature — for an owner who has explicitly said he will not notice patterns himself. The 18.2 risk table cites an 'Observation threshold' as the topic-sprawl mitigation, but no such threshold is defined anywhere in the packet — a dangling reference to a nonexistent mechanism.
- **Consensus recommendation:** Fix the dangling 18.2 reference; define provisional per-category maturation thresholds (repetition count and/or impact class) in the LRN-06 provisional style; bound proposal surfacing (at most N per scheduled briefing, mapped to the existing 4.5 levels); add a hoard alarm (queue size/age triggers a batched review via the C-12 digest); register threshold refinement into the Phase 2 classification work area.
- **Disposition:** Proposed for v1.1 (expert default; batch D8)
- **Owner decision & rationale:** _pending walkthrough review_

### C-35 [Medium] — Housekeeping has no decidable trigger, cadence, or bound

- **Sources:** F-WFDS-12
- **Affected:** ORG-05, WF-12; Manual 7.5, 18.1
- **Problem:** 'Dozens of active topics' and 'excessive unresolved children' are unquantified, 'summaries match current reality' has no defined check, and nothing states whether the coordinator evaluates stability continuously, on hub open, or on schedule. Housekeeping either never fires or fires arbitrarily, and rot is discovered late as an unbounded owner cleanup session — the exact no-progress-session pattern the owner abandons systems over.
- **Consensus recommendation:** Define provisional, configurable triggers per hub type — active-child count, checkpoint staleness age, Completed-but-unfolded age, Needs-Owner age — plus an evaluation cadence (scheduled sweep per C-23), routing resulting items through the bounded system-review digest (C-12).
- **Disposition:** Proposed for v1.1 (expert default; batch D8)
- **Owner decision & rationale:** _pending walkthrough review_

### C-36 [Medium] — Blocker-override friction will habituate; predictions uncalibrated

- **Sources:** F-UX-06, F-WFDS-08
- **Affected:** WF-06, AUT-06, ADR-010, DP-017; Manual 8.3, 18.2; Decision Trail 38
- **Problem:** Consequence summaries carry unfalsifiable predictions ('Expected rework: medium') with no evidence, confidence label, or provenance requirement — unlike approval cards — and no prediction-vs-outcome tracking or habituation detection exists. Since all blocking is advisory, habituated click-through silently dissolves the only protocol-enforcement mechanism the design has, and the first visibly wrong estimate destroys the mechanism's credibility with no feedback loop to notice.
- **Consensus recommendation:** Require override consequence summaries to cite the specific dependent decisions/plans that assume the unresolved item, carry a confidence label, and be capped at mobile-readable length; log predicted-vs-actual outcomes and surface the track record in subsequent friction screens; repeated overrides of the same blocker auto-generate a protocol-review observation (per LRN-01) instead of re-presenting identical friction; define override friction classes for non-design (execution/production) work.
- **Disposition:** Proposed for v1.1 (expert default; batch D8)
- **Owner decision & rationale:** _pending walkthrough review_

### C-37 [Medium] — No re-entry protocol after absence or an overwhelmed week

- **Sources:** F-UX-03
- **Affected:** WF-05, ORG-05, WF-12; Manual 4.2, 7.4-7.5, 11.3, 15.2
- **Problem:** After a multi-day absence, accumulated fold-backs, approvals, and routing confirmations have no prioritized catch-up brief and no batch operations — the Desk specifies what is shown, not how volume is triaged. Existing mechanics keep hubs truthful (events flow regardless of review), but the highest-stakes re-entry moment for an ADD owner is served only by a 'what changed' line and a serial queue.
- **Consensus recommendation:** Add a re-entry requirement: a prioritized catch-up brief on reconnect after N days or M accumulated items ('the 3 things that matter; the rest can wait'); batch operations on accumulated items (approve-all-low-risk, defer-all, sample-one); outcomes remain visible as pending-owner-acceptance per the existing 4.4/18.1 mechanics rather than auto-approved.
- **Disposition:** Proposed for v1.1 (expert default; batch D8)
- **Owner decision & rationale:** _pending walkthrough review_

### C-38 [Medium] — Reception the place versus capture the behavior unspecified

- **Sources:** F-UX-07
- **Affected:** EX-01; Manual 4.1, 8.1, 16.3
- **Problem:** Whether in-topic input receives the same capture-first, classify-later treatment as Reception-channel input is never stated, so the owner faces an entry-time 'where do I type this' decision — a classification decision the design explicitly forbids — and thoughts typed in topic threads may be treated inconsistently.
- **Consensus recommendation:** State explicitly in 4.1, as a requirement adjacent to EX-01: any owner input on any surface is Reception-grade (captured first, classified later); Reception the channel is merely the default surface when no topic context is open.
- **Disposition:** Proposed for v1.1 (expert default; batch D8)
- **Owner decision & rationale:** _pending walkthrough review_

### C-41 [Medium] — Multi-HQ visibility mandated with no link or view primitive

- **Sources:** F-ARCH-08
- **Affected:** BUS-06, BUS-09, EX-10; Manual 6.1, 6.3, 13.2; ADR-005
- **Problem:** The hybrid business model requires the same authoritative hub to appear in multiple functional HQ views without copying, and EX-10 requires related-topic links — but the hierarchy is a single-parent tree and the object model contains no link, view, or reference type. Implementers will either duplicate records (violating BUS-09 and creating drift) or hard-code ad hoc cross-links with no consistent semantics.
- **Consensus recommendation:** Add a first-class typed Reference/View primitive (view-of, related-to, blocks, depends-on) to the object model; the tree remains the single ownership parent; declare that rollups and fold-back follow ownership edges only, while views and navigation may follow reference edges.
- **Disposition:** Proposed for v1.1 (expert default; batch D8)
- **Owner decision & rationale:** _pending walkthrough review_

### C-42 [Medium] — Operating System domain placement inconsistent; no OS priority queue

- **Sources:** F-ARCH-09
- **Affected:** ORG-01, EX-03, PER-02; Manual 4.2, 6.1, 6.4, 16.3
- **Problem:** 'Operating System' is a third Domain in 6.1, a single HQ in 4.2's navigation, and a channel category containing multiple HQs in 16.3, while the Executive Desk defines only Business and Personal priority queues — so governance work (rule reviews, automation policies, the Memory Architecture blocker) has no defined needs-owner surface and silently stalls despite being one of the three core loops.
- **Consensus recommendation:** Decide in v1.1 and state it: recommended default — Operating System remains a third domain (memory scoping and permissions key off Domain) whose priority items collapse into the Business queue on the Executive Desk for this single owner-operator; explicitly state where OS-domain needs-owner items appear.
- **Disposition:** Proposed for v1.1 (expert default; batch D8)
- **Owner decision & rationale:** _pending walkthrough review_

### C-47 [Low] — No terminal state for deliberately rejected work

- **Sources:** F-ARCH-13
- **Affected:** Manual 4.4, 7.1; Decision Trail 12; ORG-04, LRN-07
- **Problem:** The trail establishes explicit no-build decisions as core preserved behavior, but the status enum ends at Completed/Failed — a topic the owner decided not to pursue has no distinct representation, so To-Did and momentum views cannot distinguish 'done' from 'decided against' from 'abandoned', and rejected ideas (named learning evidence) are misrepresented.
- **Consensus recommendation:** Add a 'Closed - No Build' (Cancelled) terminal status that requires an attached Decision object and renders distinctly in To-Did views.
- **Disposition:** Proposed for v1.1 (expert default; batch D8)
- **Owner decision & rationale:** _pending walkthrough review_


## Tier 2 — Protection layer (identity, trust, evidence, resilience)

### C-01 [Critical] — Single Discord session is the entire authority model

- **Sources:** F-SEC-01
- **Affected:** ADR-001, EX-05, AUT-04, AUT-06, WF-06; Manual 11.1-11.3, 12.4, 16.3-16.4; Appendix A (no identity family)
- **Problem:** Every consequential authority — production-risk approvals, blocker overrides, automation-policy expansion, and eventual write actions against business systems — terminates in a message or button click from the owner's Discord session on phone or PC. The packet defines no owner-identity model, no step-up verification for high-consequence action classes, no compromise assumption, no kill switch, and no recovery path. A phished or hijacked session grants an attacker full owner authority, with the system's own logs recording it as legitimate.
- **Consensus recommendation:** Add an identity-and-authority requirement family before Phase 2: (a) Discord input is a presentation-layer signal that must bind to an authenticated owner identity, not the authority itself; (b) production-risk and write-action approvals require step-up confirmation on a second factor/channel outside Discord; (c) define an account-compromise assumption with a kill switch (suspend all write authority and delegation) and recovery procedure; (d) require Discord account hardening (MFA, session review) as a Wave 0/1 precondition. Feed into Phase 2 Execution Authority so channel identity and approval authority are distinct concepts.
- **Disposition:** Proposed for v1.1 (expert default; batch D8)
- **Owner decision & rationale:** _pending walkthrough review_

### C-02 [Critical] — No untrusted-content or prompt-injection concept exists

- **Sources:** F-SEC-02
- **Affected:** EX-01, BUS-03/04/05, WF-09, DEC-01; Manual 4.1, 8.1, 13.6-13.8, 6.3; doc 06 Inputs/Classification rows
- **Problem:** Email bodies, call transcripts, lead/ad data, and links flow directly into agents that will hold tool access, yet the packet contains zero occurrences of injection, untrusted, or phishing concepts and no trust dimension on any input, observation, or event. Adversarial content can steer classification, plant observations that mature into rules, shape the evidence the owner sees, or drive exfiltration through drafted replies. The Phase 2 input-schema question omits trust/provenance, so the Decision Engine would be designed without it and defenses become a retrofit across classification, routing, learning, and verification.
- **Consensus recommendation:** Add a content-trust primitive before Phase 2 discovery: every input event carries a trust class (owner-authored / internal-system / external-untrusted); untrusted content is treated as data, never instructions, and is quarantined from directly triggering rule/skill/automation proposals or outbound actions; agents processing untrusted content run with reduced tool scopes and no external egress without owner approval. Make trust class a first-order dimension of the Decision Engine input schema.
- **Disposition:** Proposed for v1.1 (expert default; batch D8)
- **Owner decision & rationale:** _pending walkthrough review_

### C-14 [High] — Verification harness has no owner, minimum bar, provenance, or tiering

- **Sources:** F-APPDEV-04, F-SEC-04, F-UX-10, F-FEAS-08
- **Affected:** AUT-02/03/04, DP-014/015, ADR-008; Manual 11.2-11.3, 11.6, 12.4, 17.3, 18.1-18.2; v0.1 backlog item 5; doc 09
- **Problem:** The harness is the design's substitute for the owner's technical judgment and the justification for expanding automation authority, yet it is a permissive 'may include' list with no mandatory minimum per risk class, no named owner or maintenance model, and the v0.1 discovery item defining it silently vanished from the v1.0 backlog with no change-log entry. Nothing requires checks to be executed by deterministic infrastructure the builder cannot influence, results to be recorded tamper-evidently, or approval cards to render from that evidence store rather than agent narrative — so 'passed' chips can be fabricated, approvals become ceremonial, and automation authority ratchets up on self-reported success. The unscoped eight-item list is simultaneously a full CI/security program a solo owner cannot build or operate.
- **Consensus recommendation:** Restore the harness as a named work item at the top of the backlog and add requirements: the harness is a governed application built, versioned, and audited through the same lifecycle; a risk-tiered mandatory minimum per application class (internal tool vs employee-facing vs customer-facing), assembled from hosted services (GitHub Actions CI, branch protection, scanners) rather than custom-built; verdicts come from deterministic checks writing to an append-only evidence store from which approval cards render, with honest coverage disclosure ('2 of 6 checks configured'); evidence counted toward automation-policy expansion must be harness-verified, never self-reported; approval dwell/latency recorded as observations so rubber-stamping surfaces, and the 18.1 'meaningful judgment' measure defined in those terms.
- **Disposition:** Proposed for v1.1 (expert default; batch D8)
- **Owner decision & rationale:** _pending walkthrough review_

### C-15 [High] — Reviewer independence asserted but never operationally defined

- **Sources:** F-APPDEV-03
- **Affected:** APP-03, APP-01, EX-04, AUT-03; Manual 11.2, 12.1-12.4, 16.4, 18.2
- **Problem:** Independence leaks in four places: no re-audit loop exists after the Builder fixes audit-found defects; the one-visible-coordinator model does not exclude builder narrative from the auditor's context; because model assignments are configuration, the same worker could legally serve as Builder and Launch Auditor; and plan-scope comparison has no designated independent executor, allowing builder self-attestation. Today's independence is an accident of using a different vendor and would dissolve silently on a routine configuration change.
- **Consensus recommendation:** Define independence operationally: the Launch Auditor runs in a separate session with separate credentials and an evidence-only input set (approved plan, diff, test results, artifacts — never builder conversation); must be a different worker instance than the Builder for the same build topic (different provider preferred, same provider only with isolated context); post-audit fixes above a defined triviality threshold require scoped re-audit of the changed surface before merge; plan-scope comparison is explicitly assigned to the auditor role.
- **Disposition:** Proposed for v1.1 (expert default; batch D8)
- **Owner decision & rationale:** _pending walkthrough review_

### C-19 [High] — Security work deferred with no gates in the rollout

- **Sources:** F-SEC-06
- **Affected:** Manual 17.1-17.6, 19.3, 5.1; doc 06 security deferral; Appendix A (no SEC family)
- **Problem:** The requirements register contains zero security requirements, and Waves 1-4 as written accumulate a Discord bot token, model API keys, GitHub credentials, mailbox access, and MCP credentials to business systems on an always-on host — plus email bodies, transcripts, and lead data — while no wave contains any security task, precondition, or milestone. Secrets management is unaddressed even at requirement level. For an owner who by his own account skips self-administered protocol, ungated security work is precisely the protocol that will be skipped.
- **Consensus recommendation:** Keep detailed security design in Phase 2, but add to the baseline (a) a security requirement family (identity, secrets, logging, data classification, backup) and (b) per-wave security gates in section 17: Wave 1 requires host hardening, disk encryption, a secrets store with per-agent scoping, and operational-DB backup before durable state goes live; Wave 4 requires data classification (C-20), audit logging (C-21), and untrusted-content handling (C-02) before email, transcripts, or MCP business connections are made.
- **Disposition:** Proposed for v1.1 (expert default; batch D8)
- **Owner decision & rationale:** _pending walkthrough review_

### C-20 [High] — No data classification or Discord exposure policy

- **Sources:** F-SEC-03
- **Affected:** PLAT-01/02, BUS-05/07, PER-02, ORG-06; Manual 5.2, 13.3, 13.8, 14.3, 16.2; ADR-001
- **Problem:** As specified, personal email contents, customer and employee PII, call summaries, and eventually health and financial matters render into a consumer cloud chat platform under Discord's retention, staff access, and breach exposure. PLAT-02 ('not the source of truth') is an architecture statement, not an exposure control — a summary in a Discord message is disclosed regardless of where the authoritative record lives — and no prohibited-in-Discord data classes are defined anywhere. Accumulated exposure cannot be retracted later.
- **Consensus recommendation:** Define data classes (secrets/credentials, health, personal-financial, employee PII, customer PII, business-sensitive, general) and a per-class Discord render policy — never render / render masked or aggregate / render summary with deep link into the purpose-built application — enforced by the system through the Decision Engine's presentation logic, not by owner discipline. The classification framework is mandatory; per-class exposure acceptance is an explicit owner decision framed in business-consequence terms.
- **Decision options:** (A) Strict policy: sensitive classes (health, financial, employee/customer PII) never render in Discord, only masked summaries with deep links — cost: extra taps and reduced at-a-glance value on mobile, where the owner does most approvals. (B) Owner consciously accepts Discord exposure for named classes (e.g., topic status, dev progress, masked lead aggregates) for convenience — cost: irreversible accumulation of business and personal data on a third-party consumer platform, all exposed together in an account compromise. Recommendation: A for health/financial/PII classes, B only for operational status classes, decided class-by-class with the owner.
- **Disposition:** Owner decision D5 — presented in walkthrough scenario 6 (Discord render classes)
- **Owner decision & rationale:** _pending walkthrough review_

### C-21 [High] — Audit logging insufficient to reconstruct any incident

- **Sources:** F-SEC-05
- **Affected:** BUS-02, EX-04, AUT-11; Manual 6.3 (Event), 13.7, 16.4; Appendix A
- **Problem:** The only logging mandate covers business-data reads; agent tool calls, outbound communications, approvals and overrides with acting identity, learning-registry changes, and Personal-domain access are unlogged. The Event object has no completeness, tamper-resistance, or retention requirements and lives in the same operational database agents write to, and the one-visible-coordinator model gives no guarantee that true internal attribution (which worker/model/provider acted) is preserved. When something goes wrong, the owner cannot establish what happened or distinguish attacker actions from legitimate ones.
- **Consensus recommendation:** Require append-only logging of every tool call, data access, outbound message, approval, override, and learning-registry change with true internal actor identity, timestamp, affected object, and evidence link; a defined retention schedule; storage where workers hold no write/delete access; and sufficiency to reconstruct an overnight autonomous session end-to-end. Tie the 9.3 Recent-log views to this same store so operational visibility and forensic record are one dataset.
- **Disposition:** Proposed for v1.1 (expert default; batch D8)
- **Owner decision & rationale:** _pending walkthrough review_

### C-22 [High] — Externalized memory with no backup, watchdog, or degraded mode

- **Sources:** F-SEC-07, F-FEAS-04
- **Affected:** MEM-01/02, HW-01; Manual 4.4, 15.2, 16.3, 18.1, 20.1; doc 06 backup/DR deferral; Appendix A (no OPS family)
- **Problem:** The system is explicitly designed to become the owner's externalized working memory (manual handoffs 'approach zero') while backup/DR is deferred with no gate and no requirement makes the system detect or report its own failure. On a single always-on host run by one non-technical owner, silence reads as 'all quiet' — Discord cannot alert that its own bot is down — so a disk failure, ransomware event, or silent outage loses the business's coordination brain or its overnight work invisibly, with no fallback records because offloading them was the point.
- **Consensus recommendation:** Add a resilience requirement family gated on Wave 1 completion: automated backups of all authoritative stores (operational DB, knowledge layer, artifacts, registries) with at least one offline/offsite copy and a periodic system-verified restore test (system-managed per WF-12, never owner-administered); an external heartbeat/watchdog independent of Discord and the host that pushes to the owner's phone when the coordinator stops checking in; a documented degraded mode (where authoritative state can be read without the bot, automated periodic export); and recurring maintenance (patching, token rotation, API deprecations) as coordinator-managed scheduled system topics.
- **Disposition:** Proposed for v1.1 (expert default; batch D8)
- **Owner decision & rationale:** _pending walkthrough review_

### C-39 [Medium] — Business/Personal separation has no enforcement or remediation path

- **Sources:** F-SEC-09
- **Affected:** PER-02, EX-01, MEM-04, LRN-03, ADR-004; Manual 14.2, 15.3-15.4, 18.2
- **Problem:** Reception is shared by design and misclassification will happen, but scope enforcement is delegated entirely to the storage provider's contract while the coordinator assembles worker context with no stated scope filtering, and no remediation flow re-scopes a misfiled item or purges it from the summaries, checkpoints, and knowledge entries it already touched. PER-02 is currently a paper guarantee with no enforcement point for Phase 2 to build on.
- **Consensus recommendation:** Add requirements: (a) domain scope is enforced at retrieval time by the coordinator for every context assembly, not only promised by the provider; (b) re-scoping an object propagates to derived summaries, checkpoints, and knowledge entries with a logged event; (c) cross-domain retrieval requires an explicit, logged exception.
- **Disposition:** Proposed for v1.1 (expert default; batch D8)
- **Owner decision & rationale:** _pending walkthrough review_

### C-40 [Medium] — Employee and caller data processed without compliance treatment

- **Sources:** F-SEC-08
- **Affected:** BUS-03, AUT-10, ORG-06; Manual 1, 11.6, 13.5-13.6; Decision Trail 34-36
- **Problem:** Call transcripts of named employees, AI-assisted performance ratings, coaching insights, and verification dossiers are created and copied into new stores (knowledge layer, Discord, coaching topics) with no treatment of consent, notice, call-recording law, retention limits, or employee access/dispute rights; customers' personal data in transcripts is likewise unaddressed. The derived records are a new processing purpose the call platform's compliance posture does not cover, creating legal exposure and a serious trust problem if ever surfaced in a dispute.
- **Consensus recommendation:** Add requirements: defined lawful basis/notice for employee and caller data; retention limits for transcripts, ratings, and derived insights; a defined answer to employee access/dispute requests linked to audit-log lineage (C-21); a call-recording jurisdiction check; AI-derived ratings labeled as owner-reviewed judgments, never autonomous records. Defer coaching-trend analytics until these are settled; per-call owner rating prompts may proceed.
- **Disposition:** Proposed for v1.1 (expert default; batch D8)
- **Owner decision & rationale:** _pending walkthrough review_

### C-49 [Low] — System-record deletion is unlogged and approval-free

- **Sources:** F-SEC-10
- **Affected:** LRN-05, AUT-11; Manual 10.4, 11.3, 11.7
- **Problem:** LRN-05 permits permanent deletion of rules, preferences, skills, observations, artifacts, and events with no actor, approval, or logging constraint — unreconciled with 11.7's 'history is appended, not rewritten' — and the 11.3 action-class table has no deletion row. Unlogged deletion is also the natural cover for evidence-tampering scenarios.
- **Consensus recommendation:** Make deletion of any system object an explicit approval-required action class; require a permanent tombstone event (who, what, why, when) that survives the deletion; state that Archived, not Deleted, is the only state reachable without owner approval.
- **Disposition:** Proposed for v1.1 (expert default; batch D8)
- **Owner decision & rationale:** _pending walkthrough review_


## Tier 3 — Sequencing for owner attention (nothing cut from the vision)

### C-03 [High] — Build and operating scope is roughly triple solo capacity

- **Sources:** F-FEAS-01
- **Affected:** Manual 5.1-5.2, 10, 11, 13, 15, 17.1-17.6; MEM-01, AUT-03, AUT-07-11, BUS-02/05, LRN-01-08
- **Problem:** Waves 0-5 explicitly require roughly 24 distinct subsystems with no effort, capacity, or operating-cost model anywhere in the packet. The binding constraint is the owner's review, debugging, and integration bandwidth — realistically 6-8 well-operated subsystems for a solo non-technical owner, versus a 12-24+ month build plus a permanent multi-hour weekly operations load as written. The plan would fail on capacity even if every design decision were correct.
- **Consensus recommendation:** Add a one-page capacity model to v1.1 (subsystem inventory, order-of-magnitude effort per wave, standing owner-time and dollar budgets, a per-wave subsystem cap) and mark every requirement as Version-1 versus target-architecture. The auditors' converged V1 core: checkpoints/resumption, capture/classification, operational state + rendering, and a risk-tiered hosted-CI harness; most of AUT-07-11, BUS-02, BUS-05, LRN-05/06, and the reconciliation engine become target-architecture.
- **Decision options:** (A) Rescope V1 to the 6-8 subsystem resumption/visibility core and mark the rest target-architecture — cost: features the owner explicitly asked for (Mailroom automation, delegation tracking, learning machinery) leave V1 and arrive only after gates pass. (B) Keep the full Wave 0-5 scope and accept a multi-year build with sustained 4-10 hrs/week operations, possibly paying for help — cost: money, long-deferred payoff, and maximum abandonment risk given the owner's documented history of abandoning invisible-effort projects. Recommendation: A.
- **Disposition:** Owner decision D1 — presented in walkthrough closing (activation order)
- **Owner decision & rationale:** _pending walkthrough review_

### C-04 [High] — No wave delivers the coordinator; Wave 1 contradicts WF-12

- **Sources:** F-FEAS-02, F-WFDS-13
- **Affected:** Manual 17.1-17.5, 19.2; WF-12, WF-09/10/11, DP-001, EX-01, DEC-01, AUT-01/02, ATT-01-03
- **Problem:** No rollout wave implements Reception classification, interruption routing, attention handling, or protocol coaching — the components that produce the owner's core pain relief — and the wave plan never states which waves depend on Phase 2 Decision Engine output. Wave 1 as written hands the owner a manually administered tracker, which is exactly the self-administered protocol the packet itself (3.3, 7.5, WF-12) predicts he will abandon; the first live experience of the system is its own documented failure mode. Mechanism-encoding requirements are also inconsistently annotated, so Phase 2 inherits 'Confirmed' items it must be free to redesign.
- **Consensus recommendation:** Rescope Wave 1 to include a minimal LLM-backed coordinator: Reception capture with automatic classification into topic/checkpoint records, automatic status updates from worker events, and a Needs-You queue; restrict manual-only operation to the Wave 0 clickable prototype. Add an explicit wave-to-Phase-2 dependency map, and annotate WF-09/10/11, the ATT calibration defaults, and AUT-01/02 as 'confirmed intent, mechanism pending Phase 2' so the register's status column distinguishes intent from mechanism.
- **Disposition:** Owner decision D2 — presented in walkthrough closing (day-one substrate)
- **Owner decision & rationale:** _pending walkthrough review_

### C-05 [High] — Only one wave has a gate, and it is unmeasurable

- **Sources:** F-FEAS-03, F-APPDEV-08
- **Affected:** Manual 17.2-17.6, 18.1, 18.2 hobby-risk row
- **Problem:** Only Wave 2 has a go/no-go gate, and it is defined against 'current productivity' — a baseline that is never captured, so the packet's strongest scope brake cannot be objectively passed or failed. Waves 1, 3, 4, and 5 have no entry, exit, or abandonment criteria, and all ten 18.1 success measures track benefits while none track the cost side (hours and dollars spent building and operating the system). The system consuming the owner's capacity would be invisible to its own metrics — the exact invisible-effort pattern behind his abandonment history.
- **Consensus recommendation:** Add a pre-migration baseline task (recent cycle time from approved plan to deployed change on the pilot app; owner orchestration hours per change) and define the Wave 2 gate against those numbers. Give every wave a go/no-go gate tied to a named pain-relief measure, add weekly system build/maintenance hours and monthly system cost to 18.1, and define a stop/park criterion (e.g., two consecutive missed gates parks the program and preserves state).
- **Disposition:** Proposed for v1.1 (expert default; batch D8)
- **Owner decision & rationale:** _pending walkthrough review_

### C-28 [Medium] — Five authoritative stores overbuilt for Version 1

- **Sources:** F-FEAS-07, F-CLAUDE-09
- **Affected:** MEM-01/02; Manual 5.2, 15.2, 17.2, 17.4; APP-02/04
- **Problem:** The core pain relief (resumption, visibility, capture, protocol) needs only the operational DB, Git, and a filesystem; the governed artifact store and semantic layer are enhancements that each add build, backup, and consistency surface. Meanwhile checkpoints-as-git-files already satisfy MEM-02 for development topics natively, yet Wave 1 fronts a custom operational data model before any value ships — sequencing durability behind schema design.
- **Consensus recommendation:** Reword MEM-01 as target architecture with a V1 clause: operational DB + Git (including per-topic checkpoint files) + filesystem with DB-held metadata satisfies Version 1; the database serves presentation, statuses, and rollups rather than being a prerequisite for durability; the semantic knowledge layer activates only after the Wave 2 gate passes; the governed artifact store is a Phase 2+ upgrade. The full five-store ownership matrix (C-06) still gets defined now — built incrementally.
- **Disposition:** Proposed for v1.1 (expert default; batch D8)
- **Owner decision & rationale:** _pending walkthrough review_

### C-29 [Medium] — No adopt-vs-build disposition before the waves execute

- **Sources:** F-CLAUDE-01
- **Affected:** Manual 5.1, 17.2-17.4; DP-020, PLAT-04, DEC-01, APP-04, MEM-02
- **Problem:** Waves 1-3 are written as build tasks for subsystems that today are products or configuration of existing capabilities (scheduled routines/triggers, session resume and compaction, CI plus hooks as harness substrate, skills-as-files with PR review, email connectors), and no artifact requires an adopt/configure/build disposition before implementation. Provider-blind design was deliberate, but without a mapping step Phase 2 risks specifying schemas and machinery for solved problems, spending the owner's limited review bandwidth on reinvention.
- **Consensus recommendation:** Add a mandatory capability-mapping artifact to v1.1, completed before Phase 2 and before the wave plan is rewritten: for each subsystem (coordinator, scheduler, checkpointing, harness, registry, gateway, email triage) record adopt / configure / genuinely-custom — the recursive hub state model, fold-back, and Discord rendering being the genuinely custom core — and rewrite Wave 1-3 tasks against that mapping.
- **Disposition:** Proposed for v1.1 (expert default; batch D8)
- **Owner decision & rationale:** _pending walkthrough review_

### C-30 [Medium] — Role-tool mapping carries the old PC bottleneck into Wave 2

- **Sources:** F-APPDEV-05, F-CLAUDE-07
- **Affected:** APP-01, APP-03, APP-04, MEM-03; Manual 3.2-3.3, 12.1, 17.3, 20.1; Decision Trail 19
- **Problem:** Debugger=Cursor keeps a human-driven, PC-bound IDE inside the pipeline — it cannot run as a coordinator-managed worker, emit checkpoints, or be replaced per APP-04, and it reinstates the exact PC bottleneck section 3.3 names as core friction. The six-role list is a carryover of the current tool inventory rather than a designed target, inserting undefined handoffs at the moment of highest context density, and the Hyperagent/Codex auditor chain's availability and headless drivability are unvalidated. Wave 2 hard-commits to all six roles anyway.
- **Consensus recommendation:** For Version 1, collapse Debugger into Builder as a repair mode within the same topic/checkpoint machinery, and implement Ideator/Designer as coordinator-led Discovery/Design stages — reducing Wave 2 to three worker roles (Planner, Builder, Launch Auditor) on one platform, with auditor independence achieved via session isolation and/or CI-triggered review. Keep the role abstraction (APP-01) so the six-role configuration remains available; record Cursor and Hyperagent/Codex as optional enhancements in the model-routing backlog, and add a validation task confirming each remaining role's tool can be driven headlessly.
- **Disposition:** Owner decision D3 — presented in walkthrough scenario 5 (worker roles)
- **Owner decision & rationale:** _pending walkthrough review_

### C-44 [Medium] — No coexistence plan for months of dual-system operation

- **Sources:** F-FEAS-10
- **Affected:** Manual 3.3, 17.2-17.3, 18.1
- **Problem:** Wave 2 migrates exactly one pilot application; nothing states how the owner's other 3-4 chat-session projects and daily business operations run during the months of Waves 1-3, when he is operating the old fragmented workflow while also building and feeding the new system. This dual-system period is the highest-load, highest-abandonment-risk phase and it is entirely unplanned and unmeasured.
- **Consensus recommendation:** Add a coexistence rule: non-pilot projects stay entirely in current tools until the Wave 2 gate passes (no partial migration); define the cutover trigger and a per-project migration checklist as a Wave 2 exit artifact; optionally let the new system passively capture checkpoints for old-tool projects (cheap, high resumption value) without migrating them.
- **Disposition:** Proposed for v1.1 (expert default; batch D8)
- **Owner decision & rationale:** _pending walkthrough review_

### C-45 [Medium] — Mac Studio purchase precedes any wave that needs it

- **Sources:** F-FEAS-09, F-CLAUDE-06
- **Affected:** HW-01, ADR-011; Manual 17.6, 20.1-20.2, 2.3
- **Problem:** The design is explicitly cloud-first, and Waves 0-2 run on a cheap VM or existing spare hardware; the premium host's differentiating capacity serves exactly the workloads (local inference, broad local hosting) the packet itself defers to Wave 5. HW-01 stands 'Confirmed Phase 1' while ADR-011 says provisional-until-purchase — a register/ADR contradiction — and an early ~$4k purchase adds the sunk-cost commitment the hobby-risk mitigation warns against.
- **Consensus recommendation:** Reclassify HW-01 as a deferred purchase decision gated on the Wave 2 pilot success gate, resolving the register/ADR contradiction; add an interim hosting line to Waves 0-2 (cloud agent sessions + GitHub + a cheap always-on gateway host); purchase when a measured workload (builds, browser automation, embeddings, concurrency) exceeds the interim host.
- **Decision options:** (A) Defer the purchase behind the Wave 2 gate — cost: a possible later host migration (cheap by construction, since PLAT-04 makes state portable) and delayed ownership of the target hardware. (B) Buy up front to avoid migration and force commitment — cost: ~$4,000 committed before the operating model is validated, inverting the packet's own hobby-risk mitigation and creating sunk-cost pressure on a program that currently lacks stop criteria. Recommendation: A.
- **Disposition:** Owner decision D7 — presented in walkthrough closing (Mac Studio expectations/timing)
- **Owner decision & rationale:** _pending walkthrough review_

### C-46 [Medium] — Highest-value email relief sequenced last, behind unneeded dependencies

- **Sources:** F-CLAUDE-05
- **Affected:** BUS-05; Manual 13.8, 17.5, 3.3; PER-02
- **Problem:** Basic Mailroom triage (the 13.8 classification card in a daily brief) is achievable today as email-connector-plus-scheduled-routine configuration, but sits in Wave 4 behind the operational database, Data HQ, and MCP integrations it does not need — while email batching is the owner's documented top daily friction and the project needs an early visible proof of value. Pulling it forward, however, ingests attacker-controlled content earlier (see C-02).
- **Consensus recommendation:** Split Mailroom: (a) a read-only triage brief — classification and summary only, no drafting, no outbound actions, no tool-holding agent processing bodies beyond classification, separately scoped work/personal connectors — eligible to pull forward once minimal display-quarantine handling exists; (b) full Mailroom with drafts and workflow creation stays in Wave 4 behind the C-02/C-19/C-20 controls, since drafting is the most direct injection-to-exfiltration path.
- **Decision options:** (A) Pull read-only triage forward for early visible relief of the worst documented pain — cost: external email content enters the system before the full untrusted-content architecture exists, acceptable only under strict display-only containment and explicit owner risk acceptance. (B) Keep all email ingestion in Wave 4 behind full security gates — cost: months of continued email pain and loss of the cheapest early proof of value for an owner whose engagement depends on visible progress. Recommendation: A with the stated containment, revisited if any injection-shaped incident occurs.
- **Disposition:** Owner decision D6 — presented in walkthrough scenario 7 (email timing)
- **Owner decision & rationale:** _pending walkthrough review_

### C-48 [Low] — Cold-start seeding never stated in Wave 0/1

- **Sources:** F-UX-04
- **Affected:** Manual 17.1-17.2, 10.2, 4.5; EX-02, LRN-01; Decision Trail 06
- **Problem:** No packet document mentions onboarding, cold start, or seeding (verified by search). The staged rollout blunts the worst case — Wave 0 is a seeded manual prototype and Wave 1 has no autonomous recommender — but nothing says to pre-populate the owner's real in-flight projects or pre-load the preferences already evidenced in this packet's interview record, and no first-session value milestone exists for an owner with a documented learning-curve abandonment history.
- **Consensus recommendation:** Add to Wave 0/1: seed the prototype and first live use with the owner's current 3-4 active projects as pre-populated hubs with kickoff records; pre-load interview-evidenced preferences (bounded questions, no-fluff delivery, layered To-Do, layman consequences) as Active items via the existing 10.2 manual-proposal path; define a first-session value milestone.
- **Disposition:** Proposed for v1.1 (expert default; batch D8)
- **Owner decision & rationale:** _pending walkthrough review_


## Tier 4 — Build backlog (legitimate, but build-phase — not concept defects)

### C-18 [High] — No merge or integration policy despite encouraged parallel branches

- **Sources:** F-APPDEV-06
- **Affected:** APP-03, AUT-03; Manual 11.3, 12.2-12.3
- **Problem:** Section 12.2 says 'merge/deploy according to action policy' but the 11.3 action-class table contains no merge class, so the referenced policy does not exist. No merge ordering, conflict-resolution responsibility, or rebase policy is defined for the explicitly encouraged parallel defect branches, and — critically — audits happen on branches, so the merged combined state that actually deploys was never reviewed by any auditor while being reported as verified.
- **Consensus recommendation:** Add 'Merge to mainline' as an explicit 11.3 action class with an initial approval/auditor-sign-off policy; serialize merges of concurrently audited branches; after any non-trivial conflict resolution or any merge postdating an audit, re-run the automated check suite, with material conflicts triggering scoped re-audit before deploy.
- **Decision options:** (A) Full merge policy now — preserves parallel defect work (a stated attraction of the design) at the cost of specifying and operating more policy machinery in V1. (B) One-active-build-branch-per-repository rule for V1 — near-zero specification cost and eliminates the audit-invalidation window, at the cost of giving up parallelism until it is demonstrably needed, then adopting (A). Recommendation: B for Version 1, revisited when parallel work is actually required.
- **Disposition:** Moved to build backlog
- **Owner decision & rationale:** _pending walkthrough review_

### C-27 [Medium] — Gateway and transcript layer: ungoverned vendor at most privileged point

- **Sources:** F-ARCH-10, F-FEAS-06, F-CLAUDE-08
- **Affected:** PLAT-02/04, MEM-01/04; Manual 2.3, 5.2, 15.4; ADRs 001-012 (no gateway ADR); Decision Trail 01
- **Problem:** The source-of-truth table names 'Discord/OpenClaw transcripts' as the authoritative store for interaction history — a vendor-specific assumption embedded in the core state model, contradicting the packet's own vendor-independence discipline. OpenClaw is a young, fast-moving project that would hold all credentials and agent dispatch, yet unlike Gbrain it has no ADR, capability contract, security gate, or fallback; evidence chains for observations and completion claims dangle into a chat platform with no export/retention/provenance contract, and known Gbrain contract gaps (sensitivity scoping, lifecycle tracking) are unrecorded.
- **Consensus recommendation:** Reclassify Discord/OpenClaw as a transient presentation/capture surface and make the artifact/event archive the authoritative home of interaction history that matters (referenced excerpts archived with provenance when they become evidence). Add a gateway/runtime contract ADR mirroring 15.4 — session control, event webhooks, token handling, transcript export — with OpenClaw as one candidate and a plain bot library as documented fallback, plus a security-review gate (network exposure, credential storage, update cadence) for whichever gateway is adopted. Annotate MEM-04 with the known Gbrain gaps so Wave 3 contract testing targets scoping and lifecycle tracking first.
- **Disposition:** Moved to build backlog
- **Owner decision & rationale:** _pending walkthrough review_

### C-31 [Medium] — Mid-build plan deviation loop undefined

- **Sources:** F-APPDEV-07
- **Affected:** AUT-04/05, WF-02, WF-06; Manual 11.2, 11.4, 12.2
- **Problem:** When the Builder discovers mid-implementation that the approved plan is wrong or infeasible, nothing defines whether the topic reverts to Planning, whether the owner re-approves a delta or the whole plan, what happens to partial branch work, or — sharpest — who decides whether a deviation is business-visible (owner approval) versus technical-only (harness evidence). Detection at audit time means the wasted work already happened; routing everything to the owner recreates ceremonial approvals.
- **Consensus recommendation:** Define a Plan Deviation record (what diverged, why, business-visible or not, options): business-visible deviations pause affected work and surface as a bounded delta decision in business terms per the 8.6 standard; technical-only deviations are approved via the Planner/Auditor path and logged so the launch audit compares against plan-plus-approved-deltas; partial branch work is preserved under the paused topic, never discarded.
- **Disposition:** Moved to build backlog
- **Owner decision & rationale:** _pending walkthrough review_

### C-32 [Medium] — Delegation claim ingestion and overdue ladder not wired

- **Sources:** F-WFDS-04
- **Affected:** AUT-07-10, ORG-06; Manual 11.5-11.6, 13.3, 13.8, 4.5, 17 (no wave)
- **Problem:** The ingestion mechanisms exist in principle (read-only MCP inspection of business apps, Mailroom email), but nothing wires an employee's completion evidence to a specific assignment's claim; only first-overdue behavior is defined, 'reassigned' is absent from the state machine, and delegation tracking appears in no rollout wave even though its prerequisites land in Wave 4.
- **Consensus recommendation:** Explicitly wire claim ingestion channels (Mailroom parse, MCP record match, owner relay as a logged fallback) to the Assignment object; complete the state machine with an overdue escalation ladder and a reassigned transition; assign delegation tracking to Wave 4 or later — or state explicitly that V1 delegation is scoped to AI agents and owner-personal tasks, since AUT-07-10 and the decision trail currently promise employee delegation.
- **Disposition:** Moved to build backlog
- **Owner decision & rationale:** _pending walkthrough review_

### C-33 [Medium] — Learning loops lack observable, recordable telemetry

- **Sources:** F-WFDS-11, F-CLAUDE-03
- **Affected:** WF-11, LRN-06, MEM-04, DP-011; Manual 6.3, 8.2, 10.4-10.5, 15.4, 18.1
- **Problem:** The recommendation-learning loop has no object-model home, no rationale-ask budget, and no success measure — the system can claim to be learning indefinitely with no way to verify it. Separately, the registry's 'last applied' and 'usage count' semantics are never defined, and per-output attribution of prompt-level preference compliance does not exist on any provider, so decay reviews would otherwise rest on fictional telemetry.
- **Consensus recommendation:** Require every routing recommendation, alternatives set, owner selection, and rationale to be recorded as Decision/Event records in the operational database; add recommendation-acceptance rate to 18.1 and a provisional rationale-ask budget (e.g., at most one per day). Split registry telemetry by object class: skills tracked by explicit invocation (real signal); preferences/rules tracked by deterministic activation events, exception counts (observable per LRN-04), and calendar-based review — with per-application attribution explicitly declared out of scope for V1 in MEM-04.
- **Disposition:** Moved to build backlog
- **Owner decision & rationale:** _pending walkthrough review_

### C-43 [Medium] — Linked business dates have no synchronization or precedence rule

- **Sources:** F-ARCH-11
- **Affected:** BUS-08, ADR-006; Manual 13.4
- **Problem:** A lead follow-up exists simultaneously as a business fact (app-owned follow-up date) and a coordination obligation (AI-OS-owned due date and reminders), and 'bidirectionally linked' has no conflict behavior — the owner postpones in the app and the AI OS reminder still fires. Diverging deadlines produce wrong reminders and erode exactly the trust ADR-006 was written to protect.
- **Consensus recommendation:** Add a boundary rule to ADR-006: for linked records, the business application's dates are authoritative facts and AI OS coordination items subscribe to them, recalculating reminders on change events; the AI OS holds an independent due date only for obligations that exist in no application.
- **Disposition:** Moved to build backlog
- **Owner decision & rationale:** _pending walkthrough review_


## Genuine disagreements (synthesized)

### What Wave 1 must contain: custom minimal coordinator versus adopt-existing files-first delivery (C-04 vs C-28/C-29)

- **Position A:** Feasibility position (F-FEAS-02): rescope Wave 1 around a minimal LLM-backed coordinator and structured operational data model so classification, automatic status, and the Needs-You queue are real from first daily use. Cost accepted: more custom build before any live value, a longer path to first light, and risk of building engine mechanics Phase 2 may redesign.
- **Position B:** Ecosystem position (F-CLAUDE-01/09): adopt-first and files-first — checkpoints as git-committed markdown, scheduled routines, connectors, and native session resume deliver resumption value in days with almost no custom code. Cost accepted: no queryable state or deterministic rollups initially, some rework when the database arrives, and the early experience rides on general-purpose tools rather than the designed experience.
- **Synthesis:** Both positions agree the currently written manual-tracker Wave 1 fails (confirmed F-FEAS-02). Make Wave 1 a thin LLM-backed coordinator for capture, classification, and checkpoint maintenance layered over adopted components with files as the durable record; introduce the operational database within Waves 1-2 only when rendering and rollups need queryable state (the DB serves presentation, not durability). The C-29 capability-mapping artifact decides adopt-vs-build per subsystem before the wave plan is rewritten.

### Routing default for ambiguous interjections: always recommend-with-alternatives versus act-with-receipt below a threshold (C-11)

- **Position A:** Owner-fidelity position (WFDS strength list; Decision Trail 28 is an explicit owner-sourced choice): present recommendation plus meaningful alternatives at every genuinely multi-valid juncture, recording the selection as learning evidence. Cost accepted: decision fatigue on the single highest-frequency interaction, and the risk that a fatigued owner answers reflexively, corrupting the very learning signal the prompts exist to collect.
- **Position B:** Cognitive-load position (F-UX-01): below a defined impact/confidence threshold, file per the system's own recommendation with a one-line visible receipt ('Filed under X — [change]') and batch confirmations into review moments. Cost accepted: occasional misfiles, a deviation from the owner's literal recorded request, and safety that depends entirely on cheap correction primitives existing first.
- **Synthesis:** Keep recommend-with-alternatives for high-impact or low-confidence junctures (honoring trail 28); add the act-with-receipt tier only for trivial-ambiguous routing and only after C-11's correction primitives (re-parent/merge/reclassify, 'wrong place' command) land. Because trail 28 is a recorded owner decision, present this explicitly to the owner rather than changing it by architect default, and add routing-prompt volume to 18.1 so the calibration is measurable either way.

### Wave 2 worker roles: implement all six as confirmed versus collapse to three (C-30)

- **Position A:** Continuity position (Wave 2 as written, 17.3): implement Ideator, Designer, Planner, Builder, Debugger, and Launch Auditor, preserving the owner's described lifecycle and current tool habits. Cost accepted: handoff infrastructure at the moments of highest context density, retention of the Cursor/PC bottleneck the design exists to remove, and six undefined handoff contracts (C-17) instead of two.
- **Position B:** Simplification position (F-APPDEV-05, F-CLAUDE-07): Wave 2 builds Planner, Builder, and Launch Auditor only — Debugger becomes a Builder repair mode, Ideator/Designer become coordinator-led Discovery/Design stages. Cost accepted: departs from the owner's stated six-stage mental model and defers validating full role separation until evidence shows it is needed.
- **Synthesis:** Adopt the three-role Wave 2 while keeping the role abstraction (APP-01) intact so the six-role configuration remains a later expansion, and note that decision trail 19 records the six stages as current-state inventory, not a binding target-model choice. The separation that must survive in any configuration is builder-versus-auditor independence (C-15), which both positions preserve.

### Email: pull Mailroom triage forward for early value versus gate all email ingestion behind security controls (C-46 vs C-02/C-19)

- **Position A:** Early-value position (F-CLAUDE-05): read-only Mailroom triage is nearly pure configuration today and relieves the owner's worst documented daily pain in Wave 1, providing the early visible payoff his engagement history requires. Cost accepted: attacker-controlled email content enters the system before the untrusted-content architecture, data classification, and audit logging exist.
- **Position B:** Security position (F-SEC-02/06 and the SEC defer list): no email ingestion until trust-class handling, data classification, and logging gates exist at Wave 4 — email is the most direct injection-to-exfiltration path, especially via drafting. Cost accepted: months of continued email pain and the loss of the project's cheapest early proof of value, raising abandonment risk.
- **Synthesis:** Allow an early read-only triage brief under strict interim containment — display-only summaries, no drafting, no outbound actions, no tool-holding agent processing message bodies beyond classification, separately scoped work/personal connectors — with drafting and any action-taking held behind the full C-02/C-19/C-20 controls. Present this to the owner as an explicit, revocable risk acceptance rather than a silent default.


## Strengths to preserve (named across auditors)

- Topic checkpoint outside live model context as the durable resumption record (MEM-02/03, 15.2-15.3) — named by five auditors as the single highest-value primitive and the correct answer to session death, compaction, and provider replacement; anchor the rescoped V1 on it.
- Stage-as-state on persistent topics with independent stage/status/focus dimensions (ADR-003, WF-01-03) — matches the owner's nonlinear, revisit-prone working style instead of punishing it; preserve exactly, fixing only the vocabulary conflicts (C-07).
- Capture without entry-time classification (Reception, EX-01, DP-001: 'the user produces thoughts; the system organizes them') — the right core contract for this owner; C-11/C-38 complete it rather than change it.
- Observation-as-weak-evidence governed learning with no silent behavior change (ADR-007, LRN-01/02) — the packet's strongest single safety property, to be extended by (not replaced with) the untrusted-content controls.
- Split ownership of truth (ADR-006, 13.4): business applications own facts, the AI OS owns coordination — prevents a shadow CRM and duplicate record maintenance; needs only the date-sync rule (C-43).
- Approval philosophy (11.1-11.2, DP-015): the owner approves problem, business behavior, and outcome while a technical harness carries implementation acceptance, with the layman 'DECISION REQUIRED' card pattern — exactly right for a non-technical owner, which is why the harness must become a real trust boundary (C-14).
- Contract-before-provider discipline: the memory contract precedes Gbrain selection (15.4, MEM-04), lifecycle roles are model-agnostic configuration (APP-01, DP-020), and 2.3's rule that provider limitations must not silently become the operating model — the packet's best protection against vendor churn.
- Discord as a thin presentation layer over authoritative external state (PLAT-02, 16.2, ADR-001) with minimal permanent channels — the correct architecture for surviving Discord's limits and eventual replacement.
- The attention model separating visibility from interruption, defaulting away from forced interrupts, with owner-calibrated levels (ADR-009, 4.5, Decision Trail 38) — correct for an ADD owner; needs aging/escalation governance (C-12), not redesign.
- System-owned protocol and housekeeping (WF-12, 7.5) plus layered To-Do/To-Did visible momentum (ORG-04, 9.4) — the design correctly refuses to make the owner the housekeeper and directly serves the documented ADD motivation failure.
- Least-privilege instincts: read-only-first MCP expanding only by action class, evidence, and explicit policy (BUS-04, 13.7, AUT-02), and employees never touching the private operating environment (ORG-06) — sound skeletons for the security work the audit adds.
- Baseline hygiene and honesty: the decision-prompt quality standard banning manufactured choices (INT-01, 8.6), tri-state completion (AUT-09), the authority order and audit gate (00/07), the labeled provisional items (doc 06), and the Conversation Decision Trail (doc 08) that let auditors distinguish deliberate owner choices from architect generalizations.

## Overall pattern

All seven auditors returned Pass-with-changes, and none attacked the operating philosophy: the primitives — persistent topics, checkpoints outside model context, governed learning, split truth ownership, harness-based approval — were repeatedly named as strengths and are unusually well matched to this owner's cognitive profile. The findings instead tell one story in three movements. First, the kernel is underspecified exactly where Phase 2 will formalize it: the packet's own documents contradict each other on the status vocabulary, and rollup, store-ownership, identity, hierarchy-depth, and classification semantics are missing or frozen in forms the Phase 2 backlog simultaneously reopens. Second, every enforcement surface is asserted rather than operationalized — owner identity, untrusted content, harness evidence provenance, reviewer independence, audit logs, backups — so the system as written could self-approve and fail silently in front of the one user who by design cannot verify technical claims; the two Critical findings are simply the sharpest instances. Third, scope and sequencing invert the design's own promises: roughly triple solo capacity, no wave delivering the coordinator, one unmeasurable gate, and ungoverned review queues would relocate onto the owner the classification, protocol, and vigilance burdens the system exists to remove. Nearly everything is repairable by v1.1 specification, rescoping, and gating rather than redesign — which is precisely the outcome the packet's own audit gate was built to force before Phase 2 opens.
---

## Verifier merge (ChatGPT peer verification, 2026-07-25)

ChatGPT, acting as assigned independent stage verifier, dispositioned all 22 Critical/High entries: **zero dissents** - every entry Concur or Concur-with-modification. Fable (project manager) reviewed and adopted every verifier modification. Three verifier-originated findings were added to the register:

| ID | Severity | Tier | Title |
| --- | --- | --- | --- |
| G-01 | High | protection-layer | Checkpoint integrity: protected vs generated fields |
| G-02 | High | protection-layer | Idempotency and uncertain-outcome handling for consequential actions |
| G-03 | Medium | concept-consistency | Schema versioning and migration contract for persistent state |

Mediums/Lows (C-23..C-49) were summary-only in Rev 2 and are not individually verifier-checked; their full records are in this register (and the CSV) and remain non-blocking provisional per the verifier's scope note.

Per-entry verifier verdicts and modifications are recorded in `02_Consensus_Issue_Register.csv` (columns: Verifier disposition / Verifier modification / Fable manager disposition). The verifier's full response is preserved verbatim at `03_Auditor_Reports/VERIFIER_ChatGPT_response.md`.