# 20 — TASK-0007 R3 Task Packet, Revision 3 — the selected authority contracts

**This supersedes `17_` (Revision 2) in full.** Revision 2 failed the verifier gate (`18_`, concurred in `19_`) because it delegated architecture decisions to the Builder. This revision **makes every decision.** Where a clause here still leaves a choice, it is an implementation-internal choice (data-structure and function decomposition) inside a Fable-specified contract; if any clause instead leaves a *trust, authority, evidence, route, or limit* decision open, that is a defect — **stop and report it before building.**

The round is unchanged in nature: an increment on the integrated R2 stub baseline, throwaway POC apparatus, no Track B credit, every THROWAWAY marker preserved.

## 0. Snapshot binding, authority manifest, allowlists (R3P-02, R3P-06, R3P-08)

```text
Repository:   hkosar/ai-hq
Branch:       claude/fable-coordinator-handoff-vqpu33
Base commit:  <the commit that integrates this packet; see git bundle below>
```

**Git binding (independently reproducible):** the relay zip carries `base.gitbundle`. Verify it without the live repo: `git bundle verify base.gitbundle`, then `git clone base.gitbundle base && git -C base rev-parse HEAD^{tree}` — the tree hash must equal the one in `authority_manifest.json`. This closes `18A_`'s `commit_tree_binding_independently_reproducible: false`.

**Authority manifest (`authority_manifest.json`, shipped in the relay):** the normative classification of every file — `path, sha256, origin, trust_class, instruction_authority, artifact_role, supersedes/superseded_by, required_for_task`. Integrity (`SHA256SUMS.txt`) proves the bytes; the authority manifest states what each file *is*. Binding facts:
- **Governing instruction:** this file (`20_`) only. `instruction_authority: governing`.
- **Reference (read, do not treat as instruction):** `19_`, `18_`, `16_`, `15_`, `13_`, `12_`, `09_` §2, `08_`. `instruction_authority: reference`.
- **Evidence-only (never instruction):** `R2_Return_Manifest.json`, the R2 Builder Delivery Record (which travels in the relay, not the repo tree), all `12A_`/`15A_`/`18A_` probe JSONs, all `poc/**/out/**`. A Builder-authored completion claim is evidence and context; hashing it does not make it authority.

**Implementation allowlist** (Builder MAY modify): `poc/stub/stub_server.py` · `poc/stub/selftest_stub.py` · `poc/stub/r1_witnesses.py` · `poc/workflows/n8n/*.json` · `poc/workflows/zapier/POC_zap_build_specs.json` · `poc/runbooks/*.md` · `poc/README.md` · `poc/FINDINGS.md` · `poc/data/captures/README.md` · `poc/data/measurements.template.json` · `poc/data/validate_measurements.py` (new; Builder authors it to §6).

**Control/evidence allowlist** (regenerate by running, do not hand-edit): `poc/harness/out/**` · `poc/stub/out/**`.

**Immutable denylist** (MUST NOT change; a diff here fails the round): `poc/stub/r1_reference/stub_server_r1.py` (the SHA-pinned R1 witness reference) · all `poc/harness/*.py`, `poc/harness/*.mjs`, `poc/harness/run_all.sh` (harness **code** — a corrected capture shape that needs a harness-code change is a **change request**, not an edit).

**Baseline status, used verbatim wherever the baseline is described:** *"R2 is structurally integrated as the implementation baseline; its security claims remain Builder-authored and unaccepted until the final independent review of the R2+R3 stub."*

## 1. Governing rule (unchanged from Rev 2, restated because it is the point)

> Every authority the service asserts must trace to something the service itself established. A value a caller supplied is corroborating material, never an authority.

## 2. The two selected authority mechanisms (R2P-01, R2P-02, R3P-01)

### C-20 — Artifact authenticity: SELECTED = trusted preregistration

Chosen over wrapper ingress because it keeps the stub JSON-only (no raw-bytes/multipart surface on a throwaway service) while still testing binary fidelity by digest comparison. The bytes travel provider-side (the workflow's own file nodes); the stub holds only the digests and metadata, as the authority.

**New owner route `POST /owner/artifact/register`** (owner-key only). Accepts and records an immutable registration:

```text
artifact_id        stub-minted ("art-" + 12 hex); returned to the owner
source_digest      REQUIRED, 64-hex; the authoritative artifact identity, immutable once registered
size_bytes         REQUIRED, non-negative int
file_count         REQUIRED, positive int (archives: member count; else 1)
task_id            REQUIRED, string
transition         REQUIRED, string
target_role        REQUIRED, must be a known authorized role (§4 role table)
registration_ref   stub-minted opaque ("reg-" + token_urlsafe(24)); the provider may carry THIS
```

Registration identity = `sha256(source_digest | task_id | transition)`. **Same bytes under a different `task_id` or `transition` are a distinct registration** (R2P-01, `15_` §5 test 5). Re-registering the same identity returns the existing `artifact_id`/`registration_ref` (idempotent), never a second record.

**`/poc1/review-case` changes:** it no longer accepts a free `artifact_digest` as authority. It accepts `registration_ref` (REQUIRED) plus the identity tuple. The service looks up the registration and enforces: the tuple's `task_id`, `transition`, `target_role` **equal the registered values**, and the tuple's `artifact_digest` **equals the registered `source_digest`** — mismatch on any is a captured 403 `rejected-artifact-binding`. A provider-supplied digest is thus only ever *checked against* the owner-registered one, never trusted alone.

**Destination-digest verification at `/relay/deliver`:** the relay payload carries `destination_digest` (the digest of the bytes the provider actually moved). The relay records `source_digest`, `destination_digest`, and `fidelity_ok = (source == destination)` into the capture. A mismatch is delivered-but-flagged, not refused (the POC *measures* fidelity; a provider that corrupts bytes is a finding, not a stub error) — record it and continue.

**Measured at relay/receipt (into the capture and the measurement schema):** `size_bytes`, `file_count`, `source_digest`, `destination_digest`, `fidelity_ok`, original-vs-reconstituted (`destination_digest == source_digest`), provider retention/deletion (provider-reported, marked provider-authored). **The artifact is never placed in Discord** (`09_` §2 R1P-05); the owner card carries the `artifact_id` and metadata only.

### C-21 — Owner-authored idea authority: SELECTED = owner-key `/owner/idea` intake

**New owner route `POST /owner/idea`** (owner-key only). Mints a single-purpose opaque `idea_ref` ("idea-" + token_urlsafe(24)) and records `origin: owner`, `instruction_authority: owner-authorized`, plus owner-supplied `title`/`project`/`metadata`.

**`/poc2/triage` changes — authority comes from the ref, never from a field:**
- **Case A (owner-authored):** the request carries a valid `idea_ref`. The service looks it up; authority = `owner-authorized`. The payload's own `origin` field is **ignored for authority** — a provider setting `origin: owner` without a valid owner-minted `idea_ref` gets `instruction_authority: none`. This is the attack `15_` §5 test 1 names, closed at the root: minting an `idea_ref` requires the owner key, which no provider holds.
- **Case B (external):** no `idea_ref`; the request must carry the external-untrusted envelope (partition + `trust: external-untrusted`); authority = `none`; classification/summary only.
- **External material attached to an owner idea** carries its **own** external-untrusted envelope and `instruction_authority: none`, regardless of the surrounding `idea_ref` (`15_` §5 test 2).

Because triage now has two legitimate shapes, its envelope requirement is **conditional** (Case B requires it; Case A does not) — this replaces R2's unconditional envelope check on `/poc2/triage`. The route-policy table (§4) encodes the conditional.

## 3. Capability & evidence state machine (R2P-03, R2P-04, R3P-04)

### C-22 — Capability transition matrix (exact)

States: `MINTED`, `ATTEMPT_STARTED`, `DELIVERED_WITH_RECEIPT`, `UNCERTAIN`, `RECONCILED_DELIVERED`, `RECONCILED_NOT_DELIVERED`, `REVOKED`, `EXPIRED`.

| From | To | Trigger | Authority to effect |
| --- | --- | --- | --- |
| — | `MINTED` | `/poc1/verify-decision` succeeds on an owner **accept** | service, only after a terminal owner accept |
| `MINTED` | `ATTEMPT_STARTED` | first `/relay/deliver` with matching capability + binding + payload digest | provider (bearing the capability) |
| `ATTEMPT_STARTED` | `DELIVERED_WITH_RECEIPT` | delivery completes; receipt minted | service |
| `ATTEMPT_STARTED` | `UNCERTAIN` | delivery result ambiguous (provider reports uncertain, or timeout) | service |
| `UNCERTAIN` | `RECONCILED_DELIVERED` | reconcile finds a recorded relay receipt for the `action_request_id` | service (reconciliation) |
| `UNCERTAIN` | `RECONCILED_NOT_DELIVERED` | reconcile finds no recorded delivery | service (reconciliation) |
| `RECONCILED_NOT_DELIVERED` | `ATTEMPT_STARTED` | **exactly one** re-attempt, same idempotency identity, **new attempt id** | provider, once only |
| `MINTED`/`ATTEMPT_STARTED`/`UNCERTAIN` | `EXPIRED` | TTL (`CAPABILITY_TTL_S`) elapses | service |
| any non-terminal | `REVOKED` | owner/service revokes | owner-surface or service |

**Terminal:** `DELIVERED_WITH_RECEIPT`, `RECONCILED_DELIVERED`, `REVOKED`, `EXPIRED`. `RECONCILED_NOT_DELIVERED` is terminal **unless** the single permitted re-attempt is taken. **Replay** (a repeat `/relay/deliver`) returns the prior receipt with `no_second_side_effect: true` **only from `DELIVERED_WITH_RECEIPT` or `RECONCILED_DELIVERED`**; from any other state it is refused or routed to reconciliation, never a silent second delivery.

**Invalid transitions** (e.g. `/relay/deliver` on `EXPIRED`/`REVOKED`; a second distinct delivery from `DELIVERED_WITH_RECEIPT`; a second re-attempt after `RECONCILED_NOT_DELIVERED`) are captured refusals, no state change. **A late provider receipt on `REVOKED` or `EXPIRED` cannot alter the capability** — captured, refused, terminal (`18_` R3P-04).

**Identities:** stable submission identity = the five-component `idempotency_key`; `attempt` = per-`/relay/deliver` counter (already `STORE.relay_attempts`), separate from submission; delivery `receipt_id` minted once on first delivery. Provider retries increment `attempt`, never create a new submission (`15_` §5 test 5).

**Restart posture (stated honestly, because the stub is deliberately non-durable):** capability state is in-memory and does **not** survive a process restart; the append-only capture log (§C-23) is the durable record. On restart, any pre-restart capability is unknown and a relay bearing it **fails closed** (`refused-no-capability`) — correct for a throwaway. The capture log reconstructs transition *history* for audit; the service does **not** resume *authority* across a restart. Do not add durable capability persistence — that would be pretending to be the journal the design keeps on the AI OS side.

### C-23 — Capture/commit evidence: SELECTED = two-phase append-only

Chosen over a single mutable record because a crash between "capture written" and "state committed" must be *detectable*, not silently counted complete (R2P-04). For every **authority-bearing** transition — owner decision, token spend, capability mint, capability spend/delivery, reconcile, and each POC-3 run-started/checkpoint/reconcile — the service writes, append-only:

1. a **`prepared`** record: `{transition_id, transition, prior_status, intended_status, phase: "prepared", recorded_at, links...}` **before** committing in-memory state;
2. the in-memory commit;
3. a **`committed`** record: `{transition_id, phase: "committed", final_status, recorded_at}`.

`transition_id` = `"txn-" + token_hex(8)`, linking the pair. **Only a transition with a matching `committed` record satisfies an acceptance check.** A `prepared` with no `committed` is an **orphan** → reported **uncertain**, never counted complete. Lower-stakes single-phase records (provider receipts, provider refusals, boundary/auth refusals) stay one committed-equivalent record; they carry no authority and gate nothing. The completeness validator (§6) and the self-test both enforce "committed-only counts."

This extends — does not discard — R2's existing capture-before-commit + atomic-write machinery (`write_capture`, temp+fsync+rename); the two-phase records are written through the same durable path.

## 4. Route-policy table (R2P-05, R3P-03) — the instantiated contract

Implement as **data** (a table the dispatcher consults), not scattered handler checks. **Unknown route or missing policy row → fail closed (404/403).** Any route not listed here that the Builder believes is needed requires a **Fable-approved change request** before registration. Columns: caller · credential · media (all POST = `application/json`, ≤ `MAX_BODY`) · top-level fields accepted · partition/trust · decision-field policy · capture on success / on refusal · cache · log label · quota pool.

| Route | Caller | Credential | Top-level fields | Partition/trust | Decision field | Capture ✓ / ✗ | Quota pool |
| --- | --- | --- | --- | --- | --- | --- | --- |
| `GET /health` | open | none | — | n/a | n/a | none / none | none |
| `POST /owner/artifact/register` | owner | X-Owner-Key | source_digest, size_bytes, file_count, task_id, transition, target_role | exempt | refused | ✓ / ✓ | reserved-authority |
| `POST /owner/idea` | owner | X-Owner-Key | title, project, metadata | exempt | refused | ✓ / ✓ | reserved-authority |
| `POST /owner/cases` | owner | X-Owner-Key | — | exempt | refused | ✓ / ✓ | reserved-authority |
| `POST /owner/decide` | owner | X-Owner-Key | case_id, decision | exempt | **allowed (only here)** | ✓ / ✓ | reserved-authority |
| `POST /poc1/review-case` | provider | X-Provider-Key | registration_ref, task_id, transition, artifact_digest, target_role, submission_epoch, envelope | **required** | refused | ✓ / ✓ | cases |
| `POST /poc1/verify-decision` | provider | X-Provider-Key | token (only) | exempt | refused | ✓ / ✓ | none |
| `POST /poc1/receipt` | provider | X-Provider-Key | provider result (allowlist-reduced) | exempt | refused | ✓ / ✓ | receipts |
| `POST /poc1/refusal` | provider | X-Provider-Key | provider refusal (reduced) | exempt | refused | ✓ / ✓ | receipts |
| `POST /relay/deliver` | provider + **capability** | X-Provider-Key | capability, action_request_id, case_id, payload, destination_digest | exempt | refused | ✓ / ✓ | attempts |
| `POST /poc2/triage` | provider | X-Provider-Key | idea_ref (Case A) OR envelope (Case B), origin, metadata | **conditional** (Case B only) | refused | ✓ / ✓ | ideas |
| `POST /poc3/run-started` | provider | X-Provider-Key | schedule_id, occurrence, provider_correlation_id | exempt | refused | ✓ / ✓ | runs |
| `POST /poc3/checkpoint` | provider | X-Provider-Key | run_id, stage | exempt | refused | ✓ / ✓ | checkpoints |
| `POST /poc3/reconcile` | provider | X-Provider-Key | run_id | exempt | refused | ✓ / ✓ | none |
| `POST /poc3/receipt` | provider | X-Provider-Key | run_id, occurrence | exempt | refused | ✓ / ✓ | receipts |
| `POST /stage/deliver` | provider | X-Provider-Key | run_id | exempt | refused | ✓ / ✓ | stage-attempts |

"Exempt" = exempt from the external-untrusted envelope check (owner surface, or token/result channels that carry no inbound external content), matching R2's `ENVELOPE_EXEMPT` intent, now stated per-route. Deleting any row must make the self-test fail closed (`15_` §5 test 8).

## 5. Bounded limits, HMAC, quotas, reserves (R2P-06, R2P-07, R3P-05)

**Numeric bounds (POC-specific; state each as a named constant):**

```text
MAX_BODY                1 MiB          MAX_REDACT_DEPTH        12
MAX_OBJECT_FIELDS       256            MAX_LIST_ITEMS          1024
MAX_STRING_BYTES        65536          MAX_ACTIVE_SECRETS      512   (scrub scan bound)
MAX_CASES 5000  MAX_IDEAS 5000  MAX_TOKENS 5000  MAX_DECISIONS 5000
MAX_ATTEMPTS_PER_AR 100  MAX_RECEIPTS 5000  MAX_RUNS 5000
MAX_CHECKPOINTS_PER_RUN 1000  MAX_CAPTURES 20000  CAPABILITY_TTL_S 300
```

A payload exceeding a structural bound (fields/list/string/body) → captured 400 before handler dispatch. The redaction scan checks at most `MAX_ACTIVE_SECRETS` live values and recurses at most `MAX_REDACT_DEPTH`, so redaction is not itself a DoS path (R3P-05).

**Unknown-field descriptor HMAC (replaces R2's truncated SHA-256):** `digest = HMAC-SHA256(key = per-process random 32 bytes generated at startup and never persisted, msg = utf-8 of the JSON-canonical value)`, hex, first 32 chars. Per-process keying means descriptors **cannot be precomputed** and **cannot be correlated across runs** (R3P-05). The withholding marker schema is exactly: `{"__withheld__": <why>, "name", "type", "bytes", "hmac"}` — never a bare constant (it would score PRESENT and hide the loss, FAB-05).

**Quota pools and reserves (R2P-07):** each pool above is independent. **`MAX_CAPTURES` is split: 90% general pool, 10% reserved-authority pool.** Owner-decision, capability-mint/spend, and **all security-refusal** captures draw from the reserve; provider receipts/ideas/checkpoints draw from the general pool. **Exhaustion precedence:** when the general pool is full, provider-facing writes get a captured 429 (from the reserve, which is protected), but owner decisions and security refusals **still record**. No provider-driven flood can evict or prevent an owner decision or a security-refusal record (`15_` §5 test 9). Restart empties all in-memory pools; the capture log on disk is unaffected.

## 6. Measurement schema and completeness validator (R2P-09, R3P-07)

Amend `poc/data/measurements.template.json` so every provider × candidate × POC measure carries `{status, value, evidence_ref}` where `status ∈ {MEASURED, NOT_TESTED, UNSUPPORTED}` and a non-`MEASURED` status **requires** a reason string. Required measure family (C-27, now schema-bound): artifact bytes · file count · source digest · destination digest · original-vs-reconstituted · provider task/step/execution count · owner-attention steps and minutes · approval latency · retry count · uncertain-result reconciliation outcome · capture/receipt completeness · provider retention/deletion observation · failure/unsupported-capability reason.

**New control artifact `poc/data/validate_measurements.py`** (Builder authors it to this spec; stdlib only): it **fails (non-zero exit)** if any required measure is missing, lacks a `status`, or has a non-`MEASURED` status without a reason. It does not judge values — it enforces that nothing silently disappears. No provider capability is claimed from authored workflow files alone; unpopulated measures stay explicit `NOT_TESTED` until the owner session.

## 7. Required tests (additive; all shown failing against the pre-R3 baseline via the witness method)

The ten from `15_` §5 (owner-authority upgrade attempt; embedded external stays untrusted; correct-digest-wrong-bytes relay fails; altered-digest-same-bytes relay fails; retry ≠ new submission; uncertain → reconcile, no execute; prepared-not-committed ≠ complete; deleting a route-policy row fails closed; refusal-quota exhaustion cannot evict an owner decision; health leaks no case/decision activity), **plus**: every capability transition in §3's matrix and every invalid transition; a late receipt on EXPIRED/REVOKED changes nothing; the single permitted re-attempt after RECONCILED_NOT_DELIVERED, and that a second is refused; each structural bound (fields/list/string) refuses; the HMAC descriptor differs across two process runs for the same value; the reserve protects an owner decision under a full general pool; `validate_measurements.py` fails on a measure with no status. Keep `r1_reference/stub_server_r1.py` byte-identical with its run-time SHA pin; pin the R2 artifact the same way where an R3 test needs the R2 baseline behaviour.

## 8. Allowlist, return, and the stop-and-report contract

Allowlists and denylist per §0. Return: Delivery Record with the reflexive falsifier; self-test covering §7 with mandatory cases shown failing first; `validate_measurements.py` run clean on the populated-with-NOT_TESTED template; the structural harness re-run (regenerated `out/` shipped, harness code untouched); diffs for every workflow/runbook change; `authority_manifest.json` regenerated to match the returned tree; one zip; `RETURN_MANIFEST.json` self-verified; H-06 first.

**Stop and report** — the discipline that has caught every prior gap — if any clause here delegates a trust/authority/evidence/route/limit decision (it should not; `19_` §1 says a remaining delegation is a defect), is internally inconsistent, conflicts with `09_` §2, or cannot be met within the allowlist. `19_` §1 records that this class of slip has now recurred four times; the cheapest place to catch a fifth is before the build.

## 9. After R3

R3 return → Fable structural verification (static, per the trail-127 practice; the adversarial suite is the verifier's) → **one independent ChatGPT security review of the final R2+R3 stub**, carrying whatever further probes it directs. Then the owner POC session. Before that: **this packet (`20_`) goes to ChatGPT first** for the narrow Revision-3 confirmation the gate requires; Builder release is held until it returns.
