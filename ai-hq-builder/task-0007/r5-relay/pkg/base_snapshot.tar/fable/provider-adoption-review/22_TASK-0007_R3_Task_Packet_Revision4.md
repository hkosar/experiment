# 22 — TASK-0007 R3 Task Packet, Revision 4 — corrected authority, evidence, and capacity contracts

**This supersedes `20_` (Revision 3) in full**, which superseded `17_` (Revision 2). Revision 3 failed the plan gate (`21_`) on nine findings, all **concurred without reservation** (`23_`). Revision 3 fixed the delegation defect — it selected mechanisms instead of asking the Builder to — but several of the mechanisms it selected were themselves unsound. This revision corrects them.

Unchanged: an increment on the integrated R2 stub baseline; throwaway POC apparatus; no Track B credit; every THROWAWAY marker preserved. **Baseline status, used verbatim wherever described:** *"R2 is structurally integrated as the implementation baseline; its security claims remain Builder-authored and unaccepted until the final independent review of the R2+R3 stub."*

**Governing rule (unchanged, and the source of most of what follows):**

> Every authority the service asserts must trace to something the service itself established. A value a caller supplied is corroborating material, never an authority.

Revision 3 violated its own rule in two places — provider-supplied `destination_digest` treated as fidelity proof (R3Q-02) and absence-of-local-receipt treated as proof of non-delivery (R3Q-03). Both are corrected below. **If any clause here asserts an authority not rooted in something this service established, that is a defect — stop and report it.**

## 0. Snapshot, authority manifest, allowlists

### C-28 — Snapshot: an honest snapshot-only artifact (R3Q-01, R3P-06)

Revision 3 shipped a `base.gitbundle` and instructed `git clone base.gitbundle`. **That command fails**, exactly as the verifier reported. Fable reproduced the failure and found the cause: **this working repository is a shallow clone** (`.git/shallow` grafts at `18c571b`, whose real parent `ffd5cc6c` does not exist locally). Complete history therefore **cannot** be produced from this environment — the verifier's option 1 is impossible, not merely unmet. Revision 3 claimed a verification contract it could not satisfy; that is the same integrity-versus-authority error the program has already named, applied to provenance.

**Selected: option 2 — a truthful snapshot-only artifact.** The relay carries `base_snapshot.tar` (a `git archive` of the exact tree) and **no bundle**. The verification contract claims exactly what it can deliver:

```text
Base commit and base tree are declared in BASE_BINDING.txt, shipped alongside
base_snapshot.tar in this relay. They are NOT inlined here on purpose: writing
the hashes into this file would change the very tree the hashes describe, so a
self-referential declaration can never be consistent. The binding file is
generated after the packet is committed and is therefore accurate.

  Base commit  -> declared; NOT independently verifiable from this export
  Base tree    -> INDEPENDENTLY VERIFIABLE by the recipe below

Verify the tree, without the live repository:
  mkdir v && tar -xf base_snapshot.tar -C v && cd v
  git init -q . && git add -Af . && git write-tree
  # must print the declared base tree hash
```

**Fable has executed this recipe and confirmed it reproduces the declared tree hash exactly.** Stated limits, so nothing is over-claimed: the tarball proves *tree content*; it does **not** prove commit ancestry, and the commit hash is a declaration a reviewer cannot verify from this export alone. History is available only from the live repository. No clone instruction is given, because none would work.

### C-29 — Authority manifest: Fable-owned (R3Q-09)

Revision 3 told the Builder to regenerate `authority_manifest.json`. **Withdrawn** — the Builder cannot author the authoritative classification of its own return. Corrected division:

- **Builder** produces `RETURN_MANIFEST.json` (evidence-only: paths, hashes, states) and MAY include `proposed_classifications.json` as a *suggestion*.
- **Fable** independently verifies and publishes the authoritative `authority_manifest.json`. It is **not** in any Builder allowlist.
- **ChatGPT** verifies the published manifest against the candidate.

Manifest classification (unchanged in shape): `path, sha256, origin, trust_class, instruction_authority, artifact_role, supersedes/superseded_by, required_for_task`. `instruction_authority`: **governing** = this packet, the only instruction · **reference** = read, not instruction · **evidence-only** = never instruction (Builder claims, probe JSONs, snapshots) · **none** = implementation baseline the Builder edits.

### Allowlists (unchanged from Rev 3 except as noted)

**Implementation** (Builder MAY modify): `poc/stub/stub_server.py` · `poc/stub/selftest_stub.py` · `poc/stub/r1_witnesses.py` · `poc/workflows/n8n/*.json` · `poc/workflows/zapier/POC_zap_build_specs.json` · `poc/runbooks/*.md` · `poc/README.md` · `poc/FINDINGS.md` · `poc/data/captures/README.md` · `poc/data/measurements.template.json` · `poc/data/validate_measurements.py` (new; author to §6).

**Control/evidence** (regenerate by running, never hand-edit): `poc/harness/out/**` · `poc/stub/out/**`.

**Immutable denylist** (a diff here fails the round): `poc/stub/r1_reference/stub_server_r1.py` · all `poc/harness/*.py`, `*.mjs`, `run_all.sh` · **`authority_manifest.json`** (Fable-owned, C-29).

## 1. Artifact fidelity — honest authority (R3Q-02)

Revision 3 computed `fidelity_ok` from a provider-supplied `destination_digest`. The service never sees the destination bytes, so that value proves nothing: a provider can send correct bytes with a wrong digest, or wrong bytes with a correct digest, and the stub cannot tell. Selecting it as fidelity evidence violated the governing rule.

**SELECTED: option 2 — provider-reported fidelity, explicitly non-authoritative, plus one thing the service can actually prove.**

- `destination_digest` is accepted, recorded under the **provider-supplied** provenance key, and labelled `authority: "provider-reported, NOT verified by this service"`. It **cannot satisfy any security gate** and MUST NOT gate delivery.
- The field `fidelity_ok` is **removed**. In its place the capture records `source_digest` (owner-registered, authoritative), `destination_digest_claimed` (provider), and `destination_verified: false` with the reason `"this service does not receive destination bytes and cannot hash them"`.
- **What the service can prove, and does:** the relay payload it authorizes carries the owner-registered `source_digest`, and the capability binding covers the canonical payload digest. So the stub proves *what it authorized*, not *what arrived*. That distinction is stated in the capture rather than papered over.
- **Consequence recorded for the measurement set:** end-to-end binary fidelity is **NOT ESTABLISHED by this apparatus**. It becomes an owner-session observation (compare the artifact the provider delivered against the registered `source_digest` out-of-band) and is recorded as `UNSUPPORTED` with that reason by the validator (§6) unless the owner session supplies evidence. Do not let a green field imply a check that did not happen — that is FAB-08's lesson.

Two tests from `15_` §5 ("correct digest, wrong bytes → relay fails" and "altered digest, same bytes → relay fails") are therefore **not satisfiable by this apparatus** and are withdrawn as stated. They are replaced by: *a provider-supplied destination digest never gates delivery, is always recorded as provider-authored, and never appears as a verified fidelity claim in any capture.*

**Registration identity now includes `target_role`** (R3Q-02, second half): registration identity = `sha256(source_digest | task_id | transition | target_role)`. A re-registration differing only in `target_role` is therefore a **distinct** registration, not a silent role change — consistent with the accepted duplicate-suppression model, in which the destination role is part of identity.

## 2. Owner-idea / external-attachment split authority (R3Q-05)

Revision 3 described the split narratively but gave only a broad `metadata` field, so nothing structurally prevented a valid `idea_ref` from elevating provider-added content. **Exact schema for `POST /poc2/triage`:**

```text
idea_ref            optional; owner-minted (Case A). Authority derives ONLY from this.
owner_content       optional object; MEANINGFUL ONLY with a valid idea_ref.
                    Accepted keys: title, body, project, tags.
                    -> instruction_authority: "owner-authorized"
external_items      optional array (0..MAX_LIST_ITEMS). EACH item is an object:
                      { envelope: { partition: "business",
                                    trust: "external-untrusted" },   REQUIRED per item
                        source: string, content: string|object }
                    -> instruction_authority: "none", ALWAYS, per item,
                       regardless of any surrounding idea_ref
```

Rules, enforced structurally rather than by narrative:

- Authority comes **only** from a valid owner-minted `idea_ref`. Any `origin` field in the payload is **ignored for authority** and recorded as provider-supplied.
- `owner_content` present **without** a valid `idea_ref` → captured 403; it is never treated as owner-authored.
- Every `external_items[i]` **requires its own envelope**; a missing or non-conforming per-item envelope → captured 400. An item **never** inherits authority from the enclosing idea.
- Case B (no `idea_ref`) → the request must carry the top-level external-untrusted envelope; authority `none`; classification and summary only.
- The capture records authority **per component**: `owner_content` authority `owner-authorized`; each external item `none` with its own source. A single flattened authority value for the whole request is a defect.

This makes the established protection rule structural: external-untrusted content may inform classification as **data** and can never acquire **instruction** authority.

## 3. Capability state, reconciliation, and revocation (R3Q-03, R3Q-04)

### C-30 — Reconciliation requires positive evidence (R3Q-03)

Revision 3 allowed `UNCERTAIN → RECONCILED_NOT_DELIVERED` on absence of a local receipt, then permitted a retry. **Absence of a local record is not proof that no external action occurred** — a provider may have completed the action and failed before the receipt was written. That path could authorize a duplicate real-world action, which is precisely what the POC exists to disprove.

**Corrected:** `RECONCILED_NOT_DELIVERED` requires **positive negative evidence**, defined for this POC as *either*:

- **(a)** a downstream idempotency query against the recorded `idempotency_key` returning an authoritative "no such delivery", from a source the service controls (for the stub: its own delivery ledger **plus** the absence of any `relay-delivered` capture for that `action_request_id` in the on-disk capture log — a durable check, not just in-memory); **or**
- **(b)** an owner-attested statement recorded through the owner surface (`POST /owner/reconcile`, owner key required) declaring the action did not occur.

**If neither is available, the capability stays `UNCERTAIN` and fails closed** — no retry is authorized, and the state is reported as unresolved rather than resolved-negative. `UNCERTAIN` is an acceptable terminal outcome for the POC; a wrong `RECONCILED_NOT_DELIVERED` is not. Note the honest limit: for a throwaway stub with no external system, (a) reduces to "this service has no record, durably" — which is why (b) exists and why the state may legitimately remain uncertain.

### C-31 — Reconcile and revoke are real routes (R3Q-04)

Revision 3 named these transitions but gave no route to effect them. Added, and present in the §4 table:

- **`POST /poc1/reconcile`** (provider credential): supplies `capability` or `action_request_id`; the service performs check (a) above and returns `RECONCILED_DELIVERED`, `RECONCILED_NOT_DELIVERED`, or **`UNCERTAIN` (unresolved)**. It never accepts a provider-asserted outcome.
- **`POST /owner/reconcile`** (owner key): the owner attestation of (b). Records an owner-attested reconciliation outcome.
- **`POST /owner/revoke`** (owner key): moves a non-terminal capability to `REVOKED`, terminal. A late provider receipt on `REVOKED` or `EXPIRED` is captured, refused, and changes nothing.

The transition matrix is otherwise as Revision 3 specified (states `MINTED`, `ATTEMPT_STARTED`, `DELIVERED_WITH_RECEIPT`, `UNCERTAIN`, `RECONCILED_DELIVERED`, `RECONCILED_NOT_DELIVERED`, `REVOKED`, `EXPIRED`; terminal = `DELIVERED_WITH_RECEIPT`, `RECONCILED_DELIVERED`, `REVOKED`, `EXPIRED`; replay returns the prior receipt **only** from `DELIVERED_WITH_RECEIPT` or `RECONCILED_DELIVERED`; attempts counted separately from submissions; exactly one re-attempt permitted from `RECONCILED_NOT_DELIVERED`, now reachable only via positive evidence). **Restart posture unchanged and honest:** capability state is in-memory; a relay bearing a pre-restart capability fails closed; the capture log reconstructs history for audit, never authority.

## 4. Route-policy table — complete (R3Q-04)

All columns populated for every route. Media type for every POST is `application/json`, body ≤ `MAX_BODY`; every route captures on success and on refusal unless noted. **Unknown route or missing policy row → fail closed.** A new route requires a Fable-approved change request.

| Route | Caller | Credential | Fields (exact) | Envelope | Decision field | Cache | Log label | Quota pool |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| `GET /health` | open | none | — | n/a | n/a | no-store | `GET /health` | none |
| `POST /owner/artifact/register` | owner | X-Owner-Key | source_digest, size_bytes, file_count, task_id, transition, target_role | exempt | refused | no-store | `POST /owner/artifact/register` | reserved-owner |
| `POST /owner/idea` | owner | X-Owner-Key | title, project, metadata | exempt | refused | no-store | `POST /owner/idea` | reserved-owner |
| `POST /owner/cases` | owner | X-Owner-Key | — | exempt | refused | no-store | `POST /owner/cases` | reserved-owner |
| `POST /owner/decide` | owner | X-Owner-Key | case_id, decision | exempt | **allowed (only here)** | no-store | `POST /owner/decide` | reserved-owner |
| `POST /owner/reconcile` | owner | X-Owner-Key | action_request_id, delivered (bool), note | exempt | refused | no-store | `POST /owner/reconcile` | reserved-owner |
| `POST /owner/revoke` | owner | X-Owner-Key | capability or action_request_id, reason | exempt | refused | no-store | `POST /owner/revoke` | reserved-owner |
| `POST /poc1/review-case` | provider | X-Provider-Key | registration_ref, task_id, transition, artifact_digest, target_role, submission_epoch, envelope | **required** | refused | no-store | `POST /poc1/review-case` | cases |
| `POST /poc1/verify-decision` | provider | X-Provider-Key | token (only) | exempt | refused | no-store | `POST /poc1/verify-decision` | none |
| `POST /poc1/reconcile` | provider | X-Provider-Key | capability, action_request_id | exempt | refused | no-store | `POST /poc1/reconcile` | none |
| `POST /poc1/receipt` | provider | X-Provider-Key | action_request_id, case_id, provider_status ∈ {ok,error,uncertain}, provider_message (str ≤1024), destination_digest_claimed (64-hex or null), provider_metrics {task_count,step_count,execution_count,tokens_used: int} | exempt | refused | no-store | `POST /poc1/receipt` | receipts |
| `POST /poc1/refusal` | provider | X-Provider-Key | action_request_id or case_id, refusal_code (str ≤64), refusal_message (str ≤1024) | exempt | refused | no-store | `POST /poc1/refusal` | receipts |
| `POST /relay/deliver` | provider + **capability** | X-Provider-Key | capability, action_request_id, case_id, payload, destination_digest_claimed | exempt | refused | no-store | `POST /relay/deliver` | attempts |
| `POST /poc2/triage` | provider | X-Provider-Key | idea_ref, owner_content{title,body,project,tags}, external_items[{envelope,source,content}] (§2) | **conditional** (Case B) | refused | no-store | `POST /poc2/triage` | ideas |
| `POST /poc3/run-started` | provider | X-Provider-Key | schedule_id, occurrence, provider_correlation_id | exempt | refused | no-store | `POST /poc3/run-started` | runs |
| `POST /poc3/checkpoint` | provider | X-Provider-Key | run_id, stage | exempt | refused | no-store | `POST /poc3/checkpoint` | checkpoints |
| `POST /poc3/reconcile` | provider | X-Provider-Key | run_id | exempt | refused | no-store | `POST /poc3/reconcile` | none |
| `POST /poc3/receipt` | provider | X-Provider-Key | run_id, occurrence, provider_status ∈ {ok,error,uncertain} | exempt | refused | no-store | `POST /poc3/receipt` | receipts |
| `POST /stage/deliver` | provider | X-Provider-Key | run_id | exempt | refused | no-store | `POST /stage/deliver` | stage-attempts |

The two placeholder schemas Revision 3 left ("provider result (allowlist-reduced)", "provider refusal (reduced)") are now exact, above. Any field not listed for a route is reduced to a descriptor (§5) and stored under the provider-supplied provenance key; it never reaches the top level.

## 5. Fault-safe evidence, reserves, and secret capacity (R3Q-06, R3Q-07)

### C-32 — Authority becomes effective only on committed evidence (R3Q-06)

Revision 3's order (prepared → change state → committed) leaves effective authority if the committed write fails. **Corrected, and this is the binding rule:**

> An authority-bearing transition becomes effective **only** when its `committed` record has durably landed. If the committed write fails, the in-memory change is **rolled back**; if rollback is impossible, the subject enters an explicit **non-authoritative `UNCERTAIN`** state that **fails closed to every authority check**.

Concretely: `prepared` record → mutate in-memory state **marked provisional** (invisible to authority checks) → `committed` record → **clear the provisional flag**, at which point the state is authoritative. A crash or failure at any point leaves either a provisional state (never authoritative) or an orphan `prepared` with no `committed` (reported uncertain). **No path leaves effective authority without committed proof.** "Permanently stuck" is not an outcome: an orphaned provisional is reported by the validator and resolved by the owner surface (`/owner/reconcile`, `/owner/revoke`).

**Fault-injection tests required at each write boundary** (`21_` R3Q-06): owner decision · token spend · capability mint · capability spend · delivery · reconciliation. Each: force the committed write to fail, then assert the authority is **not** effective and the subject reads as uncertain or rolled back.

### C-33 — Separate reserves; no provider-consumable owner capacity (R3Q-07)

Revision 3 put security refusals and owner-authority records in one 10% reserve, so a provider could flood refusals and consume the reserve that owner decisions depend on — falsifying the guarantee it claimed. **Corrected: three disjoint pools.**

```text
general pool          70% of MAX_CAPTURES   provider receipts, ideas, checkpoints, stage, triage
security-refusal pool 15% of MAX_CAPTURES   refusals arising from provider-reachable routes
reserved-owner pool   15% of MAX_CAPTURES   owner-surface routes ONLY — decision, register,
                                            idea, reconcile, revoke, cases
```

**No provider-reachable event may draw from `reserved-owner` under any condition.** Exhaustion behaviour, exactly: general full → provider writes get a captured 429 recorded in the security-refusal pool; security-refusal pool full → further provider refusals are counted in an in-memory counter and **not** captured (bounded, disclosed in `/health` as an aggregate only, never per-case); reserved-owner full → owner writes get a 507 and the service refuses further owner state changes rather than silently dropping evidence. **When every pool is full the service fails closed** and continues to serve `GET /health`.

### C-34 — Bounded secret index with guaranteed coverage (R3Q-07)

Revision 3 could mint thousands of tokens while scanning at most 512 — so some live secrets would be unredactable, with no rule saying which. **Corrected:** `MAX_ACTIVE_SECRETS = 512` is a **hard ceiling on live secrets, not on the scan**. Every live secret is always scanned. Enforced by:

- Minting a token or capability when the index is full is **refused** (captured 429) rather than exceeding coverage.
- Secrets are removed from the index the moment they become unusable (token consumed, capability terminal, process key rotated), so the ceiling is a working-set bound.
- **Invariant, tested:** `len(secret_index) ≤ MAX_ACTIVE_SECRETS`, and **every** live token/capability is in the index. A test must assert that no live secret exists outside the index and that redaction covers all of them.

Other bounds unchanged from Revision 3: `MAX_BODY` 1 MiB · `MAX_REDACT_DEPTH` 12 · `MAX_OBJECT_FIELDS` 256 · `MAX_LIST_ITEMS` 1024 · `MAX_STRING_BYTES` 65536 · `MAX_CASES`/`MAX_IDEAS`/`MAX_TOKENS`/`MAX_DECISIONS` 5000 · `MAX_ATTEMPTS_PER_AR` 100 · `MAX_RECEIPTS` 5000 · `MAX_RUNS` 5000 · `MAX_CHECKPOINTS_PER_RUN` 1000 · `MAX_CAPTURES` 20000 · `CAPABILITY_TTL_S` 300. Descriptor HMAC unchanged: per-process random 32-byte key, never persisted, `HMAC-SHA256` over the canonical JSON value, hex, first 32 chars.

## 6. Measurement validator — exact contract (R3Q-08)

`poc/data/validate_measurements.py` (stdlib only; Builder authors it to this spec) enforces, per measure:

```text
MEASURED     -> value REQUIRED (non-null) AND evidence_ref REQUIRED and RESOLVABLE
                (resolvable = the referenced capture/output file exists under poc/data or poc/harness/out)
NOT_TESTED   -> reason REQUIRED (non-empty string)
UNSUPPORTED  -> reason REQUIRED AND capability_gap_evidence REQUIRED
                (a reference to the recorded refusal/limitation that establishes the gap)
```

It **also enumerates the full expected matrix** — every (candidate × POC × measure) combination from the required family — and **fails on any missing combination**, so a measure cannot silently disappear by omission. Required family (unchanged): artifact bytes · file count · source digest · destination digest **claimed** (provider-reported, non-authoritative per §1) · original-vs-reconstituted (**`UNSUPPORTED` by default per §1**, with the destination-verification gap as its evidence) · provider task/step/execution count · owner-attention steps and minutes · approval latency · retry count · uncertain-result reconciliation outcome · capture/receipt completeness · provider retention/deletion observation · failure/unsupported-capability reason. Exit non-zero on any violation. It judges completeness and provenance, never values.

## 7. Required tests

Everything Revision 3 required, **minus** the two withdrawn digest-fidelity tests (§1), **plus** a negative test for each correction here:

1. Provider-supplied `destination_digest_claimed` never gates delivery and never appears as a verified fidelity claim in any capture.
2. Re-registration differing only in `target_role` produces a **distinct** registration, not a role change.
3. `owner_content` without a valid `idea_ref` → refused; never owner-authored.
4. An `external_items` entry lacking its own envelope → refused; a valid `idea_ref` never elevates an external item; per-component authority appears in the capture.
5. `UNCERTAIN` with neither positive-evidence source → stays `UNCERTAIN`, **no retry authorized**, reported unresolved.
6. `RECONCILED_NOT_DELIVERED` reachable **only** via check (a) or an owner attestation; a provider-asserted outcome is refused.
7. `/owner/revoke` → terminal; a later provider receipt changes nothing.
8. Fault injection at each of the six write boundaries: committed write fails → authority not effective, state rolled back or uncertain.
9. A provider flooding refusals **cannot** prevent an owner decision from being recorded (disjoint pools).
10. Every pool full → fail closed; `/health` still serves.
11. Minting beyond `MAX_ACTIVE_SECRETS` is refused; no live secret exists outside the index; all live secrets redact.
12. `validate_measurements.py` fails on: a `MEASURED` with no value; a `MEASURED` with an unresolvable `evidence_ref`; an `UNSUPPORTED` with no capability-gap evidence; a missing (candidate × POC × measure) combination.
13. Deleting any route-policy row makes the self-test fail closed.
14. Every capability transition and every invalid transition from §3.

Keep `r1_reference/stub_server_r1.py` byte-identical with its run-time SHA pin; pin the R2 artifact the same way where a test needs the R2 baseline behaviour.

## 8. Return requirements

Delivery Record with the reflexive falsifier element · self-test covering §7, mandatory cases shown failing first · `validate_measurements.py` run clean against the template populated with explicit `NOT_TESTED`/`UNSUPPORTED` · structural harness re-run (regenerated `out/` shipped; harness code untouched) · diffs for every workflow and runbook change · `RETURN_MANIFEST.json` self-verified, plus optional `proposed_classifications.json` (**suggestion only** — Fable publishes the authority manifest, C-29) · one zip · H-06 first.

**Note on the harness:** `21A_` records `full_harness_self_contained: false` (the n8n workflow-validation dependency is absent in the review environment, validator control 9/10). That is an environment limitation, not a defect to fix in this round; keep the structural harness as-is and note any locally unrunnable check in the Delivery Record rather than working around it.

**Stop and report** if any clause here delegates a trust/authority/evidence/route/limit decision, asserts an authority not rooted in something the service established, is internally inconsistent, conflicts with `09_` §2, or cannot be met within the allowlist. Four consecutive packet revisions have each been corrected by review; the cheapest place to catch the fifth is before the build.

## 9. After R3

R3 return → Fable structural verification (static, per the trail-127 practice) → **one independent ChatGPT security review of the final R2+R3 stub** → owner POC session. Before any of that: **this packet goes to ChatGPT for the narrow Revision-4 confirmation**; Builder release stays held until it returns.
