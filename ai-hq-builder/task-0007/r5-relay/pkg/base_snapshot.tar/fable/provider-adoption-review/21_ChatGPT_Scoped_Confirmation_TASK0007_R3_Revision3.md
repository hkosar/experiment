# 21 — ChatGPT Scoped Confirmation: TASK-0007 R3 Task Packet Revision 3

**Role:** Independent verifier / plan-gate reviewer  
**Review target:** `20_TASK-0007_R3_Task_Packet_Revision3.md`  
**Packet:** `TASK0007_R3_Revision3_Packet.zip`  
**Scope:** Narrow confirmation of R3P-01 through R3P-08 before Builder release

## 1. Verdict

# **FAIL — Revision 3 is not yet implementation-ready; Builder release remains blocked**

Revision 3 is a substantial improvement over Revision 2. Fable now selects concrete authority mechanisms, supplies a route table, defines a capability state model, chooses an evidence model, establishes numeric limits, separates integrity from instruction authority, and adds a measurement contract.

However, several selected contracts are internally incomplete or unsafe. The packet therefore does not yet satisfy its own opening rule that no trust, authority, evidence, route, or limit decision may remain for the Builder.

No provider selection, Release-1 definition, Decision Engine baseline, or owner decision is reopened. This is a bounded Task-Packet correction cycle.

---

## 2. Independent packet verification

```text
Uploaded ZIP SHA-256
b865683c4390025205a82b4e0692056a0c3ef18d831432680fa36c8fecd1f678

SHA256SUMS payloads
57 / 57 passed

Authority-manifest entries
56 / 56 referenced files present
56 / 56 declared hashes passed
Required authority fields present on all 56 entries

Authority-manifest classifications
1 governing
8 reference
4 evidence-only
43 none

Declared base commit
1a6634bed349bc90219c8c8546367779965f0624

Declared base tree
 ded2925f01c851c2aa8f17563ac5cc8ea65caca2

Bundle HEAD
1a6634bed349bc90219c8c8546367779965f0624

HEAD tree after manual unbundle
 ded2925f01c851c2aa8f17563ac5cc8ea65caca2
```

### Baseline evidence reproduced

```text
Integrated R2 stub self-test
56 / 56 passed

Pinned R1 witness suite
21 / 21 passed
```

### Evidence qualifications

1. The packet's required command `git clone base.gitbundle base` fails because the bundle is missing ancestor commit `ffd5cc6ce6626f18de73f671c362806b4a168afe`. A manual unbundle can expose the declared HEAD and tree, but `git fsck --full` reports a broken parent link.
2. `poc/harness/run_all.sh` is not self-contained in the packet: the unshipped `n8n-workflow` dependency prevents structural validation, and the current validator self-test reports 9/10 rather than a clean control pass. This is not the central gate failure, but future Builder-return evidence must pin and ship the required validation environment.

---

## 3. Prior-finding status

| Prior finding | Scoped result |
| --- | --- |
| **R3P-01 — Selected authority architecture** | **Partially closed.** Fable selected mechanisms, but artifact-fidelity authority and owner-idea attachment authority remain incomplete. |
| **R3P-02 — Integrity versus instruction authority** | **Substantially closed.** The authority manifest is useful; Builder ownership of its regeneration remains incorrect. |
| **R3P-03 — Instantiated route policy** | **Partially closed.** A route table exists, but not every required field/transition is instantiated. |
| **R3P-04 — Capability and evidence state** | **Partially closed.** The transition table is materially better; uncertain-outcome and commit-failure semantics remain unsafe. |
| **R3P-05 — Redaction and quota bounds** | **Partially closed.** Numeric limits now exist, but two claimed protection guarantees are not actually achieved. |
| **R3P-06 — Snapshot and allowlists** | **Open.** The declared clean-clone proof fails, and the authority-manifest return role is misassigned. |
| **R3P-07 — Measurement acceptance contract** | **Partially closed.** Required fields are named, but the validator's required enforcement is incomplete. |
| **R3P-08 — Baseline-status wording** | **Closed.** The governing packet uses the accepted baseline wording. |

---

## 4. New findings

### R3Q-01 — High: The claimed self-contained Git snapshot is not self-contained

**Problem:** Section 0 instructs the reviewer and Builder to clone `base.gitbundle` and independently reproduce the base commit/tree. The supplied bundle identifies the correct HEAD and tree but cannot be freshly cloned.

**Independent result:**

```text
git clone base.gitbundle base
→ fatal: Failed to traverse parents of commit 18c571b...
→ missing commit ffd5cc6ce6626f18de73f671c362806b4a168afe

git fsck --full after manual unbundle
→ broken link from 18c571b... to ffd5cc6...
```

**Required correction:** export a truly self-contained bundle that freshly clones and passes `git fsck --full`, or explicitly provide a shallow/snapshot-only artifact whose verification contract does not claim complete history. The exact clone, `rev-parse`, tree, `fsck`, and clean-checkout commands must pass from the relay alone.

---

### R3Q-02 — High: Artifact-fidelity authority is still caller-supplied

**Problem:** Trusted preregistration establishes the owner-approved **source** digest. But `/relay/deliver` accepts `destination_digest` from the provider and derives `fidelity_ok` from that caller-supplied value. The stub never receives or hashes the destination bytes, and no independent destination hasher or evidence owner is defined.

The packet nevertheless requires tests that a correct digest paired with wrong bytes fails and an altered digest paired with the same bytes fails. Those tests cannot be meaningfully performed by a JSON-only wrapper that sees neither byte stream.

The preregistration identity also omits `target_role`, even though the accepted idempotency contract includes route/target role. Re-registering the same digest/task/transition for a different role therefore collides with the prior registration.

**Required correction:** Fable must select one of two honest contracts:

1. **Trusted destination verification:** a wrapper-controlled ingress/destination component hashes the actual bytes and issues independently owned fidelity evidence; or
2. **Provider-reported measurement only:** label `destination_digest` and `fidelity_ok` as provider-authored, prohibit them from satisfying security or acceptance gates, and replace the impossible byte-substitution tests with truthful provider-capability measurements.

In either case, include `target_role` in the registration identity or define an explicit conflict/refusal rule for a role-changing re-registration.

---

### R3Q-03 — High: Uncertain-result reconciliation can authorize a duplicate side effect

**Problem:** The selected state machine allows:

```text
UNCERTAIN
→ RECONCILED_NOT_DELIVERED
when no recorded local relay receipt exists
→ one permitted re-attempt
```

Absence of a local receipt does not prove absence of an external side effect. The receipt may be missing because capture failed, the provider timed out after delivery, or the downstream system accepted the action without producing the local record.

This conflicts with the accepted Release-1 requirement to reconcile an uncertain provider result before any second side effect.

**Required correction:** `RECONCILED_NOT_DELIVERED` must require positive, independently owned negative evidence or a downstream idempotency query—not merely absence of a local receipt. When the external system cannot prove non-delivery and does not provide an idempotency guarantee, the capability must remain uncertain and fail closed rather than retry.

The contract must also define the exact evidence that authorizes each reconciliation outcome.

---

### R3Q-04 — High: The state machine is not fully reachable through the route-policy contract

**Problem:** The transition matrix defines reconciliation and revocation, but the route table provides no POC-1 reconciliation endpoint and no owner/service revocation endpoint. It therefore leaves the Builder to decide how those transitions are requested, authenticated, captured, and quota-controlled.

The route table also says it instantiates media, cache, log-label, success/refusal capture, and accepted-field policy, but its actual columns omit cache and log-label rules. `/poc1/receipt` and `/poc1/refusal` use non-normative placeholders such as “provider result (allowlist-reduced)” instead of exact accepted schemas.

**Required correction:** add exact route-policy rows—or exact internal-only transition rules—for:

- POC-1 reconciliation
- Capability revocation
- Expiry processing if it is not purely lazy

Complete the route table with every promised column, exact accepted fields, capture types, cache policy, log label, and quota pool. Unknown transition paths must remain fail-closed.

---

### R3Q-05 — High: Owner ideas and attached external content do not have a representable split-authority schema

**Problem:** The narrative correctly says external content attached to an owner idea retains its own external-untrusted envelope. But `/owner/idea` accepts only `title`, `project`, and `metadata`, while `/poc2/triage` accepts `idea_ref OR envelope`, `origin`, and `metadata`. No explicit field model distinguishes:

- Owner-authored instruction/content
- Provider-added metadata
- Quoted, attached, or forwarded external material
- The envelope attached to each external item

A Builder could reasonably treat all metadata under a valid `idea_ref` as owner-authorized, violating the accepted two-envelope requirement.

**Required correction:** define a concrete schema. For example:

```text
idea_ref
owner_content_ref or owner_content
external_items[]:
  item_id
  content_ref / content
  origin = external
  trust = external-untrusted
  instruction_authority = none
  sensitivity / partition / verification metadata
```

State exactly which fields are loaded from the owner-minted record, which fields may arrive from the provider, and which content can influence classification without acquiring instruction authority.

---

### R3Q-06 — High: The two-phase evidence model can leave effective authority without committed evidence

**Problem:** C-23 writes `prepared`, changes in-memory state, then writes `committed`. It says only committed transitions satisfy acceptance checks, but it does not define what happens when the final committed write fails after the in-memory authority state changed.

Examples include:

- Owner decision becomes terminal in memory but its committed record fails
- Capability becomes spent/delivered in memory but its committed record fails
- Owner cannot retry because the in-memory object already appears decided
- Downstream code observes the changed state despite the transition being evidentially uncertain

**Required correction:** select one exact rule:

- Commit durable state/evidence before exposing the transition as effective; or
- Roll back the in-memory mutation when committed evidence fails; or
- Move the object into an explicit `UNCERTAIN` state from which no authority may be exercised until reconciliation.

Every authority read must be defined to consult only committed/effective state. Add fault-injection tests at each write boundary for owner decision, token spend, capability mint/spend, delivery, and reconciliation.

---

### R3Q-07 — High: The quota and secret-scan guarantees are internally false

**Problem A — evidence reserve:** security refusals and owner-authority records share the same 10% reserve. A provider can deliberately generate security refusals until that reserve is full, after which an owner decision cannot be recorded. This contradicts the packet's statement that no provider-driven flood can prevent an owner decision or security-refusal record.

**Problem B — active-secret limit:** the design allows thousands of tokens/capabilities but scans at most `MAX_ACTIVE_SECRETS = 512`. It does not state that minting fails after 512 active secrets or which 512 are scanned. A live secret outside the scanned subset can therefore survive redaction.

**Required correction:**

- Give owner-authority records a separately protected reserve that provider-triggered refusals cannot consume, or rate-limit/refuse provider capture before the owner reserve is threatened.
- Define behavior when every reserve is exhausted.
- Make the active-secret index itself bounded and fail closed: either refuse minting beyond the scan capacity, expire/remove secrets deterministically, or guarantee that every live secret is scanned.
- Add flood and over-capacity tests proving owner decisions remain recordable and every live secret remains redactable.

---

### R3Q-08 — Medium: The measurement validator does not enforce the complete evidence contract

**Problem:** Section 6 says every measure carries `{status, value, evidence_ref}`. But the stated validator only fails when a measure is missing, lacks status, or has a non-`MEASURED` status without a reason. It does not explicitly require:

- A value for `MEASURED`
- A valid evidence reference for `MEASURED`
- Absence or explicit handling of values that conflict with `NOT_TESTED` / `UNSUPPORTED`
- Complete provider × POC × candidate coverage

**Required correction:** define the exact schema and validator outcomes. At minimum:

```text
MEASURED     → value required, evidence_ref required and resolvable
NOT_TESTED   → reason required, no silent measured claim
UNSUPPORTED  → reason and capability-gap evidence required
```

The validator must enumerate the expected provider/POC/candidate matrix and fail when a required combination is absent.

---

### R3Q-09 — High: The Builder is assigned authority-manifest ownership

**Problem:** Section 8 instructs the Builder to regenerate `authority_manifest.json` to match the returned tree. That file classifies origins, trust classes, instruction authority, artifact roles, supersession, and task necessity. A Builder cannot author the authoritative classification of its own return without collapsing the role separation that R3P-02 was intended to establish.

**Required correction:**

- Builder produces a `RETURN_MANIFEST.json`, changed-file list, hashes, and proposed classifications as evidence-only.
- Fable independently verifies and publishes the authoritative manifest in the integration/gate packet.
- ChatGPT verifies that manifest against the actual candidate.

The Builder may run a manifest-generation utility, but its output remains evidence-only until Fable adopts it.

---

## 5. Required Revision 4 contents

Fable should issue one more narrow Task-Packet revision containing:

1. A freshly clonable, `fsck`-clean snapshot bundle or a truthful snapshot-only contract.
2. An honest artifact-fidelity model with independently owned destination evidence or provider-report-only semantics.
3. `target_role` treatment in the preregistration identity.
4. Positive-evidence uncertain-result reconciliation and explicit no-safe-proof behavior.
5. Exact reconciliation/revocation transition paths and complete route-policy rows.
6. A representable owner-idea/external-item schema.
7. A fault-safe prepared/committed state contract.
8. Separate owner-authority evidence reserves and fail-closed secret-index capacity.
9. A complete measurement schema and validator contract.
10. Fable-owned authority-manifest publication.
11. Updated negative tests for each correction.

This should remain a plan-only correction. Builder release is not authorized yet.

---

## 6. Gate state

```text
Release-1 product definition:            VALID
Capability Portfolio discovery:          VALID
Fable’s prior security dispositions:      ACCEPTED
Integrated R2 implementation baseline:   STRUCTURALLY VALID / SECURITY UNACCEPTED
Revision 3 direction:                     CONCUR
Revision 3 Task Packet gate:              FAIL
Builder release:                          BLOCKED
Owner POC session:                        BLOCKED
Provider selection:                       NOT MADE
Decision Engine / accepted baseline:      NOT REOPENED
Hunter action required now:               NONE
Next actor:                               FABLE
Next artifact:                            TASK-0007 R3 Task Packet Revision 4
```

The review remains within the standing owner-approved separation: Fable owns architecture and project management, the Builder implements only an accepted contract, ChatGPT independently verifies, and Hunter retains final authority.
