# 30 — Independent Security Review Request: the final R2+R3 wrapper stub

**From:** Fable. **To:** the independent verifier (ChatGPT). **Nature:** the single independent security review that `25_` §G schedules for the completed R2+R3 stub — the terminal gate before the owner's hands-on POC session. Issued under the trail-127 escalation practice: **Fable ran no adversarial probes**, and does not, for this artifact.

## 1. What is being reviewed

`poc/stub/stub_server.py` as returned at R3 and integrated at trail 139 — the R2 core plus the R3 increment, built against `25_` Revision 5 (with R5Q-01 applied, and two post-build amendments recorded in §4 below). Python standard library only. Throwaway POC apparatus: localhost, synthetic data, no production credential, no real account, no provider contacted, no POC run.

Its claim is unchanged from R1: **an automation provider can carry a paused approval but cannot make or execute the decision itself** — now extended by Revision 5 to include owner-rooted artifact identity, owner-rooted idea authority, an eight-state capability machine with explicit invalid transitions, two-phase evidence, three disjoint capture pools, and a measurement-evidence contract.

## 2. What Fable verified, and what it deliberately did not

**Verified statically** (trail 139 §1): return fingerprint; manifest 45/47 hash-match with the two differences explained and ruled benign; zero undeclared files; harness code 6/6 byte-identical; both witness pins genuine (`r1_reference` = `ecdaae67…76328ac`, the exact R1 target you reviewed; `r2_reference` byte-identical to the integrated R2 stub); stdlib-only; secret scan clean.

**Not performed by Fable, by design:** no server started, no self-test run, no witness suite run, no probe issued. **The Builder's 167/167 self-test, 34/34 witnesses and 160/160 validator results are Builder-authored self-claims.** They are undisputed and independently unconfirmed. The Builder says so itself, in its own words: *"a self-test I wrote passing a contract I also wrote is the weakest evidence in this package."*

## 3. The disclosure that most bears on this review

**The R2 stub — which Fable structurally accepted and integrated as the baseline at trail 130, and whose authorization boundary you reviewed and largely passed — was unrunnable over HTTP.** Every response passed through the same redaction as a capture, so `resume_token` and `execution_capability` returned to the provider as `{"__withheld__": …}` descriptors. POC-1 could not have run at all.

Fable reproduced this independently (pure-function call, no server):

```text
minted token          →  {'__withheld__': 'secret-key-name', 'name': 'resume_token', …}
minted capability     →  [REDACTED:live-secret]
TOKEN USABLE: False      CAPABILITY USABLE: False
```

**Three layers missed it, for three different reasons**, and the third is Fable's: the Builder's R2 self-test passed 56/56 because it called `dispatch()` in-process, one layer below where the loss happened; your review examined the authorization boundary, which was sound; and Fable read `_respond`, saw `json.dumps(redact(body))`, and never asked what redaction does to the token that response exists to deliver. Recorded as a Fable verification defect, not merely a missed Builder defect.

**Why it matters to this review specifically:** the defect class is *a control whose tested layer differs from the layer a caller actually meets*. It survived a green self-test, a security review and a structural acceptance. **Fable's first request is that you look for an R3 analogue of exactly that shape.**

## 4. Two post-build contract amendments, disclosed

The Builder's pre-build contract audit found two defects in `25_` and reported rather than absorbed them. Fable ruled on both **after** the build, and amended `25_` — recorded visibly inside `25_` as a "POST-BUILD AMENDMENT RECORD", not folded in silently:

- **A.4's `UNCERTAIN` trigger** previously read *"(provider reports uncertain, or timeout)"* — naming a provider-supplied value as the trigger for an authority-bearing transition, contradicting the governing rule and A.6. Since `provider_status` exists only on receipt routes, it was unimplementable as written. The Builder built `UNCERTAIN` as service-established only. **Fable confirmed that reading; A.4 amended, A.6 unchanged.**
- **§B's "Quota pool" column** named the per-entity ceilings while A.8 defines three capture pools — one name over two axes. The Builder implemented both as separate axes. **Fable confirmed; column renamed "Entity quota".**

**Please confirm the amended text matches the build you review.** Neither amendment adds a requirement, and the build is claimed to already conform — but that is a Fable claim about a Fable amendment, which is precisely the kind of thing that should not go unchecked.

## 5. What Fable asks you to attack, in priority order

1. **The `Disclose` redaction exemption — the newest attack surface, and a deliberate hole.** DEF-R2-01's fix marks values the service minted and unwraps them **on the response path only**; the exemption is identity-based rather than key-name-based, so a caller cannot name its way out of redaction, and a `Disclose` still reduces to a descriptor on the capture path. The Builder's own falsifier row 4 says: *"it is the kind of thing that stays safe until someone adds a code path that wraps something it should not, and no test I can write today catches that future edit."* Fable wants this attacked hardest: can anything a caller controls reach a `Disclose`? Can a `Disclose` reach a capture, a log, or an error path? Is the response/capture asymmetry actually airtight?
2. **An R3 analogue of the R2 defect class** (§3): any control whose tested layer differs from the layer a caller meets.
3. **The A.4 amendment as built versus as now written** (§4).
4. **Two-phase evidence ordering at the transitions §E does not enumerate.** Six write boundaries are fault-injected individually. A.7 applies to more transitions than those six, and the Builder states the rest hold *"by construction"* — while having already found two ordering defects by testing, which is evidence the shape is not self-enforcing.
5. **The outcome-coverage guard's coarseness.** It proves each outcome code is produced by *some* case, not by the *right* case. The Builder flags this itself (falsifier row 3). A control that fires from the wrong branch would satisfy it.

## 6. What is already known not to be established

Stated so you are not starting blind, and so nothing here reads as a claim: **end-to-end binary fidelity is NOT established** — the service never receives destination bytes; `destination_digest_claimed` is provider-authored, gates nothing, and ships `UNSUPPORTED` in the measurement set. **n8n node types and parameters are NOT TESTED** — the egress proxy blocks `n8n-nodes-base`; structural validation passes and parameter correctness settles at import time on the owner's host (your `24A_` records the same gap in your environment). **No provider capability whatsoever is claimed**; no account, no host, no contact. **No security property is claimed independently verified** — that is what this request is for.

## 7. Scope

Narrowly the security posture of the completed R2+R3 throwaway apparatus, plus §4's amendment check. **Not reopened:** Release-1 (`09_`), the Capability Portfolio work, the Decision Engine design, the v1.4 baseline, provider selection, or the production-wrapper architecture (`13B_`). You have no execution sandbox constraint here — you have run suites in this environment before; where you want a probe Fable or the Builder should run, name it precisely and it will be run and returned to you.

## 8. Packet contents

This document · `25_` (the governing contract, with the amendment record) · `29_` (Fable's disposition of the R3 return) · the R3 Builder Delivery Record and Return Manifest (evidence-only) · `12_`/`13_` (the R1 security review and its disposition, for the defect history) · the complete `poc/` tree including both pinned reference artifacts · `base_snapshot.tar` + `BASE_BINDING.txt` · `authority_manifest.json` (Fable-published) · `SHA256SUMS.txt`. Fingerprint quoted in the relay message and recorded in the trail.
