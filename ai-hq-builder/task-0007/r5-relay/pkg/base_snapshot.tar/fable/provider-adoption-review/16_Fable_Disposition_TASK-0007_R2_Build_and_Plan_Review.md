# 16 — Fable Disposition: TASK-0007 R2 Builder return and the ChatGPT plan review

**Two inputs arrived together, because the owner relayed both packets in parallel:**

1. **The R2 Builder return** (zip SHA-256 `8f15f28998b95e027a09ae5cb9d47e93abe0e2319768fbc2b524fc6f8a9f0d72`) — the stub rework built against `14_` (Revision 1).
2. **ChatGPT's plan review of `14_`** (`15_` + `15A_`; bundle reviewed the `ChatGPT_R1_Disposition_and_Corrections.zip` at `b218020d…605806`, matching the trail-129 relay fingerprint) — verdict **PASS WITH CHANGES, Builder release BLOCKED**, asking for a Revision 2 before the Builder builds.

So the Builder built Revision 1 while the verifier was still reviewing Revision 1 and concluding it was not yet complete. That is not a failure by either party — it is the cost of parallel relay, and it is recoverable because the two outputs are complementary, not contradictory (§3).

## 1. Verification of the R2 build — what Fable did, and what Fable deliberately did not do

**Static verification (performed):**

| Check | Result |
| --- | --- |
| Return manifest vs disk, every entry re-hashed | **43/43 byte-identical**, 0 missing, 0 mismatch |
| Files on disk not in the manifest | 1 — a `__pycache__/*.pyc`, covered by the shipped `poc/stub/.gitignore`; excluded from the repo, never staged |
| Relay `poc/` copy vs accepted R1 return | byte-identical, 40/40 (the Builder's own H-06 self-check reproduced) |
| `r1_reference/stub_server_r1.py` vs the reviewed R1 target | byte-identical to `ecdaae67…76328ac` — the witness pin is genuine |
| Harness **code** unchanged (Builder §6a claim) | **6/6 SAME** — no harness code file changed |
| Harness **outputs** changed | exactly 4 — `structural.{json,log}`, `boundary.{json,log}` — the ones a structural re-run rewrites |
| Third-party imports across the three stub files | none — stdlib only (`errno`, `subprocess`, `importlib.util` are stdlib; `subprocess`/`importlib` appear only in the witness runner, never in `stub_server.py`) |
| Architecture vs delivery record | `/sink` gone (0 refs); `/relay/deliver` (capability-gated) and `/stage/deliver` (retry-tolerant) are **separate routes**; `--candidate` is `required=True`; 14 routes, 1,324 lines |
| Secret-shaped scan across the R2 tree | exactly the **two disclosed fixtures** (`check_boundaries.py`'s R1 synthetic Bearer; `r1_reference`'s `password: hunter2` docstring), both non-credentials, both correctly left untouched; everything R2 wrote scans clean |

**Adversarial verification (NOT performed by Fable, by design):** per the trail-127 practice, Fable did **not** start the stub, did **not** run the 56-case adversarial self-test, and did **not** run the 21 R1 witnesses. Those fire forged-capability, bypass, replay and self-approval probes at an authorization boundary — exactly the category the owner ruled routes to independent review rather than being executed by Fable. The Builder's `56/56` and `21/21` are therefore **Builder-authored self-claims**, disclosed as such, and their independent confirmation is a scheduled step (§3), not something this disposition asserts. This is the practice working as designed, and the limitation is recorded plainly: Fable's structural pass confirms the artifact's *shape and provenance*, not its *runtime security behaviour*.

**The Builder's §6 contract tensions, both ruled:**

- **§6(a) — regenerated `harness/out/` (4 files) outside the allowlist.** `14_` §5 required the structural harness re-run; running it rewrites its own outputs; `harness/**` was allowlist-excluded. The Builder shipped the regenerated outputs and reported the tension rather than absorbing it. **RULING: accept the regenerated outputs.** Reverting them would leave the shipped structural report describing R0 workflow files that no longer exist — a worse evidence state than the one the exclusion was protecting. No harness *code* changed (verified, 6/6). This is the correct fail-open-and-report behaviour, the same discipline R0/R1 showed.
- **§6(b) — two secret-shaped fixtures outside the allowlist, correctly untouched.** The `check_boundaries.py` Bearer fixture is the pre-existing R1 synthetic (outside this round's allowlist). The `r1_reference` `password: hunter2` docstring **must** stay byte-identical or the witness pin fails by design. Both correctly left alone. No action.

**Disposition of the R2 build: STRUCTURALLY ACCEPTED and INTEGRATED** as the new `poc/` baseline (6 added, 3 removed, 13 modified, matching the manifest). The hash-bound `R2_Return_Manifest.json` is integrated at top level as the audit record R2P-08 asks for. Its security posture is **NOT independently verified** and its contract is **Revision 1 only** — both carried forward as open gates, not closed ones.

**One convention conflict, resolved on existing precedent.** The Builder's Delivery Record self-identifies its runtime with a raw API model-ID string. Two standing rules collide: verbatim Builder records are **never** rewritten (the verifier's own instruction at the trail-69 substitution: *"Do not silently rewrite the verbatim Builder record"*), and raw model-ID strings are never written into pushed artifacts. Resolution follows what every prior round in this program did without needing a ruling: **Delivery Records travel verbatim in the relay zip and are not integrated into the repository tree.** The record is therefore preserved byte-untouched where it belongs, no raw model ID is pushed, and the audit trail is kept whole by hash-binding it here and in trail 130 — `R2_Builder_Delivery_Record.md`, SHA-256 `fb32e60d5ad23318f457646cc0a24d8ea7392e460a21afb2732b4315c1963698`. Its substance is summarised in this document; nothing is lost.

## 2. The build is genuinely good work, and it anticipated the review

Recorded because it bears on how the outstanding work is framed. The Builder:

- **Refused to use defect switches** and instead ran its probes against the *pinned, byte-verified R1 artifact itself* (`r1_witnesses.py`, SHA-checked against the reviewed target at run time, refusing to continue on mismatch). "The unfixed behaviour" it demonstrates is the exact artifact the verifier examined, not a reconstruction — a stronger evidentiary method than R1's defect-probe approach.
- **Already implemented a plan-review refinement before it existed:** it split the shared `/sink` into distinct `/relay/deliver` and `/stage/deliver` routes — which is precisely what ChatGPT independently asked for in `15_` §3 (VC-03 "concur with modification": *"use distinct route identities rather than sharing one generic /sink"*). The Builder and the verifier converged on the same design independently.
- **Wrote a falsifier that states its own limits honestly:** the redaction field-enumeration "is mine and could be short" (row 3); capture-before-commit is "two sites tested, others by construction" (row 4); "I have no basis to believe R2 is different in kind" from R1 and does not pre-empt the independent review (row 1). Those three admissions map almost exactly onto three of the verifier's plan corrections (R2P-06, R2P-04, and the standing need for the independent review) — the Builder and the verifier are pointing at the same gaps.

The R2 build addresses everything `14_` Rev 1 asked for. What it does not address is what `14_` Rev 1 did not yet contain — which is the subject of the plan review.

## 3. Disposition of the plan review (`15_`) — CONCUR in full

ChatGPT's plan review is **concurred in full.** It confirms Fable's disposition of the security review (SEC-R1-01..08, DOC-01 all CONCUR), concurs with all four corrections (`VC-01`..`VC-04`, VC-03 with the route-split modification the Builder already implemented), and affirms the security-plus-scenario merge as acceptable. Its nine plan corrections are accepted:

| ID | Fable disposition |
| --- | --- |
| **R2P-01** artifact authenticity & transport undefined | **CONCUR — genuine gap, owned (§4).** Choose the explicit POC mechanism (trusted preregistration or wrapper ingress); provider-supplied digests never authoritative; source vs relayed digest compared; artifact never in Discord. |
| **R2P-02** owner-idea authority not established | **CONCUR — genuine gap, owned (§4).** Add a wrapper-controlled authority path (owner-key `/owner/idea` intake minting an opaque idea token, or a pre-registered owner record); provider-set `origin=owner` can never upgrade authority. |
| **R2P-03** execution-capability / uncertain-outcome state machine | **CONCUR.** Specify the explicit state machine (MINTED → ATTEMPT_STARTED → DELIVERED_WITH_RECEIPT / UNCERTAIN → RECONCILED_*; REVOKED/EXPIRED); replay returns a receipt only from a verified-delivered state; uncertain permits reconciliation, never a second side effect. Tightens the Builder's C-3 implementation, which is close but not a specified machine. |
| **R2P-04** capture-before-commit needs truthful crash semantics | **CONCUR.** Prepared-vs-committed transition records; only committed records satisfy an acceptance check; orphaned prepared records reported uncertain, never counted complete. This is exactly the Builder's own falsifier row 4 caveat made into a contract. |
| **R2P-05** route authority as a declarative matrix | **CONCUR.** Replace `14_` C-11's global-check-plus-comments with a route-policy table implemented as data; unknown routes and missing policies fail closed; exemptions are explicit entries with reasons. |
| **R2P-06** redaction/unknown-field digest mechanics | **CONCUR.** Bound recursion depth, string length, list size, field count; per-process keyed HMAC (not raw SHA-256) for unknown values; this also answers the Builder's falsifier row 3. |
| **R2P-07** quota / evidence-exhaustion | **CONCUR.** Bound every collection; reserve capacity for owner decisions, capability spends and security refusals so an unauthenticated flood cannot evict them; closes FAB-16/FAB-17 explicitly. |
| **R2P-08** packet not snapshot-bound / self-contained | **CONCUR — a Fable defect (§4).** Revision 2 ships base commit + tree, a hash-bound authority manifest, task/topic/risk/trust/data classes, complete allowlists, and pre-fix/post-fix commands. |
| **R2P-09** provider-discriminating measures need acceptance coverage | **CONCUR.** The workflows/runbooks must expose/record the `09_` §2 artifact measures; no capability claimed from authored workflow files alone. |

The ten additional acceptance tests in `15_` §5 are adopted into the Revision-2 contract.

## 4. Fable defects owned

Two of the nine corrections are not refinements — they are logical contracts the Release-1 scenarios require and `14_` failed to specify:

- **R2P-01 (artifact authenticity)** — `09_` §2 defines POC-1 as "receive artifact → bind identity → **hash and validate**." `14_` accepted an `artifact content digest` field but never said who computes it or how the bytes travel, which would have let a provider-supplied hash stand as authoritative artifact identity. That is the same failure class as the SEC-R1-01 bypass: a control named but not anchored.
- **R2P-02 (owner-idea authority)** — `09_` §2 POC-2 requires an authenticated owner-authored idea *distinct from* external-untrusted material. `14_` carried the external-untrusted envelope from R1 but never defined the owner-authority path, leaving `origin=owner` self-assertable.

This is the third time in this workstream a Fable brief has been too narrow in the same direction: `08_` asked for two refusals without asking whether the guarded thing was reachable another way; `14_` Rev 1 specified the identity tuple without specifying how identity is *established*. The pattern is worth naming: Fable has been specifying the *shape* of a control and under-specifying its *root of trust*. Revision 2 (`17_`) is written to that lesson — every authority the stub asserts must trace to something the stub itself established, not something a caller supplied.

## 5. Sequencing ruling

**The R2 build's independent security review is NOT requested now.** The verifier explicitly sequenced it after Revision 2 (`15_` §248: *"a scoped verifier confirmation is required after Revision 2 because R2P-01 and R2P-02 alter the endpoint authority model and the actual Release-1 scenario contract"*). Reviewing the R2 build's security today would review an authority model that R2P-02 is about to change — the waste the verifier warned against. Fable concurs.

**Therefore:**

1. **`17_` issues as TASK-0007 R3 (the `14_` Revision 2 the verifier asked for)** — folding R2P-01..09 as an *increment on the integrated R2 build*, not a rebuild. The R2 security + evidence core stands as the baseline; R3 adds the two Release-1 authority contracts, the four specification tightenings (state machine, crash semantics, route matrix, redaction mechanics), the quota reservation, the snapshot binding, and the measurement coverage.
2. **The relay order is serial this time, on Fable's recommendation:** `17_` goes to **ChatGPT first** for the scoped Revision-2 confirmation it asked for, and Builder release is held until that confirmation lands. This cycle demonstrated the cost of parallel relay — the Builder built a contract the verifier then found incomplete. The owner controls relay timing; Fable's recommendation is to confirm the contract before building it, consistent with the standing "thoroughness over speed" preference. If the owner prefers parallel speed, the accepted risk is a possible second R3 rework.
3. **One independent security review, at the end.** After R3 returns and is structurally verified, the *final* stub — R2 core plus R3 additions — gets a single independent ChatGPT security review under the trail-127 practice. This avoids reviewing a moving target and spends one security-review cycle instead of two.

## 6. State after this disposition

```text
R2 build:                          STRUCTURALLY ACCEPTED, integrated as poc/ baseline
                                   (security posture NOT independently verified; contract = Rev 1 only)
Plan review (15_):                 CONCURRED in full; R2P-01..09 accepted; 10 tests adopted
R3 packet (17_ = 14_ Revision 2):  ISSUED — folds R2P-01..09 onto the R2 baseline
Recommended relay order:           17_ -> ChatGPT scoped confirmation -> then Builder release
Independent security review:       DEFERRED to after R3 (single review of the final stub)
Owner POC session:                 BLOCKED (unchanged)
Provider selection:                NOT MADE
Decision Engine / v1.4 baseline:   NOT REOPENED
v1.4 owner one-line acceptance:    still outstanding (standing item)
Next actor:                        Owner (relay 17_ to ChatGPT), then ChatGPT (scoped confirm)
```
