#!/usr/bin/env python3
# THROWAWAY POC EVIDENCE APPARATUS — see stub_server.py header.
"""Branch-specific acceptance oracle for every security route (SEC-R3-07).

The outcome-coverage guard the Builder introduced at R3 proves each outcome
*label* is produced by some case. The reviewer's correction stands: that is
completeness, not correctness — a 167/167 suite coexisted with two reachable
Criticals, because a label appearing somewhere says nothing about the right
branch firing for the right scenario. `32_` §3 keeps the guard as a completeness
aid and requires this instead.

Every scenario binds:

    starting_state          what is true before the request
    request + caller        the exact body and the authenticated identity
    expected_status         the HTTP status
    expected_outcome        the exact outcome code, not a family
    expected_state_delta    what must change in the service's own state
    expected_evidence_delta what must appear in the capture corpus
    forbidden               outcomes and evidence that must NOT appear
    concurrency_cardinality how many may succeed if issued concurrently

and every one is evaluated over **live HTTP**, against a server started for the
scenario, with the state and evidence read back after the call.
"""
from __future__ import annotations

import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

from barrier_suite import DIGEST, Server, race        # noqa: E402


def captures(srv, step=None):
    """Read the evidence corpus back off disk."""
    out = []
    root = os.path.join(srv.data, "captures")
    for dp, _dn, fs in os.walk(root):
        for f in fs:
            if not f.endswith(".json"):
                continue
            try:
                body = json.load(open(os.path.join(dp, f), encoding="utf-8"))
            except ValueError:
                continue
            if step is None or body.get("step") == step:
                out.append(body)
    return out


def outcomes_in(srv):
    return {c.get("fields", {}).get("outcome") for c in captures(srv)}


def steps_in(srv):
    return {c.get("step") for c in captures(srv)}


# --------------------------------------------------------------------------
# Each scenario returns (observed: dict, verdicts: dict) — one verdict per
# clause of the oracle, so a failure names the clause that broke.
# --------------------------------------------------------------------------
def o_review_unregistered(srv):
    """A review-case whose registration does not exist."""
    before = len(captures(srv))
    st, body = srv.post("/poc1/review-case",
                        {"registration_ref": "reg-nope", "task_id": "T",
                         "transition": "R", "artifact_digest": DIGEST,
                         "target_role": "verifier", "submission_epoch": 1,
                         "envelope": {"trust": "external-untrusted",
                                      "partition": "business"}})
    after = captures(srv)
    return ({"status": st, "outcome": body.get("outcome"),
             "cases": len(srv.post("/owner/cases", {}, "owner")[1]["cases"]),
             "captures_added": len(after) - before}, {
        "expected_status 403": st == 403,
        "expected_outcome rejected-artifact-binding":
            body.get("outcome") == "rejected-artifact-binding",
        "expected_state_delta none (no case opened)":
            len(srv.post("/owner/cases", {}, "owner")[1]["cases"]) == 0,
        "expected_evidence_delta a refusal capture": len(after) - before >= 1,
        "forbidden: no case-opened evidence":
            "case-opened" not in {c.get("fields", {}).get("outcome") for c in after},
        "forbidden: no resume token disclosed": "resume_token" not in body,
    })


def o_relay_without_capability(srv):
    """The represented side effect, called directly."""
    st, body = srv.post("/relay/deliver",
                        {"capability": "cap-" + "f" * 32,
                         "action_request_id": "ar-x", "case_id": "case-x",
                         "payload": {}, "destination_digest_claimed": DIGEST})
    return ({"status": st, "outcome": body.get("outcome")}, {
        "expected_status 403": st == 403,
        "expected_outcome refused-no-capability":
            body.get("outcome") == "refused-no-capability",
        "expected_state_delta none": srv.post(
            "/poc1/reconcile", {"capability": "cap-" + "f" * 32,
                                "action_request_id": "ar-x"})[0] == 404,
        "forbidden: not delivered": body.get("delivered") is not True,
        "forbidden: no receipt": body.get("receipt") is None,
    })


def o_owner_route_with_provider_key(srv):
    """An owner route reached with the provider credential."""
    before = len(captures(srv))
    st, body = srv.post("/owner/decide",
                        {"case_id": "case-x", "decision": "accept"}, "provider")
    after = captures(srv)
    pools = {c.get("pool") for c in after[before:]}
    return ({"status": st, "outcome": body.get("outcome"), "pools": sorted(pools)}, {
        "expected_status 403": st == 403,
        "expected_outcome refused-auth": body.get("outcome") == "refused-auth",
        "expected_evidence_delta a captured refusal": len(after) - before >= 1,
        "expected_evidence pool security-refusal, never reserved-owner":
            "reserved-owner" not in pools,
        "forbidden: no decision recorded":
            "owner-decision" not in {c.get("step", "") for c in after},
    })


def o_verify_pending(srv):
    """A valid token with no owner decision yet: pending, token NOT consumed."""
    ref = srv.post("/owner/artifact/register",
                   {"source_digest": DIGEST, "size_bytes": 1, "file_count": 1,
                    "task_id": "PEND", "transition": "R",
                    "target_role": "verifier"}, "owner")[1]
    opened = srv.post("/poc1/review-case",
                      {"registration_ref": ref["registration_ref"],
                       "task_id": "PEND", "transition": "R",
                       "artifact_digest": DIGEST, "target_role": "verifier",
                       "submission_epoch": 1,
                       "envelope": {"trust": "external-untrusted",
                                    "partition": "business"}})[1]
    tok = opened["resume_token"]
    st, body = srv.post("/poc1/verify-decision", {"token": tok})
    st2, body2 = srv.post("/poc1/verify-decision", {"token": tok})
    return ({"first": [st, body.get("outcome")],
             "second": [st2, body2.get("outcome")]}, {
        "expected_status 403": st == 403,
        "expected_outcome pending": body.get("outcome") == "pending",
        "expected_state_delta none — the token is NOT consumed":
            body2.get("outcome") == "pending",
        "forbidden: not authorized": body.get("authorized") is not True,
        "forbidden: no capability disclosed": "execution_capability" not in body,
    })


def o_decision_terminal(srv):
    """The first valid owner decision is terminal; a second is a captured 409."""
    ref = srv.post("/owner/artifact/register",
                   {"source_digest": DIGEST, "size_bytes": 1, "file_count": 1,
                    "task_id": "TERM", "transition": "R",
                    "target_role": "verifier"}, "owner")[1]
    srv.post("/poc1/review-case",
             {"registration_ref": ref["registration_ref"], "task_id": "TERM",
              "transition": "R", "artifact_digest": DIGEST,
              "target_role": "verifier", "submission_epoch": 1,
              "envelope": {"trust": "external-untrusted", "partition": "business"}})
    cid = [c["case_id"] for c in srv.post("/owner/cases", {}, "owner")[1]["cases"]
           if not c["decided"]][-1]
    first = srv.post("/owner/decide", {"case_id": cid, "decision": "reject"}, "owner")
    second = srv.post("/owner/decide", {"case_id": cid, "decision": "accept"}, "owner")
    return ({"first": first[0], "second": second[0],
             "second_outcome": second[1].get("outcome")}, {
        "expected_status 200 then 409": first[0] == 200 and second[0] == 409,
        "expected_state_delta the decision stays REJECT":
            second[1].get("refused") is True,
        "expected_evidence_delta an owner-decision transition":
            any(s.startswith("committed-owner-decision") for s in steps_in(srv)),
        "forbidden: the second decision is not recorded as effective":
            sum(1 for s in steps_in(srv)
                if s.startswith("committed-owner-decision")) == 1,
    })


def o_owner_reconcile_delivered(srv):
    """`/owner/reconcile` cannot manufacture a delivered state."""
    from barrier_suite import to_capability
    cid, v = to_capability(srv, "REC")
    ar = v["action_request"]
    st, body = srv.post("/owner/reconcile",
                        {"action_request_id": ar["id"], "outcome": "delivered",
                         "note": "n"}, "owner")
    return ({"status": st, "outcome": body.get("outcome")}, {
        "expected_status 400": st == 400,
        "expected_state_delta none": body.get("action_request_status") != "DELIVERED_WITH_RECEIPT",
        "forbidden: RECONCILED_DELIVERED is not reachable here":
            "reconciled-delivered" != body.get("outcome"),
        "forbidden: no receipt minted": body.get("receipt") is None,
    })


def o_concurrency_cardinality(srv):
    """The cardinality clause, stated as its own oracle over live HTTP."""
    ref = srv.post("/owner/artifact/register",
                   {"source_digest": DIGEST, "size_bytes": 1, "file_count": 1,
                    "task_id": "CARD", "transition": "R",
                    "target_role": "verifier"}, "owner")[1]
    body = {"registration_ref": ref["registration_ref"], "task_id": "CARD",
            "transition": "R", "artifact_digest": DIGEST,
            "target_role": "verifier", "submission_epoch": 1,
            "envelope": {"trust": "external-untrusted", "partition": "business"}}
    a, b = race(lambda: srv.post("/poc1/review-case", body),
                lambda: srv.post("/poc1/review-case", body))
    outs = [r[1].get("outcome") for r in (a, b)]
    opened = [c for c in srv.post("/owner/cases", {}, "owner")[1]["cases"]
              if c.get("task_id") == "CARD"]
    return ({"outcomes": outs, "cases": len(opened)}, {
        "concurrency_cardinality: exactly one case-opened":
            outs.count("case-opened") == 1,
        "concurrency_cardinality: the loser is truthfully suppressed":
            outs.count("duplicate-suppressed") == 1,
        "expected_state_delta exactly one case": len(opened) == 1,
        "forbidden: never two effective transitions": len(opened) <= 1,
    })


ORACLES = (
    ("/poc1/review-case — unknown registration", o_review_unregistered),
    ("/relay/deliver — no capability", o_relay_without_capability),
    ("/owner/decide — provider credential", o_owner_route_with_provider_key),
    ("/poc1/verify-decision — pending", o_verify_pending),
    ("/owner/decide — terminal decision", o_decision_terminal),
    ("/owner/reconcile — outcome=delivered", o_owner_reconcile_delivered),
    ("/poc1/review-case — concurrency cardinality", o_concurrency_cardinality),
)


def run(target: str, emit=None) -> list:
    rows = []
    for title, fn in ORACLES:
        srv = None
        try:
            srv = Server(target, candidate="oracle")
            observed, verdicts = fn(srv)
        except Exception as exc:                                 # noqa: BLE001
            observed = {"error": "%s: %s" % (type(exc).__name__, exc)}
            verdicts = {"scenario ran": False}
        finally:
            if srv:
                srv.close()
        failed = sorted(k for k, v in verdicts.items() if not v)
        rows.append({"route": title, "ok": not failed, "observed": observed,
                     "clauses": len(verdicts), "failed_clauses": failed})
        if emit:
            emit(rows[-1])
    return rows


if __name__ == "__main__":
    tgt = os.path.abspath(sys.argv[1]) if len(sys.argv) > 1 \
        else os.path.join(HERE, "stub_server.py")
    res = run(tgt, emit=lambda r: sys.stderr.write(
        "  [%s] %-48s %d clauses%s\n"
        % ("ok  " if r["ok"] else "FAIL", r["route"][:48], r["clauses"],
           "" if r["ok"] else "  FAILED: " + "; ".join(r["failed_clauses"])[:150])))
    bad = [r for r in res if not r["ok"]]
    total = sum(r["clauses"] for r in res)
    sys.stderr.write("\n%d/%d oracles hold (%d clauses) — %s\n"
                     % (len(res) - len(bad), len(res), total, os.path.basename(tgt)))
    sys.exit(1 if bad else 0)
