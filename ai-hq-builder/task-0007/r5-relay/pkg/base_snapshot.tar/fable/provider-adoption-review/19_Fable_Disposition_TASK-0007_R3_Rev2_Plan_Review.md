# 19 — Fable Disposition: ChatGPT scoped confirmation of the R3 / Revision 2 packet

**Input:** `18_` + `18A_` (bundle SHA-256 `e641fe32bf4071565478e1c405a86dcc5a54d06570ced1404d61bd245ecdb66c`, matching the verifier's stated fingerprint; internal `SHA256SUMS` 2/2 OK; both files integrated byte-identical). The verifier reviewed the `TASK0007_R3_Revision2_Packet.zip` at `40f4bd55…500102`, matching the trail-130 relay fingerprint.

**Verdict: FAIL — R3 Task Packet gate. CONCURRED IN FULL, without reservation.**

The finding is correct and it is mine. `17_` (Revision 2) repeatedly instructed the Builder to *choose* or *define* security and evidence architecture — the artifact-authority mechanism, the owner-idea mechanism, the capture/commit model, the capability state behaviour, the route policies, the redaction and quota limits. **Those are architecture decisions. They belong to the Architect role, which is Fable's. The Builder implements decisions; it does not make them.** A packet that delegates them is not implementation-ready, and releasing it would have had the Builder inventing the security contract that a later review would then measure against — the design reviewed against itself.

## 1. The pattern, now named plainly and corrected

`16_` §4 already recorded that Fable had three times specified the *shape* of a control while under-specifying its *root of trust*. `17_` §6 predicted "a fourth is likelier than not." It arrived — not as another missing root of trust, but as the same role-discipline slip one level up: **`17_` named the roots of trust that were needed and then asked the Builder to design them.** Identifying that a decision is required is Architect work; *making* the decision is also Architect work, and `17_` stopped at the first half.

The corrective in `20_` (Revision 3) is not "try harder." It is structural: every clause that previously said "choose one" or "define" now carries **one selected mechanism and one normative contract**, specified to the point a Builder can implement without a design judgment. Where `20_` still leaves a choice, it is explicitly an *implementation-internal* choice (data structures, function decomposition) bounded by a Fable-specified contract. If any clause in `20_` still delegates a trust or evidence decision, that is a defect to report before building — the same stop-and-report discipline every prior round used.

## 2. Disposition of the nine prior findings and eight new ones — all CONCUR

The verifier's scoped status of R2P-01..09 is accepted exactly. R2P-03 (partially closed) and R2P-09 (directionally closed) are the two where Revision 2 made real progress; the other seven were open because Revision 2 described the requirement without instantiating it. The eight new findings R3P-01..08 are all concurred:

| ID | What Revision 3 does about it |
| --- | --- |
| **R3P-01** authority delegated to Builder | `20_` §2 **selects** trusted preregistration (artifact) and an owner-key `/owner/idea` intake (owner authority), each with a normative record and transition contract. No "choose one" remains. |
| **R3P-02** integrity confused with authority | `20_` ships a machine-readable **authority manifest** (`authority_manifest.json`) classifying every file by origin, trust class, and instruction authority. The Builder Delivery Record and Return Manifest are **evidence-only**; `20_` is the sole governing instruction. |
| **R3P-03** route policy not instantiated | `20_` §4 is the **actual route-policy table**, one row per route for all current routes plus the two new owner routes; any new route needs a Fable-approved change request. |
| **R3P-04** capability/evidence state under-specified | `20_` §3 is an **exact transition matrix** (states, legal transitions, per-transition authority, terminal behaviour, reconciliation evidence, restart posture, invalid-transition handling) and **one selected** append-only evidence model. |
| **R3P-05** redaction/quota lack checkable bounds | `20_` §5 gives **numeric bounds**, an exact keyed-HMAC contract, protected reserves, and exhaustion precedence. |
| **R3P-06** snapshot/allowlist incomplete | `20_` ships a **git bundle** binding commit↔tree independently, plus separate implementation and control/evidence allowlists and an explicit immutable denylist (the R1 pin, harness code, prior governance records). |
| **R3P-07** measurement not acceptance-bound | `20_` §6 specifies the exact measurement schema and a **completeness validator** (`poc/data/validate_measurements.py`) that fails when any required measure lacks a status / evidence reference / explicit `NOT TESTED`/`UNSUPPORTED`. |
| **R3P-08** baseline wording inconsistent | Adopted verbatim, everywhere: *"R2 is structurally integrated as the implementation baseline; its security claims remain Builder-authored and unaccepted until the final independent review of the R2+R3 stub."* |

The one verifier observation Fable acts on immediately rather than deferring: the commit/tree declaration in `17_` was **not independently reproducible from the export** (`18A_` `commit_tree_binding_independently_reproducible: false`). A declared hash a reviewer cannot verify is exactly the integrity-vs-authority confusion R3P-02 names, applied to provenance. `20_` carries a `git bundle` of the base commit so the binding is verifiable from the relay alone.

## 3. Two things preserved from the record

- The verifier re-confirmed the R2 baseline reproduces its Builder-authored evidence (56/56 self-test, 21/21 witnesses, 14 routes) — and correctly restated that this is **not** the independent security acceptance, which remains scheduled after R3. That posture is now the single wording used everywhere (R3P-08).
- Nothing accepted reopens: Release-1, the Capability Portfolio work, the Decision Engine baseline, v1.4, and the R1/R2 security dispositions all stand. This is a bounded plan correction.

## 4. Sequencing

`20_` (Revision 3) goes to **ChatGPT first** for the narrow confirmation the verifier requires, before any Builder release — the serial order already adopted in `16_` §5 and now doubly warranted, because Revision 3 finally *selects* the two authority roots and instantiates the route, state, evidence, and quota contracts, which is precisely what the confirmation exists to check. On that confirmation, the Builder implements R3 against the integrated R2 baseline; the final combined R2+R3 stub then receives the single independent security review already planned. Owner action: relay `20_` to ChatGPT; hold Builder release until the confirmation returns.
