# 15 — ChatGPT Verifier Response: TASK-0007 R2 Dispositions and Builder Packet

**Review type:** scoped plan / rework-packet review before Builder release  
**Input packet:** `ChatGPT_R1_Disposition_and_Corrections.zip`  
**Input packet SHA-256:** `b218020d08f34409194b4bd81f70ac9111879cb73c34f3fc2e4f7aa0cc605806`  
**Primary review targets:** `13_Fable_Dispositions_TASK-0007_R1_Security_Review.md` and `14_TASK-0007_R2_Task_Packet_Stub_Rework_and_Release1_Reaim.md`

## 1. Verdict

**PASS WITH CHANGES — do not release the current Task Packet to the Builder yet.**

Fable's disposition of the prior independent security review is substantially correct. The corrections VC-01 through VC-04 sharpen the prior review, and the additional FAB findings identify real evidence-integrity defects that belong in the same bounded apparatus-rework cycle.

The proposed R2 Task Packet is not yet complete enough to implement safely. It correctly addresses the known endpoint bypass, terminal decisions, capture integrity, route hardening, evidence provenance, and Release-1 identity tuple. However, it leaves two Release-1 fundamentals undefined and several execution/evidence boundaries underspecified:

1. The Builder-return POC does not define who independently computes and verifies the ZIP/artifact digest or how the binary travels without trusting a provider-supplied digest.
2. The owner-authored idea POC does not define how owner instruction authority is established without permitting the provider to self-assert `origin=owner`.

Those are not production-hardening requests. They are necessary logical contracts for the two scenarios the R2 packet is explicitly re-aiming.

## 2. Packet and Baseline Verification

Independent checks completed:

```text
ZIP opened successfully
Packet SHA-256: b218020d08f34409194b4bd81f70ac9111879cb73c34f3fc2e4f7aa0cc605806
Declared SHA256SUMS: 10 / 10 passed
Current stub Python compilation: passed
Current stub self-test: 66 / 66 passed
```

The current 66/66 result is a baseline reproduction only. It does not contradict the prior FAIL because the current self-test does not exercise the direct `/sink` bypass or the broader evidence-integrity findings.

## 3. Disposition of Fable's Corrections

### VC-01 | Concur

`metadata: []` is falsy and does not reproduce the crash. A truthy non-object such as `[1]`, `"x"`, `5`, or `true` is the correct regression input. The rework test must use a reproducing value.

### VC-02 | Concur

The previous statement that provider-supplied decision fields were refused was endpoint-scoped, not service-wide. The R2 design should make refusal a declarative route policy and verify every provider-persisting route.

### VC-03 | Concur with modification

POC-1 execution and POC-3 staging need separate authority and retry semantics. They should also use distinct route identities rather than sharing one generic `/sink`; separate routes make the capability boundary and evidence classification directly testable.

### VC-04 | Concur

Query rejection alone does not prevent caller-controlled path data from reaching `BaseHTTPRequestHandler` logging. Logging must use route constants and status only, including malformed and unmatched requests.

## 4. Required Plan Corrections

### R2P-01 — High: Artifact authenticity and transport are undefined

`09_` defines POC-1 as:

```text
Receive artifact -> bind task/transition identity -> hash and validate
```

The R2 contract accepts an `artifact content digest`, but does not identify who computes it, how it is verified, or how the original artifact reaches the relay. A digest supplied by the automation provider is corroborating material, not an authoritative artifact identity.

The JSON-only transport rule also conflicts with testing ZIP fidelity unless the artifact travels through a separately defined channel.

**Required correction:** choose one explicit POC mechanism:

- **Trusted preregistration:** the AI OS side registers `artifact_id`, source digest, size, task, expected transition, and allowed target role before the provider sees the artifact; the provider carries only the bound reference and later destination digest; or
- **Wrapper ingress:** a dedicated artifact endpoint accepts raw bytes or a bounded multipart upload, computes the digest locally, rejects malformed/path-traversal cases, and stores only the controlled POC artifact/reference.

In either model:

- Provider-supplied hashes are never authoritative by themselves.
- Source and relayed-object digests are compared.
- Same bytes under different task IDs remain distinct submissions.
- Size, file count, binary fidelity, original-versus-reconstituted delivery, and provider retention are recorded as POC measurements.
- The artifact must not be placed in Discord.

### R2P-02 — High: Owner-authored idea authority is not established

POC-2 requires both:

```text
A. authenticated owner-authored idea
B. external-untrusted imported or forwarded material
```

The current service only understands an external-untrusted envelope. A provider cannot be allowed to convert an arbitrary payload into owner-authorized instructions by setting `origin=owner` or an equivalent field.

**Required correction:** define a wrapper-controlled authority path. A POC-level solution may be:

- an owner-key-protected `/owner/idea` intake that mints an opaque, single-purpose idea token; or
- a pre-registered owner-authored intake record whose reference the provider may carry.

External material attached to an owner idea receives its own separate external-untrusted envelope and no instruction authority. Tests must prove that changing provider-supplied origin, trust, or instruction-authority fields cannot upgrade authority.

### R2P-03 — High: Execution capability and uncertain-outcome state are incomplete

C-3 says a replay returns the prior receipt, while R1P-04 requires reconciliation before any second side effect after an uncertain result. Those rules need an explicit state machine.

**Required correction:** define at least:

```text
MINTED
ATTEMPT_STARTED
DELIVERED_WITH_RECEIPT
UNCERTAIN
RECONCILED_DELIVERED
RECONCILED_NOT_DELIVERED
REVOKED / EXPIRED
```

Rules:

- A replay returns a prior receipt only from a verified delivered state.
- An uncertain state permits reconciliation, not a second side effect.
- A verified-not-delivered reconciliation may authorize one new attempt under the same idempotency identity.
- Attempt count and delivery count remain separate.
- Capability binding includes the stable submission identity, ActionRequest, case, target role/endpoint, canonical payload digest, provider/candidate, and expiry.
- Retry attempt identity is separate from the stable submission epoch; provider retries must not accidentally create new submissions.

### R2P-04 — High: Capture-before-commit needs truthful crash semantics

Filesystem capture and in-memory state cannot be one atomic transaction. Writing a capture first prevents unrecorded authority, but a crash after the write and before the state change can leave a record that appears completed when it was not.

**Required correction:** the POC evidence format must distinguish transition intent from committed outcome. Acceptable POC mechanisms include:

- `prepared` plus `committed` records linked by transition ID; or
- one append-only transition record whose status is later advanced and whose incomplete state is explicitly reconciled.

Only committed records may satisfy an acceptance check. Orphaned prepared records must be reported as uncertain, never counted as completed. The same rule applies to owner decisions, token spend, capability spend, delivery, and POC-3 checkpoint/reconcile transitions.

This is a POC evidence-integrity contract, not a request for a production database transaction.

### R2P-05 — High: Route authority and schema need a declarative matrix

C-11 proposes global dispatch checks plus exemptions. That remains ambiguous because owner routes legitimately carry a decision, provider routes require a provider credential, the POC-1 execution route requires a capability, POC-3 needs retry-tolerant staging, and health is public or separately protected.

**Required correction:** add a route-policy table to the Task Packet and implement it as data, not scattered handler choices. For each route specify:

```text
caller class
required credential/capability
accepted media type
maximum body size
allowed top-level and nested fields
partition/trust requirements
decision-field policy
capture-on-success / capture-on-refusal
cache policy
logging label
rate/quota class
```

Unknown routes and missing policies fail closed. Exemptions must be explicit entries with reasons, not comments around a global bypass.

### R2P-06 — Medium: Redaction and unknown-field digest rules need exact mechanics

C-10's intent is correct but needs bounded implementation rules. Searching every substring of a 1 MiB body against token digests can itself become a denial-of-service path, and a plain digest of a low-entropy unknown value is not meaningfully non-reversible.

**Required correction:** define:

- Maximum recursion depth, string length, list size, and field count.
- Which active secret lengths may be checked by bounded digest comparison.
- A per-process keyed HMAC or salted digest for unknown values rather than raw SHA-256.
- Structured redaction markers that cannot be mistaken for PRESENT evidence.
- Tests for exact secret equality, secret substring, Unicode-confusable key, key-name false positives, and preserved non-secret D-EC_ fields.

### R2P-07 — Medium: Quota and evidence-exhaustion behavior are incomplete

C-12 captures every refusal while C-15 only broadly says to bound counts. An unauthenticated caller must not be able to consume the entire evidence budget and prevent an owner decision or security refusal from being recorded.

**Required correction:** bound every in-memory and capture collection—cases, tokens, decisions, attempts, receipts, runs, checkpoints, captures—and define fail-closed behavior when capacity is reached. Reserve or otherwise protect capacity for owner decisions, capability spends, and security refusals. Remove activity counts from unauthenticated health output or protect the detailed health view.

This also closes FAB-16 and FAB-17 explicitly rather than relying on the generic `FAB-01..17` reference.

### R2P-08 — High: The Builder authority packet is not snapshot-bound or self-contained

The packet references `05_`, `07_`, `08_`, `13B_`, three runbooks, workflow definitions, the measurement template, and other repository materials not included in this review export. It also does not identify an exact Builder baseline commit/tree or an authority/context manifest.

**Required correction before Builder release:** publish Revision 2 with:

- Exact base commit and tree.
- Hash-bound source/authority manifest.
- Task ID, parent/topic ID, risk class, trust class, data class, allowed action set, and prohibited actions.
- Complete implementation and control-artifact allowlists.
- All files the Builder is instructed to read, or exact repository paths and hashes.
- Explicit failure, concurrency, idempotency, rollback/recovery, logging, and evidence requirements, including justified `N/A` where appropriate.
- Reproducible pre-fix evidence and post-fix acceptance commands.

### R2P-09 — Medium: Provider-discriminating measures need acceptance coverage

The R2 packet permits updates to `measurements.template.json` but does not require the Release-1 artifact measures from `09_` §2 to be present and populated during the later owner session.

**Required correction:** the rework packet must require the workflow definitions and runbooks to expose or record, at minimum:

```text
artifact bytes and file count
source and destination digests
original versus reconstructed relay
provider task/step/execution count
owner-attention steps and minutes
approval latency
retry count and uncertain-result reconciliation
capture/receipt completeness
provider retention/deletion observation
failure or unsupported-capability reason
```

No provider capability is claimed from authored workflow files alone; unsupported or untested values remain explicit.

## 5. Additional Acceptance Tests

Add these tests to the R2 contract:

1. Provider changes `origin`, `trust`, or `instruction_authority` on an idea payload; authority does not increase.
2. External content embedded in an owner-authored idea remains external-untrusted and cannot become an instruction.
3. Provider supplies the correct artifact digest for different bytes; relay fails.
4. Provider supplies altered digest metadata for the same bytes; relay fails.
5. Same artifact/reference and task with a new retry attempt does not create a new submission.
6. First delivery enters uncertain state; replay does not execute; reconciliation determines the next legal transition.
7. Prepared-but-uncommitted capture after simulated crash does not count as completed evidence.
8. Every route is present in the route-policy table; deleting one policy entry makes the self-test fail closed.
9. Exhausting ordinary refusal quota does not prevent an owner-decision or capability-spend record.
10. Public health output does not reveal owner-decision or case activity.

## 6. Gate State

```text
Fable disposition of SEC-R1-01..08:   CONCUR
Fable disposition of DOC-01:          CONCUR
VC-01:                                CONCUR
VC-02:                                CONCUR
VC-03:                                CONCUR WITH MODIFICATION
VC-04:                                CONCUR
Additional FAB findings:              VALID INPUT TO R2
R2 merge of security + scenario work: ACCEPTABLE
Current R2 Builder packet:             PASS WITH CHANGES
Builder release:                       BLOCKED
Owner POC session:                     BLOCKED
Provider selection:                    NOT MADE
Decision Engine / v1.4 baseline:       NOT REOPENED
Next actor:                             FABLE
Next action:                            ISSUE R2 TASK PACKET REVISION 2
```

A scoped verifier confirmation is required after Revision 2 because R2P-01 and R2P-02 alter the endpoint authority model and the actual Release-1 scenario contract. No broader provider-review or Decision Engine review is required.

