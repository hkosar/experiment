# 11 — Independent Security Review Request: TASK-0007 R1 Wrapper Stub

**From:** Fable. **To:** the independent verifier (ChatGPT). **Nature of this request:** new — not a design-gate or build-gate review. Per an owner process ruling (trail 127), adversarial/exploit-style verification of a Builder deliverable's security properties is now routed to you as an independent second opinion, in addition to whatever Fable already checked directly. This request is the first instance of that practice.

## 1. What this artifact is

`poc/stub/stub_server.py` (653 lines, Python standard library only) — a **throwaway test double**, not the AI OS wrapper. It exists so the Zapier/n8n proof-of-capability workflows (TASK-0007) have something to call during the owner's hands-on testing session. It is explicitly marked THROWAWAY in its own header, `/health` response, a response header on every request, every capture record, and the README — and it deliberately lacks four things the real production wrapper (`13B_` build-gate scope) will require: authentication beyond a shared local key, cryptography, persistence, and clock authority. It runs on localhost only, for a session the owner controls.

## 2. Why it has real security-shaped controls despite being throwaway

The POC-1 flow requires proving that a provider (Zapier or n8n) can pause on an owner decision without being able to *make* that decision itself — this is a design-accepted boundary (packet `08_` §R1, tracing to the standing rule that approval authority never transfers to a provider). So the stub has to actually enforce that separation, even though it is disposable apparatus. The two properties packet `08_` required as mandatory, demonstrated failing:
1. A missing/forged/replayed resume token must be refused.
2. An approval decision arriving from the provider side (rather than the owner surface) must be refused.

## 3. What the Builder found and fixed, in its own adversarial pass (disclosed in full — nothing summarized away)

The Builder ran independent attacker exercises against its own build (its Delivery Record §4a, attached) and found — and fixed — **eight defects**, the two most significant:

- **Token-lifecycle bug:** the original design consumed the resume token at *validation* time, so a provider's routine early poll (checking whether a decision exists yet, before it does) would burn the token — the owner's subsequent approval could then never be relayed. This is the kind of bug a unit test hides if the test uses two different tokens for "not yet decided" and "decided," rather than the same token polled twice — which is what a real provider does. Fixed by splitting token *validation* from token *consumption*.
- **Self-approval bypass:** nothing originally distinguished the owner's own decision request from a request the provider could make itself — the provider could open a case and approve it, unattended, while a field-name check on a *different* endpoint passed the whole time. Fixed with a per-process owner key (never given to a provider) required on the decision endpoint, plus turning the decision-endpoint's input validation from a denylist (which unicode/casing variants defeated) into an allowlist (only one field accepted, everything else refused).

Full findings table, every fix, and every regression case: `poc/FINDINGS.md` and the Delivery Record §4a (both attached). Self-test grew from 39 to 66 cases as a direct result.

## 4. What Fable already verified (disclosed so you are not starting blind)

- Manifest/hash integrity: 40/40 files match the return manifest.
- The full harness (structural validation, boundary compliance, cost model, receipt conformance) re-run on a clean copy: PASS, 39/39 self-test cases.
- The stub's own self-test re-run on a clean copy: PASS, 66/66.
- **Fable additionally ran a live adversarial walkthrough by hand** against a locally-started copy — the exact scenario this process ruling is about. Sequence and results: opened a case (provider side) → attempted self-approval without the owner key → **refused**; smuggled a `decision`-shaped field into the verify-decision call → **refused**; polled the pending case before any decision existed → correctly reported pending, **token not consumed**; the owner listed and decided the case through the key-protected endpoints → recorded; the provider's subsequent poll → **authorized**; replaying the same token → **refused**. Every one of the Builder's claims reproduced live, cleanly. No new defect found by Fable's own pass.
- Workflow definitions: unchanged, byte-identical to the accepted R0 return (correct — R1 does not touch scenario content).

## 5. What is being asked of you specifically

1. **Independent code-level assessment of `stub_server.py`** (attached in full): does the code actually implement what §3–4 claim? Are there residual bypass vectors beyond the eight already found and fixed — particularly around the owner-key mechanism (a shared secret over plain HTTP on loopback — sound for a throwaway single-operator local POC, not a claim of real authentication; say so if you disagree), the token allowlist, the redaction logic (key-name **and** value-shape, per the Builder's disclosure that value-shape alone misses structured JSON secrets), and the fail-closed posture on malformed input (two of the eight findings were crashes-instead-of-refusals).
2. **Any additional attack vectors you want tested that neither the Builder's adversarial pass nor Fable's live walkthrough covered.** You have no execution sandbox, so name the scenario precisely enough that Fable or the Builder can run it and return the transcript to you — this request explicitly is not asking you to execute anything, only to review and to direct further testing.
3. **A verdict on whether this satisfies the two `08_` §R1 mandatory refusals** as an independent matter, separate from Fable's or the Builder's own say-so.

## 6. What is NOT in scope

Nothing about the design gate, TASK-0005/0006, the provider shortlist, or the Release-1 re-aim (`09_`/`10_`) is reopened by this request. This is narrowly the security posture of one throwaway apparatus file. No provider has been contacted; no POC has been run; this stub does not touch production credentials or real accounts.

## 7. Packet contents

This document · `poc/stub/stub_server.py` · `poc/stub/selftest_stub.py` · `poc/stub/out/stub_selftest.json` (the 66-case self-test output) · `poc/FINDINGS.md` · the Builder's Delivery Record for TASK-0007 R1 (`BUILDER_DELIVERY_RECORD.md`, §§1–4a and 6 especially) · `08_TASK-0007_R1_Wrapper_Stub_Packet.md` (the governing instruction). Fingerprint quoted in the relay message.
