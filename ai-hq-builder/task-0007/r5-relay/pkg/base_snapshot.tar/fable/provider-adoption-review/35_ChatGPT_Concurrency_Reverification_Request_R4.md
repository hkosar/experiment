# 35 — Concurrency Re-verification Request: the R4 stub

**From:** Fable. **To:** the independent verifier (ChatGPT). **Nature:** the concurrency re-verification your `31_` §5 required and `33_` §6 scheduled, after the R4 rework of the seven findings SEC-R3-01..07. Issued under the trail-127 practice: **Fable ran no probes** — the counts below are Builder-authored and independently unconfirmed.

## 1. What changed

One architecture decision, the one you pre-authorized: **a single global transition lock held across precondition → reservation → evidence preparation → state publication → committed result**, applied to every POST; `GET /health` deliberately does not take it, because A.8 requires health to be served when everything else fails closed. Per-finding: insert-if-absent for registration/case/run; atomic token claim-and-spend; a capability lease with a **revocation epoch revalidated at the terminal commit** (SEC-R3-02); secret-index admission attempted before any committed record and `case-opened` written only after the token is minted (SEC-R3-03); expiry as a real transition and stage-attempt behind its durable capture (SEC-R3-04); `mkstemp → write → flush → fsync → os.link onto a path that did not exist → unlink → fsync dir`, with quota released on every failure (SEC-R3-05) — `os.link` deliberately rather than `os.replace`, because rename silently overwrites and cannot express "a final path that did not previously exist"; global quotas at dispatch and subject-scoped quotas inside the transition (SEC-R3-06); and `oracle_suite.py` binding seven security routes to 33 branch-specific clauses over live HTTP (SEC-R3-07).

Builder-reported, unverified: barriers **6/6 against R4, 0/6 against pinned R3**; oracle **7/7 (33 clauses) vs 5/7 against R3**; self-test **170/170**; witnesses **34/34**; validator **160/160**. Your nine probe scripts ship in the return byte-identical, with their outputs, so this is checkable standalone.

## 2. The one requirement not met as written — please adjudicate first

**Five of your nine probe scripts do not run green, and the Builder argues no correct implementation of the model you authorized could make them.** Fable tested that claim rather than accepting it, by reading your scripts: `http_race_probes.py:24-28` patches `write_capture` and waits on `Barrier(2)` when the step is `review-case` (the probe's own comment: *"barrier in capture after pre-check"*); `http_revoke_race.py:11-16` patches `Transition.prepare` to block until released. Both align two requests at a point **inside** the transition — which a global lock makes mutually exclusive by construction. The barrier times out and both requests fail.

**Fable's ruling: Option 1 — the socket-aligned barriers in `barrier_suite.py` are accepted as equivalent evidence for those five.** Alignment is moved to a point both requests can reach; the properties tested are the ones SEC-R3-01/02 state; and the suite runs **0/6 against the pinned R3 and 6/6 against R4**, so it is demonstrably capable of failing. The alternative — switching capture I/O to release-the-lock-and-re-check — would reintroduce a narrower check-then-act window purely to satisfy an instrumentation artifact, which trades real safety for test shape.

**This is Fable's ruling and yours to confirm; Fable does not declare your acceptance criterion met while your scripts are red.** The Builder states the falsifying condition itself and Fable adopts it: **if you can produce an implementation of the global-lock model under which those five probes go green, the analysis is refuted** and the release-for-I/O option stands available. If you concur instead, please say so explicitly so the record shows the criterion was amended by you, not by us.

## 3. Also worth your attention

- **Three disclosed probe evasions.** The Builder's first attempt routed *around* three of your injection points rather than passing them: a pre-reservation that sailed past the `SECRETS.add` injection; `os.fdopen` on the `mkstemp` descriptor, bypassing the `builtins.open` injection; and a parallel counter that made the quota probe's setup gate nothing. All three were found by running each criterion against the defective build and demanding red — which also caught a criterion of the Builder's that *passed vacuously against the build it was written to fail*. **Please look for a fourth instance.** A build that routes around an injection produces a green probe and a false gate.
- **The deadlock proof is structural, not enforced.** Two locks, a claimed total acquisition order, no outbound I/O. Nothing in the build enforces the order; a future edit adding a third lock lapses the proof silently.
- **Beyond two concurrent requests is not claimed.** The barriers are deterministic two-request tests, per your `31B_` preference. Three-way and n-way interleavings are untested.
- **`os.link` semantics** on the capture path — please confirm the "path that did not previously exist" guarantee holds as implemented, including the failure/cleanup path.

## 4. Fable's rulings on the Builder's other findings, for your check

**AUDIT-R4-1 CONFIRMED:** three of eight entity quotas are subject-scoped, and at dispatch the only subject id available is caller-supplied — enforcing there would let a caller evade its ceiling by naming another subject, violating the governing rule. Global at dispatch, subject-scoped inside the transition against the service-resolved subject. **AUDIT-R4-2 CONFIRMED as real, DEFERRED to `13B_`:** a provider flooding `/poc2/triage` can exhaust the shared `ideas` ceiling the owner needs — the crowd-out A.8's reserved-owner pool prevents on the capture axis. Genuine, but it belongs to the production wrapper; the POC has no hostile provider and the owner is the sole operator of a supervised localhost session. Recorded as a carried-forward `13B_` requirement: every owner-authority ceiling needs a reserve no provider-reachable route can consume. **AUDIT-R4-3 CONFIRMED:** a derived `EXPIRED` conflicts with A.8's "secrets leave the index the moment they become unusable"; the evidence-backed transition was the correct option.

## 5. Scope

Narrowly the concurrency and evidence-ordering posture of the R4 stub, plus §2's adjudication. **Not reopened:** Release-1, the Capability Portfolio work, provider selection, the Decision Engine design, v1.4, the production-wrapper architecture, or the `25_` contract (unchanged this round — no new `Disclose` construction site, so that exemption is untouched and `control_probes` stays green).

**If this closes, the owner's hands-on POC session is next.** It has been blocked since the R1 security review, and this is the gate.
