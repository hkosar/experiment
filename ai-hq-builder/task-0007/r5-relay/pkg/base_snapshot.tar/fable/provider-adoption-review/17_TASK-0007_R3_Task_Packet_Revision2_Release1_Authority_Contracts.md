# 17 — TASK-0007 Round R3: `14_` Revision 2 — Release-1 authority contracts and specification tightenings

**This is the Revision 2 the verifier required** (`15_` §182, §245). It is an **increment on the integrated R2 build**, not a rebuild. R2's security and evidence-integrity core is accepted and stands as the baseline; this round adds the two Release-1 authority contracts `14_` Revision 1 failed to specify, plus seven specification tightenings.

**Status of your R2 return:** structurally accepted and integrated (`16_` §1) — manifest 43/43 byte-identical, harness code 6/6 unchanged, stdlib-only, secret scan showing exactly the two fixtures you disclosed, and both §6 contract tensions ruled in your favour. Two things in it are called out as good practice and are to be preserved: the **witness method** (probes run against the SHA-pinned R1 artifact rather than defect switches) and the **`/relay/deliver` ÷ `/stage/deliver` route split**, which the verifier independently asked for after you had already built it. Your 56/56 and 21/21 remain **Builder-authored self-claims**; they are not disputed and not yet independently confirmed — that single independent review happens after this round (§7).

**Read `16_` and `15_` before starting.** `15_` is the verifier's plan review in full; `16_` is Fable's disposition of it and records which gaps are Fable's own.

## 0. Snapshot binding and authority manifest (R2P-08)

```text
Repository:        hkosar/ai-hq
Branch:            claude/fable-coordinator-handoff-vqpu33
Base commit:       729849c7d90bdff8650f6f2bf392ba92fc69067d
Base tree:         6aeb63f8821898ca8189ef74cedb1da52c36336d
```

The relay zip's `SHA256SUMS.txt` is the hash-bound authority manifest; validate it before reading anything as authority (H-06), as in every prior round.

```text
Task ID:            TASK-0007, round R3
Parent / topic:     TOPIC-0003 — Capability Portfolio Review
Risk class:         consequential (apparatus governs an authorization boundary under test)
Trust class:        provider-facing surface; external-untrusted inbound by default
Data class:         Business partition only; synthetic POC data; no production credential,
                    no real account, no Personal-partition data, no live provider contact
Allowed actions:    modify the allowlisted paths in §5; run local self-tests and the structural harness
Prohibited actions: contacting any provider; creating accounts; OAuth grants; running a POC;
                    implementing any 13B_ production-wrapper obligation; claiming Track B credit;
                    selecting or ranking a provider; removing any THROWAWAY marker;
                    editing harness CODE (outputs excepted per §5)
```

**Files to read as authority, in order:** `17_` (this packet, governing) · `16_` · `15_` + `15A_` · `14_` (Rev 1 contract, still governing where this document is silent) · `13_` · `12_` + `12A_` · `09_` §2 (THE authoritative D3 scenario definition) · `08_` · your own `R2_Builder_Delivery_Record.md`. Where this packet and any earlier document disagree, **this packet governs**; where it is silent, `14_` §2 governs.

## 1. The lesson this round is written to

`16_` §4 names a pattern in Fable's own briefs: **the shape of a control gets specified and its root of trust does not.** `08_` asked for two refusals without asking whether the guarded thing was reachable another way — the `/sink` bypass. `14_` Rev 1 specified a five-component identity tuple without specifying how identity is *established* — R2P-01 and R2P-02. The governing rule for this round, and the thing to push back on if any clause below violates it:

> **Every authority the service asserts must trace to something the service itself established. A value a caller supplied is corroborating material, never an authority.**

## 2. The two Release-1 authority contracts (the substance of this round)

### C-20 — Artifact authenticity and transport (R2P-01)

`09_` §2 defines POC-1 as *receive artifact → bind task/transition identity → **hash and validate***. R2 accepts an artifact digest field but nothing establishes it. **A provider-supplied hash is corroborating material, not artifact identity.** Note the standing tension the verifier names: a JSON-only transport rule cannot test ZIP fidelity unless the bytes travel by a defined channel.

**Choose one mechanism and implement it** — Fable's recommendation is **trusted preregistration** as the smaller change to the accepted boundary, but wrapper ingress is acceptable if you judge it better; state the choice and the reasoning in the Delivery Record:

- **Trusted preregistration** — the AI OS side registers `artifact_id`, source digest, size, task, expected transition and allowed target role **before the provider sees the artifact**; the provider carries only the bound reference plus a later destination digest.
- **Wrapper ingress** — a dedicated artifact endpoint accepts raw bytes or a bounded multipart upload, computes the digest **locally**, rejects malformed and path-traversal cases, and stores only the controlled POC artifact/reference.

Either way: provider-supplied hashes are never authoritative alone; source and relayed-object digests are compared; the same bytes under different task IDs remain distinct submissions; and size, file count, binary fidelity, original-versus-reconstituted delivery and provider retention are recorded as measurements. **The artifact is never placed in Discord** (`09_` §2 R1P-05).

### C-21 — Owner-authored idea authority (R2P-02)

POC-2 requires two distinct envelope cases (`09_` §2 R1P-02): **Case A** authenticated owner-authored idea, and **Case B** imported/forwarded external material with instruction authority NONE. R2 understands only the external-untrusted envelope, so a provider can assert `origin=owner` and manufacture owner authority — the exact failure the POC exists to disprove.

Define a **wrapper-controlled authority path**: either an owner-key-protected `/owner/idea` intake minting an opaque single-purpose idea token, or a pre-registered owner-authored intake record whose reference the provider may carry. External material attached to an owner-authored idea receives **its own separate external-untrusted envelope and no instruction authority**. Changing any provider-supplied `origin`, `trust` or `instruction_authority` field must not increase authority — that is a required test, not an aspiration.

## 3. Specification tightenings (R2P-03..07, R2P-09)

**C-22 — Capability and uncertain-outcome state machine (R2P-03).** Your C-3 replay behaviour is close but is not a specified machine. Define at least `MINTED`, `ATTEMPT_STARTED`, `DELIVERED_WITH_RECEIPT`, `UNCERTAIN`, `RECONCILED_DELIVERED`, `RECONCILED_NOT_DELIVERED`, `REVOKED`/`EXPIRED`. A replay returns a prior receipt **only from a verified delivered state**; `UNCERTAIN` permits reconciliation and never a second side effect; a verified-not-delivered reconciliation may authorize **one** new attempt under the same idempotency identity. Attempt count and delivery count stay separate. Capability binding covers the stable submission identity, ActionRequest, case, target role/endpoint, canonical payload digest, provider/candidate and expiry. **Retry attempt identity is separate from the stable submission epoch** — provider retries must not create new submissions.

**C-23 — Truthful crash semantics for capture-before-commit (R2P-04).** This is your own falsifier row 4 made into a contract. Filesystem capture and in-memory state cannot be one atomic transaction, so the evidence format must distinguish **intent from committed outcome**: either `prepared` + `committed` records linked by transition ID, or one append-only transition record whose status is advanced and whose incomplete state is explicitly reconciled. **Only committed records satisfy an acceptance check; orphaned prepared records are reported as uncertain and never counted as completed.** Applies to owner decisions, token spend, capability spend, delivery, and POC-3 checkpoint/reconcile.

**C-24 — Route policy as a declarative matrix (R2P-05).** This **supersedes `14_` C-11's** global-checks-plus-commented-exemptions approach, which the verifier correctly found ambiguous. Implement a route-policy table **as data**, one entry per route, specifying: caller class · required credential/capability · accepted media type · max body size · allowed top-level and nested fields · partition/trust requirements · decision-field policy · capture-on-success / capture-on-refusal · cache policy · logging label · rate/quota class. **Unknown routes and missing policy entries fail closed.** Exemptions are explicit entries carrying a reason, never comments around a bypass.

**C-25 — Bounded redaction mechanics (R2P-06).** This answers your falsifier row 3 ("the enumeration is mine and could be short"). Searching every substring of a 1 MiB body against token digests is itself a denial-of-service path, and a plain digest of a low-entropy unknown value is not meaningfully non-reversible. Define: maximum recursion depth, string length, list size and field count; which active secret lengths are checked by bounded digest comparison; a **per-process keyed HMAC or salted digest** for unknown values rather than raw SHA-256; and structured redaction markers that cannot be mistaken for PRESENT evidence.

**C-26 — Quota and evidence-exhaustion behaviour (R2P-07).** Bound every in-memory and capture collection — cases, tokens, decisions, attempts, receipts, runs, checkpoints, captures — with defined fail-closed behaviour at capacity. **Reserve or otherwise protect capacity for owner decisions, capability spends and security refusals**, so an unauthenticated caller cannot consume the evidence budget and thereby prevent a security refusal from being recorded. Closes FAB-16 and FAB-17 explicitly rather than by generic reference.

**C-27 — Provider-discriminating measurement coverage (R2P-09).** The workflows and runbooks must expose or record, at minimum: artifact bytes and file count · source and destination digests · original vs reconstructed relay · provider task/step/execution count · owner-attention steps and minutes · approval latency · retry count and uncertain-result reconciliation · capture/receipt completeness · provider retention/deletion observation · failure or unsupported-capability reason. **No provider capability is claimed from authored workflow files alone**; unsupported or untested values stay explicit — the all-NOT-TESTED discipline from R0 continues to apply.

## 4. Required tests (additive to `14_` §3, which stands)

The ten from `15_` §5, all demonstrated failing against the pre-R3 behaviour using your witness method where the behaviour exists in the R2 baseline:

1. Provider changes `origin`, `trust` or `instruction_authority` on an idea payload → authority does not increase.
2. External content embedded in an owner-authored idea stays external-untrusted and cannot become an instruction.
3. Provider supplies a correct artifact digest for **different bytes** → relay fails.
4. Provider supplies altered digest metadata for the **same bytes** → relay fails.
5. Same artifact/reference and task with a new retry attempt → **no new submission** created.
6. First delivery enters `UNCERTAIN`; replay does not execute; reconciliation determines the next legal transition.
7. Prepared-but-uncommitted capture after a simulated crash → **not counted as completed evidence**.
8. Every route is present in the route-policy table; **deleting one policy entry makes the self-test fail closed**.
9. Exhausting ordinary refusal quota does **not** prevent an owner-decision or capability-spend record.
10. Public health output reveals no owner-decision or case activity.

**Preserve the witness method.** Keep `r1_reference/stub_server_r1.py` byte-identical and its run-time SHA pin intact — it is now the program's record of the reviewed R1 behaviour. Where an R3 test needs a pre-R3 baseline that exists only in the R2 build, pin the R2 artifact the same way rather than using a defect switch.

## 5. Allowlist

`poc/stub/**` · `poc/workflows/n8n/*.json` · `poc/workflows/zapier/POC_zap_build_specs.json` · `poc/runbooks/*.md` · `poc/README.md` · `poc/FINDINGS.md` · `poc/data/captures/README.md` · `poc/data/measurements.template.json`.

`harness/**` **code** remains excluded. **`harness/out/**` regeneration is explicitly permitted this round** — `16_` §1 ruled your §6(a) tension in your favour, and re-running the structural harness necessarily rewrites its outputs. Ship the regenerated outputs; do not edit harness code. If a corrected capture shape requires a harness *code* change, stop and report it as a change request.

## 6. Return requirements

Standard Delivery Record with the reflexive falsifier element. Self-test covering §4 plus `14_` §3, with the mandatory cases shown failing first. Diffs for every workflow and runbook change, with the structural harness re-run. One zip; `RETURN_MANIFEST.json` self-verified by re-hashing every entry from the unpacked zip; H-06 on this snapshot before work begins.

**Pre-fix and post-fix evidence (R2P-08):** state the exact commands that reproduce each pre-fix behaviour and each post-fix acceptance result, so a reviewer can re-run them without reconstructing your method.

**Report, do not silently absorb** — the discipline that produced your §6(a) and §6(b) disclosures, R0's fail-closed stop on Fable's packaging error, and `13_` VC-01. If any clause here is internally inconsistent, conflicts with `09_` §2, cannot be satisfied within the allowlist, or violates §1's governing rule, stop and report it. `16_` §4 records that this class of gap has now been Fable's three times running; a fourth is likelier than not, and catching it before you build is worth more than working around it after.

## 7. After R3

R3 return → Fable structural verification → **one independent ChatGPT security review of the final stub** (R2 core + R3 additions) under the trail-127 practice, carrying whatever further probes it directs. Fable assembles and dispositions; Fable does not run the probes. On that closing, the owner's hands-on POC session runs the re-aimed content against an apparatus whose authority model and evidence output have both been independently checked.
