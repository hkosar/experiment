# 23 — Fable Disposition: ChatGPT plan-gate review of R3 / Revision 3

**Input:** `21_` + `21A_` (bundle SHA-256 `984153746ead1fedc593107539186977718dbc5f01ff04e7ad2a1619bd54a85b`, matching the verifier's stated fingerprint; both files integrated byte-identical after hash comparison). The verifier reviewed the `TASK-0007_R3_Revision3_Packet.zip` at `b865683c…d1f678`, matching the trail-132 relay fingerprint.

**Verdict: FAIL on the R3 Task Packet gate — CONCURRED IN FULL on all nine findings, without reservation.**

Revision 3 fixed what Revision 2 got wrong (it selected mechanisms instead of delegating them). The verifier's finding is that **several of the mechanisms Revision 3 selected were themselves unsound.** That is a fair and accurate reading. Revision 4 (`22_`) corrects them.

## 1. One finding Fable reproduced directly, and its root cause

`R3Q-01` is the one item verifiable without judgement, so Fable ran it rather than accepting it on trust. **The verifier is exactly right:** `git clone base.gitbundle` fails with `Could not read ffd5cc6ce6626f18de73f671c362806b4a168afe`.

**Root cause, found by Fable:** this working repository is a **shallow clone**. `.git/shallow` grafts history at `18c571b`, and that commit's real parent `ffd5cc6c` does not exist locally at all (`git cat-file -t` fails; `git rev-parse --is-shallow-repository` returns `true`). A bundle built here necessarily references an object the environment does not have.

The consequence matters for the correction: **the verifier's option 1 — "a complete bundle that freshly clones and passes `git fsck --full`" — is not merely unmet, it is impossible from this environment.** Fable tested the alternatives rather than assuming: a `--depth` bundle is unsupported by this git (2.43.0, `unrecognized argument`), and a range bundle from the graft point declares prerequisites and cannot clone standalone.

So `22_` C-28 selects **option 2, the truthful snapshot-only artifact**: `base_snapshot.tar` (a `git archive` of the tree), no bundle, no clone instruction, and a verification contract limited to what it can actually deliver — the **tree hash**, independently reproducible by `tar -x` → `git init` → `git add -Af` → `git write-tree`. **Fable executed that recipe and confirmed it reproduces the declared tree hash exactly** before writing it into the packet. The commit hash is declared and explicitly marked *not* independently verifiable from the export; ancestry is available only from the live repository.

That last point is the honest lesson: Revision 3 **claimed a verification contract it could not satisfy**, which is the program's own integrity-versus-authority error (R3P-02) committed against provenance. The corrective is not a better bundle — it is claiming only what the artifact proves.

## 2. Two findings where Revision 3 violated the packet's own governing rule

The rule `20_` §1 states — *every authority the service asserts must trace to something the service itself established; a caller-supplied value is corroborating material, never an authority* — was violated twice **inside the packet that stated it**:

- **R3Q-02:** `fidelity_ok` was computed from a provider-supplied `destination_digest`. The service never receives the destination bytes, so that value proves nothing about them. `22_` §1 removes `fidelity_ok`, records the provider value as explicitly non-authoritative, and states plainly that end-to-end binary fidelity is **not established by this apparatus**. Two of the ten adopted tests are consequently **withdrawn as unsatisfiable** and replaced with a test that the provider value never gates delivery — declaring the gap rather than letting a green field imply a check that never happened.
- **R3Q-03:** `UNCERTAIN → RECONCILED_NOT_DELIVERED` on absence of a local receipt, then a permitted retry. Absence of a local record is not proof no external action occurred; that path could authorize a duplicate real-world action — the exact failure POC-1 exists to disprove. `22_` C-30 requires **positive negative evidence** (a durable ledger-plus-capture-log check the service controls, or an owner attestation via a new `/owner/reconcile`), and otherwise **stays `UNCERTAIN` and fails closed**. An unresolved outcome is acceptable; a wrong resolved-negative is not.

Stating a rule and then breaking it twice in the same document is worth recording plainly: the rule was applied to the Builder's future code and not to Fable's own contract.

## 3. Disposition of all nine findings

| ID | Disposition | Correction in `22_` |
| --- | --- | --- |
| **R3Q-01** git snapshot not self-contained | **CONCUR** (reproduced; root cause = shallow clone) | C-28: snapshot-only `base_snapshot.tar`, no clone claim, tree-hash recipe **tested** |
| **R3Q-02** fidelity is provider self-attestation | **CONCUR** | §1: `fidelity_ok` removed; provider digest non-authoritative; fidelity declared NOT ESTABLISHED; two tests withdrawn; `target_role` added to registration identity |
| **R3Q-03** reconciliation can authorize a duplicate | **CONCUR** | C-30: positive-evidence requirement; otherwise stay `UNCERTAIN`, fail closed |
| **R3Q-04** transitions/route policy not instantiated | **CONCUR** | C-31: real `/poc1/reconcile`, `/owner/reconcile`, `/owner/revoke`; §4 table with cache, log label, and the two placeholder schemas made exact |
| **R3Q-05** split authority not representable | **CONCUR** | §2: exact `owner_content` / `external_items[]` schema, per-item envelopes, per-component authority in the capture |
| **R3Q-06** two-phase can leave uncommitted authority | **CONCUR** | C-32: provisional-until-committed, rollback or explicit non-authoritative uncertain; fault injection at all six write boundaries |
| **R3Q-07** reserve and secret guarantees false | **CONCUR** | C-33: three disjoint pools, owner reserve provider-unreachable, exact exhaustion behaviour; C-34: `MAX_ACTIVE_SECRETS` as a ceiling on live secrets with a tested coverage invariant |
| **R3Q-08** measurement validation incomplete | **CONCUR** | §6: exact per-status contract and full (candidate × POC × measure) matrix enumeration |
| **R3Q-09** Builder assigned manifest ownership | **CONCUR** | C-29: withdrawn; Builder proposes, **Fable publishes**, ChatGPT verifies; manifest added to the immutable denylist |

Prior-finding status is accepted as scored (`R3P-02` substantially closed, `R3P-08` closed, `R3P-06` open, the rest partial). `21A_`'s `full_harness_self_contained: false` is recorded as an environment limitation of the review sandbox, not a defect to fix this round; `22_` §8 says so explicitly.

## 4. One observation returned to the verifier

`SHA256SUMS_TASK0007_R3_REV3_PLAN_REVIEW.txt` lists **absolute sandbox paths** (`/mnt/data/...`), so `sha256sum -c` fails on any other machine until the paths are stripped. Integrity was confirmed by comparing hashes per basename (both files match). Minor and non-blocking — noted only because relay integrity is checked in both directions, and the same convention this program applies to its own outbound packets should apply to inbound ones.

## 5. Standing pattern, and what is different this time

Four consecutive packet revisions have each been corrected by review: Rev 1 (incomplete contracts), Rev 2 (delegated architecture), Rev 3 (unsound selected mechanisms), now Rev 4. The trajectory is real — each round the findings are narrower and more specific — but the honest reading is that Fable has been shipping packets that had not been checked against their own stated rule. `22_` was written differently in two respects: the one verifiable claim in it (the tree-hash recipe) was **executed before being written down**, and every clause was re-read against the governing rule with two violations found and removed. Whether that is enough is the verifier's call, which is why the serial relay order stands.

## 6. Sequencing

`22_` (Revision 4) goes to **ChatGPT first** for the narrow Revision-4 confirmation; **Builder release stays held** until it returns. Serial order has now prevented three separate releases against a failing contract, which is its whole purpose. On confirmation: Builder implements R3 against the integrated R2 baseline → Fable structural verification → the single independent security review of the final R2+R3 stub → owner POC session. Nothing accepted reopens: Release-1, the Capability Portfolio work, the Decision Engine baseline, v1.4, and the R1/R2 security dispositions all stand.
