# 34 — Fable Disposition: TASK-0007 R4 concurrency-rework return

**Input:** `TASK0007_R4_Builder_Return.zip`, SHA-256 `9b2a047d5fa63d26dccff8e8bc96fb09d43086d653510cb5d9f96151c2c8448e`.

## 1. Structural verification (static only, per the trail-127 practice)

| Check | Result |
| --- | --- |
| Manifest re-hashed entry by entry | 71 entries — **69 match, 0 missing, 2 differ** (the known `out/**` non-determinism, §1.1) |
| Files under `poc/` undeclared | **0** |
| Immutable denylist | **8/8 byte-identical** — all six harness code files, `r1_reference`, `r2_reference` |
| `r3_reference/stub_server_r3.py` | `7f13494e…5b90f572` — **exactly the target the security review examined** |
| Reviewer's 9 probe **scripts** in the return vs the originals | **9/9 byte-identical** |
| Stdlib-only across stub + three new test modules | **confirmed** |
| Secret-shaped scan | **clean** |
| `barrier_suite.py` runs against both builds | **confirmed** — documented and parameterised on the pinned R3 |

**Adversarial verification NOT performed by Fable:** no server started, no suite run, no probe executed. The Builder's 170/170, 34/34, 6/6 barriers, 7/7 oracle and 160/160 validator are **Builder-authored self-claims**, undisputed and independently unconfirmed here.

### 1.1 One check worth recording, because it nearly went the other way

The nine probe **result** JSONs in the return are **byte-identical to the reviewer's original failing results**, including their random identifiers. Fable's first reading of that was that the Builder had shipped the FAIL results as if they were a passing run. **That reading was wrong**, and the return says so plainly before being asked: `stub/security_probes/README.md` states the nine scripts and nine outputs are *"the reviewer's own, copied byte-identically… evidence-only inputs… not Builder-authored"*, shipped so the green claim is checkable standalone. The Builder's post-fix results live in `out/selftest.json`, `barrier_suite`, `oracle_suite` and `probe_runner` output, not in those files. Recorded because the disclosure is what resolved it — an undisclosed copy of a reviewer's failing evidence into a return would be indistinguishable from the real thing at a glance.

The two manifest differences are the same benign `out/**` non-determinism ruled at trail 139 (identical byte length; embedded run-specific ids). **Process slip, not a defect**, unchanged.

## 2. AUDIT-R4-5 — the ruling this round turns on

**The Builder reports it has not met one acceptance requirement as written, and argues no correct implementation could.** `33_` §4 required the reviewer's nine probe scripts to run green; five do not. The claim: those five align two requests at a point **inside** the transition, so under the global-lock model `33_` §1 *selected*, the second request cannot arrive, the barrier times out, and both requests fail.

**Fable tested the claim rather than accepting it** — the Builder's own falsifier row 5 correctly flags this as the finding most convenient to itself. Reading the reviewer's scripts directly:

- `http_race_probes.py:24-28` monkeypatches `S.write_capture` and calls `bar.wait(timeout=5)` when the step is `review-case`. The probe's own comment: *"barrier in capture after pre-check."*
- `http_revoke_race.py:11-16` monkeypatches `S.Transition.prepare` to block until released — again inside the transition.

**The claim is structurally correct.** A barrier placed inside `write_capture`/`Transition.prepare` requires two requests to be inside one transition simultaneously. That is precisely the condition linearization removes. The probes' *instrumentation method* presumes the defect they were written to detect.

**RULING: Option 1 — the socket-aligned barriers are accepted as equivalent evidence for those five probes.** Reasons: (a) Option 2 would deliberately reintroduce a check-then-act window — release the lock for I/O, re-check on re-acquire — purely so an instrumentation artifact can be satisfied, trading real safety for test-shaped convenience, which is backwards; (b) the underlying properties are demonstrated either way, and demonstrated *in both directions* — `barrier_suite` goes **0/6 against the pinned R3 and 6/6 against R4**, with the one-winner/one-truthful-loser cardinality SEC-R3-01 actually specifies; (c) the reviewer's own `31B_` states the deterministic barrier is the controlling evidence — the barrier, not the particular patch point.

**This ruling is Fable's to make and the reviewer's to confirm.** Fable does not declare its own acceptance suite satisfied when the reviewer's scripts are red. AUDIT-R4-5 is the **first item** for the scheduled concurrency re-verification; if the reviewer produces an implementation of the selected model under which those probes go green, the Builder's analysis is refuted and Option 2 stands available. That falsifying condition is the Builder's own, and Fable adopts it as the test.

## 3. The other three audit findings

**AUDIT-R4-1 — CONFIRMED (global/subject quota split).** Three of eight entity quotas are subject-scoped, and at dispatch the only subject identifier available is the **caller-supplied** one — for `/relay/deliver` the authoritative action-request id comes from the capability binding, not the caller's claim. Enforcing those at dispatch would rest a ceiling on a caller-supplied value and let a caller evade its own ceiling by naming another subject: a direct violation of `25_`'s governing rule. The Builder's split — global quotas at dispatch, subject-scoped inside the transition against the **service-resolved** subject, both reserving atomically and releasing on failure — is correct and is what SEC-R3-06's own correction bullet requires. No contract change.

**AUDIT-R4-2 — CONFIRMED as a real finding; DEFERRED, not dismissed.** A provider flooding `/poc2/triage` can exhaust the shared `ideas` ceiling the **owner** needs to register an idea — the same crowd-out shape A.8's reserved-owner pool already prevents on the capture axis. The Builder flagged rather than fixed it because it is contract-shaped; that was the right call. **Ruling:** genuine, and it belongs to the **real wrapper** (`13B_`), not to throwaway apparatus. In the POC's threat model there is no hostile provider — the owner is the sole operator of a supervised localhost session, the ceiling is 5,000, and no provider has any incentive to flood. Fixing it here would cost another build round for a risk that is nil in this context while the finding's actual value is to the production build. **Recorded as a carried-forward requirement for `13B_`: every owner-authority ceiling needs a reserve a provider-reachable route cannot consume — the A.8 pattern generalised beyond captures.**

**AUDIT-R4-3 — CONFIRMED.** A derived `EXPIRED` conflicts with A.8's *"secrets leave the index the moment they become unusable"*, since a derived state has no moment of observation and its secret would linger until a sweeper removed it — and a sweeper is itself an unrecorded mutation. `33_` §2 offered both options and required the Builder to state which; it took the evidence-backed transition and explained why. Correct.

## 4. What this round did that the previous four did not

Recorded because it is the first structural break in a four-round pattern. The Builder's §1: *"That is the third round in which my own verification, not my implementation, was the thing that was wrong… I test the layer I was last burned at, rather than the layer the defect could live in."* Its response was to run **every criterion against the pinned defective build first and demand red** — and that check caught a criterion of its own that *"passed vacuously against the build it was written to fail."* It also disclosed three places where its first attempt **evaded a probe rather than passing it**: a pre-reservation that sailed past the probe's `SECRETS.add` injection; an `os.fdopen` that routed around the probe's `builtins.open` injection; and a parallel counter that made the quota probe's setup gate nothing.

That last set is the important one. A build that quietly routes around an injection point produces a green probe and a false gate — the exact failure family this program has hit at R1, R2 and R3. **Fable adopts "run every acceptance criterion against the defective build and require red" as a standing rule for the production wrapper's build**, superseding the outcome-coverage guard adopted at trail 139 and correctly downgraded at trail 141. A test that cannot fail is not evidence, and running it against the known-bad build is the cheapest way to find out.

## 5. Disposition and sequencing

**R4 is STRUCTURALLY ACCEPTED and INTEGRATED** as the new `poc/` baseline (24 added, 4 modified). Allowlist additions accepted: `stub/r3_reference/` (`33_` §5 permits it explicitly), `stub/security_probes/` (the reviewer's own scripts and outputs, byte-identical, making the return checkable standalone), and the three new test modules `probe_runner.py`, `barrier_suite.py`, `oracle_suite.py` (covered by §5's "and its tests"). **Security posture NOT independently verified.**

**Next: ChatGPT concurrency re-verification**, as `31_` §5 and `33_` §6 both schedule. Fable's requested order: (1) **AUDIT-R4-5** — adjudicate the barrier-placement argument, since it decides whether this round is acceptable as built; the falsifying condition is stated and Fable adopts it; (2) the three probe-evasion instances in §4 and whether a fourth exists; (3) whether the global lock is genuinely deadlock-free, since the Builder's proof is structural and unenforced — a future edit adding a third lock lapses it silently; (4) behaviour beyond two concurrent requests, which the Builder explicitly does not claim.

Owner POC session remains **BLOCKED** pending that re-verification. Nothing accepted reopens.
