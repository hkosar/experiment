# 18 — ChatGPT Scoped Confirmation: TASK-0007 R3 / Revision 2 Plan

**Review type:** narrow Task Packet confirmation before Builder release  
**Input packet:** `TASK0007_R3_Revision2_Packet.zip`  
**Input packet SHA-256:** `40f4bd55220e21f61191b95b0e93bb7b75c00bf8296b5b82efcee080ba500102`  
**Primary review targets:** `16_Fable_Disposition_TASK-0007_R2_Build_and_Plan_Review.md` and `17_TASK-0007_R3_Task_Packet_Revision2_Release1_Authority_Contracts.md`

## 1. Verdict

**FAIL — do not release the current R3 Task Packet to the Builder.**

Revision 2 correctly identifies the nine prior plan findings and materially improves the direction of the packet. It does not yet close the two authority-root gaps or several related execution contracts. The central problem is that the packet repeatedly instructs the Builder to **choose or define** security and evidence architecture that belongs to Fable's Architect role.

This is a bounded plan correction. It does not reopen the Release-1 product decision, provider shortlist, Capability Portfolio Review, Decision Engine baseline, or accepted R1/R2 security dispositions.

## 2. Independent packet and baseline verification

```text
Uploaded ZIP SHA-256
40f4bd55220e21f61191b95b0e93bb7b75c00bf8296b5b82efcee080ba500102

SHA256SUMS entries
55 / 55 passed

Archive
Opened successfully

R2 stub self-test
56 / 56 passed

Pinned R1 witness suite
21 / 21 reproduced

Current R2 route registry
14 routes
```

The supplied R2 baseline reproduces its Builder-authored evidence as reported. This does not constitute the independent final security review that the packet correctly schedules after R3.

The packet declares base commit `729849c7d90bdff8650f6f2bf392ba92fc69067d` and tree `6aeb63f8821898ca8189ef74cedb1da52c36336d`, but it contains no Git bundle, commit object, or equivalent proof binding that commit to that tree. The file-integrity snapshot is valid; the Git provenance declaration is not independently reproducible from this export.

## 3. Disposition of R2P-01 through R2P-09

| Prior finding | Scoped result | Reason |
| --- | --- | --- |
| **R2P-01 — artifact authenticity and transport** | **Open** | The packet tells the Builder to choose trusted preregistration or wrapper ingress. The Architect must select the authority mechanism and define its records, authorized caller, transitions, and evidence. |
| **R2P-02 — owner-authored idea authority** | **Open** | The packet again offers two mechanisms rather than selecting one. The owner-authority root cannot be a Builder design choice. |
| **R2P-03 — execution capability / uncertain outcome** | **Partially closed** | The required states and several invariants are listed, but the allowed transition table, transition authority, reconciliation authority, terminal behavior, and persisted evidence are left for the Builder to define. |
| **R2P-04 — truthful crash semantics** | **Open** | The packet offers two incompatible evidence models and asks the Builder to choose. It does not define which record is authoritative or how recovery reconstructs truth. |
| **R2P-05 — declarative route policy** | **Open** | The packet provides the column headings but no actual per-route policy table. The current baseline has fourteen routes; their caller, credential, schema, capture, logging, cache, and quota rules remain unstated. |
| **R2P-06 — bounded redaction mechanics** | **Open** | No numerical limits, key lifecycle, canonical HMAC input, marker schema, or failure behavior is selected. `keyed HMAC or salted digest` leaves a security-relevant choice to implementation. |
| **R2P-07 — quota / evidence exhaustion** | **Open** | Every collection is named, but no quota, protected reserve, exhaustion precedence, eviction prohibition, or restart behavior is specified. |
| **R2P-08 — snapshot-bound authority packet** | **Open** | The checksum list proves integrity but is mislabeled as an authority manifest; it does not classify normative authority versus evidence. The Builder Delivery Record is incorrectly listed as authority. Commit/tree binding and a control-artifact allowlist are absent. |
| **R2P-09 — provider-discriminating measures** | **Directionally closed** | The required measures are enumerated and correctly remain NOT TESTED until the POC. Revision 3 must bind them to an exact schema and a completeness validator. |

## 4. New findings

### R3P-01 — High: Authority architecture is delegated to the Builder

The Task Packet says:

```text
Choose one mechanism and implement it
```

for artifact authenticity, and presents another either/or for owner-authored idea authority. It also asks the Builder to `define` the capability machine and select one of two crash-evidence models.

These are not mechanical implementation choices. They determine the root of trust, authoritative record shape, legal transitions, and recovery semantics. Fable must select and specify them before Builder release.

**Required correction:** Fable publishes one selected mechanism and one normative contract for each:

1. Artifact authority
2. Owner-idea authority
3. Capability transitions
4. Capture/commit evidence

The Builder may choose internal code structure only within those contracts.

### R3P-02 — High: Integrity is being confused with instruction authority

`SHA256SUMS.txt` is a valid integrity manifest. It does not determine whether a file is normative instruction, owner decision, verifier finding, Builder disclosure, historical evidence, or non-authoritative context.

The Task Packet's authority list includes `R2_Builder_Delivery_Record.md`. A Builder-authored completion claim is evidence and context; it cannot become instruction authority merely because it is hashed.

**Required correction:** add a machine-readable authority manifest with, at minimum:

```text
path
sha256
origin
trust_class
instruction_authority
artifact_role
supersedes / superseded_by
required_for_task
```

Classify the Builder Delivery Record and Return Manifest as evidence-only. Keep `17_` as governing instruction, with the prior Fable and verifier documents classified according to their actual roles.

### R3P-03 — High: The route-policy contract is not instantiated

The current R2 stub exposes fourteen registered routes. Revision 2 lists the required route-policy fields but supplies no row for any route. This leaves the Builder to decide which caller can reach each route, which credentials apply, what fields are legal, what gets captured, and which quota pool is consumed.

**Required correction:** the Task Packet must contain the actual route-policy table for every retained and newly added route. Any route added during implementation must require a Fable-approved change request before it can be registered.

The table must include the new artifact and owner-idea routes selected under R3P-01.

### R3P-04 — High: Capability and evidence state remain under-specified

The named state set is useful, but it is not yet a state machine. The Task Packet does not state:

- Which transitions are legal
- Which actor may request or commit each transition
- Whether `REVOKED` and `EXPIRED` are terminal
- Whether a late provider receipt can alter a revoked or expired capability
- What evidence authorizes `RECONCILED_DELIVERED` or `RECONCILED_NOT_DELIVERED`
- How attempt IDs, stable submission IDs, and delivery receipts relate
- Which persisted records reconstruct state after restart

The crash-evidence clause similarly offers two models without selecting one.

**Required correction:** provide an exact transition matrix and one selected append-only evidence model, including restart reconstruction and invalid-transition tests.

### R3P-05 — Medium: Redaction and quota controls have no checkable bounds

The plan requires bounded behavior but supplies no values or formulas. The Builder would have to invent the limits and protected-capacity policy, making later tests validate the Builder's own policy rather than Fable's accepted design.

**Required correction:** define POC-specific limits and behavior for:

```text
body bytes
recursion depth
object fields
list items
string bytes
active secrets checked
cases / ideas / tokens / decisions / attempts / receipts
runs / checkpoints / captures
protected evidence reserves
behavior at each exhausted pool
```

Define the HMAC algorithm, key source/lifetime, canonical input, output encoding, and structured marker schema. Unknown-field evidence must not permit low-entropy recovery or cross-run correlation unless explicitly intended.

### R3P-06 — Medium: Snapshot and allowlist controls are incomplete

The packet gives a base commit and tree but does not carry evidence that independently binds them. It also has one broad implementation allowlist and no separate control-artifact allowlist.

`poc/stub/**` includes `poc/stub/r1_reference/stub_server_r1.py`, while the packet separately requires that file to remain byte-identical. The broad allowlist therefore technically permits modification of an artifact the packet says is immutable.

**Required correction:**

- Include a Git bundle or exact base projection plus independently reproducible commit/tree binding.
- Separate implementation and control/evidence allowlists.
- Add an explicit immutable denylist, including the pinned R1 reference and prior verifier records.
- Define how regenerated `harness/out/**` evidence is classified and returned without granting the Builder authority to edit harness code.

### R3P-07 — Medium: Measurement coverage is described but not acceptance-bound

C-27 lists the correct measurement family. The current measurement template does not yet contain several of those fields, including artifact bytes/file count, source/destination digests, original-versus-reconstituted relay, retention/deletion observations, and explicit unsupported-capability reasons.

**Required correction:** attach the exact revised schema or a complete field-level amendment and a validator that fails when any required provider/candidate/POC measure is missing a status, evidence reference, or explicit `NOT TESTED / UNSUPPORTED` result.

### R3P-08 — Medium: Baseline-status wording is internally inconsistent

Revision 2 says the R2 security and evidence-integrity core is `accepted and stands as the baseline`, while the same packet correctly says its security posture has not been independently verified.

**Required correction:** use one precise status throughout:

> R2 is structurally integrated as the implementation baseline. Its security claims remain Builder-authored and unaccepted until the final independent review of the R2+R3 stub.

## 5. Required Revision 3 contents

Fable should issue one narrowly corrected packet containing:

1. **Selected artifact mechanism:** recommend trusted preregistration for this POC, with exact record fields, authorized registration actor, immutable source digest, expected transition, allowed target role, and destination-digest verification.
2. **Selected owner-idea mechanism:** recommend owner-key-protected `/owner/idea`, minting a single-purpose opaque reference; external attachments remain separately enveloped and untrusted.
3. **Exact capability transition table** and reconciliation authority.
4. **One selected append-only evidence model** with prepared/committed/uncertain/reconciled semantics.
5. **Actual route-policy rows** for every route.
6. **Exact redaction bounds, HMAC contract, quotas, reserves, and exhaustion behavior.**
7. **Authority manifest, Git binding evidence, implementation/control allowlists, and immutable denylist.**
8. **Exact measurement schema amendment and validator.**
9. The ten adopted negative tests plus tests proving each transition, route-policy row, capacity boundary, and immutable artifact constraint.

No broader provider review or Release-1 redefinition is required.

## 6. Gate state

```text
Release-1 App-Building Platform ruling:    VALID
Capability Portfolio D1-D2 work:           VALID
Fable security dispositions:               ACCEPTED
Integrated R2 implementation baseline:     STRUCTURALLY VALID
R2 independent security acceptance:        NOT YET PERFORMED
R3 / Revision 2 direction:                 CONCUR
R3 Task Packet gate:                       FAIL
Builder release:                           BLOCKED
Owner POC session:                         BLOCKED
Provider selection:                        NOT MADE
Decision Engine / v1.4 baseline:           NOT REOPENED
Next actor:                                FABLE
Next artifact:                             TASK-0007 R3 Task Packet Revision 3
```

A narrow verifier confirmation remains required because the corrected packet will finally select the two authority roots and instantiate the route, state, evidence, and quota contracts. After that confirmation, the Builder may implement R3; the final combined R2+R3 stub then receives the single independent security review already planned.
