# Fable Coordinator Handoff #2 — read this first

**Why this file exists:** this is a planned session transition, not a violation-driven one (contrast the original `FABLE_COORDINATOR_HANDOFF.md`, which was — read that file too, once, for full program history; it remains accurate through trail entry 91). The owner (Hunter Kosar) reported a flag on the prior session's security-adjacent verification activity and asked for a fresh Fable session plus a new standing practice for that category of work going forward. Nothing about the accepted program state changed; this document exists purely for continuity.

**How to use this file:** read it in full. Then read `phase1-audit-v1.0/06_Decision_Trail_Addendum.md` entries 113 through 127 at minimum (the whole file if time allows — it is the authoritative event-by-event record of this entire program, and the original handoff document covers everything before that).

---

## 1. The standing governance model (unchanged from the original handoff)

Four fixed roles: **Fable** (you) — architect, designer, project manager, stage-gate approver; you author plans, designs, dispositions, and decision-trail records, and you do **not** write executable code or build mechanics — that is Builder's job under a Task Packet. **ChatGPT** — independent verifier; nothing advances without its review. **Claude Opus 5** — Builder; acts only under an issued Task Packet. **Hunter** — owner, final authority; batches decisions, trusts your judgment on when to stop and ask.

**Gate rule (unchanged):** verifier review → your dispositions → owner acceptance of owner-level decisions.

## 2. NEW addendum — security-verification escalation practice (trail 127)

Added 2026-08-03, scope limited to security-adjacent verification (the owner's stated scope — this is a working practice, not yet a Manual amendment):

When a verification step would require **you** to actively execute adversarial/exploit-style probes against a security or authorization boundary — forging credentials, attempting bypass, simulating exploitation — even fully authorized, even against the program's own throwaway test targets:

1. **Disclose plainly** what (if anything) you already did in that category and the outcome, in the trail — never omit or reframe.
2. **Package it as an independent-review request to ChatGPT** instead of running the live probes yourself: the artifact, the claimed security properties, any evidence already produced (by you or the Builder), and an explicit ask for ChatGPT's own assessment plus any further attack vectors it wants tested (it has no execution sandbox — it directs, the Builder or you execute, results go back to it).
3. **Your role narrows** to packet assembly and PM-level disposition of what ChatGPT returns — same shape as every other verifier finding.
4. This triggers when the owner flags a step (for any reason, including pure caution — proof of an actual problem is not required to invoke it).
5. Whether this becomes a *permanent* default for all adversarial verification, not just as-flagged, is an **open owner decision** — do not assume it broader than stated here without the owner saying so.

The first instance of this practice: `provider-adoption-review/11_ChatGPT_Independent_Security_Review_Request_TASK-0007_R1_Stub.md`, issued trail 127, response pending as of this handoff.

## 3. Program history since the original handoff (compressed; trail 92–127)

- **TASK-0003** (behavioral simulator) ran five rework cycles to a clean accept (trail 98).
- **TASK-0004** (P2T corrections) ran one round plus a closure micro-round to a clean accept (trail 101).
- **TASK-0005** (P2U→P2Y corrections) ran the longest arc: R0 sequencing deviation → R1 through R5, nine verifier packets total, with a genuine **loop-productivity crisis** at packet seven — the owner directed *"I only want the loops to continue if the feedback is meaningful and on task"* (trail 109), Fable issued a scope ruling, the verifier contested it once, and the **owner arbitrated a split** (design-portion blocking, build-portion deferred to a new register) that held to the end (trail 110–111). The **final verdict FAILED on exactly one narrow item** (trail 112), R5 closed it, and — the payoff — **the Decision Engine design gate PASSED** (`51_`, trail 114): zero open findings, the machine validator green for the first time.
- **Owner design acceptance** (trail 116): five items decided — floors confirmed; the DE-R8 autonomy hard-ceiling set to **5,000/day** (the owner's own number, after Fable explained the compounding-growth math) with expansion armed at go-live; a real-data privacy test authorized in principle; conversational card style; **design ACCEPTED**. Build change plan issued (`52_`); **TASK-0006** allocated (v1.4 baseline integration).
- **TASK-0006** ran R0 (honest partial — three of four items landed, the fourth correctly stopped fail-closed on a Fable packaging error, not a Builder defect) then a clean C1 closure (trail 121, 123). **v1.4 is built and verified complete; the owner's one-line acceptance is still outstanding** — this is a standing open item, not urgent, revisit it.
- **TOPIC-0003 / Capability Portfolio Review** (the "don't rebuild Zapier" workstream, owner-initiated from an external verifier handoff, trail 117): sequencing ruling, discovery plan verifier-audited to PASS with three recommendations adopted (ownership matrix, per-axis scoring, retitle — trail 118), owner-approved (trail 119), D1–D2 capability inventory + shortlist executed and verifier-passed (trail 120). **TASK-0007** allocated for the proof-of-capability round (Zapier vs n8n).
- **TASK-0007 R0**: the Builder correctly delivered a complete, self-tested test apparatus with every measurement honestly marked NOT TESTED (no account, no OAuth grant is possible without the owner) — accepted (trail 122). One genuine finding worth carrying forward: of 16 fields a valid evidence receipt needs, a provider can only ever supply 4 — the AI OS wrapper mints the other 12, regardless of which platform is adopted.
- **Owner release-definition ruling** (trail 124) — significant, do not lose this: *"Release 1 needs to be the app-building management platform"* — not the TNBS business-operations workloads (calls, email ops) that had been leaking into the test scenarios. Release 1 = the artifact-relay/stage-tracking/idea-capture/remote-ops platform this program's own manual process already resembles; Release 2 = business operations, parked with its design notes (including a fork-level decision-learning idea the owner and Fable worked through together — filed, not built). POC-1/POC-2 test scenarios were re-aimed accordingly (`09_`), verifier-corrected with five required fixes — all applied same-day (trail 125): one authoritative scenario definition, two owner-idea trust-envelope cases, a real idempotency-identity spec with five required tests, Release-1-based cost variables, artifact-handling measures.
- **TASK-0007 R1** (the wrapper stub the test workflows call) returned, was structurally accepted, and its security properties were the subject of the escalation practice this handoff exists to establish (trail 126–127; see §2 above).

## 4. Immediate state (as of this handoff)

```text
Accepted v1.3 baseline:                UNCHANGED
Decision Engine design gate:           PASSED (trail 114); owner-ACCEPTED (trail 116)
v1.4 build:                            COMPLETE, verified; owner one-line acceptance OUTSTANDING
TASK-0006:                             CLOSED
TOPIC-0003 Capability Portfolio Review: OPEN — Release 1 = App-Building Management Platform (trail 124)
TASK-0007:                             OPEN — R0 apparatus ACCEPTED; R1 (wrapper stub) structurally ACCEPTED;
                                        independent ChatGPT security review of R1 REQUESTED, response PENDING
TASK-0007 R2 (scenario re-aim build):  BLOCKED on the R1 security-review response
Provider selection:                    NOT MADE
Owner hands-on POC session:            NOT YET SCHEDULED — sequenced after R1 fully closes + R2 completes
Next actor:                            Fable (await ChatGPT's response on 11_)
Owner action required right now:       relay 11_'s packet to ChatGPT if not already done;
                                        the v1.4 one-line acceptance whenever convenient
```

## 5. Immediate next actions for this session

1. Confirm whether the owner has already relayed `provider-adoption-review/11_...` to ChatGPT; if not, that is the standing ask.
2. When ChatGPT's response lands, disposition it exactly as any other verifier finding (concur/contest, record, integrate any required fix via a Builder round if one is needed).
3. On that closing, issue TASK-0007 R2 (the scenario-specific workflow rewrite to the `09_` §2 definitions) — packet `07_` already carries the addendum pointing to it.
4. After R2 verifies: the owner's hands-on POC session (runbooks already exist in `poc/runbooks/`).
5. Standing, not urgent: the v1.4 owner-acceptance one-liner remains open — mention it opportunistically, don't chase it.

## 6. Standing conventions (do not relearn these)

One-zip transport for every relay, in either direction (a hard-won owner preference from early in the program). Trail-entry-per-event discipline with immediate commit + push. Checksum regeneration for every touched directory before every commit. Never write raw API model-ID strings (e.g. `claude-fable-5`, `claude-opus-5`) into commits or pushed artifacts — chat replies only. Commit trailer: `Co-Authored-By: Claude Fable 5 <noreply@anthropic.com>` + the `Claude-Session:` line. Verification discipline: reproduce the Builder's claims yourself before accepting, on a **copy** never inside the extracted return tree (a determinism-testing lesson paid for twice this program). Owner preferences on record: thoroughness over speed; batch questions; layman explanations for owner-facing decisions.
