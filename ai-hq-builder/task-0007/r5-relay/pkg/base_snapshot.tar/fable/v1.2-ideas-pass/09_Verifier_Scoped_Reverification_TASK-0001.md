# ChatGPT Independent Verifier — TASK-0001 Scoped Re-Verification

**Packet reviewed:** `AI_OS_TASK0001_Scoped_Reverification_Packet.zip`  
**Packet SHA-256:** `a9ee8dc5c967a6ea8a44ace834bcc21fecb804aa2692714003212876d9f8cd96`  
**Candidate named by packet:** `ffd5cc6`, tree `62cab8cd319a78b0298168d6ff17c2e545791031`  
**Review scope:** Prior findings I-01 through I-05; candidate/control boundary; authority-envelope addendum; finalization model; dual allowlists; line-ending and whitespace evidence.  
**Role:** Independent verifier. Fable remains architect/project manager/integration owner; Opus 4.8 remains Builder; Hunter remains owner/final authority.

# 1. Verdict

```text
TASK-0001 SCOPED RE-VERIFICATION

Underlying semantic v1.2 content:     PASS (unchanged from prior review)
I-01 candidate/control separation:    SUBSTANTIALLY FIXED
I-02 conformance addendum:             FIXED WITH ONE RECORD CORRECTION
I-03 finalization mechanism:           NOT CLOSED
I-04 dual-allowlist accounting:        CLOSED
I-05 reproducible whitespace control:  NOT CLOSED

Overall scoped verdict:                PASS WITH CHANGES
Finalization authorization:            NOT GRANTED
Integration/publication:               BLOCKED
Builder rerun:                          NOT REQUIRED
```

The corrected packet materially improves the audit boundary and is independently reproducible in several important respects. It does **not** yet earn the requested pass to apply the finalization set. Two High-severity controls remain unresolved: the new repository-wide line-ending rule makes a fresh checkout of the named candidate immediately dirty, and the proposed finalization sequence records integration before the merge/publication action actually occurs.

# 2. Independent reproduction results

## 2.1 Passed checks

| Check | Independent result |
| --- | --- |
| ZIP opened and structure matched the corrected two-layer model | **PASS** |
| Top-level manifest payload hashes | **62/62 PASS**; no missing, extra, or mismatched payload files |
| Candidate raw Git tree identity | **PASS** — recomputed from exported bytes with filters bypassed; result exactly `62cab8cd319a78b0298168d6ff17c2e545791031` |
| Prior verifier response provenance | **PASS** — exported original is byte-identical to the verifier-published file; SHA-256 `6487569e460de7469142795297443ff96a1c2011f947b773c865571b2268bc05` |
| Candidate patch reverse-check and reverse-apply | **PASS** |
| Candidate patch forward-check and forward-apply after reversal | **PASS** |
| Patch round trip | **PASS** — byte-identical to exported candidate |
| Phase 1 candidate checksum set | **23/23 PASS** |
| v1.2 candidate checksum set | **8/8 PASS** |
| Requirements register integrity | **PASS** — Markdown and CSV each contain 111 unique IDs; sets are identical |
| Peer sources unchanged from prior post-build packet | **PASS** — both files byte-identical |
| Exact-range `git diff --check` using synthetic commits with the exported raw trees | **PASS** under Git defaults |
| Full candidate diff path accounting | **PASS** — exactly 13 paths, matching the declared 8-path implementation set plus 5-path gate/control set |

## 2.2 Failed or qualified checks

| Check | Independent result |
| --- | --- |
| Fresh checkout of exact candidate tree is clean | **FAIL** — four files appear modified immediately because `.gitattributes` conflicts with legacy/verbatim CRLF blobs |
| Finalization records an event only after it occurs | **FAIL** — proposed finalization writes “integrated” and an integration event before the later merge/push |
| Authority addendum classifies all processed source trust correctly | **FAIL** — external peer documents were processed as reference material but the addendum says no external-untrusted content was processed |
| Manifest carries full immutable commit provenance and an exact delta description | **FAIL** — candidate, control, and base commits are abbreviated; the described scoped delta omits the regenerated Phase 1 checksum file |
| `control_layer_checksums.sha256` validates in its exported location | **FAIL** — paths are neither packet-root-qualified nor resolvable from `review-control/` without undocumented staging |
| Accepted v1.1 state is internally restamped | **FAIL** — authoritative records still contain pre-acceptance status language |

# 3. I-finding dispositions

## I-01 — Candidate/control snapshot separation

**Disposition: Concur-with-modification — substantially fixed, not perfectly closed.**

The corrected directory boundary works:

- `candidate/` is a complete immutable content projection.
- `review-control/` is separate and references the candidate.
- The exported candidate raw tree exactly matches the declared tree hash.
- The patch reverse-applies and forward-applies to a byte-identical round trip.
- The top-level manifest validates every payload file.

The remaining provenance defects are recorded under J-04. They do not invalidate the candidate content hash, but they prevent the packet from making every commit/delta/control-checksum claim exactly as written.

## I-02 — APP-05 authority-envelope conformance

**Disposition: Concur-with-modification — addendum accepted after correction of J-03.**

The addendum transparently admits that the Builder did not receive the missing fields, supplies the actual task envelope, preserves history, and correctly explains why a Builder rerun is unnecessary for this documentation-only task. That satisfies the principal I-02 remedy.

The trust line must be corrected: the two friend/peer documents are external-origin, external-untrusted reference data with `instruction_authority: none`; they were processed, even though they were not allowed to instruct the Builder. Treating “reference-only” as “not untrusted content” collapses the trust-versus-authority distinction adopted in v1.1.

The reusable Task Packet template must be a concrete artifact or enforced schema before TASK-0002, not only a prose promise. That future-template condition does not require another TASK-0001 Builder run.

## I-03 — Candidate finalization after verifier review

**Disposition: Dissent — not closed.**

The selected scoped-finalization model is valid in principle, but the enumerated sequence still records a state transition before it occurs:

1. The proposed finalization text changes status to **“post-build verified; integrated; pending owner v1.2 acceptance.”**
2. It appends an **integration event** at finalization-application time.
3. Only after the verifier acknowledges that finalization diff does Fable plan to merge to the designated branch and push/publicize it.

If “integrated” means merged/published to the designated branch, the record is premature. If it means Fable assembled the local integration candidate, that event already occurred and is represented by trail entry 56; it should not be used as the later release/integration event.

**Required correction:**

- The pre-ack finalization candidate may say: `post-build verified; finalization candidate prepared; pending final verifier ack` or `approved for release pending final verifier ack`.
- It may append the actual scoped-verification event because that event has occurred.
- It must not claim merge, publication, or integration-to-target before the Release Executor performs that action.
- After the final verifier ack, the Release Executor performs a compare-and-swap merge/push against the pinned target and emits a separately hashed execution receipt containing target-before, candidate, resulting commit/tree, actor/service identity, time, and push result.
- That release receipt belongs in the control plane and must not mutate the already acknowledged candidate.

This closes the candidate-invalidation loop while preserving truthful event ordering.

## I-04 — Final-candidate allowlist accounting

**Disposition: Concur — closed.**

The full patch touches exactly 13 paths. They match the declared union:

- 8 implementation paths; and
- 5 PM/gate/control paths.

No path outside the union appears in the candidate diff. The distinction between Builder scope and final-candidate control scope is now explicit and testable.

## I-05 — Reproducible whitespace evidence

**Disposition: Dissent — range check fixed; repository policy not fixed.**

The specific `git diff --check 8c599e2..ffd5cc6` claim is reproducible and clean when the exact raw base and candidate trees are used under default Git configuration. The two live register CSVs are correctly normalized to LF.

However, the new root `.gitattributes` applies `text eol=lf` to every Markdown and CSV file while the candidate still contains four tracked legacy/verbatim files with CRLF blob content:

```text
baseline/chatgpt-phase1-v1.0/02_Phase_1_Requirements_Register.csv
baseline/chatgpt-phase1-v1.0/11_Audit_Issue_Register_Template.csv
fable/v1.2-ideas-pass/sources/dual_agent_repository_development_guide.md
fable/v1.2-ideas-pass/sources/openclaw_github_claude_dual_agent_development.md
```

An independent fresh clone of the exact candidate tree reports all four as modified immediately:

```text
 M baseline/chatgpt-phase1-v1.0/02_Phase_1_Requirements_Register.csv
 M baseline/chatgpt-phase1-v1.0/11_Audit_Issue_Register_Template.csv
 M fable/v1.2-ideas-pass/sources/dual_agent_repository_development_guide.md
 M fable/v1.2-ideas-pass/sources/openclaw_github_claude_dual_agent_development.md
```

This means the candidate is clean as an archive projection but not clean as an ordinary repository checkout. It also creates a future risk that Git will silently renormalize the peer source documents that the process promises to preserve verbatim.

**Required correction:** adopt one explicit policy and test it on a fresh clone:

- **Preferred:** keep LF enforcement for active generated artifacts, but exempt immutable historical and verbatim source trees, for example with later-precedence rules equivalent to:

```gitattributes
*.csv text eol=lf
*.md text eol=lf
*.json text eol=lf
*.sha256 text eol=lf

/baseline/** -text
/fable/v1.2-ideas-pass/sources/** -text
```

- **Alternative:** perform an explicit repository-wide renormalization migration, enumerate every changed file, preserve provenance for source snapshots, regenerate all hashes, and independently review that larger change.

The preferred correction is smaller and consistent with the stated requirement that historical baselines and peer sources remain verbatim.

# 4. New findings

## J-01 — Repository-wide line-ending attributes make a fresh candidate checkout dirty

**Severity:** High  
**Affected:** I-05, H-06, APP-06, APP-09, `.gitattributes`, peer-source preservation, candidate reproducibility

**Problem:** The candidate range passes `git diff --check`, but the root attributes conflict with four existing tracked CRLF blobs. A fresh checkout of the exact candidate tree immediately reports modifications. This is not only cosmetic: future staging can change source and historical snapshot bytes without an intentional content decision.

**Required change:** Narrow the attributes or explicitly exempt immutable source/history trees; prove an empty `git status --porcelain` on a fresh checkout; rerun the exact range check, tree hash, checksums, and source-file hash comparison.

**Closure evidence:**

```text
fresh clone/checkout of full candidate commit
`git status --porcelain=v1` => empty
`git diff --check <full-base>..<full-candidate>` => exit 0
peer-source hashes unchanged
all checksum sets and top-level manifest => 100% pass
```

## J-02 — Finalization sequence records integration before release execution

**Severity:** High  
**Affected:** I-03, APP-07, APP-08, APP-09, GOV-03, decision trail, release-state truthfulness

**Problem:** The proposed finalization set changes authoritative text to “integrated” and appends an integration event before the later merge/push. This violates event-after-action ordering and leaves no mutation-free place to record the actual Release Executor outcome.

**Required change:** Use a pre-release status in the finalization candidate; record only events that have occurred; after final ack, have the Release Executor merge/push and emit an external/control-plane receipt referencing the immutable candidate. Do not mutate the acknowledged candidate after release execution.

## J-03 — Authority addendum confuses trust class with instruction authority

**Severity:** Medium  
**Affected:** I-02, TRS-01, TRS-02, APP-05, authority-envelope precedent

**Problem:** The addendum says no external-untrusted content was processed, while also acknowledging two external-origin peer source documents were read as reference material. Under the accepted five-field input envelope, external reference documents remain external-untrusted unless separately verified; `instruction_authority: none` is the control that prevents them from governing the build.

**Required change:** Replace the trust entry with an explicit envelope such as:

```text
origin: external peer-provided documents
trust_class: external-untrusted
instruction_authority: none / reference-only
sensitivity_class: business-general design material
verification_state: source copies hash-verified; substantive claims not independently certified
```

No Builder rerun is required.

## J-04 — Snapshot metadata does not exactly match its own provenance claims

**Severity:** Medium  
**Affected:** I-01, H-06, `EXPORT_MANIFEST.json`, corrected gate packet, control checksum artifact

**Problem:**

- The corrected gate says the full candidate hash is in the manifest, but candidate, control, and base commits are recorded only as abbreviations.
- The manifest says the `ea50c22 -> ffd5cc6` delta is the two CSV normalizations plus `.gitattributes` “only,” but the Phase 1 `checksums.sha256` file also changed to record the normalized hashes.
- `review-control/control_layer_checksums.sha256` mixes candidate and control files using unqualified paths. It passes only after an undocumented merged staging layout is manually created; it does not validate from packet root or its exported directory.

**Required change:** Record full 40-character candidate, control, base, and accepted-v1.1 commit IDs; state the exact four-path scoped delta, including regenerated checksums; and either use packet-root-qualified checksum paths or remove the redundant checksum file and rely on the top-level manifest. Regenerate the manifest after correction.

## J-05 — Accepted v1.1 artifacts retain pre-acceptance state labels

**Severity:** High  
**Affected:** accepted baseline authority, Requirements Register, Manual closure/status text, ADR register, finalization allowlist

**Problem:** The authoritative register declares v1.1 accepted at its top but still labels **26 requirements** `Adopted v1.1 (pending owner acceptance)`. The Manual still contains pre-acceptance language including “candidate baseline,” an instruction that Phase 2 must wait for an audit already passed, and ADR-013 through ADR-018 marked `Proposed in v1.1`. These are not merely historical quotations; they appear in authoritative current-state fields.

A machine or later agent reading row-level status can therefore conclude that accepted requirements are still provisional. That undermines the authority set the Task Packet is supposed to enumerate.

**Required change:** Expand the pre-authorized finalization set to include a deterministic v1.1 acceptance restamp:

- all 26 `pending owner acceptance` requirement statuses become accepted v1.1 statuses tied to trail entry 53;
- ADR-013 through ADR-018 become accepted v1.1 decisions, or receive an explicit reason if any genuinely remained provisional;
- the Phase 1 Closure Statement and “How to use this baseline” text are updated from pre-audit candidate language to accepted-baseline language;
- README/count/status references reconcile the 104 accepted v1.1 requirements plus 7 proposed v1.2 additions;
- a grep/status-count report is included in the finalization evidence.

Because these are status/provenance corrections rather than changes to the adopted mechanisms, a Builder rerun is not required; the finalization diff must still receive the already-planned scoped verifier acknowledgment.

# 5. Required next packet

Fable should return one more narrowly scoped packet containing:

1. The candidate delta that fixes J-01 and its regenerated checksums/tree identity.
2. Revised `07_TASK-0001_Corrected_Gate_Packet.md` and `EXPORT_MANIFEST.json` resolving J-04.
3. Corrected authority-envelope addendum resolving J-03.
4. A revised finalization plan resolving J-02 and explicitly separating pre-release candidate status from the post-release execution receipt.
5. The expanded, exact finalization allowlist that includes the J-05 acceptance restamp.
6. Fresh-clone evidence, exact commands, and outputs.

The next review remains scoped. The underlying APP/ADR/DP/GOV substance does not require another full semantic audit unless the corrections alter its meaning.

# 6. Gate position

```text
Candidate semantic content:     ACCEPTED FOR CONTINUED FINALIZATION WORK
Current corrected gate packet:  PASS WITH CHANGES
Apply current finalization set:  NO
Merge/push/publication:         NO
Builder rerun:                  NO
Next actor:                     Fable
Next action:                    Correct J-01..J-05 and return scoped packet
```

The dual-verification process is functioning as intended: the candidate/control split and allowlist correction are real improvements, while independent reconstruction exposed a repository-cleanliness defect and an event-ordering defect that a narrative review would likely have missed.
