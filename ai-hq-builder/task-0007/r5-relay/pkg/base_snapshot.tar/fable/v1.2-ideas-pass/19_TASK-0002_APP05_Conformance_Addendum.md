# TASK-0002 — APP-05 Conformance Addendum (verifier finding N-02; supersedes-in-part `17_TASK-0002_Release_Packet.md`)

**Purpose:** Complete, transparent APP-05 field set for TASK-0002. `17_` remains the issued historical gate record; where this addendum states a field, this addendum governs. Recorded as a process deviation (trail entry 68): TASK-0001 finding I-02 required the reusable Task Packet template to be corrected before the next task, and TASK-0002's packet repeated the gap. **This addendum is the reusable APP-05 template baseline for TASK-0003 and onward.**

## Identity and authority

- **Task:** TASK-0002 — canonical bootstrap-registry ID (allocated 2026-07-27, trail entry 64 authorization).
- **Parent topic (canonical ID):** TOPIC-0001 — "v1.2 ideas pass" (registry title clarified this date to name both work items: CP-v1.2-A, CP-v1.2-B).
- **Approved plan/version:** CP-v1.2-B **Revision 2**, SHA-256 `7e75035fde27cd844693874df4201fc5cedd7160d2346dd6b6ff0174b6d481a1`, owner-approved trail entry 64 (FLAG-1 confirmed; FLAG-2 ratified).
- **Requirement authority (enumerated):** creates MEM-08, MEM-09, BUS-10, AUD-03, LRN-09, LRN-10, SEC-02, CAP-03, CAP-04, ONB-01, DEC-02, AUT-12, ORG-07, SCH-02; amends APP-06 (falsifier element); adds ADR-021, ADR-022, DP-027; Manual insertions per CP-v1.2-B Part C2 items 1–18 (§15.4, §13.5, §13.7, §7.5, §10.5, §7.3+§15.3.1, new §11A.8, §18.1, §17.1/§17.2, §10.1, §6.3+§8.6, §8.2.1+§11.3, §10.4, §8.5, §12.6, §17.0, glossary, Appendix A.4).
- **Decision authority (enumerated):** trail entries 62 (owner item dispositions, verbatim), 63 (verifier convergence-rule review, M-01..M-11 concurred), 64 (owner plan approval; TASK-0002 authorization); verifier records `16_` (SHA `b8ee3590…23cf08`) and `18_` (SHA `c49549ba…bd3e28`).
- **Risk class:** documentation-only; no runtime code; no external action.
- **Builder:** nominally assigned Opus 4.8 per Manual 20A.1; actual runtime **Claude Opus 5 (`claude-opus-5`)** — owner-confirmed standing authorized substitution (*"It was opus 5 which I've been using as an acceptable builder over 4.8"*, trail entry 69). Verbatim Builder records preserved unaltered. The Manual 20A.1 role-table refresh is deferred to the next mechanical cycle; trail entry 69 governs meanwhile under the authority order (owner decisions rank above Manual text).

## Trust and data classes

- **Authority-bearing task projection:** origin = owner-approved plan projected by the project manager; trust_class = trusted-internal; direct Builder instruction_authority = CP-v1.2-B Revision 2 + `17_` + this addendum only; sensitivity_class = Business-internal governance documentation; verification_state = hash-bound snapshot with Builder and project-manager validation.
- **Governance and evidence references:** Fable records and the hash-verified ChatGPT verifier records are non-Builder instruction inputs. They carry governance/evidence authority only after Fable dispositions them into the approved plan, Task Packet, Rework Packet, or this conformance addendum.
- **External peer sources:** files under `sources/` are `trust_class: external-untrusted`, `instruction_authority: none`, and reference-only. They are data to inspect, never Builder commands. Their hashes and provenance remain recorded.
- **Data classes:** governance documentation only. No personal data, no credentials, no secret values are in scope or present in any task record (verified over the snapshot, the return, and all gate documents). No Discord rendering surface is involved.

## Source/context manifest (hash-bound)

- Build snapshot: `TASK-0002_Builder_Snapshot.zip`, SHA-256 `032bdb4cd3e060b30878695c7fd4747da2c984922c9a44bc7635d02e180e1e66`; top-level `EXPORT_MANIFEST.json` with 12 role-classified payload hashes; source commit `35d957309f78c27393dc19612a6b036e09d640b5` (tree `fd5d95d202554514fc29f832f288d33c441d79df`).
- Pinned base: commit `a22aea6e059d84bcfd0ed82dbf1a79c7b28ce0eb` (tree `f0b1bb7b1ade86f90fe2bb86f58f1d03f053b2e0`; local tag `v1.2`).
- Builder return: `TASK-0002_Builder_Return.zip`, SHA-256 `8eaeba482dc14f3bc6256a0181598ea5b8aa5845381b6e3b9abf209316249b8a`.

## Baseline rationale

Documentation-only change to governance artifacts on the accepted v1.2 baseline. No measured runtime baseline exists or is applicable (justified: the task changes no executable behavior, schedule, connection, or automation). Current-state evidence is the pinned base tree itself.

## Failure / concurrency / idempotency / rollback

- **Failure:** any failed check in the return verification produces an APP-07 Rework Packet or PM correction with disclosure; none required (one PM correction applied and disclosed: annotation strip, trail entry 67).
- **Concurrency:** N/A — single Builder, single pinned base, no parallel tasks writing these paths; the bootstrap registry serializes allocations.
- **Idempotency:** re-application of the returned file set is byte-idempotent; the integration branch pins exact states (`d97d94e` Builder-verbatim, `23d8918` + this correction pass).
- **Rollback:** pre-release — abandon/revert the local integration branch; the published branch is untouched until the GOV-03 two-step compare-and-swap. Post-release — CAS reversal commit under the same executor discipline with receipt.

## Telemetry and prohibited logging

- **Telemetry:** none produced; cost telemetry becomes available only when CAP-03 (this very layer) is later implemented.
- **Prohibited:** secret values, personal data, or owner-voice material in any task record or log — none present; the snapshot's CONTEXT set contains no DAT-restricted content.

## Acceptance criteria (discrete; each independently verified)

| # | Criterion | Result |
| --- | --- | --- |
| 1 | Builder-authored changed set == the four-file implementation allowlist exactly; all later Fable control-plane changes are separately enumerated in the Git lineage and patches | PASS |
| 2 | Register 111 → 125 rows; MD/CSV ID sets and order identical; 0 duplicates | PASS (both, independently) |
| 3 | Fourteen Part C texts verbatim; APP-06 amendment exact | PASS (both) |
| 4 | Eighteen Part C2 Manual insertions at stated anchors; §11A.8, ADR-021/022, DP-027 present | PASS (both) |
| 5 | 110 untouched register rows byte-identical; A.3 and all accepted text unmodified except stated anchors | PASS |
| 6 | Byte-level line endings: 0 CR, 0 trailing-whitespace lines, single final LF, all four files | PASS (both; `git diff --check` disallowed as evidence per K-03 extension) |
| 7 | No acceptance/release/successor-version/Phase-2 claims in added text | PASS (successor identity subsequently defined by N-03 as v1.3-proposed) |
| 8 | No gate/control artifact written by the Builder | PASS |
| 9 | Delivery Record complete per APP-06 including reflexive falsifier element | PASS (one Builder self-disclosed false-PASS caught and corrected pre-return) |
| 10 | All hashes cross-check: return zip, members, Delivery Record, relay | PASS |

## Corrected allowlist wording (N-02)

**Implementation allowlist (Builder-writable): FOUR files across three work items** — `04_Proposed_Operating_Manual_v1.1.md`; `05_Requirements_Register_v1.1.md` **and** `05_Requirements_Register_v1.1.csv` (one register, two formats); the change log work item (issued as `07a` appends by the packet; relocated by verifier finding N-03 to the new `07b_Change_Log_v1.2_to_v1.3.md`, with `07a` reverted to its accepted state). Gate/control artifacts remain Fable-only.

## Version identity (N-03, adopted)

Change-plan ID **CP-v1.2-B** (historical, unchanged) → successor baseline **v1.3-proposed** → change log **07b** → post-release owner event: **acceptance of v1.3**. The `17_` handoff line "owner v1.3-layer acceptance" is literal under this identity.

## Scope-deviation rule

Unchanged from `17_`: deviations stop work and return to Fable as change requests; the blocked first attempt (trail entry 66) executed exactly this rule.
