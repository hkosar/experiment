# TASK-0001 Finalization Plan (Rev 2 — resolves J-02 and J-05)

**Author:** Fable — Project Manager / Integration Owner.
**Status:** Plan only. Nothing here is applied until the verifier acks the accompanying gate packet; the applied finalization diff then returns for the already-planned scoped acknowledgment before any release execution.

## Event-ordering rules (J-02, adopted)

1. The finalization candidate may record only events that have **occurred** and may carry only **pre-release** status: `post-build verified; finalization candidate prepared; approved for release pending final verifier ack`. It never says "integrated," "merged," or "published."
2. Trail entries appended at finalization application: (a) the post-build verification + scoped re-verification events (occurred); (b) the finalization-prepared event. **No integration event is written at this stage.**
3. After the final verifier ack, release execution runs as a **pre-published deterministic sequence** (below). The execution outcome is recorded in a **separately hashed Release Execution Receipt** committed *after* the push as a control-plane record — it references, and never mutates, the acknowledged candidate.
4. The receipt commit and its trail entry (the actual integration event, recorded after it occurs) touch only the receipt file, the trail append, the bootstrap-registry status cell, and regenerated integrity files — nothing else.

## Release execution (GOV-03 posture, disclosed)

- **Two-step compare-and-swap sequence (K-02):**
  - *Step 1 — Release content:* verify remote head == pinned target-before `8c599e2c373d9d5744ff59333072d72eb0dd3b98` → verify the finalization commit maps to the verifier-acknowledged tree (`git rev-parse <finalization-commit>^{tree}`) → verify ancestry (`git merge-base --is-ancestor 8c599e2… <finalization-commit>`) → push by compare-and-swap → re-read remote and verify remote head == `released_content_commit`.
  - *Step 2 — Publish execution receipt:* create the receipt commit directly on `released_content_commit` (receipt file + actual integration trail entry + bootstrap-registry status + regenerated integrity files, nothing else) → verify remote head still == `released_content_commit` → push the receipt commit by compare-and-swap → re-read remote and verify `final_remote_head` == `receipt_commit`.
  - The receipt records `released_content_commit`, `released_content_tree`, `receipt_commit` (captured from push output/subsequent event, since a file cannot contain its own commit hash), `final_remote_head`, first-push result, actor, UTC time, and the receipt file's own SHA-256.
- **Actor disclosure (per the verifier's K-03 executor note):** executed as a Fable-invoked deterministic git sequence under standing owner authority. This is a **recorded one-time transitional exception** for this documentation-only publication, accepted by the owner with this plan — it is *not* claimed to satisfy the constrained Release Executor design; the structurally separate executor (CI) arrives with Stage 2.
- **Receipt contents:** target-before commit, acknowledged candidate/finalization commits and trees, resulting remote commit, actor identity, UTC time, push result, and the receipt file's own SHA-256 recorded in the trail entry.

## Deterministic finalization allowlist (expanded per J-05)

**A. v1.2 status truthing (pre-release wording only):**
- Register (md+csv): the 8 v1.2 rows' status → `Post-build verified (TASK-0001); release candidate; pending owner v1.2 acceptance`.
- Manual Document Control v1.2 line, Appendix A.3 tail note, ADR-020 status cell → same pre-release wording.
- `07a` change log endpoint → pipeline state through scoped re-verification.

**B. v1.1 acceptance restamp (J-05 — deterministic, tied to trail entry 53):**
- Register (md+csv): all **26** rows reading `Adopted v1.1 (pending owner acceptance)` → `Accepted v1.1 (owner acceptance, trail entry 53)`.
- Manual: ADR-013..ADR-018 status cells `Proposed in v1.1.` → `Accepted with v1.1 (trail entry 53).`
- Manual pre-acceptance language in authoritative current-state fields: the Phase 1 Closure Statement paragraph ("This is a candidate baseline…"), the Document Control "How to use this baseline" auditor-challenge blockquote, and §21.1 ("not accepted as the final Version 1…") → accepted-baseline language referencing entries 45–53; historical quotations inside trail/audit records are untouched.
- Register header count line reconciled: 104 accepted v1.1 requirements + 7 proposed v1.2 additions = 111.
- `00_READ_ME_FIRST.md` (K-03): register count corrected to 104 accepted v1.1 + 7 proposed v1.2 = 111; acceptance section restated in past tense with current v1.2 gate state; explicit note that `04_Proposed_Operating_Manual_v1.1.md` is a historical filename containing the accepted baseline.
- `07_Change_Log_v1.0_to_v1.1.md` (K-03): title de-proposed; "Pending: owner acceptance" replaced with the acceptance date and trail entry 53.
- **Evidence:** a grep/status-count report (commands + outputs) accompanies the finalization diff: 0 remaining `pending owner acceptance` rows; 0 remaining `Proposed in v1.1` ADR cells; 0 current-facing `Pending: owner acceptance`; README count reconciles to 111; excluded historical quotations enumerated.

**C. Records and integrity:**
- Trail entries per rule 2 above; bootstrap registry TASK-0001 status → `finalization candidate prepared`.
- Current-round control documents (gate packet Rev 3, this plan, the scoped re-verification verbatim record when supplied) commit into `fable/v1.2-ideas-pass/` as durable records (APP-02) — joining the repository at finalization, per the candidate-lineage rule in the gate packet.
- Both checksum sets and the packet manifest regenerated; fresh-clone evidence re-run and attached.

**Nothing outside A–C changes between the verifier's ack of this plan and the release execution.**
