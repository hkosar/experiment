# Independent Verifier Response — CP-v1.2-B Revision 1

**Reviewer:** ChatGPT, Independent Verifier  
**Review target:** `15_Change_Plan_CP-v1.2-B_NateHerk_Adoption.md`  
**Review-target SHA-256:** `dbd83bd205cb120be2aa7c2147c80fd6dd38620adb1b71f14d20beb6305cfc57`  
**Packet:** `CPv1.2B_Rev1_Verifier_Review_Packet.zip`  
**Packet SHA-256:** `4fb4bed861396483efe54d847b6333f1fdd4d38e4e0d440342c4de71f4ec7961`  
**Date:** 2026-07-27  
**Gate:** Pre-approval change-plan verification under Manual §20A

## 1. Verdict

**PASS WITH CHANGES**

The plan is traceable to the owner-dispositioned idea register, preserves the accepted operating model in most respects, and is suitable for revision into an owner-approval candidate. No CPB item requires wholesale rejection.

The plan is **not yet ready for owner approval or TASK-0002 release** because several proposed requirements are either too absolute, under-specified, or capable of weakening accepted v1.1/v1.2 controls. The required corrections are bounded and can be incorporated by Fable without reopening the full ideas review.

**FLAG-1 and FLAG-2 are not dispositioned here.** They remain owner confirmations at plan approval, exactly as instructed. This response evaluates whether the proposed mechanisms surrounding those flags are coherent and safe; it does not decide the owner's preference.

## 2. Snapshot and traceability checks

- The export opened successfully.
- All four payload hashes match `EXPORT_MANIFEST.json` (**4/4 pass**).
- The packet contains sixteen item plans: **CPB-01 through CPB-16**.
- Part C proposes fourteen new requirement IDs; none collide with the released 111-row register.
- The arithmetic **111 current rows + 14 new rows = 125 rows** is correct; the APP-06 amendment does not add a row.
- The four owner modifications recorded in trail entry 62 are carried into the plan: external managed-memory direction, staged outbound voice use, grant-once/activate-staged onboarding, and automation-first intent.
- The five Tier-4 rejections are carried as an owner-ratification flag rather than silently treated as accepted.
- The released v1.2 content tree used for conflict checking was independently reconstructed from the previously authorized snapshot and matched tree `19aa1c321764ceae6fa6fd9b304d28898e256ab3`.

**Evidence limitation:** the current ZIP proves the four exported file contents, but it does not contain a Git object/bundle or the complete released Manual/register. The claimed association with source commit `29c08f6632da8b7942107556f81998e2f4e14152` is therefore not independently reproducible from this packet alone. This did not prevent this review because the released baseline remained available from the prior gate record; it must be corrected for TASK-0002's self-contained context pack (M-10).

**Research limitation:** this review treats `14_NateHerk_Comprehensive_Review.md` as the supplied research basis. It does not independently re-research Herk's repositories, licensing, popularity metrics, attribution claims, or ecosystem history.

## 3. Owner flags — reserved, not dispositioned

### FLAG-1 — Grant-once / activate-staged

**No owner-preference disposition issued.** The owner decides whether the proposed interpretation matches the intended experience.

Verifier condition: whichever interpretation the owner selects must use the protected onboarding and credential-handling boundary in M-01. A plan may promise one coordinated setup experience for currently known integrations; it may not promise that credential expiry, revocation, recovery, new systems, or step-up authorization will never require later owner action.

### FLAG-2 — Tier-4 ratification

**No disposition issued.** The plan accurately identifies the five proposed rejections and leaves ratification to the owner approval event.

## 4. CPB dispositions

### CPB-01 | Concur-with-modification

The grounding, conflict, and admission clauses materially strengthen MEM-04 and correctly preserve the owner's decision not to adopt the file-wiki as the primary memory implementation. The requirement must also state that an external memory provider remains a **derived knowledge layer**, never the canonical store for workflow state, approved decisions/rules/policies, credentials, or action authority. Provider selection and external data transfer remain separate gated decisions.

**Required modification:** adopt the revised MEM-08 boundary in §6.1 and ensure ADR-021 preserves MEM-01 and §5.2.1 ownership.

### CPB-02 | Concur-with-modification

A connections registry is a direct fit for Data HQ. The current text leaves the canonical store, secret boundary, API-reference freshness, and health-monitor relationship ambiguous. Connection freshness should feed Data HQ health and AUD-03; it should not redefine the independent host-liveness watchdog in §11A.5/RES-02.

**Required modification:** use the revised BUS-10 in §6.2; home the registry in §13.5 with §13.7 references; store metadata only, never secrets.

### CPB-03 | Concur-with-modification

The read-only scorecard is appropriate, but a 0–100 score is not reproducible until the rubric version, weights, denominators, missing-data handling, evidence links, and control ownership are specified. A self-audit may summarize independent security/harness signals; it must not manufacture its own proof that those controls passed.

**Required modification:** use the revised AUD-03 in §6.3. The score is advisory evidence and prioritization input, not a gate by itself.

### CPB-04 | Concur-with-modification

The governed-learning ritual fits the operating model. Part B says **exactly one** artifact while Part C says **at most one** and also contains a KPI-or-stop rule. Those cannot all be true. The correct rule is at most one accepted improvement artifact; zero is valid when no candidate passes the KPI and governance tests. Urgent security/corrective work must not wait for this ritual.

The CAP-01 citation is also incorrect: CAP-01 is the standing-load requirement. “Adopt before build” is the §17.0 rule.

**Required modification:** use revised LRN-09 in §6.4 and correct the traceability reference.

### CPB-05 | Concur

Checkpointing each structured-interview answer is a direct specialization of MEM-05 through MEM-07 and §15.3.1. The persisted interview record must inherit data-class, provenance, versioning, correction, and protected/generated-field rules; no additional architecture change is required.

### CPB-06 | Concur-with-modification

Authentic prior writing samples, refusal of made-to-order samples, internal provenance, and gradual category-level use are sound. However, permission to apply a voice profile and permission to **send** an external communication are separate action classes. Correction-rate graduation may expand drafting/style authority; it cannot independently confer send authority or bypass IDN, DAT, ACT, AUT, and step-up policies. Voice samples also need explicit classification, retention, deletion, and access controls.

**Required modification:** use revised SEC-02 in §6.5 and make §11A.8 distinguish profile use, draft approval, and external-send authority.

### CPB-07 | Concur-with-modification

The local JSONL tool is a valid adopt-before-build Stage-1 producer, but it covers only the records it can actually observe. The requirement must disclose provider/account coverage, billed-versus-estimated status, missing sources, and date range. It should parse usage metadata by default and avoid ingesting prompt or response content merely to calculate cost.

**Required modification:** use revised CAP-03 in §6.6. The dashboard must support additional provider exports/APIs rather than becoming Claude-JSONL architecture.

### CPB-08 | Concur-with-modification

The single coordinated onboarding experience and internally staged activation are compatible with the baseline. The absolute phrases “all credentials” and “MUST NOT issue follow-up access requests” are not safe or implementable as written. Credentials expire, are revoked, require rotation, may need re-consent, and new integrations may be added later. Secrets must never travel through Discord, model prompts, repository documents, logs, or ordinary interview records.

**Required modification:** use revised ONB-01 in §6.7. This preserves the owner's no-trickle intent for known integrations while allowing batched, explained reauthorization when materially required. FLAG-1 remains the owner's confirmation.

### CPB-09 | Concur-with-modification

A default three-occurrence threshold is a reasonable promotion signal, but the plan needs a normalized task class, distinct-event deduplication, an owner-tunable observation window, and provenance/trust constraints. External-untrusted content, retries, duplicate imports, or one repeated conversation must not manufacture three observations. Crossing the threshold creates a candidate observation for LRN-09; it does not change behavior.

**Required modification:** use revised LRN-10 in §6.8.

### CPB-10 | Concur-with-modification

The falsifier field is a useful anti-loop mechanism. “Consequential” should be tied to the existing impact/risk classification, and the record must permit “unknown/not presently identifiable” with rationale rather than force false precision.

**Required modification:** use revised DEC-02 in §6.9.

### CPB-11 | Concur-with-modification

The owner's automation-first intent can be preserved, but “full automation” and “manual work is a long-term detriment” cannot apply indiscriminately. The accepted baseline deliberately retains owner judgment and step-up for consequential, sensitive, irreversible, legally constrained, or insufficiently evidenced actions. Raw model confidence is explicitly not an unlock criterion under §8.2.1; any confidence routing must be calibrated against observed outcomes and bounded by risk class.

**Required modification:** use revised AUT-12 and DP-027 in §§6.10 and 6.14. The destination is the **highest safe, policy-authorized autonomy for each eligible action class**, not universal removal of human control.

### CPB-12 | Concur-with-modification

A cost-versus-value retirement review is appropriate. “Cost exceeds savings” needs a declared measurement window and a complete value model: model/tool spend, maintenance, owner time, failure burden, quality, risk reduction, mandatory compliance, and other non-financial value. The rule should create a retirement review, not automatically disable the automation. Safety, resilience, and compliance controls must not be retired merely because they are cost centers.

**Required modification:** use revised CAP-04 in §6.11.

### CPB-13 | Concur

The three-question test is appropriately advisory and expressly does not gate capture. It fits §8.5 and ORG-05. The three-touch measure should remain owner-tunable and the quarterly sweep can be scheduled through AUD-03.

### CPB-14 | Concur-with-modification

The falsifier prompt improves Builder self-disclosure but must not become ceremonial boilerplate on every minor statement. Apply it to each **material acceptance/evidence claim**, permit a reasoned N/A where no meaningful disconfirming test exists, and preserve APP-06's rule that Builder-authored records are not independent evidence.

**Required modification:** use the APP-06 amendment in §6.12.

### CPB-15 | Concur-with-modification

Scoped context reduces cost and blast radius, but “minimal context” cannot mean omitting the controls that make the run safe. Every scheduled run needs the smallest task-specific context **plus** a mandatory control envelope: identity/authority, trust and data classes, active scoped rules and policies, current checkpoint/schema, tool limits, failure/idempotency/rollback rules, and an evidence destination. Missing or stale mandatory control context must fail closed.

**Required modification:** use revised SCH-02 in §6.13.

### CPB-16 | Concur

WAT may be added as optional teaching vocabulary with contested provenance noted. It has no design authority and must not replace the system's existing role, object, or layer vocabulary.

## 5. New findings

### M-01 — High — Protected onboarding and secret-handling boundary is missing

**Affected:** CPB-08, ONB-01, ADR-022, §§11A.1/11A.3/11A.7, 17.1–17.2  
**Problem:** “One-time full credential collection” does not specify where secrets are entered, stored, rotated, revoked, or recovered and promises no later access requests. That can place credentials in model-visible or repository-visible channels and conflicts with identity recovery, staged activation, least privilege, and connection freshness.  
**Required change:** credentials and grants are collected only through a protected secret-management/onboarding surface; models receive handles/scopes, never secret values; known grants are batched once; later reauthorization is allowed for expiry, revocation, rotation, new integrations, changed scope, and risk-tiered step-up.  
**Closure:** revised ONB-01 and ADR-022 text present before owner plan approval.

### M-02 — High — Automation-first wording weakens accepted risk-tiered controls

**Affected:** CPB-11, AUT-12, DP-027, §§8.2.1, 11.1–11.3  
**Problem:** universal “full automation” and “manual work is a detriment” language conflicts with accepted owner-value approvals, step-up confirmation, action-class policies, and the rule that raw model confidence cannot unlock authority.  
**Required change:** target the highest evidence-supported autonomy **for eligible action classes**; retain durable human judgment where law, safety, sensitivity, irreversibility, owner value, or weak evidence requires it; use calibrated confidence plus risk/policy, never raw self-reported confidence alone.  
**Closure:** revised AUT-12 and DP-027 present before owner plan approval.

### M-03 — High — Scoped scheduled context lacks a mandatory control envelope

**Affected:** CPB-15, SCH-02, APP-05, TRS/DAT/ACT/LOG  
**Problem:** a minimal context slice can reduce cost while accidentally dropping active rules, authority limits, data handling, retry constraints, or the current checkpoint. That would turn cost optimization into a permission bypass.  
**Required change:** define a versioned, hashed context manifest containing mandatory control context plus minimum task context; missing, expired, or mismatched control context fails closed.  
**Closure:** revised SCH-02 and Manual placement before build.

### M-04 — High — Voice-profile graduation and external-send authority are conflated

**Affected:** CPB-06, SEC-02, new §11A.8  
**Problem:** measured correction rate may justify better automated drafting but cannot by itself authorize sending, recipient selection, data disclosure, or consequential external action. The plan also omits data handling for the owner's writing samples and generated voice profile.  
**Required change:** separate (1) profile creation/use, (2) draft generation, (3) draft approval, and (4) send authority; classify and protect voice samples; bind every outbound artifact to profile/version, drafting actor, approval event, and send policy.  
**Closure:** revised SEC-02 and exact §11A.8 text before owner plan approval.

### M-05 — High — The Builder authority package and allowlists are incomplete

**Affected:** Part C, Part D, APP-05 through APP-07, bootstrap registry  
**Problem:** exact requirement rows are supplied, but ADR-021, ADR-022, DP-027, and most Manual amendments are only described. Leaving normative wording to the Builder violates the Builder boundary. Part D also uses one ambiguous allowlist and says `bootstrap_id_registry.md` is “status column only,” although TASK-0002 allocation requires appending a new row and allocation is PM/control-plane authority, not Builder authority.  
**Required change:** Revision 2 must contain exact owner-facing ADR/DP language and sufficiently exact Manual insertion text; the Task Packet must separate the **implementation allowlist** from the **gate/control-artifact allowlist**; Fable allocates TASK-0002 atomically after owner approval, and the Builder has no registry-allocation authority.  
**Closure:** corrected Revision 2 and Task Packet contract before TASK-0002 release.

### M-06 — Medium — The self-audit score is not reproducible

**Affected:** CPB-03, AUD-03  
**Problem:** dimensions are named, but weights, scoring rules, missing-data treatment, rubric version, evidence links, and independent signal sources are absent. A 0–100 result can therefore look precise while being non-repeatable.  
**Required change:** versioned rubric and weights; show numerator/denominator and unknowns; link every deduction to evidence; prohibit self-attestation for independent controls; score informs prioritization but does not alone pass a gate.  
**Closure:** exact AUD-03/Manual language before build.

### M-07 — Medium — Cost telemetry and economic retirement lack coverage and value boundaries

**Affected:** CPB-07, CPB-12, CAP-03, CAP-04  
**Problem:** Claude-local JSONL records do not represent all subscriptions, providers, APIs, or infrastructure costs; “savings” is undefined and may exclude owner time, quality, risk reduction, or mandatory controls.  
**Required change:** coverage disclosure, billed/estimated distinction, multi-provider extension path, metadata-only collection by default, defined evaluation window, complete value model, and review-not-auto-retire behavior.  
**Closure:** revised CAP-03/CAP-04 before owner approval.

### M-08 — Medium — Observation promotion can be gamed or contaminated

**Affected:** CPB-09, LRN-10, TRS-02, LRN-01  
**Problem:** three occurrences are undefined: duplicates, retries, repeated transcript text, and external-untrusted material could satisfy the threshold.  
**Required change:** distinct verified occurrences, normalized task class, owner-tunable window, deduplication, provenance, and explicit prohibition on untrusted content directly creating the candidate. Threshold crossing remains weak evidence only.  
**Closure:** revised LRN-10 before build.

### M-09 — Medium — Connections registry ownership and watchdog semantics are unclear

**Affected:** CPB-02, BUS-10, §§13.5, 13.7, 11A.5  
**Problem:** the plan does not identify the registry's canonical store, could encourage secret storage in reference docs, treats “captured-once” documentation as permanently current, and overloads the independent host watchdog with connection-health semantics.  
**Required change:** operational database owns connection metadata; Git/artifact storage owns versioned reference docs; secrets remain in the secret store; docs refresh on API/tool version changes; connection health feeds Data HQ/AUD-03, while RES-02 remains the independent coordinator-liveness watchdog.  
**Closure:** revised BUS-10 and section targets.

### M-10 — Medium — The verifier packet is not self-contained against the claimed baseline

**Affected:** export process, APP-05 source/context manifest, §20A.2  
**Problem:** the packet hashes its four payloads but omits the current Manual/register and does not prove that the declared source commit resolves to those files. A fresh verifier session could not test collisions, section targets, or baseline contradictions.  
**Required change:** TASK-0002's context pack must include the exact current Manual/register or a hash-bound immutable baseline export, plus full commit/tree binding evidence and material exclusions.  
**Closure:** corrected source/context manifest in the Task Packet; this finding does not require re-running the present plan review.

### M-11 — Low — Internal wording and traceability corrections

**Affected:** Parts A, B, C  
**Corrections required:**

1. Part A should say “sixteen owner-dispositioned items” rather than “owner-approved items” while FLAG-1/FLAG-2 remain pending.
2. CPB-04 should say “at most one” rather than “exactly one.”
3. Replace the incorrect “CAP-01 adopt-before-build” citation with Manual §17.0.
4. BUS-10 should target §13.5 as its primary home, with §13.7 cross-reference.
5. Do not say connection freshness feeds the §11A.5 watchdog; use Data HQ health/AUD-03.

## 6. Verifier-required language

Fable may express these requirements equivalently, but Revision 2 must preserve every boundary below.

### 6.1 MEM-08 replacement

> **MEM-08** — Any knowledge-memory provider satisfying MEM-04 remains a derived knowledge layer and MUST NOT become the canonical store for workflow state, approved decisions, rules, preferences, skills, automation policies, credentials, or action authority. Every retained knowledge claim MUST carry stable provenance and a resolvable source reference; unsupported claims are quarantined or flagged as unverified rather than treated as fact. Conflicting information creates a versioned `Disputed` record linked to the competing claims and enters governed resolution rather than silently overwriting either source. Admission, retention, model access, Business/Personal separation, export, and deletion obey DAT/TRS/PER policies. Provider selection and authorization of external data transfer require a separate gate.

### 6.2 BUS-10 replacement

> **BUS-10** — The operational database MUST own a connections registry for every configured or discoverable integration, including mechanism, scope, authentication-health state, last verified time, owning domain, applicable trust/data classes, tool/API version, and reference-document pointer. The registry and reference documents MUST contain no secret values. Versioned per-tool reference documents live in Git or controlled artifact storage, identify their source/version/capture date, and refresh when the tool or API materially changes. Connection freshness feeds Data HQ health and AUD-03; it does not replace the independent RES-02 coordinator-liveness watchdog.

### 6.3 AUD-03 replacement

> **AUD-03** — The system MUST run an owner-tunable scheduled, read-only structural self-audit using a versioned rubric with declared dimensions, weights, denominators, and missing-data treatment. The one-screen output MUST show the total score, 3–5 strengths, top-three leverage-ranked gaps, one concrete next step per gap, and evidence references for every deduction. Unknown or unavailable evidence MUST be shown separately from a zero score. Independent security, verification, and resilience controls may be summarized only from their authoritative evidence sources; the self-audit cannot self-attest that they passed. The score informs prioritization and review but does not independently pass a gate.

### 6.4 LRN-09 replacement

> **LRN-09** — Governed learning MUST offer an owner-tunable periodic improvement ritual that presents a system-prepared, bounded shortlist and ships **at most one** accepted improvement artifact per cycle. Zero artifacts is a valid outcome when no candidate has a named KPI, passes scope/impact review, or justifies machinery. Selection follows the smallest-machinery ladder (template → deterministic mechanism → one-AI-call skill → sub-agent last). Urgent security, reliability, or corrective work is not delayed by the one-artifact cap, and owner review time is measured under CAP-01.

### 6.5 SEC-02 replacement

> **SEC-02** — An owner-voice profile MUST derive only from authentic, pre-existing owner-authored samples deliberately supplied or imported for that purpose; the system MUST refuse synthetic made-to-order samples and MUST provide no default or fallback person's voice. Samples and derived profiles receive a data class, provenance, access, retention, export, and deletion policy. Profile use, draft generation, draft approval, and external-send authority are separate action classes. Measured category-level correction rates may expand drafting/profile-use authority, beginning with per-draft approval, but MUST NOT by themselves authorize sending or bypass IDN/DAT/ACT/AUT controls. Every outbound artifact using the profile records the profile/version, drafting actor, approving authority/event, and applicable send policy; unlocks remain owner-visible and reversible.

### 6.6 CAP-03 replacement

> **CAP-03** — The system MUST produce token, usage, and cost telemetry from available local records and provider billing/usage sources as evidence for §18.1 and CAP-02. Every view MUST disclose provider/account coverage, date range, missing sources, and whether amounts are billed, estimated, or inferred. Collection parses usage metadata by default and MUST NOT ingest prompt/response content solely for cost calculation. The Stage-1 implementation may adopt or port the Herk token-dashboard where applicable, but the architecture remains multi-provider and source-replaceable.

### 6.7 ONB-01 replacement

> **ONB-01** — Onboarding SHOULD provide one coordinated, bounded setup session for every **currently known** integration and permission request, with a default cap of seven owner questions and per-answer persistence under MEM-09. Credentials and grants MUST be entered only through a protected secret-management/onboarding surface; secret values MUST NOT appear in Discord, model context, interview records, repositories, or ordinary logs. Granted capabilities remain inactive until their §11A.7 gates pass. The system MUST avoid trickle requests for grants already known at onboarding, but credential expiry, revocation, rotation, recovery, new integrations, changed scope, and risk-tiered step-up MAY require later owner reauthorization; such requests are batched and explained whenever feasible.

### 6.8 LRN-10 replacement

> **LRN-10** — When the same normalized manual task is observed in at least three distinct, verified occurrences within an owner-tunable window, the system MUST raise or update an automation-candidate observation for the next LRN-09 cycle. Retries, duplicate imports, repeated text, and untrusted external content do not independently count as occurrences. Threshold crossing remains weak evidence only and MUST NOT create an active automation, rule, skill, or policy without the governed topic workflow.

### 6.9 DEC-02 replacement

> **DEC-02** — Decision records classified as consequential under the applicable impact/risk policy MUST include a falsifier: evidence or conditions that would materially change or reverse the decision. When no meaningful falsifier is presently identifiable, the record may state `unknown` or `none identified` with rationale and a review trigger; the field MUST NOT force false precision.

### 6.10 AUT-12 replacement

> **AUT-12** — Each eligible automation class SHOULD progress toward the highest safe, evidence-supported, policy-authorized autonomy through a staged schedule: bounded low-volume full review → monitored autonomy → unsupervised execution where permitted. Advancement uses measured correction/reversal/failure outcomes, risk class, and calibrated confidence; raw model confidence alone is never an authority unlock. Stage durations are minimized when evidence supports advancement. Persistent owner approval or step-up remains valid where required by law, safety, sensitivity, irreversibility, owner judgment value, or insufficient evidence. Initial volume is a tunable pilot parameter, not a universal fixed ratio.

### 6.11 CAP-04 replacement

> **CAP-04** — Over a declared evaluation window, an automation whose measured total operating cost exceeds its measured total value MUST be flagged for retirement or redesign review at AUD-03. The comparison includes provider/tool spend, maintenance, failure burden, owner time, quality, risk reduction, and any mandatory or non-financial value. The flag does not automatically disable the automation. Safety, resilience, security, audit, and legally required controls are not retired solely because they are cost centers.

### 6.12 APP-06 amendment

Add to APP-06:

> For each material acceptance or evidence claim, the Builder Delivery Record identifies plausible evidence that would disconfirm the claim or expose a false-pass condition; a reasoned `N/A` is permitted where no meaningful discriminating test exists. This Builder-authored falsifier is review input only and never replaces independent reproduction or harness evidence.

### 6.13 SCH-02 replacement

> **SCH-02** — Every scheduled or cadence run MUST receive the smallest task-specific context sufficient for its objective **plus** a mandatory, versioned control envelope containing authenticated actor/authority, applicable trust and data classes, active scoped rules and automation policies, current checkpoint and schema versions, permitted tools/actions, failure and idempotency constraints, rollback/recovery requirements, and evidence/log destinations. The context pack and source manifest are hashed and time-bounded; missing, stale, or mismatched mandatory control context fails closed. The full workspace is not loaded by default.

### 6.14 DP-027 replacement

> **DP-027 — Automation-first for eligible execution:** repetitive execution should advance toward the highest safe, evidence-supported autonomy that policy permits. Manual review is transitional where it adds no durable judgment or protection value; persistent owner judgment, approval, or step-up remains a valid designed control for consequential, sensitive, irreversible, legally constrained, or insufficiently evidenced actions.

## 7. Required Revision 2 plan corrections

Before owner plan approval, Fable should publish Revision 2 with:

1. All CPB dispositions and M-01 through M-11 incorporated or explicitly contested.
2. Exact text for ADR-021, ADR-022, and DP-027; the ADRs must preserve canonical-store, data-protection, staged-activation, and owner-flag boundaries.
3. Exact or bounded Manual amendment text sufficient to prevent the Builder from making normative design choices.
4. Separate anticipated **implementation** and **gate/control-artifact** allowlists.
5. TASK-0002 allocation described as a Fable/control-plane append to the bootstrap registry after owner approval; the Builder receives no ID-allocation or lifecycle-state authority.
6. The source register classified as external/reference-only in the Task Packet; the owner-approved Revision 2 plan becomes the Builder's normative authority.
7. A self-contained, hash-bound baseline/context export for the TASK-0002 verifier packet.

## 8. Gate recommendation

```text
CP-v1.2-B Revision 1:          PASS WITH CHANGES
FLAG-1 owner confirmation:     RESERVED FOR OWNER
FLAG-2 owner confirmation:     RESERVED FOR OWNER
Owner plan approval now:       BLOCKED pending Revision 2 corrections
TASK-0002 allocation/release:  BLOCKED pending owner approval
Builder execution:             BLOCKED
Owner v1.2 acceptance:         Separate pending event
Phase 2 opening:               Still blocked by owner v1.2 acceptance
```

**Convergence rule:** Fable may incorporate the required changes and present Revision 2 directly to the owner for approval **without another pre-approval verifier round**, provided (a) no M finding is contested, (b) the meaning of the sixteen CPB items is not materially expanded, and (c) the exact high-severity boundaries above are preserved. If Fable contests a finding or makes a material semantic change, return only the contested/revised scope for targeted verification.

After owner approval, TASK-0002 must travel through the standing Task Packet → Builder Delivery Record → independent post-build verification → controlled integration path. This response does not authorize the build.
