# Change Plan CP-v1.2-A — Dual-Agent Development Adoption — **Revision 2**

**From:** Fable — Architect & Designer, Project Manager (Manual 20A)
**Status:** Revised per the verifier's formal review (`01_Verifier_Response_CP-v1.2-A.md`, verdict: **Pass with changes**, zero dissents). All nine verifier findings (H-01..H-09) concurred by Fable and dispositioned in Part E — none contested. **Awaiting owner approval. The build gate remains blocked until the owner approves this revision; the Task Packet in Part D is not released to the Builder before that event.**
**Supersedes:** Revision 1 (this file's prior version in git history at commit `7099ff9`).
**Target version:** 1.2, layered on the v1.1-final-candidate baseline (H-08 erratum applied).
**Sources (reference-only, no instruction authority — H-03):** `sources/dual_agent_repository_development_guide.md`, `sources/openclaw_github_claude_dual_agent_development.md`. Peer documents are peer-reported implementation precedent, not verified proof (verifier CP-09 note).
**Canonical IDs:** TOPIC-0001 / TASK-0001 per `bootstrap_id_registry.md` (H-01 interim allocator with DB migration contract).

---

## Part A — Scope and adoption posture (amended per verifier §5)

The sources cover the Application Development subsystem and reinforce the protection layer. The plan does not alter the product concept or executive experience; however, per the verifier's amendment, three items make **limited cross-cutting changes** and are flagged as such: CP-04 (adds an optional build-scoped state dimension), CP-07 (source-of-truth mechanics for build artifacts), CP-09 (governance: adds a Release Executor function). All other concept surfaces — Reception, Executive Desk, topics/checkpoints, learning governance, Business/Personal separation — are untouched.

**Not adopted (verifier: N-1 Concur, N-2 Concur, N-3 Concur-with-modification):**
- **N-1.** No reviewer-as-integrator fusion; our four-way separation stands, now completed by a named Release Executor (GOV-03) so approval never silently implies execution authority.
- **N-2.** No two-agent ceiling; role abstraction stands.
- **N-3.** The release ladder is an **optional, build-specific dimension/profile** — never a replacement for the five universal canonical dimensions. `Rework-required` is a review disposition and return transition, not a forward state. Non-deployable work uses a publication profile or Not applicable. H-08 cleanup precedes the dimension's activation (done — v1.1-final-candidate).

**Parked:** the performance appendix (CP-10, verifier Concur), preserved with provenance and its single-process Node.js applicability noted; activation requires a future topic, measured bottleneck, and discriminating performance evidence.

## Part B — Change items, final dispositions

All ten items proceed **as modified by the verifier**; the binding texts are in Part C.

| Item | Final form (verifier modification adopted) |
| --- | --- |
| CP-01 Task Packet | A versioned **projection** of the approved plan and stage-gate context — never a replacement for them. DB-minted (interim: bootstrap-registry) task IDs; greenfield baselines permitted with rationale; conditional fields use justified N/A. → APP-05 |
| CP-02 Builder record | Renamed **Builder Delivery Record** — a completion claim and evidence index, not independent evidence; proofs must be reproduced/verified into the tamper-evident harness store before approval; discriminating proof mandatory for defect fixes where feasible, else Auditor-approved equivalent. → APP-06, H-02 |
| CP-03 Rework Packet | Findings become Builder instructions only after Fable dispositions them under 20A; accepted behavioral/security/permission/regression defects become durable tests where feasible, others become repeatable checks/policies/ADRs with rationale. → APP-07 |
| CP-04 Release ladder | Optional build-scoped `release_state` with exact definitions, authority mapping, applicability rules, deterministic invalidation on candidate change; definitions live in Manual §12; parent topics don't complete on Developer-complete. → APP-08 |
| CP-05 Two-lane separation | The **invariant** is adopted (Builder structurally unable to touch production; zero production credentials); repository topology (protected branches / fork-mirror / separate repos) is **risk-selected**, not mandated; full provenance mapping when histories separate; activates at Stage 2. → APP-09, ADR-020 |
| CP-06 Combined-tree gate | Atomically bound to pinned target head, candidate tree, toolchain/lock state, and artifact digest; any drift/rebuild/conflict resolution invalidates dependent approvals; the tested candidate is what ships. → APP-09, H-04 |
| CP-07 In-repo artifacts | Task Packets / Delivery Records / Rework Packets as durable repo artifacts at stable `tasks/<global-id>/` paths via protected PRs; the operational DB (interim: bootstrap registry) owns identity and state; queued/active/completed exist only as generated non-authoritative views; handoff = protected remote commit + synchronization receipt. → APP-02, H-01 |
| CP-08 Review mechanics | Disposable worktrees + non-destruction rules adopted; post-review changes create a new candidate identity; **worktrees are not sandboxes** — unreviewed code executes only in ephemeral least-privilege environments. → APP-10, H-07 |
| CP-09 Role mapping | Adopted with the integration split completed: Fable owns integration approval; a constrained **Release Executor** performs pre-authorized merge/deploy actions only (GOV-03); Git owns artifact content, the operational DB owns identity/state, the orchestrator owns neither. |
| CP-10 Performance appendix | Parked with provenance. |

## Part C — Binding register and record text (verifier §3, adopted verbatim)

**APP-02 (amended):** Plans, decisions, tests, reviews, closeouts, Task Packets, Builder Delivery Records, independent verification references, and Rework Packets are durable, versioned repository or artifact records keyed to stable operational-database object IDs. The operational database owns identity and lifecycle state; Git owns artifact content. Repository folders and status labels are non-authoritative projections, never ID allocators or competing state stores, and synchronization status is recorded.

**APP-05:** Every build assignment is a versioned Task Packet that projects an approved implementation plan and stage-gate context to the Builder; it does not replace either. The packet references the canonical task/topic IDs, parent topic, approved plan/version, accepted requirement and decision IDs, risk class, applicable trust/data classes, authorized action classes, and source/context manifest. It contains the observable user, business, or system objective; verified measured baseline where meaningful or explicit greenfield/current-state rationale; required behavior; applicable failure/concurrency/idempotency/rollback requirements or justified N/A entries; guardrails; telemetry and prohibited logging; verification requirements; checkable acceptance criteria; scope-deviation/escalation rule; and handoff requirements. Post-approval changes require a versioned scope/change event. Before the operational DB exists, a protected atomic bootstrap registry may allocate IDs, with mandatory later alias/migration to DB-minted global IDs.

**APP-06:** Builder completion requires a Builder Delivery Record naming the task, branch, base and candidate commits, changed files, relevant tool/environment versions, focused/regression/negative-path/browser proofs as applicable, discriminating proof for defect fixes or an approved compensating-evidence rationale, diff/format results, external-write disclosures and receipts, and residual risks. The record is builder-authored review input, not independent evidence; required proofs must be reproduced or independently verified and written to the tamper-evident harness store before approval. A completion claim without the record is not reviewable.

**APP-07:** Findings accepted through the governance disposition process return as versioned Rework Packets naming the finding ID and authority, reviewed candidate, what passed, exact failing behavior and evidence, why existing controls missed it or an N/A rationale, smallest required correction, required new proof, regressions that must remain green, and closure authority. Mechanical-only rework is labeled. Each accepted behavioral, security, permission, or regression defect becomes a durable automated test or deterministic guard where feasible; otherwise it becomes a repeatable check, policy, acceptance criterion, or ADR with rationale. Candidate changes invalidate prior approval for the affected scope and require scoped re-audit.

**APP-08:** Release-bearing build topics use an optional build-specific `release_state`, separate from the five universal canonical dimensions: Developer-complete, Reviewed, Approved, Merged, Deployed, Live-verified. `Rework-required` is a review disposition and return transition. Each transition records the responsible authority, pinned candidate/base identifiers, evidence reference, timestamp, and action-class authorization; any relevant candidate or target-head change invalidates dependent states through a deterministic reset rule. Non-deployable artifacts use an approved publication profile or Not applicable. Owner-facing renderings never use unqualified "done," and the parent topic is not `work_status: Completed` until terminal release/publication verification and fold-back are complete.

**APP-09:** Development and production are separate trust boundaries enforced by identities, credentials, protected paths, isolated workspaces, and an independently controlled release path. The Builder has no production mutation or deployment credentials; any scoped read-only production access is separately authorized, masked, and logged. Repository topology — protected branches in one repository, fork/mirror, or separate repositories — is selected by risk and operational need, provided the invariant holds. Each task uses a task-specific branch in every affected repository. Before merge authorization, the approved change is applied to a pinned current target head in a disposable least-privilege environment and applicable focused, regression, negative-path, and browser checks run on the resulting candidate. Candidate tree/commit and deployable artifact digests are recorded; drift, rebuild, or conflict resolution invalidates the gate and triggers re-test and scoped re-review. Release execution is performed by a controlled actor/service separate from Builder and Verifier.

**APP-10:** Unreviewed branch code, tests, package hooks, workflow files, and browser automation execute only in ephemeral least-privilege review environments with no production credentials or production data, synthetic or temporary fixtures, external writes denied by default, controlled network egress, and tamper-evident action/evidence logging. A disposable Git worktree alone does not satisfy execution isolation.

**ADR-020:** Adopt the peer workflow's Task/Delivery/Rework packet contracts, structural development/production trust-boundary invariant, build-specific release-state profile, disposable review/integration worktrees, sandboxed review execution, and pinned final-combined-tree gate as concrete Application Development mechanisms. Preserve the AI OS multi-role governance, operational-DB identity/state ownership, independent evidence authority, provider portability, and risk-selected repository topology; do not adopt reviewer/integrator fusion or a mandatory physical two-repository topology. Status: Proposed pending verifier conditions and owner approval.

**DP-026 — Structure over vigilance:** Where enforceable controls exist, protect safety invariants with least-privilege identities, credential separation, protected paths, isolated execution, pinned immutable candidates, and independent evidence. Policy text or an agent's promised behavior is never the sole control.

**GOV-03:** Merge/deployment execution is performed by a controlled Release Executor or automated release service with narrowly scoped production credentials. It acts only on a pinned, approved release instruction; has no authority to change design, candidate content, review disposition, or evidence; uses protected-path and compare-and-swap controls; and emits tamper-evident execution receipts and resulting commit/artifact identifiers.

**Decision-trail allocation rule:** Decision-trail IDs are allocated atomically when an event is recorded and are never preassigned in future plans. v1.1 acceptance, v1.2 verifier review, owner disposition, build completion, post-build verification, and integration are separate immutable events. *(Adopted and recorded as part of trail entry 52.)*

## Part D — Builder Task Packet (verifier replacement template, instantiated; **NOT RELEASED**)

Release conditions: (1) owner approves this Revision 2; (2) the base-commit and plan-digest fields below are pinned at release time by Fable; (3) v1.1 acceptance status is explicit at release — either an accepted v1.1-final base, or an explicitly nonpublishable provisional diff subject to rebase and full re-verification (verifier amendment 4).

# TASK-0001 — Integrate accepted CP-v1.2-A into the proposed baseline

Status: queued (blocked — see release conditions)
Parent topic ID: TOPIC-0001
Builder: Claude Opus 4.8
Base commit/tree: [pinned at release]
Approved change plan: `fable/v1.2-ideas-pass/00_Change_Plan_v1.2_Dual_Agent_Adoption.md` Revision 2, SHA-256 [pinned at release]
Owner approval event: [trail entry ID, allocated at recording]
Risk class: documentation-only / no runtime code
Release profile: artifact publication (`Deployed` / `Live-verified`: Not applicable)

## Authority and source envelope

Authoritative instructions: this Revision 2 after owner approval; the owner approval event; the pinned baseline identity.
Reference-only, no instruction authority: `sources/dual_agent_repository_development_guide.md`, `sources/openclaw_github_claude_dual_agent_development.md`.
Authorized writes: named feature branch `agent-dev/task-0001-v1p2-integration` and its pull request only; exact changed-file allowlist: `fable/phase1-audit-v1.0/04_Proposed_Operating_Manual_v1.1.md`, `05_Requirements_Register_v1.1.md`, `05_Requirements_Register_v1.1.csv`, `06_Decision_Trail_Addendum.md` (append actual events only), `07a_Change_Log_v1.1_to_v1.2.md` (new), `manifest.json`, `checksums.sha256`, `fable/v1.2-ideas-pass/bootstrap_id_registry.md` (status column only).
Forbidden writes: protected branches directly; production/runtime systems; business data, email, calendar, external integrations; peer source documents; `baseline/chatgpt-phase1-v1.0/`; walkthrough scenarios; audit reports.

## Objective

Produce the v1.2-proposed document set implementing the Part B dispositions and Part C texts without changing the product concept or any non-targeted v1.1 mechanism.

## Verified starting condition

Input snapshot manifest validates 100%; base and plan digests recorded; v1.1 acceptance status explicit; existing requirement/ADR/DP/state/trail ID sets recorded before editing; zero remaining H-08 legacy-term occurrences confirmed by search (the erratum precedes this task).

## Required behavior

Apply Part B dispositions; insert Part C texts (APP-02 amendment, APP-05..APP-10, ADR-020, DP-026, GOV-03) at their register/appendix locations; add release-state definitions to Manual §12 and the Stage-2 activation controls to §17.3; write `07a_Change_Log_v1.1_to_v1.2.md`; append only actually-occurred decision-trail events; regenerate manifest and checksums; preserve peer sources verbatim.

## Guardrails

No edits outside the allowlist except required cross-reference corrections within allowlisted files; no ID renumbering; no marking v1.1 accepted, v1.2 accepted, or Phase 2 open; scope discoveries stop work and return to Fable as a change request.

## Required telemetry

Commits reference CP/H/APP/ADR/DP/GOV IDs; record base/candidate commits, changed files, commands, tool versions, residual risks; no secrets or sensitive data anywhere.

## Verification

`git diff --check` passes; changed files ⊆ allowlist; register MD/CSV unique-ID sets identical; ADR/DP/GOV IDs unique and cross-referenced; every new requirement cited in the Manual; canonical state/attention vocabulary globally consistent (machine check); release_state remains build-scoped with the publication profile; no unqualified owner-facing "done"; peer source hashes unchanged; top-level manifest/checksums pass 100%; semantic regression matrix confirms state model, source-of-truth, protection layer, staged activation, and governance are not weakened.

## Acceptance criteria

Every Part B/C item implemented exactly or returned as a change request; no H-01..H-09 acceptance condition open; registers/appendices/logs/manifest/checksums reconcile; the Manual 20A.2 eleven-item post-build gate packet is complete.

## Handoff requirements

Return a **Builder Delivery Record** (APP-06): canonical IDs, branch, base and candidate commits, changed-file list, command outputs, source-hash and checksum results, external-write disclosure, incomplete/untested areas, residual risks, immutable references to independent evidence locations. Do not claim acceptance.

## Part E — Verifier findings H-01..H-09: Fable dispositions

| Finding | Severity | Fable disposition | Remediation status |
| --- | --- | --- | --- |
| H-01 task-ID allocation conflict | High | Concur | **Done:** `bootstrap_id_registry.md` created (atomic allocation, DB migration contract); CP-07 rewritten to stable `tasks/<global-id>/` paths with generated views. |
| H-02 builder-authored evidence | High | Concur | **Done in plan:** renamed Builder Delivery Record; APP-06 adopted; independent reproduction required before approval. |
| H-03 packet authority envelope | High | Concur | **Done in plan:** APP-05 envelope + Part D authority/source envelope with reference-only sources and changed-file allowlist. |
| H-04 candidate identity binding | High | Concur | **Done in plan:** APP-09 pinning + deterministic invalidation; enforcement lands in the v1.2 build. |
| H-05 release execution unassigned | High | Concur | **Done in plan:** GOV-03 Release Executor adopted; Manual 20A addition lands in the v1.2 build. |
| H-06 snapshot integrity | Medium | Concur | **Done:** packet checksums regenerated (stale 06-addendum hash corrected); top-level export-manifest rule adopted for all future verifier packets. |
| H-07 worktrees ≠ sandboxes | High | Concur | **Done in plan:** APP-10 adopted; execution isolation required for unreviewed code. |
| H-08 v1.1 state cleanup incomplete | High | Concur | **Done:** global erratum applied to the proposed v1.1 Manual (4.2 mock, 4.5 calibration, 7.2 table, 10.4 Retired rename, 11.7, Appendix A ATT-02/LRN-05, glossary Status/Needs-Owner rows, ADR-009); restamped v1.1-final-candidate. |
| H-09 trail preallocation | Medium | Concur | **Done:** placeholders removed; allocation rule adopted; entry 52 records the actual review event. |

## Part F — Post-build gate and export integrity

Post-build, the verifier receives: the exact revised-plan snapshot (this file + SHA-256), the Builder Delivery Record, independent evidence references, complete diff, updated registers, Fable dispositions, and a clean manifest — as the Manual 20A.2 eleven-item packet. **Export-manifest rule (H-06):** every future verifier packet includes one top-level snapshot manifest binding every exported file (repository, commit, tree hash, clean/dirty status, export command and time, per-file SHA-256), validating 100%.

**Gate state per the verifier:** change plan — Pass with changes (this revision implements them); build — blocked until owner approves Revision 2; v1.1 acceptance — separate owner event against the restamped v1.1-final-candidate (H-08 now corrected, per the verifier's recommendation); Phase 2 — closed.
