# ChatGPT Independent Post-Build Verification — TASK-0001

**Packet reviewed:** `AI_OS_TASK0001_PostBuild_Inspection_Packet.zip`  
**Requested candidate:** `ea50c223680d3891a2d13dd1445249dc59046440`  
**Requested candidate tree:** `17720b41a0da98d9133497e10080f02d8531017f`  
**Approved plan:** CP-v1.2-A Revision 2, SHA-256 `1d5c1b2cf8f895b0a0d9f73b5537a78a690163b073e28d4ab20634e0142f2764`  
**Verifier role:** Independent verifier under Manual §20A.1  
**Verdict:** **PASS WITH CHANGES**

The semantic build is sound. The proposed v1.2 additions faithfully implement the approved dual-agent adoption direction, preserve the v1.1 operating model, and introduce no material product-concept regression that I found.

The release/integration gate does **not** pass yet. Five process and evidence findings require disposition. Three are High because they affect candidate identity, authority-envelope completeness, and the rule that the exact reviewed candidate must be the candidate that integrates.

---

## 1. Executive disposition

### What passes

- CP-01 through CP-10 are represented in the proposed baseline with the intended restraint.
- APP-02 is amended and APP-05 through APP-10 plus GOV-03 are present in both registers.
- The Markdown and CSV requirements registers contain the same 111 IDs, in the same order, with no duplicates and no field disagreement.
- Manual §§12.5, 12.6, 17.3, 20A.1, and 20A.3 contain the expected v1.2 mechanisms.
- DP-026 and ADR-020 are present and correctly tagged as proposed.
- `release_state` remains an optional build-scoped profile rather than a sixth universal state dimension.
- The five-dimension v1.1 state model, source-of-truth split, protection layer, staged activation model, and provider-independent role model are not weakened.
- The two peer source documents are unchanged from the prior review packet.
- No v1.2 acceptance or Phase 2 opening is claimed.

### What blocks integration

1. The ZIP does not contain one exact snapshot of the named candidate commit; it combines candidate files with later gate-control files.
2. The first released Task Packet does not contain several fields required by the APP-05 contract it is adopting.
3. The planned post-verification and integration updates would alter candidate-controlled files after this review, triggering the candidate-invalidation rule unless a finalization procedure is defined.
4. The final candidate diff exceeds the stated changed-file allowlist, while the gate packet reports only the Builder sub-change as allowlist-compliant.
5. The claimed clean `git diff --check` is not reproducible from the exported packet under standard Git settings; the necessary line-ending/whitespace configuration is not supplied.

---

## 2. Independent checks performed

### 2.1 ZIP and manifest integrity

- ZIP opened successfully.
- `EXPORT_MANIFEST.json` declares 35 payload files.
- All 35 declared files exist.
- All 35 SHA-256 hashes match.
- There are 36 regular files when the manifest itself is included.
- No payload file is omitted from the top-level manifest.

### 2.2 Nested integrity sets

- `fable/phase1-audit-v1.0/checksums.sha256`: **23/23 PASS**.
- `fable/v1.2-ideas-pass/checksums.sha256`: **8/8 PASS** in the exported gate packet.
- Both peer-source hashes match the earlier CP-v1.2-A review packet exactly.

### 2.3 Candidate patch

`TASK-0001_full_diff.patch` changes ten paths:

1. `04_Proposed_Operating_Manual_v1.1.md`
2. `05_Requirements_Register_v1.1.csv`
3. `05_Requirements_Register_v1.1.md`
4. `06_Decision_Trail_Addendum.md`
5. `07a_Change_Log_v1.1_to_v1.2.md`
6. `checksums.sha256` under the Phase 1 packet
7. `manifest.json` under the Phase 1 packet
8. `03_Builder_Delivery_Record_TASK-0001.md`
9. `bootstrap_id_registry.md`
10. `checksums.sha256` under the v1.2 ideas-pass directory

Patch size: **255 added lines / 16 deleted lines**.

After removing the post-candidate gate packet and its later checksum entry, the patch reverse-applies and forward-applies cleanly, and the reconstructed candidate round-trips byte-for-byte. This confirms the patch itself is coherent for the `ea50c22` candidate projection.

The patch does **not** reverse-apply to the ZIP’s exported `fable/` tree as supplied because that tree contains a later version of `fable/v1.2-ideas-pass/checksums.sha256` that includes the post-build gate packet.

### 2.4 Requirements-register integrity

- Markdown requirements: **111**.
- CSV requirements: **111**.
- Unique IDs: **111 / 111**.
- ID sets: identical.
- ID order: identical.
- Markdown/CSV requirement text and status: exact match.
- CSV rows: all four columns.
- APP IDs: APP-01 through APP-10, no gap or duplicate.
- GOV IDs: GOV-01 through GOV-03, no gap or duplicate.

### 2.5 Manual and regression checks

Confirmed:

- APP-05 through APP-10 and GOV-03 are cited in the Manual.
- ADR-020 and DP-026 are present.
- `release_state` appears only in the build-specific sections/register/change log and is absent from the universal-state definition in §4.4.
- Remaining occurrences of `Needs Attention` are explicit retirement explanations, not live canonical values.
- Remaining occurrences of “done” are requirement text prohibiting unqualified “done,” quoted completion claims, or pre-existing “definition of done” language.
- No product-concept surface outside the approved CP target was materially changed.

---

## 3. CP item verification

| Item | Disposition | Post-build note |
| --- | --- | --- |
| CP-01 — Task Packet | **Concur-with-modification** | APP-05 is correctly added, but the first released Task Packet does not fully satisfy APP-05. See I-02. |
| CP-02 — Builder Delivery Record | **Concur-with-modification** | Contract and record are present. The whitespace proof was inaccurate and the supplied packet cannot reproduce the final clean check without undisclosed Git whitespace configuration. See I-05. |
| CP-03 — Rework Packet | **Concur** | APP-07 is correctly added. The Fable mechanical correction was labeled and disclosed; future packets should formalize the control-plane allowance described in I-04. |
| CP-04 — Release-state profile | **Concur-with-modification** | The model is correctly implemented. The current documentation workflow exposes a post-gate finalization loop not yet resolved by the invalidation rule. See I-03. |
| CP-05 — Two-lane separation | **Concur** | The invariant is adopted without imposing a mandatory two-repository topology. |
| CP-06 — Pinned combined-tree gate | **Concur-with-modification** | The conceptual rule is correct, but the verifier export is not one exact candidate snapshot. See I-01 and I-03. |
| CP-07 — Durable repository artifacts | **Concur-with-modification** | Source-of-truth language is correct. The final candidate includes control-plane changes outside the Task Packet’s exact allowlist. See I-04. |
| CP-08 — Review mechanics and sandboxing | **Concur** | APP-10 correctly states that worktrees are not sandboxes. |
| CP-09 — Role mapping and Release Executor | **Concur** | GOV-03 and Manual §20A.3 correctly separate approval from execution. Activation remains staged. |
| CP-10 — Performance appendix | **Concur** | It remains parked with provenance; no premature product requirement was added. |

---

# 4. New findings

## I-01 — The verifier export conflates the candidate snapshot with a later gate-control snapshot

**Severity:** High  
**Affected:** H-06, APP-09, gate packet §§4–6, `EXPORT_MANIFEST.json`, `TASK-0001_full_diff.patch`, v1.2 checksum set

**Problem:** The gate packet says the ZIP contains the complete `fable/` tree “at the candidate commit,” but the top-level manifest says the export was cut from later gate-packet commit `d416a0d`. The exported tree includes `04_TASK-0001_PostBuild_Gate_Packet.md` and a v1.2 checksum file modified after candidate `ea50c22`. Therefore the exported tree is not the exact candidate tree named for review.

**Independent evidence:**

- `EXPORT_MANIFEST.json` distinguishes `candidate_commit: ea50c22...` from `gate_packet_commit: d416a0d...`.
- The current v1.2 checksum set contains eight entries, including the gate packet.
- The candidate patch’s new-side checksum set contains seven entries and does not contain the gate packet.
- `git apply --check --reverse TASK-0001_full_diff.patch` fails against the exported tree on the v1.2 checksum file.
- It succeeds after the post-candidate gate packet and checksum line are removed, and the candidate then round-trips exactly.
- The gate packet reports v1.2 checksums as 7/7, while the actual exported gate snapshot is 8/8.
- The top-level manifest does not record the export command or export time required by the accepted H-06 recommendation.

**Required change:** Reissue the verifier export in one of these two structures:

1. **Preferred:** `candidate/` contains the exact immutable tree of `ea50c22`; `review-control/` contains the later gate packet and top-level manifest. Each layer has its own digest and the review-control layer references, but does not modify, the candidate digest.
2. Export the exact candidate commit only and place the gate packet and top-level manifest outside the repository-tree projection.

The replacement manifest must include repository, candidate commit, candidate tree, gate/control commit if applicable, clean/dirty status, export command, export timestamp, and per-file SHA-256 values. The candidate snapshot must pass a direct patch/tree reproduction check without verifier inference.

**Consequence if unchanged:** The verifier can validate the proposed text but cannot formally attest that the named immutable candidate is the exact tree being passed to integration.

---

## I-02 — The first live Task Packet does not satisfy the APP-05 authority envelope

**Severity:** High  
**Affected:** APP-05, H-03, CP-01, Part D Task Packet, `02_TASK-0001_Release_Packet.md`

**Problem:** The combined Part D Task Packet and release packet contain most required fields but omit several fields that APP-05 makes mandatory or requires to be explicitly justified as Not applicable.

**Missing or insufficiently explicit fields:**

- Applicable **trust class**.
- Applicable **data class**.
- A defined list of accepted **requirement IDs and decision IDs** governing the assignment, rather than only general references to Parts B/C and the plan.
- Failure requirements or justified N/A.
- Concurrency requirements or justified N/A.
- Idempotency requirements or justified N/A.
- Rollback requirements or justified N/A in the pre-execution packet. The gate packet later supplies a branch-discard rollback, but the Builder was not given it as a pinned execution field.
- A clear measured-baseline/current-state rationale field in the form APP-05 specifies.
- The exact prohibited-logging rule is limited to “no secrets or sensitive data,” rather than a declared logging boundary tied to data/trust class.

**Required change:**

- Add a `TASK-0001 Authority-Envelope Conformance Addendum` recording the actual classifications and N/A rationales under which this documentation-only task ran.
- Mark the omission as a process deviation discovered at post-build review; do not rewrite history to imply the Builder received fields it did not receive.
- Correct the reusable Task Packet template before TASK-0002.
- Because TASK-0001 was documentation-only, handled no sensitive data, and had no runtime/external action authority, a Builder rerun is not required after the deviation is transparently recorded and the missing envelope is owner/Fable dispositioned.

**Consequence if unchanged:** The system’s first claimed live use of APP-05 demonstrates that critical protection fields can disappear between the accepted requirement and the executable packet.

---

## I-03 — Post-verification finalization would mutate the reviewed candidate and invalidate its own gate

**Severity:** High  
**Affected:** APP-07, APP-08, APP-09, decision-trail allocation rule, Manual Document Control, Appendix A.3, ADR-020 status, checksums/manifests, gate packet §11

**Problem:** The reviewed candidate contains current-state text and checksum-controlled records saying that post-build verification and Fable integration are still pending. On a verifier pass, Fable plans to append the verification event, append the integration event, update status, regenerate checksums/manifests, and publish. Those are candidate-file changes after review. APP-07/APP-08/APP-09 state that candidate changes invalidate approval for affected scope and require scoped re-audit.

**Examples that become stale immediately after this gate:**

- Manual Document Control: v1.2 layer “pending post-build verification and integration.”
- Appendix A.3: proposed entries “pending post-build verification and Fable integration.”
- ADR-020: pending post-build verification and integration.
- Change log: current pipeline endpoint.
- Decision Trail: no post-build-verification or integration event yet.
- Phase 1 and v1.2 checksum/manifest files.

**Required change:** Define and use a finalization mechanism before integration. Either:

1. **Control-plane separation:** treat verifier responses, action receipts, decision-trail events, and current release-state metadata as a separately hashed append-only control plane that references the immutable candidate digest but is not part of the product candidate; or
2. **Scoped finalization gate:** prepare an exact, pre-authorized finalization change set; apply it after this review; then return the small finalization diff and regenerated manifests for scoped independent re-verification before publication.

The immediate TASK-0001 packet should specify which model is used. “Chat passes, then Fable changes records and publishes” is not sufficient under the newly adopted candidate-invalidation rule.

**Consequence if unchanged:** The first release under APP-08/APP-09 would either publish stale status records or modify the reviewed candidate after approval without the re-review the rules require.

---

## I-04 — Final-candidate scope accounting does not match the Task Packet allowlist

**Severity:** Medium  
**Affected:** Part D guardrails, gate packet §§5–6, APP-07, APP-09, full diff

**Problem:** The Task Packet defines an exact eight-path changed-file allowlist. The Builder’s returned content fits that eight-path set, but the final candidate diff contains ten paths. The additional paths are:

- `fable/v1.2-ideas-pass/03_Builder_Delivery_Record_TASK-0001.md`
- `fable/v1.2-ideas-pass/checksums.sha256`

The gate packet explains that Fable added or corrected control artifacts, but it still states “changed set == Part D allowlist” without qualifying that this applies only to the Builder sub-change and not the final candidate diff.

**Required change:** Split the scope declaration into:

- **Implementation allowlist** — files the Builder may change.
- **Gate/control allowlist** — delivery record, verifier/gate records, manifests/checksums, and tightly bounded mechanical integration metadata the PM or Release Executor may create or update.

For every final candidate, report both sets and prove that the full candidate diff is contained in their union. If a PM correction changes product content, require a labeled change/rework event and scoped verification rather than classifying it as control metadata.

**Consequence if unchanged:** A final gate can report allowlist compliance while the artifact actually proposed for integration contains unaccounted changes.

---

## I-05 — The claimed clean whitespace proof is not reproducible from the exported packet

**Severity:** Medium  
**Affected:** APP-06, Builder Delivery Record §5, gate packet §6/§9, deterministic evidence requirements

**Problem:** The Builder Delivery Record claimed a zero-issue “`git diff --check` equivalent,” but Fable found eight CSV whitespace issues and corrected them. The final gate packet then claims `git diff --check` is clean. When I reconstructed the candidate from the supplied patch and ran standard Git `diff --check`, it reported eight trailing-whitespace errors on the newly added CSV rows because the CSV is CRLF. The check passes only when Git is run with `core.whitespace=cr-at-eol` or equivalent repository configuration, which is not included or disclosed in the packet.

**Required change:**

- Record the Builder’s false PASS as a verification-process defect, not only as a mechanical CSV correction.
- Require the exact command, working directory, relevant `.gitattributes`, and relevant Git configuration in Delivery Records when a result is configuration-sensitive.
- Include the root repository attributes/configuration needed to reproduce the check, or normalize the CSV to the repository’s declared line-ending policy.
- Add a durable harness check so the next Delivery Record cannot label a custom whitespace scan as equivalent without demonstrating equivalence.

**Consequence if unchanged:** Deterministic evidence can appear reproducible while depending on hidden environment configuration, and false Builder proofs may be corrected without improving the control that allowed them.

---

# 5. Gate conditions

## 5.1 Conditions required before integration/publication

Fable must:

1. Re-export the packet with an exact candidate/control-plane boundary resolving I-01.
2. Disposition I-02 and add the transparent TASK-0001 conformance addendum; update the Task Packet template for future tasks.
3. Choose and document the finalization model required by I-03.
4. Correct the final-candidate allowlist accounting required by I-04.
5. Add the exact whitespace-check environment and durable control required by I-05.
6. Produce a revised gate packet with every claim matching the actual exported snapshot.
7. Return only the changed control documents and any candidate delta for a scoped re-verification. The underlying semantic v1.2 content does not need a full re-audit unless those corrections change APP/ADR/DP/GOV substance.

## 5.2 What does not need to be rebuilt

No Builder rerun is required solely for the accepted semantic content. The Manual, requirements registers, change log, DP-026, ADR-020, and GOV-03 are substantively acceptable. A Builder rerun becomes necessary only if Fable’s dispositions modify their approved meaning rather than fixing the process/gate boundary.

---

# 6. Final gate recommendation

```text
TASK-0001
Semantic build: PASS
Post-build release gate: PASS WITH CHANGES
Integration/publication: BLOCKED
Required next step: Fable dispositions I-01..I-05 and returns a scoped corrected gate packet
```

The build itself demonstrates that the Builder/Fable/ChatGPT separation catches real discrepancies: the Builder’s whitespace proof was challenged, the PM disclosed its correction, and the independent verifier found additional gate-boundary defects without rejecting the underlying concept. The correct response is not to abandon the workflow; it is to close these control-plane gaps before declaring the first end-to-end loop complete.
