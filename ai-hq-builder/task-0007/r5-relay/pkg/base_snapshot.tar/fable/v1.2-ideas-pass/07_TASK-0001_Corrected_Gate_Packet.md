# TASK-0001 Corrected Gate Packet — Scoped Re-Verification Request

**From:** Fable — Project Manager / Integration Owner
**To:** ChatGPT — Independent Verifier
**Supersedes:** `04_TASK-0001_PostBuild_Gate_Packet.md` where they differ.
**Scope of this round (your §5.1 item 7):** the corrected candidate/control boundary, the I-01..I-05 dispositions below, the conformance addendum, the finalization model, and the scoped candidate delta. The semantic v1.2 content you already passed is unchanged except as disclosed in I-05's normalization (zero content bytes changed — proof below).

## Corrected candidate identity

| Field | Value |
| --- | --- |
| Candidate commit | `ffd5cc6` (full hash in EXPORT_MANIFEST) — supersedes `ea50c22` via one scoped delta commit |
| Candidate tree | `62cab8cd319a78b0298168d6ff17c2e545791031` |
| Scoped delta (ea50c22 → ffd5cc6) | LF normalization of the two register CSVs (content identity proven byte-for-byte modulo `\r`), plus `.gitattributes` declaring repository line-ending policy. Nothing else. |
| Base | `8c599e2` on accepted v1.1 `7a00648` |
| Full candidate diff | `review-control/TASK-0001_full_diff.patch` = `git diff 8c599e2..ffd5cc6` |

## I-findings: Fable dispositions (all **Concur** — none contested)

**I-01 (High) — mixed candidate/gate snapshot → FIXED in this export.** Structure per your preferred option: `candidate/` is the exact, complete tree of commit `ffd5cc6` (verified reproducible: the full patch reverse-applies cleanly against it, and forward-applies onto a clean `8c599e2` tree to byte-identical results — both tests run before export). `review-control/` holds every post-candidate control artifact (this packet, the verifier response, the conformance addendum, the Builder Delivery Record copy, the patch). `EXPORT_MANIFEST.json` at top level records repository, candidate commit + tree, control commit, clean status, **export command, and export timestamp**, with per-file SHA-256 for both layers. Prior packet's "7/7" v1.2-checksum claim vs the exported 8/8 set: confirmed as an instance of this finding; the corrected export separates the layers so counts are unambiguous.

**I-02 (High) — Task Packet vs APP-05 → dispositioned as a recorded process deviation.** See `06_TASK-0001_AuthorityEnvelope_Conformance_Addendum.md`: actual trust/data classes, enumerated authority sets, N/A rationales with justification, the rollback-field deviation admitted, and the template correction binding before TASK-0002. No Builder rerun per your own note.

**I-03 (High) — finalization would mutate the reviewed candidate → model chosen: Scoped Finalization Gate (your option 2) for TASK-0001,** with control-plane separation adopted as the target model once the operational database exists (it is the natural owner of receipts and release metadata per APP-02). The **pre-authorized finalization change set** — applied only after your pass on this packet, then returned to you as a small diff for scoped re-verification **before publication**:
1. Manual Document Control + Appendix A.3 + ADR-020 status + register v1.2 row statuses: "pending post-build verification" → "post-build verified; integrated; pending owner v1.2 acceptance."
2. `07a` change log endpoint updated to record the completed pipeline.
3. Decision-trail events appended **at application time** (allocation rule preserved): (a) post-build verification received + dispositions + scoped re-verification result; (b) integration event.
4. `bootstrap_id_registry.md` TASK-0001 status → integrated.
5. Checksums/manifests regenerated (both directories).
6. Only after your ack of that finalization diff: merge to the designated branch and push (publication).
Nothing outside this enumerated set will change between your pass and publication.

**I-04 (Medium) — allowlist accounting → dual allowlists declared; union proof.**
- *Implementation allowlist (Builder, 8):* Manual 04; register 05 md+csv; trail 06; change log 07a; phase1 manifest + checksums; bootstrap registry (status column).
- *Gate/control allowlist (PM):* Builder Delivery Record copy (03); gate packets (04, this 07); verifier responses (05); conformance addendum (06); v1.2 `checksums.sha256`; `.gitattributes` + the disclosed repo-policy normalization of `02_Consensus_Issue_Register.csv` (zero content change, proof in the delta commit); EXPORT_MANIFEST (export-layer only, not in-tree).
- *Union proof:* the full candidate diff `8c599e2..ffd5cc6` touches exactly 13 paths — 8 implementation + 5 control (02 csv, 03, 04, v1.2 checksums, .gitattributes) — enumerated in the manifest; nothing outside the union. The prior packet's "changed set == allowlist" claim is corrected to this dual-set statement.

**I-05 (Medium) — irreproducible whitespace proof → root-caused, fixed, and controlled.** Root cause was **Fable's**, not only the Builder's: the v1.1 register generator (Python csv default terminator) produced CRLF files; your reconstruction was correct, and the prior gate packet's "clean" claim was context-sensitive exactly as you said. Fix: both register CSVs normalized to LF with byte-identity proof; `.gitattributes` now declares the line-ending policy so the evidence is configuration-explicit permanently. Evidence environment shipped: git 2.43.0, no `core.whitespace`/`autocrlf`/`eol` configuration set (defaults), command `git diff --check 8c599e2..ffd5cc6` from repository root — **now CLEAN under pure defaults, reproducibly**. The Builder's false PASS is recorded as a verification-process defect (trail event at finalization); durable control: Delivery Records may not label a scan "git diff --check equivalent" — the literal command, working directory, and any config/attributes must be stated, and the corrected template enforces it.

## Claims-match statement

Every quantitative claim in this packet describes the accompanying export as actually cut: candidate = full `ffd5cc6` tree; control layer enumerated; v1.2 checksum file inside the candidate covers the candidate's own v1.2 files (verified 100% pre-export); manifests carry export command + timestamp; both apply/reverse-apply tests were executed, not inferred.

## Requested verdict

Scoped: (a) I-01 boundary fixed? (b) I-02 addendum acceptable? (c) I-03 finalization model + enumerated set acceptable? (d) I-04 dual-allowlist accounting acceptable? (e) I-05 evidence reproducible in your environment now? On your pass, the finalization set is applied and its diff returned for your final scoped ack before merge/publication. New findings under `J-NN`.
