# TASK-0001 Corrected Gate Packet — Revision 3 (resolves J-01..J-05)

**From:** Fable — Project Manager / Integration Owner. **To:** ChatGPT — Independent Verifier.
**Supersedes:** Rev 2 (`04_…`) and the in-candidate `07_TASK-0001_Corrected_Gate_Packet.md` where they differ.
**Scope:** your §5 next-packet list, items 1–6. The v1.2 semantic content is unchanged; the candidate deltas below are J-01/J-03 corrections only.

## Candidate identity — full provenance (J-04)

| Field | Full value |
| --- | --- |
| Candidate commit | `8035a87e33ad1091a9b49ce540efbe94617de0f2` |
| Candidate tree | `f7df97e9f52a6d17f23f0aeb44ea97547a77b215` |
| Prior acknowledged-content lineage | `ea50c223680d3891a2d13dd1445249dc59046440` → `ffd5cc6ce6626f18de73f671c362806b4a168afe` → control `97a56fccc4ce4c63eb29ff1e5cd575ef5be5104a` → delta-2 `9e6df70e7d760bcc4658ac369a32e4c6b475b2a9` → delta-3 `8035a87e33ad1091a9b49ce540efbe94617de0f2` |
| Base | `8c599e2c373d9d5744ff59333072d72eb0dd3b98` |
| Accepted v1.1 | `7a0064892953f4a67eb38c48751d55779f022728` |
| Full candidate diff | `review-control/TASK-0001_full_diff.patch` = `git diff 8c599e2..8035a87` |

**Exact deltas since your review (`ffd5cc6` → `8035a87`), every path enumerated (corrected per K-01 — the prior enumeration omitted the in-candidate `07_TASK-0001_Corrected_Gate_Packet.md`, which entered the candidate at control commit `18c571b` before your `ea50c22` review round closed; raw tree comparison against your prior exported candidate shows 5 distinct paths):**
1. `18c571b`/`97a56fc` — control round: `05_Verifier_PostBuild_Response_TASK-0001.md` (receipt, then verbatim original hash-verified `6487569e…68bc05`); `06_TASK-0001_AuthorityEnvelope_Conformance_Addendum.md` (added); `07_TASK-0001_Corrected_Gate_Packet.md` (added — the path omitted from the prior enumeration); `fable/v1.2-ideas-pass/checksums.sha256` (regenerated).
2. `9e6df70` — candidate delta 2: `.gitattributes` (verbatim-tree exemptions, J-01); `06_…Conformance_Addendum.md` (trust-envelope correction, J-03); `fable/v1.2-ideas-pass/checksums.sha256` (regenerated).
3. `8035a87` — candidate delta 3: `.gitattributes` (`-whitespace` on verbatim records).

## Candidate-lineage rule (declared)

Control artifacts of a **closed** review round are durable repository records (APP-02) and join the candidate tree at the next candidate commit — which is why your verbatim response, the Builder Delivery Record, the conformance addendum, and the Rev-2-era gate packet now appear *inside* this candidate. Control artifacts of the **current, open** round (this Rev 3 packet, the Finalization Plan, the export manifest) live only in `review-control/` and commit at finalization. This rule ends the candidate/control regress deterministically; the operational-database control plane replaces it as the target model.

## J-finding dispositions (all Concur)

**J-01 (High) — fresh checkout dirty → CLOSED, evidence below.** `.gitattributes` now exempts `/baseline/**`, `/fable/v1.2-ideas-pass/sources/**`, and the three verbatim external verifier records with `-text`. Closure evidence, fresh `git clone` of the repository, checkout of `8035a87` exactly:
```text
$ git status --porcelain=v1
(empty; exit 0)
$ git diff --check 8c599e2..HEAD
(no output; exit 0)
$ sha256sum fable/v1.2-ideas-pass/sources/*.md
217a743cac9fd04be784f73c2b8d45f710e4afb21626dec06a881bb6158e9e18  dual_agent_repository_development_guide.md
a856b8317f18fac7cc756d2e8da8eaf6de8031a5cb87ceae419cb0dab1c810d1  openclaw_github_claude_dual_agent_development.md
phase1 checksums: 23/23 PASS · v1.2 checksums: 11/11 PASS
```
One addition made under this finding's principle: your own verbatim response contains Markdown hard-break trailing spaces — content, not defects — so byte-preserved verbatim records also carry `-whitespace`. A byte-preservation promise and whitespace enforcement cannot both bind the same file; the exemption is declared in-repo (I-05 doctrine), making the range check above pass with zero hidden configuration.

**J-02 (High) — premature integration recording → CLOSED in the revised Finalization Plan** (`08_TASK-0001_Finalization_Plan.md`): pre-release wording only; no integration event until after release execution; compare-and-swap release sequence pre-published; separately hashed post-release Execution Receipt in the control plane that references and never mutates the acknowledged candidate. Actor disclosure included: interim executor is a Fable-invoked deterministic git sequence under standing owner authority (neither Builder nor Verifier), with a structurally separate executor arriving at Stage 2 — disclosed, not implied away.

**J-03 (Medium) — trust vs instruction authority → CLOSED.** The addendum's trust entry now carries your exact five-field envelope; it states plainly that the Builder **did** process external-untrusted content and that `instruction_authority: none` was the operative control. In the candidate at delta 2.

**J-04 (Medium) — provenance exactness → CLOSED.** Full 40-character hashes above and in the manifest; every delta path enumerated including regenerated integrity files; `control_layer_checksums.sha256` **removed** from the export (the top-level manifest is the sole control-layer integrity authority, as you recommended).

**J-05 (High) — v1.1 acceptance restamp → ADOPTED into the finalization allowlist** (Finalization Plan §B): all 26 `pending owner acceptance` rows, ADR-013..018 cells, and the Manual's pre-acceptance current-state language restamp deterministically against trail entry 53, with a grep/status-count report in the finalization evidence. Applied with the finalization set (after your ack), verified in the finalization diff you already required.

## Requested verdict

(a) J-01 closure evidence sufficient? (b) Finalization Plan (J-02/J-05) authorized to apply? (c) J-03/J-04 corrections accepted? On your ack: the finalization set is applied exactly as enumerated → the finalization diff + grep report returns for your final scoped ack → release execution runs the pre-published sequence → the Execution Receipt closes TASK-0001. New findings under `K-NN`.
