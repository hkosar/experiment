# TASK-0002 Release Packet — Integrate CP-v1.2-B Revision 2 (APP-05 Task Packet)

**Task:** TASK-0002 (bootstrap registry allocation 2026-07-27; owner authorization trail entry 64; Fable control-plane append per verifier M-05 — the Builder has no ID-allocation or lifecycle-state authority).
**Builder:** Claude Opus 4.8, separate window, no repository access; works on the exported snapshot; returns complete copies of changed files plus a Builder Delivery Record (APP-06, including the new falsifier element — applied reflexively to this build).
**Topic:** v1.2 ideas pass. **Risk class:** documentation-only / no runtime code. **Authorized action classes:** file edits within the implementation allowlist on the exported snapshot only.

## Pinned identities

- **Base (accepted v1.2 baseline + acceptance restamp):** commit `a22aea6e059d84bcfd0ed82dbf1a79c7b28ce0eb` (tagged `v1.2`, local per v1.1 precedent), branch `claude/ai-hq-workspace-design-e9j69h`.
- **Normative authority:** `15_Change_Plan_CP-v1.2-B_NateHerk_Adoption.md` **Revision 2**, SHA-256 `7e75035fde27cd844693874df4201fc5cedd7160d2346dd6b6ff0174b6d481a1`, owner-approved trail entry 64 (FLAG-1 confirmed; FLAG-2 ratified). Parts C and C2 are the exact texts to instantiate; the Builder exercises **no normative discretion**.
- **Reference-only (no instruction authority):** `14_NateHerk_Comprehensive_Review.md` (source register), `16_Verifier_Response_CP-v1.2-B_Rev1.md` (verifier record), peer sources under `sources/`.

## Objective and required behavior

Instantiate CP-v1.2-B Revision 2 into the accepted v1.2 baseline exactly as specified:

1. **Requirements Register** (`05_Requirements_Register_v1.1.md` + `.csv`): add the fourteen Part C rows verbatim — MEM-08, MEM-09, BUS-10, AUD-03, LRN-09, LRN-10, SEC-02, CAP-03, CAP-04, ONB-01, DEC-02, AUT-12, ORG-07, SCH-02 — status `v1.2-proposed (CP-v1.2-B)`, source `CP-v1.2-B (CPB-nn; trail 62)`; append the Part C APP-06 amendment text to the existing APP-06 row (status note: `Amended by CP-v1.2-B (CPB-14); v1.2-proposed`). **111 → 125 rows; MD and CSV ID sets identical; no renumbering; no other row changes.**
2. **Manual** (`04_Proposed_Operating_Manual_v1.1.md`): apply the eighteen Part C2 amendment texts verbatim at their stated anchors (§15.4, §13.5, §13.7, §7.5, §10.5, §15.3.1 + §7.3, new §11A.8, §18.1, §17.1/§17.2, §10.1, §6.3 + §8.6, §8.2.1 + §11.3, §10.4, §8.5, §12.6, §17.0, glossary WAT, Appendix A.3 extension); add ADR-021, ADR-022 (Part C2 texts verbatim; status `Proposed (v1.2, CP-v1.2-B)` pending release — the plan-approval acceptance language in those texts describes the owner event already recorded at trail 64, not a release claim) and DP-027 (verifier text verbatim) to their appendices; update the Contents list only as needed for §11A.8.
3. **Change log** (`07a_Change_Log_v1.1_to_v1.2.md`): append a CP-v1.2-B section (Added/Amended, process narrative through trail entry 64, register arithmetic), snapshot-truthful: built, **not** released, **not** claiming any gate beyond this build.

## Constraints (fail the task rather than violate)

- Only the three implementation-allowlist files change. The gate/control set — `bootstrap_id_registry.md`, `manifest.json`, `checksums.sha256`, packet/gate documents, decision trail, README — is **Fable-only**; do not touch.
- Nothing may be marked released, accepted, v1.3, or Phase 2-open; TASK-0002 status language stays "built; post-build verification pending."
- No ID allocation, renumbering, or lifecycle-state changes; peer sources and verifier records byte-preserved.
- LF line endings on all three changed files per repository `.gitattributes` policy; no trailing whitespace.
- Scope deviations are change requests back to Fable, never silent expansions.

## Verification requirements (Delivery Record must include)

- Per-file SHA-256 of every returned file; changed-set list proving allowlist conformance.
- Register proofs: row count 125, MD/CSV ID-set identity, CSV parsed row×field validation (**exact command and output**; the L-01 lesson — schema checks are mandatory, quoting-safe writer required).
- Whitespace/diff proof with the **exact command, configuration, and attributes context** (K-03 durable control; the TASK-0001 false-PASS may not recur).
- **Falsifier element (new APP-06 clause, reflexive):** for each material claim above, plausible evidence that would disconfirm it, or a reasoned N/A.
- Confirmation that no text outside the Part C/C2 payloads was authored by the Builder beyond mechanical anchoring (heading levels, list continuation).

## Handoff and gates after build

Builder returns changed files + Delivery Record → Fable applies and independently re-verifies on a local integration branch → post-build verification packet to ChatGPT (self-contained per M-10: exact current Manual/register + commit/tree binding evidence + disclosed exclusions) → verifier disposition → corrections if any → final acknowledgment → two-step compare-and-swap release under GOV-03 (transitional-executor disclosure applies unless a constrained executor exists by then) → owner v1.3-layer acceptance is **not** part of this task and is not claimed.
