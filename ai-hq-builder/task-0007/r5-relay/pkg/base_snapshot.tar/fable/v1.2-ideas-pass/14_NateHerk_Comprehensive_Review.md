# Comprehensive Review — Nate Herk's AI OS Resource Package (Idea Register for CP-v1.2-B)

**Status:** Fable review complete; awaiting owner item-by-item disposition. Approved items become change plan **CP-v1.2-B** and travel the established pipeline (Chat verification → owner approval → build → post-build verification → integration).

**Owner directive (verbatim, 2026-07-27):** *"I want us to explore Nate Herks package of offered AI OS resources to ensure that we have done a comprehensive review of his plan and that we are presenting the ideas worth stealing to me directly with your recommendations on why or why not the idea fits with our plan. I don't want to just do a quick scan, I want this single review to be comprehensive so that we know that we for sure have elevated our foundation to an extraordinate state so that we can feel confident proceeding to the next phase of development on this idea."* The owner also noted Herk has endorsed this style of reuse (his starter kit is MIT-licensed and distributed for exactly this purpose).

**Relation to prior work:** This supersedes and completes the parked survey at `../phase1-audit-v1.0/09a_Parked_Research_Nate_Herk_AIOS.md` (2026-07-25, breadth-only, explicitly not audit input). This document is the depth pass the owner asked for.

---

## 1. How this review was performed

Two independent research agents ran to completion on 2026-07-27; Fable synthesized their returns against the accepted v1.1 baseline plus the released v1.2 layer.

**Agent 1 — verbatim deep-read of the primary artifact** (`github.com/nateherkai/AIS-OS`, MIT, 991★): full 14-file inventory read file-by-file; the complete `/audit` scoring rubric reconstructed with its point math (25 points per "C", leverage = points lost × 1–4 impact multiplier, 4× reserved for "business blindness"); `/onboard` and `/level-up` interview mechanics extracted question-by-question; 24 mechanics not captured by the earlier breadth survey; and source-level defects noted (section 2).

**Agent 2 — ecosystem sweep beyond the starter kit:** his 11 public repositories (including `token-dashboard` and `a-bunch-of-skills` internals), four written guides, the Herk2 second-brain design (Inbox → Raw → Wiki), his 5-levels rubric with his own placement at Level 2, the Karpathy LLM-wiki pattern he builds on, two independent hardening derivatives (the GAIOS fork's Verification Gate and wiki-admission policy; Astro-Han's Grounding Invariant and four-way triage), the "grill-me + checkpointing" interview technique (provenance traced to Matt Pocock, not Herk), the criticism landscape, and an explicit "in his videos but NOT in the kit" delta list. Unverifiable claims (his revenue, "10x productivity," community-reported "95% token reduction") are flagged as self-/community-reported wherever they appear.

**Method note:** every idea below carries (a) exact source, (b) what it is in his words/mechanics, (c) Fable's recommendation with the specific v1.1/v1.2 requirement or Manual section it maps to, and (d) why it fits or doesn't. Nothing was scored by enthusiasm; several of his headline frameworks land in the reject tier.

## 2. What the deep-read found about the sources themselves

Reported for calibration, not mockery — it tells us how much weight the kit can bear:

- The AIS-OS repository froze at **2 commits (2026-04-30)**; no issues triaged, no fixes since launch. It is a published teaching artifact, not a maintained system.
- **Broken internal references:** CLAUDE.md references a `/decision` command that does not exist in the kit; the intake references a "Q90" that no interview contains.
- **Template leakage:** default voice-sample text is hardcoded (a user who skips the paste gets *Herk's* voice), and a "Herk-2" test string remains in shipped files.
- The kit ships **zero connections, zero cadence, zero security mechanics, zero verification** — all four exist only in his videos or paid community. Independent derivatives (GAIOS, Astro-Han) each had to add verification and grounding layers before daily use — i.e., they added what our baseline already has.
- Every generated artifact stamps trademark/attribution headers for the 3Ms™/4Cs™ — a viral-marketing mechanism inside an MIT kit.

**Consequence for us:** the value is in specific operational mechanisms (section 3), not in adopting his architecture — and our own pipeline (Builder Delivery Records with hash proofs, verifier gates, fail-closed checks) would have caught every one of the defects above before release. That is the comparison the owner asked this review to establish.

## 3. Tier 1 — ADOPT (7 items; recommend inclusion in CP-v1.2-B)

### A1. LLM-wiki memory pattern as the Stage 1–2 implementation of our memory contract
**Source:** Karpathy pattern as operationalized in Herk2 and his multi-wiki videos; hardened by Astro-Han and GAIOS derivatives.
**Mechanic:** per-domain `raw/` (verbatim source dumps) + `wiki/` (LLM-maintained cross-linked Markdown) + `index.md` (page inventory with one-line summaries) + `log.md` (activity record); navigation by index and links instead of similarity search; multiple wikis feed one OS. Ingestion ladder **Inbox → Raw → Wiki** (nothing enters the wiki unprocessed). Adopt with the two independent hardenings: **Grounding Invariant** (every wiki claim must cite its raw source; unsourced text is flagged, never silently kept) and the four-way ingestion triage (**New / Update / Disputed / No-material** — "Disputed" records a conflict instead of overwriting), plus the GAIOS **admission policy** (what is allowed into memory at all), which maps directly onto our DAT data classes.
**Why it fits:** v1.1 deliberately fixed the memory *contract* before choosing a provider (MEM-04, ADR-011). This is the first concrete implementation that is 100 % Claude-native, plain files, portable, inspectable, and consistent with our append-only/provenance rules (LOG, TRS). It gives Stages 1–2 real memory without committing us to a vector DB. G-Brain remains the contract's possible later provider — unchanged.
**Maps to:** MEM-04 implementation profile; DAT classes govern admission; TRS supplies the provenance fields the Grounding Invariant needs.

### A2. Connections registry + per-tool reference docs with freshness discipline
**Source:** `connections.md` + the "when you wire a new tool, also save `references/{tool}-api.md`" rule.
**Mechanic:** one registry of every reachable system — tool, mechanism (`mcp`/`script`/`export`/`key+ref`/`not yet connected`), auth status, **last-verified date** — plus a captured-once API reference per tool. His 7 Tier-1 domains translate cleanly to the owner's: QuickBooks (revenue), the AP webtool (leads/operations), call transcripts, email, calendar, project state, knowledge files.
**Why it fits:** solves silent MCP/auth rot and re-research waste — failure modes our baseline names (BUS-02/BUS-04) but doesn't yet give an artifact for. The last-verified column becomes a watchdog input (11A.5).
**Maps to:** BUS-02, BUS-04; feeds RES watchdog; the registry is a natural early Stage-1 artifact.

### A3. Weekly scored self-audit — mechanism adopted, his rubric replaced
**Source:** `/audit` skill (read-only gap report, 0–100, leverage-ranked, ~60-second output).
**Mechanic to adopt:** a scheduled, read-only, scored structural scan whose output is a one-screen scorecard: total score, 3–5 strengths, top-3 gaps each with a concrete next step, ranked by leverage (points lost × impact multiplier).
**What we replace:** his Four-Cs scoring dimensions with **our** health dimensions — protection-layer coverage, checkpoint freshness, connection auth freshness (A2), review-queue depth, memory-hygiene (A1 triage backlog), capability escalation-ladder compliance. Scoring against his 4Cs would grade us on his architecture.
**Why it fits:** directly fixes C-35 (housekeeping needs a trigger, because "self-administered protocol gets skipped" — the owner's own stated constraint). A scored weekly scan the coordinator runs and *presents* costs the owner nothing to remember.
**Maps to:** C-35 disposition; QUE-01 review queue; 18.1 measures; runs under SCH cadence rules.

### A4. Weekly improvement ritual with a one-artifact cap and KPI stop-rule
**Source:** `/level-up` skill.
**Mechanic:** weekly interview that ships **exactly one** improvement artifact: candidates ranked (what repeated 3+ times, drudgery, delegable, constraint, growth lever) → the 5-element process articulation with a hard stop if the owner can't name the KPI it moves → smallest-machinery handoff (prompt template → deterministic script → one-AI-call skill → sub-agent **last**) → one decision-log entry + one artifact + one-screen summary.
**Why it fits:** this is the operating loop for our governed-learning pipeline (observations → topics → rules/skills) with built-in anti-sprawl — the one-artifact cap and KPI-or-stop rule are precisely the convergence discipline the owner demanded of our own verification loops (trail entry 57). Also implements CAP-01's adopt-before-build posture and gives C-12's consolidation review a weekly home.
**Maps to:** LRN pipeline operating cadence; CAP-01; C-12; output artifacts obey the A3-audited escalation ladder.

### A5. Checkpointed interview technique (credit: Matt Pocock)
**Source:** "grill-me + checkpointing" — provenance traced by Agent 2 to Matt Pocock; Herk popularized it.
**Mechanic:** during any long structured interview, every answer is persisted to disk *as it is given* (not at the end), so a crashed or interrupted session resumes at the exact question, and the answer file — not the chat scrollback — is the source of truth.
**Why it fits:** it is our checkpoint doctrine (MEM-05/06/07: checkpoints outside model context, reconciliation-on-resume) applied to a workflow we definitely run — owner interviews and kickoff records (7.3). Cheap, zero new concepts, closes a real crash-loses-interview gap.
**Maps to:** MEM-05..07 applied to interview/kickoff flows; Reception (4.1) capture semantics.

### A6. Voice capture with a refusal rule — plus a new impersonation-disclosure rule
**Source:** `references/voice.md` mechanics + his standing instruction "never adopt this voice for external communications without explicit approval and draft review."
**Mechanic:** raw **pasted** writing samples only (typed-to-order samples refused — they're performances, not voice); voice used for register-matching internally; hard refusal on external use without explicit approval of the specific draft.
**Our addition (new rule, gap in our baseline):** any outbound communication drafted in the owner's voice must carry an internal provenance mark (which agent, which approval) — the protection layer currently governs *inbound* trust (TRS) and consequential *actions* (ACT/harness) but has no explicit rule for *outbound impersonation*. This review surfaces that as a genuine baseline gap.
**Maps to:** new SEC/COM requirement (drafted in CP-v1.2-B); interacts with 11A.1 step-up for send-class actions; DAT render classes govern where drafts may appear.

### A7. Token/cost dashboard for the cost-side success measures
**Source:** `token-dashboard` repo (646★) — parses Claude Code's local JSONL session logs into per-day/per-model/per-project token and cost analytics.
**Why it fits:** 18.1 added cost-side measures (C-05/C-12) and CAP-02 requires capacity/cost review — but nothing yet *produces* those numbers. This is a working, local, read-only implementation; adopt as a Stage-1 utility (use or port, don't rebuild).
**Maps to:** 18.1 cost measures; CAP-02 evidence feed; A3's scorecard consumes it.

## 4. Tier 2 — ADAPT (9 items; adopt the idea, reshape to our design)

| # | Idea (source) | Adapt into | Fable recommendation |
|---|---|---|---|
| B1 | `/onboard` discipline: hard 7-question cap, resume-safe, **no credentials on Day 1** | Stage-1 activation (17.2) | Adopt the *discipline* (question cap, staged trust, resume safety via A5) for our own Stage-1 owner setup; our content differs — we onboard against the accepted Manual, not his intake. |
| B2 | "Flag manual tasks repeated **3+ times**" standing instruction | C-34 observation threshold | Adopt 3-repetitions as the **default** observation-promotion threshold in governed learning; keep it a tunable, owner-visible number. |
| B3 | Decision log's "Alternatives considered" plus GAIOS's sharper variant | Decision objects / trail template | Add a **"what would change your mind"** field (falsifier) to consequential Decision records; our trail already captures Decision/Why/Owner. |
| B4 | Bike Method staged rollout (manual → 100 % review → monitored → unsupervised; start at 10 % volume; confidence thresholds route auto/draft/escalate) | 11.3 merge/action classes + 8.2.1 staged routing | Our staged adaptive routing already unlocks by measured correction rates; adopt his **explicit volume percentages and confidence-threshold routing table** as the concrete unlock schedule. |
| B5 | Economic kill switch ("kill automations costing more than they save") | LRN-06 retirement + CAP-02 review | Add cost-vs-saved as a standing retirement criterion evaluated at the A3 weekly audit; distinct from the *safety* kill switch (IDN), which stays absolute. |
| B6 | Three-Question folder test (distinct? 3+ touches/month? future routing target? "two yeses = add") + quarterly archive sweeps | ORG-05 coaching rules | Adopt as the coordinator's *coaching* heuristic when the owner asks for new structure — advisory, never a gate on capture (DP-001 capture-without-classification is inviolable). |
| B7 | GAIOS Verification Gate: "What was done right / how was it checked / what would prove it wrong" | Task Packet (APP-05) / Delivery Record (APP-06) | Add the **falsifier question** to Delivery Record self-verification — the Builder must state what evidence would disprove its claim. Our L-01 episode (a "passing" check that validated the wrong property) is the exact failure this prevents. |
| B8 | Lean-repo-per-routine hygiene (scheduled runs get minimal dedicated context, not the whole OS) | SCH cadence design | Adopt when cadence activates (Stage 3+): each Routine gets a scoped context slice, not the full HQ tree — cost and blast-radius control. |
| B9 | WAT framing (Workflows / Agents / Tools) as teaching vocabulary | Glossary note only | Provenance ambiguous (community contests his coinage); useful when explaining the system to others; cite carefully, no design change. |

## 5. Tier 3 — ALREADY COVERED (validation, not adoption)

These confirm our foundation independently arrived at the same or stronger mechanisms:

| His mechanism | Our existing coverage |
|---|---|
| Autonomy Spectrum L0–L4, lowest-that-works default | 8.2.1 staged adaptive routing + 11.2 harness tiers + Staged Activation (17) — ours adds measured unlock criteria |
| Intern Rule (own identity, read-only default, minimal scopes, audit trail) | 11A protection layer — IDN, TRS, DAT, LOG, RES, ACT — ours is a threat model, his is a checklist |
| Cadence-last dependency order; "don't automate what doesn't work manually" | Staged Activation Plan gates + adopt-before-build (CAP-01) |
| Sub-OS folders per vertical with scoped manuals | Recursive hubs/topics with typed-role tree (6.1) — ours is native, not bolted on |
| Skill scarcity / sub-agents last | CAP-01 + the A4 escalation ladder formalizes it |
| Curiosity Rule (no dark code you can't explain) | Harness evidence + coverage disclosure (11.2); Delivery Record proofs |
| 5-levels rubric; his own system sits at **Level 2** | Validates our file-first Stage 1–2 choice: the most-followed practitioner in this space runs at exactly the level our plan starts at, by choice |
| Portability doctrine (plain files, boot in second harness as fire drill) | DP on provider-independence + memory-contract-before-provider (ADR-011); his fire-drill test is worth borrowing into RES verification |

## 6. Tier 4 — REJECT (with reasons)

1. **Trademark/attribution stamps in every generated artifact** (3Ms™/4Cs™ headers). Viral marketing embedded in outputs; violates our clean-provenance rules. Ideas credited here in the trail; no stamps in artifacts.
2. **His Four-Cs rubric as our audit dimensions.** Grades conformance to *his* architecture (e.g., his `/audit` scores Connections higher if write-capable — directly against our read-only-first posture). Mechanism adopted (A3); rubric replaced.
3. **Hardcoded voice defaults.** The kit's fallback-to-Herk's-voice defect is the exact anti-pattern A6's refusal rule exists to prevent.
4. **Fixed 60/30/10 automation split as a rule.** Useful intuition, arbitrary as a target; our split emerges from measured correction rates and KPI stops, not a preset ratio.
5. **Felt-indicators replacing metrics** ("Expect the Dip," "~2x after two weeks"). Motivational calibration, fine in prose; never admissible as success measures against 18.1.

## 7. What this review establishes about our foundation

1. **Nothing in his package contradicts our concept.** The strongest ideas (wiki memory, connections registry, weekly rituals) slot *into* existing v1.1/v1.2 contracts as implementations — none required reopening an accepted decision.
2. **Both independent hardening derivatives of his kit added what we already have.** GAIOS added verification gates; Astro-Han added grounding/provenance. Our baseline shipped with both classes of control before we read either.
3. **Our pipeline would have caught his kit's defects** (frozen repo, broken references, template leakage) — the Delivery-Record/verifier/fail-closed-check machinery exists precisely so those never reach a release.
4. **His own operating choice validates our sequencing:** he runs at Level 2 of his own 5-level ladder and warns against climbing for its own sake — the same judgment as our staged activation and adopt-before-build rules.

## 8. Requested owner disposition

Each item is individually acceptable or rejectable. On the owner's approvals, Fable drafts **CP-v1.2-B** covering the approved set (with exact requirement texts, Manual sections, and register rows) and routes it through the established pipeline: ChatGPT verification → owner approval → Opus 4.8 build → ChatGPT post-build inspection → Fable integration → release.

**Fable's recommendation:** approve Tier 1 (A1–A7) and Tier 2 (B1–B8; B9 is glossary-only) in full; note Tier 3 as validation; ratify Tier 4 rejections.

Separately pending and unaffected by this review: the owner's **v1.2 acceptance** (trail entry 59/60), which gates Phase 2.

---

*Prepared by Fable (project manager/architect) from two completed research-agent returns, 2026-07-27. Research agents' primary-source reads were of public repositories and published guides; self-reported performance claims are marked as such throughout.*
