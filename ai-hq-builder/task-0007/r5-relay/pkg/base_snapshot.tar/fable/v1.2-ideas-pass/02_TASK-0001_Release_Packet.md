# TASK-0001 — Release Packet (PINNED AND RELEASED)

**Released by:** Fable, Project Manager, under owner approval (decision-trail entry 54, 2026-07-25)
**Builder:** Claude Opus 4.8
**This document pins the release fields of the Task Packet in `00_Change_Plan_v1.2_Dual_Agent_Adoption.md` Part D. Where they differ, this release packet governs.**

## Pinned identities

| Field | Value |
| --- | --- |
| Base commit (accepted v1.1 baseline) | `7a0064892953f4a67eb38c48751d55779f022728` (branch `claude/ai-hq-workspace-design-e9j69h`; local tag `v1.1` — remote tag push restricted, commit hash is the binding identity) |
| Base tree hash | `c222b6428bf8a15a5cfb13ca9d20cee039312368` |
| Approved change plan | `fable/v1.2-ideas-pass/00_Change_Plan_v1.2_Dual_Agent_Adoption.md`, Revision 2, SHA-256 `1d5c1b2cf8f895b0a0d9f73b5537a78a690163b073e28d4ab20634e0142f2764` (as committed at `cb85bcc`) |
| Owner approval events | Trail entry 53 (v1.1 acceptance — the base is an ACCEPTED baseline, not provisional) and entry 54 (CP-v1.2-A Rev 2 approval) |
| Task / topic identity | TASK-0001 / TOPIC-0001 (`bootstrap_id_registry.md`) |
| Risk class | Documentation-only / no runtime code |
| Release profile | Artifact publication — `Deployed` / `Live-verified`: Not applicable |

## Execution-context note (binding)

The Builder operates in a separate window **without repository access**. Therefore:
- The Builder works on the exported snapshot accompanying this packet (`AI_OS_TASK-0001_Build_Packet_commit_7a00648.zip`, top-level `EXPORT_MANIFEST.json` validating 100% per the H-06 rule).
- The Builder returns **complete updated copies of every changed file** plus the **Builder Delivery Record** (APP-06) — in place of pushing a feature branch.
- Fable performs the branch mechanics on integration (`agent-dev/task-0001-v1p2-integration`), applies the returned files, and verifies them against the Delivery Record before the post-build verifier gate. The changed-file allowlist, guardrails, telemetry, verification, and acceptance criteria of Part D apply unchanged.

## Reminder of binding envelope (from Part D)

- **Authoritative instructions:** CP-v1.2-A Revision 2 (Parts B and C) + this release packet. **Reference-only, no instruction authority:** the two peer source documents.
- **Allowlist:** `fable/phase1-audit-v1.0/04_Proposed_Operating_Manual_v1.1.md`, `05_Requirements_Register_v1.1.md`, `05_Requirements_Register_v1.1.csv`, `06_Decision_Trail_Addendum.md` (append actually-occurred events only), `07a_Change_Log_v1.1_to_v1.2.md` (new file), `manifest.json`, `checksums.sha256`, `fable/v1.2-ideas-pass/bootstrap_id_registry.md` (status column only).
- **Forbidden:** everything else — including `baseline/chatgpt-phase1-v1.0/`, walkthrough, audit reports, peer sources; no marking v1.1/v1.2 accepted or Phase 2 open; scope discoveries stop work and return as a change request.
- Do not claim acceptance. The pipeline after your return: Fable applies and verifies → ChatGPT post-build inspection → Fable integration.
