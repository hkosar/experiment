# Building a Safe Dual-Agent Repository Development Workflow

## Overview

This guide describes a repository development workflow in which one AI agent implements changes and a
second AI agent independently reviews and integrates them.

The design combines:

- An agent orchestration platform for communication and controlled tool access.
- A development agent working in an isolated repository lane.
- GitHub for branches, pull requests, protected handoffs, and audit history.
- A second agent acting as reviewer and release integrator.
- A human operator retaining authority over priorities and production changes.

The central safety property is simple:

> The agent that writes a change cannot independently move that change into production.

This guide is intentionally organization-neutral. Replace placeholders with your own repository names,
paths, services, and access controls.

## Why Use Two Agents?

A single agent can plan, implement, test, review, merge, and deploy quickly—but that concentration of
authority creates familiar engineering risks:

- The same reasoning error can affect both implementation and review.
- Tests may confirm the implementation rather than the requirement.
- A confident completion summary may hide an untested user path.
- A coding agent may work from a stale branch without noticing production drift.
- Accidental production access can turn a development mistake into an outage.

A dual-agent model introduces an independent verification boundary:

- **Agent A — Developer:** implements scoped work in isolation.
- **Agent B — Reviewer/Integrator:** inspects the diff, reproduces evidence, tests the combined production
  tree, requests rework, and controls release integration.
- **Human operator:** authorizes consequential actions such as external communication and deployment.

This resembles a conventional developer plus reviewer/release-engineer workflow, implemented with agents.

## Architecture

### 1. Orchestration layer

Use an agent orchestration platform to:

- Receive requests from approved channels.
- Supply scoped tools and workspace context.
- Maintain durable task state.
- Separate read-only inspection from mutating actions.
- Require authorization for external sends, destructive operations, merges, and deployments.
- Return evidence-backed status to the human operator.

The orchestrator should not be treated as source control. Git remains the authority for code history and
reviewable change sets.

### 2. Isolated development lane

Give the development agent:

- A dedicated working copy.
- A dedicated remote repository or tightly controlled development namespace.
- A protected coordination branch.
- One feature branch per task.
- A task directory stored with the repository.
- No direct production deployment path.

Example branch convention:

```text
agent-dev/task-042-short-description
```

Example task directories:

```text
tasks/queued/
tasks/active/
tasks/completed/
```

The development lane may contain experimental work, but a successful push must not alter production.

### 3. Production lane

Maintain production as a separate trust boundary:

- A separate checkout or repository.
- A protected production branch.
- A controlled integration process.
- A service manager or deployment platform independent from the development checkout.
- Production credentials unavailable to the implementation agent unless explicitly required and approved.

Do not allow an implementation agent to deploy merely by pushing its feature branch.

### 4. GitHub handoff

Use GitHub to provide:

- Protected branches.
- Pull requests for instruction and review packets.
- Named feature branches.
- Commit history.
- CI checks where available.
- A visible record of task assignment, rework, and completion.

Branch protection should reject direct updates to the coordination and production branches.

## Role Definitions

### Human operator

The operator:

- Selects priorities.
- Resolves product and business-definition questions.
- Authorizes external communication.
- Approves destructive or irreversible operations.
- Separately authorizes merge and deployment.

### Development agent

The development agent:

- Reads a written task packet.
- Creates the requested feature branch.
- Changes only the approved scope.
- Adds focused behavioral tests.
- Runs required regressions.
- Publishes an evidence packet.
- Stops when a packet-defined scope boundary is reached.
- Never self-approves for production.

### Reviewer/integration agent

The reviewer:

- Reads the actual diff.
- Checks behavior against the task packet.
- Re-runs the developer's proof.
- Runs neighboring regressions.
- Uses a real browser for interactive behavior.
- Tests integration against the current production head.
- Approves or sends a precise rework packet.
- Merges and deploys only when authorized.

## Task Packet Design

Number tasks consistently:

```text
TASK-001
TASK-042
TASK-105
```

Before assigning an identifier, search queued, active, and completed tasks plus recent branches. Do not
infer the next identifier from chat history.

### Recommended task packet

```markdown
# TASK-NNN — Short title

Status: active
Owner: Development agent
Branch: `agent-dev/task-NNN-short-description`

## Objective

Describe the user-visible outcome.

## Verified starting condition

Record the observed defect, timing, error, or missing behavior.

## Required behavior

List exact functional requirements.

## Failure and concurrency requirements

Define timeout, retry, stale-data, atomicity, and single-flight behavior where relevant.

## Guardrails

State what must not change and which writes or integrations are forbidden.

## Required telemetry

Define useful events and prohibit sensitive logging.

## Verification

Specify focused, regression, negative-path, and browser proofs.

## Acceptance criteria

Use checkable outcomes.

## Handoff requirements

Require branch, commit, commands, results, changed files, and residual risks.
```

### Good packet characteristics

A useful packet answers:

- What does the user need to experience?
- Which files or surfaces are in scope?
- Which business rules must remain unchanged?
- Are writes or network calls authorized?
- What should happen when dependencies fail?
- What test would fail on the old behavior?
- What broader tests must stay green?
- Is deployment explicitly prohibited?

Avoid vague instructions such as “improve performance” or “fix accessibility” without a measured starting
condition and observable acceptance criteria.

## Development Workflow

### Step 1: Assign

Add the task packet to the protected coordination branch through a pull request.

Generic flow:

```bash
git fetch origin coordination
git switch -c packet/task-NNN-short-description origin/coordination

# Add tasks/active/TASK-NNN-short-description.md

git diff --check
git add tasks/active/TASK-NNN-short-description.md
git commit -m "Add TASK-NNN implementation packet"
git push -u origin packet/task-NNN-short-description
```

Open and merge the packet pull request according to repository policy.

Verify that the packet exists on the remote coordination branch. A local commit is not a completed
handoff.

### Step 2: Implement

The development agent creates the named feature branch from the current coordination base:

```bash
git fetch origin coordination
git switch -c agent-dev/task-NNN-short-description origin/coordination
```

The agent should:

1. Confirm the starting condition.
2. Stop if a required production helper is absent from its base.
3. Implement the smallest complete change.
4. Add a behavioral proof.
5. Run focused and broad tests.
6. Confirm formatting and diff cleanliness.
7. Write a completed evidence packet.
8. Push the feature branch.

### Step 3: Return evidence

Recommended evidence format:

```markdown
## Delivery record

- Task: TASK-NNN
- Branch: `agent-dev/task-NNN-short-description`
- Commit: `<commit>`
- Base: `<coordination commit>`
- Changed files:
  - `path/to/file`
- Focused proof:
  - `command` — PASS
- Regression proof:
  - `command` — PASS
- Browser proof:
  - scenario and visible assertion
- Discriminating proof:
  - restored old behavior and exact failed assertion
- Diff check: PASS
- External writes: none
- Residual risks:
  - explicit list
```

## Independent Review Workflow

### 1. Discover candidate work

```bash
git fetch --all --prune
git branch -r --sort=-committerdate
git log -1 --format="%h %cI %s" origin/agent-dev/task-NNN-short-description
git diff --stat origin/coordination...origin/agent-dev/task-NNN-short-description
```

Confirm that the branch contains implementation code. A branch containing only planning documents is not
ready for code review.

### 2. Use a disposable worktree

```bash
review_dir=$(mktemp -d /tmp/taskNNN-review.XXXXXX)
git worktree add --detach "$review_dir" origin/agent-dev/task-NNN-short-description
```

Run review commands inside the temporary worktree. This prevents the reviewer from disturbing another
agent's checkout.

### 3. Inspect the diff

Review for:

- Correct business rules.
- Authorization and feature-gate preservation.
- Unexpected writes or external requests.
- Blocking work added to a web request path.
- Timeout, retry, idempotency, and concurrency behavior.
- Sensitive-data logging.
- Escaping and accessibility.
- Misleading success or failure messages.
- Completed-packet claims that are not rendered or reachable.

### 4. Re-run the focused proof

Do not accept the developer's output text as evidence. Run the command again.

Confirm the proof calls real production functions. A test that duplicates the implementation inside the
test can pass while the application remains broken.

### 5. Run neighboring regressions

Choose tests based on the changed surface:

```bash
node scripts/focused-test.js
node scripts/related-regression.js
node scripts/browser-interaction-test.js
npm run characterization-gate
git diff --check origin/coordination...HEAD
```

An existing failing browser test is a review failure even if the new focused test passes.

### 6. Test the real user path

Use a real browser for:

- Modal open/close and keyboard behavior.
- Focus movement.
- Tabs and conditional panels.
- Navigation and deep links.
- Form validation and save feedback.
- Loading, empty, stale, and failure states.
- Controls that source-level tests claim exist.

Source substring tests prove that code is present, not that users can reach it.

### 7. Require discriminating evidence

A useful test should fail when the old defect is restored.

Examples:

- Revert the fix temporarily and record the failed assertion.
- Seed more rows than the old pagination cap.
- Trigger overlapping refreshes to prove single-flight behavior.
- Put focus inside an embedded document before pressing Escape.
- Force a post-save refresh failure after a successful write.

Restore the fixed tree before publishing the branch.

## Final-Tree Integration Testing

The development and production lanes may have drifted even when they share ancestry. In some designs they
may intentionally use separate histories.

Always test the exact feature patch against the current production head.

### Generic procedure

Fetch the feature into the production repository under a review-only reference:

```bash
git fetch <development-remote> \
  agent-dev/task-NNN-short-description:refs/remotes/review/task-NNN
```

Create a disposable production worktree:

```bash
combined_dir=$(mktemp -d /tmp/taskNNN-combined.XXXXXX)
git worktree add --detach "$combined_dir" production
```

Apply the reviewed commit:

```bash
git -C "$combined_dir" cherry-pick <feature-commit>
```

Then run the relevant focused, regression, and browser tests on the combined tree.

### Interpretation

- **Clean application and green tests:** eligible for approval.
- **Conflict:** determine whether production behavior changed. Require a refreshed base when necessary.
- **Clean application but failed tests:** return rework; the combined tree is authoritative.
- **Developer reimplemented a production helper:** stop and require the existing helper to be reused.

Do not hide conflicts with force pushes or destructive resets.

## Rework Workflow

A rework packet should be factual and narrow:

```markdown
# TASK-NNN — Rework findings: concise failure

Status: rework required
Owner: Development agent
Branch: `agent-dev/task-NNN-short-description`
Reviewed commit: `<commit>`

## What passed

## Exact failing behavior

## Why current tests missed it

## Required correction

## Required proof
```

Examples of valid rework reasons:

- The visible UI does not match the completed-packet claim.
- A browser path still displays stale or incorrect data.
- The test asserts source wiring rather than behavior.
- A successful write is later reported as failed.
- A cache performs expensive scans before checking for a hit.
- The branch fails a required formatting gate.
- The feature does not integrate onto the current production head.

Label mechanical-only rework clearly so the development agent does not rewrite correct functionality.

## Approval Criteria

Approve only when all applicable conditions are met:

- The implementation matches the packet.
- The focused proof passes.
- The proof is capable of failing on the old behavior.
- Relevant regressions pass.
- Interactive behavior passes a browser test.
- Negative paths and permissions remain intact.
- Diff and formatting checks pass.
- The feature applies cleanly to current production.
- The final combined tree passes tests.

## Merge and Deployment Gates

Treat these as separate states:

- **Reviewed:** evidence collected.
- **Approved:** reviewer accepts the final combined behavior.
- **Merged:** approved code exists in production source history.
- **Deployed:** the runtime is running that production commit.
- **Live verified:** health and the changed production user path pass.

A request to review does not authorize a merge. A request to merge does not necessarily authorize a
deployment.

### Merge procedure

When authorized:

1. Confirm the exact approved commit.
2. Apply it to the current production head.
3. Resolve only understood conflicts.
4. Re-run final tests.
5. Commit with the task identifier.
6. Push using the approved production path.
7. Report the resulting production commit.

### Deployment procedure

When authorized:

1. Confirm the production checkout is clean enough for the scoped action.
2. Verify the intended commit.
3. Use the configured service manager or hosting platform.
4. Avoid starting an unmanaged duplicate service.
5. Check health and route timing.
6. Exercise the changed live user path.
7. Confirm the deployed runtime contains the approved commit.

## Safety Controls

### No self-approval

The implementation agent cannot declare its own branch production-ready.

### Separate trust boundaries

The development checkout and remote cannot directly alter the production runtime.

### Protected branches

Coordination and production branches reject direct updates.

### Temporary test data

Tests use synthetic fixtures and temporary databases, session stores, logs, and ports. They do not seed
production data.

### External integration isolation

Test servers disable background sync and live mutations. A local test must not send email, create calendar
events, or write to a production CRM.

### Secret handling

- Inject credentials through an approved secret manager or environment wrapper.
- Never print secret values.
- Never place tokens or credentials in tasks, commits, chat, or reports.
- Keep production credentials away from the implementation agent where practical.

### Preserve unrelated work

- Inspect repository status before changes.
- Treat unrelated modifications as belonging to another user or agent.
- Avoid destructive reset and checkout commands.
- Use temporary worktrees.

### Explicit authority

Require human authorization for:

- External messages.
- Public posts.
- Destructive actions.
- Production merges where policy requires it.
- Deployments.
- Material scope expansion.

## Performance-Sensitive Web Applications

For single-process Node.js services, synchronous database work can block every request, including static
assets and health routes.

Common warning signs:

- Static files wait behind one API request.
- A cache still performs aggregate scans before testing whether the cached value is usable.
- Page startup triggers several expensive widgets simultaneously.

Preferred design:

- Compute expensive aggregates in a background worker.
- Store small, durable snapshots.
- Read snapshots on the HTTP path.
- Use explicit invalidation or cheap generation counters.
- Coalesce overlapping refreshes with single-flight behavior.
- Retain the last good snapshot on failure.
- Expose freshness and stale state.
- Load secondary widgets after the initial shell.

Indexes are useful, but they do not fix an architecture that performs large correlated scans on the web
request thread.

## Common Failure Recovery

### Protected branch rejects a push

Create a dedicated packet or review branch, open a pull request, merge using repository policy, and verify
the file on the remote target branch.

### Remote branch advanced

Fetch and rebase the local packet branch onto the new coordination head. Do not force-push over another
agent's work.

### Development base is stale

Stop if a required production function is absent. Refresh the development base or provide an equivalent
integration base. Do not create a duplicate implementation merely to avoid waiting.

### Focused test passes but browser fails

The browser result controls. Add an assertion for the missing user-visible behavior and return rework.

### Agent claims completion but required gate fails

Classify the exact failure. If it is mechanical, request only the mechanical correction. If it affects
runtime behavior, require new behavioral evidence.

## Recommended Status Vocabulary

- **Queued:** task exists but implementation has not started.
- **Active:** implementation or rework is expected.
- **Developer-complete:** branch returned for review.
- **Rework required:** a concrete defect or failed gate remains.
- **Approved:** independently verified on the feature and final combined tree.
- **Merged:** approved code is in production source history.
- **Deployed:** the live runtime is running the merged code.
- **Live verified:** the changed production path and health checks passed.

Avoid using “done” without qualification.

## Minimal Adoption Plan

An organization can introduce this model incrementally:

1. Protect the production branch.
2. Create a separate development checkout and remote namespace.
3. Give the development agent no deployment credentials.
4. Adopt numbered task packets stored in the repository.
5. Require one feature branch per task.
6. Assign a second agent to reproduce tests and inspect diffs.
7. Add temporary-worktree integration testing.
8. Require browser tests for interactive behavior.
9. Separate review, merge, deploy, and live-verification status.
10. Add CI and policy automation after the human workflow is stable.

The process does not require a specific AI vendor. The important properties are role separation,
independent evidence, protected source-control handoffs, production isolation, and retained human authority.

## Final Principle

The development agent's statement that a task is complete is a review input, not a release decision.

The release decision should answer:

> Does this exact change work on the current production tree, through the real user path, while preserving
> authorization, data, and operational safety boundaries?

If that has not been demonstrated, the task is not approved.
