# Safe Dual-Agent Repository Development

## Purpose

Our development setup separates implementation from review and production control. OpenClaw coordinates
the work, Claude develops changes in an isolated GitHub mirror, and Codex reviews, integrates, tests, and
deploys from the production repository.

The separation is intentional: no single coding agent can silently move an unreviewed change from an idea
to the live application.

## The Three Main Components

### OpenClaw: coordination and operational control

OpenClaw is the communication and orchestration layer. It receives requests, keeps project context, gives
the agents access to approved local tools, and returns status to the operator.

OpenClaw does not replace Git or code review. Its job is to make the workflow durable and observable:

- Route requests to the correct repository and agent.
- Preserve task numbers, instructions, and review findings.
- Keep credentials and machine access behind controlled local tooling.
- Require explicit authorization for external sends, public actions, destructive operations, merges, and
  deployments when those actions are not already part of the approved task.
- Report what was verified rather than treating an agent's written claim as proof.

### Claude: isolated implementation agent

Claude works from a separate development copy on the SSD and a dedicated GitHub mirror. Each assignment
is delivered as a numbered AP job packet with:

- A precise objective.
- Required behavior.
- Scope boundaries and safety guardrails.
- Acceptance criteria.
- Required automated and real-browser evidence.
- A named feature branch.

Claude implements the change on its feature branch, runs its tests, records its evidence, and pushes the
branch for review. Claude does not deploy directly to the live Agent Portal.

### Codex: independent reviewer and production integrator

Codex acts as the second agent and controls the production integration path. It does not accept a
"completed" packet at face value. It independently:

- Reads the actual diff.
- Checks the branch against the current production head.
- Runs focused tests and broader regression tests.
- Exercises the real browser path when the change affects user interaction.
- Checks negative paths, permissions, and write boundaries.
- Simulates or performs a clean integration onto the current production tree.
- Approves the work or sends a specific rework packet back to Claude.

Only after approval and explicit merge/deploy authorization does Codex integrate the branch, restart or
deploy the service, and verify the live health and user path.

## Repository Separation

The workflow uses two distinct repository lanes.

### Claude development lane

- Local SSD working copy for Claude.
- Separate GitHub mirror.
- Protected `claude-development` coordination branch.
- One feature branch per AP job.
- Active, completed, and rework packets stored with the code.

This lane is safe for experimentation because it is not the live production checkout and cannot deploy
by simply committing a change.

### Production lane

- Separate production repository and branch.
- Local bare mirror used for controlled source synchronization.
- Live service managed independently from Claude's checkout.
- Integration is performed only after review.

The repositories intentionally do not share a casual "push anywhere" workflow. Production receives a
reviewed patch or commit through a deliberate integration step.

## End-to-End Workflow

1. **Request**

   The operator identifies a bug, improvement, or review item.

2. **Job packet**

   Codex writes an AP packet with the requested outcome, constraints, and proof requirements. The packet
   is added to Claude's active queue through the protected GitHub workflow.

3. **Implementation**

   Claude creates the named feature branch, changes only the scoped files, adds tests, and publishes a
   completed packet with verification evidence.

4. **Independent review**

   Codex fetches the branch and reviews the code rather than relying on Claude's summary. Testing occurs
   in a temporary worktree so neither the production checkout nor Claude's checkout is disturbed.

5. **Decision**

   - If the change is correct, Codex marks it approved.
   - If a real-path, safety, regression, or scope issue remains, Codex writes a focused rework packet.
     Claude revises the same feature branch and returns it for another review.

6. **Integration**

   After approval, Codex applies the reviewed change onto the current production head. A clean historical
   merge is not assumed; the final combined tree is tested.

7. **Deployment**

   Deployment occurs only after explicit authorization. The live service is restarted or deployed, health
   is checked, and the relevant production user path is verified.

8. **Record**

   The AP packet, commits, review findings, test evidence, and deployment commit create an audit trail.

## Safety Controls

### No self-approval

Claude implements; Codex reviews. The implementation agent cannot declare its own work production-ready.

### Protected coordination branch

Instruction and review packets enter `claude-development` through pull requests. GitHub branch protection
prevents accidental direct updates and preserves a visible history.

### Production is a separate trust boundary

Claude's local checkout and mirror are not the production repository. A successful Claude push does not
change the live site.

### Explicit deployment authority

"Build," "review," "merge," and "deploy" are treated as different actions. A review request does not
implicitly authorize a production deployment.

### Real-path verification

Source assertions and unit tests are useful but insufficient for interactive features. Browser flows test
the behavior a staff member actually sees, including focus, navigation, modals, errors, and disabled
actions.

### Negative-path and write-boundary checks

Tests confirm not only that the desired action works, but also that gated or unauthorized actions remain
unavailable. Read-only changes must not accidentally introduce live writes or external API calls.

### Temporary integration worktrees

Reviews and merge simulations run in disposable Git worktrees. This keeps the production checkout clean,
avoids overwriting another agent's work, and makes the combined-tree result reproducible.

### No destructive conflict handling

The workflow avoids force-pushing over another agent, resetting shared work, or deleting broad paths.
When a branch advances concurrently, changes are rebased or submitted through a new pull request.

### Evidence over status labels

`completed`, `approved`, and `deployed` mean different things:

- **Completed:** Claude says the feature branch is ready for review.
- **Approved:** Codex independently verified the branch.
- **Merged:** The reviewed change is in the production source history.
- **Deployed:** The live service is running that merged commit and has passed post-deployment checks.

## Rework Loop

Rework is normal and narrowly scoped. A good rework packet includes:

- The reviewed commit.
- The exact failing behavior.
- Why the existing tests missed it.
- The smallest required correction.
- A new proof that would have caught the failure.
- The regression suite that must remain green.

This prevents vague "try again" cycles and turns each finding into a durable test.

## Why This Model Works

The setup combines the speed of an implementation agent with the skepticism of an independent reviewer.
GitHub provides immutable history and protected handoffs; OpenClaw provides coordination and controlled
machine access; Claude provides focused implementation; Codex provides production-aware review and
integration.

The practical result is a development pipeline where:

- Agents can work quickly without sharing a live checkout.
- Concurrent work is visible and less likely to overwrite another branch.
- Review findings become explicit packets and tests.
- Production changes require both technical evidence and operator authority.
- A branch being "done" never automatically means the live system changed.

## Compact Responsibility Map

- **Operator:** chooses priorities and authorizes consequential actions.
- **OpenClaw:** coordinates requests, tools, context, and reporting.
- **Claude:** implements isolated AP branches and supplies evidence.
- **GitHub:** protects handoffs and records branches, commits, and pull requests.
- **Codex:** independently reviews, requests rework, integrates, and verifies.
- **Production service:** changes only after approved integration and authorized deployment.

This is best understood as a two-person engineering workflow implemented with agents: one developer, one
reviewer/release engineer, and a human who retains final authority.
