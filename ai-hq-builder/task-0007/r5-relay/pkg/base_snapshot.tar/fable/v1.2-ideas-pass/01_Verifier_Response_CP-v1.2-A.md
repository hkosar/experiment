# ChatGPT Independent Verification — Change Plan CP-v1.2-A

**Reviewer:** ChatGPT, Independent Verifier / Peer Reviewer under Manual §20A  
**Packet reviewed:** `AI_OS_v1.2_Review_Packet_commit_7099ff9.zip`  
**Declared repository snapshot:** commit `7099ff9`  
**Change plan:** `fable/v1.2-ideas-pass/00_Change_Plan_v1.2_Dual_Agent_Adoption.md`  
**Baseline:** proposed v1.1 packet in `fable/phase1-audit-v1.0/`  
**Date:** 2026-07-25  
**Verdict:** **Pass with changes**

This review does **not** accept v1.1 and does **not** authorize the Opus 4.8 build from the embedded Part D Task Packet as written. The adoption direction is sound. Fable should incorporate the mandatory modifications below, disposition the new `H-` findings, reissue a clean Task Packet, and return any contested item to Hunter with both costs stated. v1.1 acceptance remains a separate owner event.

---

## 0. Verification basis and packet integrity

The ZIP opened successfully and contained the change plan, both peer source documents, the proposed v1.1 Manual and registers, audit reports, decision trail, walkthrough, manifest, and baseline checksums.

The semantic review basis is sufficient, but the export is not yet a fully self-verifying snapshot:

- `sha256sum -c fable/phase1-audit-v1.0/checksums.sha256` returned **21 of 22 passing files**.
- `06_Decision_Trail_Addendum.md` did not match because entries 50–51 were appended after the checksum set was generated.
- The v1.2 change plan and source documents are not covered by one top-level export manifest/checksum file.
- The filename and README assert commit `7099ff9`, but the offline export contains no Git tree proof or complete top-level hash manifest independently binding every included file to that commit.

This creates H-06. It does not prevent this semantic review, but it must be corrected before the post-build gate.

---

# 1. Explicit non-adoption list

## N-1 | Concur

Do not adopt reviewer-as-integrator fusion. The v1.1 separation among Builder, Independent Auditor, ChatGPT verifier, Fable integration authority, and owner authorization is stronger. The revised model must, however, name a constrained Release Executor so approval does not silently imply execution authority; see H-05.

## N-2 | Concur

Do not impose a two-agent ceiling. Preserve provider-independent role abstraction and activate or collapse roles only when evidence and risk justify it.

## N-3 | Concur-with-modification

Do not replace the five universal canonical dimensions with the peer’s status vocabulary. The release ladder is useful as a **build-specific optional dimension/profile**, not a replacement for `stage`, `work_status`, `attention`, `focus`, or `health`.

`Rework-required` should be a review disposition and return transition rather than a normal forward release state. Non-deployable work needs a publication profile or `Not applicable`. Before adding this dimension, the unresolved v1.1 canonical-state inconsistencies identified in H-08 must be corrected.

---

# 2. Change-item dispositions

## CP-01 | Concur-with-modification

The Task Packet is the correct required Builder-facing artifact. It must remain a versioned projection of the approved implementation plan and stage-gate context, not a replacement for the design record, plan, or Manual §20A packet.

The operational database must mint the canonical Task ID. Repository searches may detect collisions but cannot allocate identity. Before the operational store exists, the program may use a protected bootstrap ID registry with atomic allocation and an explicit later alias/migration to the DB ID; scanning folders or chat is not sufficient.

**Required modification:** use APP-05 in §3.2. Permit a verified greenfield/current-state baseline when measurement is not meaningful, and require `Not applicable` with rationale for conditional fields rather than artificial detail.

## CP-02 | Concur-with-modification

A structured completion record and discriminating proof are strong additions. A Builder-authored record is a completion claim and evidence index, not the independent evidence required by v1.1 §11.2 and DP-023.

Rename it **Builder Delivery Record**. It must reference immutable CI/Auditor evidence receipts from the Builder-inaccessible harness store. Builder command output and “external writes: none” remain disclosures until independently reproduced or observed. Discriminating proof is mandatory for defect fixes when technically feasible; unsafe or impractical cases require an Auditor-approved equivalent or documented exception.

**Required modification:** use APP-06 in §3.3 and implement H-02.

## CP-03 | Concur-with-modification

The Rework Packet contract is precise and compatible with scoped re-audit. Review observations do not become Builder instructions until Fable dispositions them under §20A, and not every finding can or should become an executable test.

Adopt the rule that every **accepted behavioral, security, permission, or regression defect** becomes a durable automated test or deterministic guard where feasible. Architecture, documentation, governance, or one-time findings become an appropriate repeatable check, policy, acceptance criterion, or ADR with a reason why automation is unsuitable.

**Required modification:** use APP-07 in §3.4. Include finding ID, source authority, reviewed candidate, acceptance condition, and closure authority.

## CP-04 | Concur-with-modification

The release ladder materially improves owner-visible status. It must remain optional and build-scoped. It also needs exact definitions, authority mapping, applicability rules, and deterministic invalidation when the candidate changes.

`Reviewed` and `Approved` must reflect this program’s actual roles. A documentation package or library may validly stop at publication verification rather than pretend it has a live runtime. The parent topic must not become `work_status: Completed` merely because the Builder is developer-complete.

**Required modification:** use APP-08 in §3.5, place release-state definitions primarily in Manual §12, and complete H-08 before adding the dimension.

## CP-05 | Concur-with-modification

The invariant is correct: the Builder must be structurally unable to mutate or deploy production and should hold zero production mutation/deployment credentials. The plan over-specifies one physical topology; the organization-neutral source permits a dedicated remote or controlled namespace and a separate checkout or repository.

Adopt the trust-boundary invariant, isolated workspace, protected paths, identity/credential separation, and independently controlled release path. Select same-repository protected branches, fork/mirror, or separate repositories by risk, provided the harness proves a Builder push cannot alter production. When separate histories are used, record the complete source-commit → reviewed candidate → integration commit → deployed artifact → rollback mapping.

**Required modification:** use APP-09 and ADR-020 in §§3.6 and 3.8. Add the Release Executor required by H-05 and map activation to Stage 2, not Stages 0–1.

## CP-06 | Concur-with-modification

Final-combined-tree testing directly addresses C-18 and should be a release gate. The gate must be atomically bound to a pinned target head, approved change, resulting candidate tree, relevant dependency/toolchain state, and deployable artifact digest.

Target-head movement, conflict resolution, rebase, rebuild, lockfile change, generated-file change, or any post-review edit creates a new candidate and invalidates the affected review/approval state. The exact tested candidate should be promoted; silently rebuilding it is a new candidate unless reproducibility is proved.

**Required modification:** implement H-04 in Manual §§11.3 and 12.5 and in APP-09. Use applicable suites: browser proof is mandatory for interactive paths, not every artifact.

## CP-07 | Concur-with-modification

Durable in-repository Task Packets, Builder Delivery Records, and Rework Packets with protected PR handoffs are compatible with APP-02. The proposed ID allocation and status directories are not.

v1.1 §5.2.1 assigns identity and workflow state to the operational database. `tasks/queued|active|completed/` encodes a competing mutable state in Git, while search-based allocation is non-atomic. Use a stable artifact path such as `tasks/<global-id>/`; queued/active/completed views may exist only as generated, non-authoritative projections.

**Required modification:** use APP-02 in §3.1 and implement H-01. A local commit is not a completed handoff; the protected remote commit/PR plus synchronization receipt is.

## CP-08 | Concur-with-modification

Disposable worktrees and non-destruction rules correctly strengthen reviewer independence and protect shared checkouts. Any rebase, conflict resolution, or candidate amendment after review creates a new candidate identity and invalidates prior review for the changed scope.

Worktree isolation is not execution isolation. Unreviewed branch code, tests, package hooks, workflow files, and browser automation must execute in an ephemeral least-privilege sandbox with no production credentials or data, synthetic fixtures, controlled egress, and external writes denied by default.

The “planning-documents only” rule applies to **code-review eligibility**, not documentation/design review. Implement APP-10 and H-07.

## CP-09 | Concur-with-modification

The role mapping is useful and correctly keeps OpenClaw governed rather than authoritative for source control. The two source documents are **peer-reported implementation precedent**, not independently verified proof and not proof of feasibility for the whole AI OS.

The mapping must distinguish integration ownership/approval from integration execution. Fable remains integration owner and project manager; ChatGPT remains verifier; the Independent Auditor produces application-level validation evidence; a narrowly scoped Release Executor performs only the pre-authorized merge/deploy action and cannot alter design, candidate, evidence, or approval.

Git remains authoritative for code/artifact content; the operational database remains authoritative for task identity and workflow state; the orchestrator is authoritative for neither.

## CP-10 | Concur

Parking the performance appendix is the correct restraint. Preserve provenance and technology assumptions, especially its focus on performance-sensitive single-process Node.js/web services. Do not activate it as a universal requirement or skill without a future topic, measured bottleneck, and discriminating performance evidence.

---

# 3. Mandatory register and record text

The following text supersedes Part C where it differs.

## 3.1 APP-02 amendment

> **APP-02:** Plans, decisions, tests, reviews, closeouts, Task Packets, Builder Delivery Records, independent verification references, and Rework Packets are durable, versioned repository or artifact records keyed to stable operational-database object IDs. The operational database owns identity and lifecycle state; Git owns artifact content. Repository folders and status labels are non-authoritative projections, never ID allocators or competing state stores, and synchronization status is recorded.

## 3.2 APP-05

> **APP-05:** Every build assignment is a versioned Task Packet that projects an approved implementation plan and stage-gate context to the Builder; it does not replace either. The packet references the canonical task/topic IDs, parent topic, approved plan/version, accepted requirement and decision IDs, risk class, applicable trust/data classes, authorized action classes, and source/context manifest. It contains the observable user, business, or system objective; verified measured baseline where meaningful or explicit greenfield/current-state rationale; required behavior; applicable failure/concurrency/idempotency/rollback requirements or justified N/A entries; guardrails; telemetry and prohibited logging; verification requirements; checkable acceptance criteria; scope-deviation/escalation rule; and handoff requirements. Post-approval changes require a versioned scope/change event. Before the operational DB exists, a protected atomic bootstrap registry may allocate IDs, with mandatory later alias/migration to DB-minted global IDs.

## 3.3 APP-06

> **APP-06:** Builder completion requires a Builder Delivery Record naming the task, branch, base and candidate commits, changed files, relevant tool/environment versions, focused/regression/negative-path/browser proofs as applicable, discriminating proof for defect fixes or an approved compensating-evidence rationale, diff/format results, external-write disclosures and receipts, and residual risks. The record is builder-authored review input, not independent evidence; required proofs must be reproduced or independently verified and written to the tamper-evident harness store before approval. A completion claim without the record is not reviewable.

## 3.4 APP-07

> **APP-07:** Findings accepted through the governance disposition process return as versioned Rework Packets naming the finding ID and authority, reviewed candidate, what passed, exact failing behavior and evidence, why existing controls missed it or an N/A rationale, smallest required correction, required new proof, regressions that must remain green, and closure authority. Mechanical-only rework is labeled. Each accepted behavioral, security, permission, or regression defect becomes a durable automated test or deterministic guard where feasible; otherwise it becomes a repeatable check, policy, acceptance criterion, or ADR with rationale. Candidate changes invalidate prior approval for the affected scope and require scoped re-audit.

## 3.5 APP-08

> **APP-08:** Release-bearing build topics use an optional build-specific `release_state`, separate from the five universal canonical dimensions: Developer-complete, Reviewed, Approved, Merged, Deployed, Live-verified. `Rework-required` is a review disposition and return transition. Each transition records the responsible authority, pinned candidate/base identifiers, evidence reference, timestamp, and action-class authorization; any relevant candidate or target-head change invalidates dependent states through a deterministic reset rule. Non-deployable artifacts use an approved publication profile or Not applicable. Owner-facing renderings never use unqualified “done,” and the parent topic is not `work_status: Completed` until terminal release/publication verification and fold-back are complete.

## 3.6 APP-09

> **APP-09:** Development and production are separate trust boundaries enforced by identities, credentials, protected paths, isolated workspaces, and an independently controlled release path. The Builder has no production mutation or deployment credentials; any scoped read-only production access is separately authorized, masked, and logged. Repository topology—protected branches in one repository, fork/mirror, or separate repositories—is selected by risk and operational need, provided the invariant holds. Each task uses a task-specific branch in every affected repository. Before merge authorization, the approved change is applied to a pinned current target head in a disposable least-privilege environment and applicable focused, regression, negative-path, and browser checks run on the resulting candidate. Candidate tree/commit and deployable artifact digests are recorded; drift, rebuild, or conflict resolution invalidates the gate and triggers re-test and scoped re-review. Release execution is performed by a controlled actor/service separate from Builder and Verifier.

## 3.7 APP-10

> **APP-10:** Unreviewed branch code, tests, package hooks, workflow files, and browser automation execute only in ephemeral least-privilege review environments with no production credentials or production data, synthetic or temporary fixtures, external writes denied by default, controlled network egress, and tamper-evident action/evidence logging. A disposable Git worktree alone does not satisfy execution isolation.

## 3.8 ADR-020

> **ADR-020:** Adopt the peer workflow’s Task/Delivery/Rework packet contracts, structural development/production trust-boundary invariant, build-specific release-state profile, disposable review/integration worktrees, sandboxed review execution, and pinned final-combined-tree gate as concrete Application Development mechanisms. Preserve the AI OS multi-role governance, operational-DB identity/state ownership, independent evidence authority, provider portability, and risk-selected repository topology; do not adopt reviewer/integrator fusion or a mandatory physical two-repository topology. **Status:** Proposed pending verifier conditions and owner approval.

## 3.9 DP-026

> **DP-026 — Structure over vigilance:** Where enforceable controls exist, protect safety invariants with least-privilege identities, credential separation, protected paths, isolated execution, pinned immutable candidates, and independent evidence. Policy text or an agent’s promised behavior is never the sole control.

## 3.10 Governance addition

Add a release-execution function to Manual §20A and the Requirements Register. `GOV-03` is recommended:

> **GOV-03:** Merge/deployment execution is performed by a controlled Release Executor or automated release service with narrowly scoped production credentials. It acts only on a pinned, approved release instruction; has no authority to change design, candidate content, review disposition, or evidence; uses protected-path and compare-and-swap controls; and emits tamper-evident execution receipts and resulting commit/artifact identifiers.

## 3.11 Decision-trail allocation rule

> Decision-trail IDs are allocated atomically when an event is recorded and are never preassigned in future plans. v1.1 acceptance, v1.2 verifier review, owner disposition, build completion, post-build verification, and integration are separate immutable events.

---

# 4. New findings

## H-01 — Task identity allocation contradicts the canonical ID contract

**Severity:** High  
**Affected:** CP-01, CP-07, APP-02/05, Manual §§5.2.1 and 12.2, ADR-015, SCH-01

**Problem:** CP-07 assigns task identifiers by searching repository folders and branches while v1.1 states that the operational database owns and mints persistent object IDs. Search-based allocation is non-atomic and status-named paths create a second state store.

**Evidence:** Manual §5.2.1 assigns all IDs and Task state to the operational DB; CP-07 assigns IDs after repository searches and uses `queued|active|completed` paths.

**Recommended change:** DB-minted global ID and atomic human-readable sequence; stable artifact path; DB↔Git synchronization receipt; generated queue views only. Before the DB exists, use one protected atomic bootstrap registry with a migration/alias contract.

**Alternative considered:** Treat Git as the Task authority during early implementation.  
**Consequence if unchanged:** Duplicate IDs, stale state, mislinked evidence, incorrect routing, and no deterministic authoritative record.

## H-02 — Builder-authored evidence conflicts with independent evidence authority

**Severity:** High  
**Affected:** CP-02, APP-06, Manual §11.2, C-14, DP-023, LOG-01/02

**Problem:** CP-02 calls the Builder artifact a Delivery/Evidence Record containing PASS results and external-write claims, while v1.1 requires approval evidence to live in an append-only store the Builder cannot modify.

**Evidence:** Manual §11.2 says approval cards render from independent evidence, never Builder narrative; CP-02 makes the Builder author of the named Evidence Record.

**Recommended change:** Builder produces a Delivery Record that indexes immutable harness/Auditor evidence receipts; label Builder output as disclosure until independently verified.

**Alternative considered:** Accept the record and let the reviewer rerun selected commands.  
**Consequence if unchanged:** False-green approval and contaminated automation-trust evidence.

## H-03 — Task Packet is not bound to the accepted plan and protection envelope

**Severity:** High  
**Affected:** CP-01, APP-05, Part D, Manual §§11A, 12.1.1, 20A.2

**Problem:** The proposed packet omits the accepted requirement/decision set, approved plan version, risk class, trust/data classes, instruction authority, authorized action classes, and source/context manifest. A precise packet could still drift from accepted design or allow reference content to act as instructions.

**Evidence:** Manual §20A.2 requires accepted requirements/decisions, risk class, source manifest, and exclusions; §11A requires trust, sensitivity, and authority classification. CP-01/Part D do not bind them into the assignment.

**Recommended change:** Use revised APP-05 and reissue Part D with the accepted change-plan digest, owner-approval event, global IDs, protection envelope, and source manifest. Peer documents are reference-only; the approved revised plan is instruction authority.

**Alternative considered:** Rely on Fable’s surrounding chat and repository location.  
**Consequence if unchanged:** Context loss, scope expansion, or injection can make the Builder implement work that was never approved.

## H-04 — Final-tree approval is not atomically bound to merge and deployment

**Severity:** High  
**Affected:** CP-04–06, APP-08/09, Manual §§11.3 and 12.5

**Problem:** CP-06 tests against a “current production head” but does not bind approval to the exact target head, candidate tree/artifact, and later merge/deploy action. Drift, conflict resolution, or rebuild can produce a release that was never reviewed.

**Evidence:** CP-06 defines the test procedure but no candidate digest, compare-and-swap condition, reset rule, or proof that the deployed artifact is the tested candidate.

**Recommended change:** Record target-head, source commit, candidate tree, toolchain/lock state, integration commit, deployable artifact digest, and rollback point. Any change invalidates downstream states and triggers re-test/re-review.

**Alternative considered:** Rerun manually only when a visible conflict occurs.  
**Consequence if unchanged:** A green gate can authorize a different merged or deployed state.

## H-05 — Integration approval exists, but release execution authority is unassigned

**Severity:** High  
**Affected:** CP-05, CP-09, N-1, Manual §20A, action classes

**Problem:** The plan rejects reviewer-as-integrator fusion and maps Fable to integration approval, but no actor/service is assigned the constrained credentials and execution path for merge/deploy. Approval and execution are different authority classes.

**Evidence:** Manual §20A names Fable, ChatGPT, Opus, Sonnet, and Hunter; CP-09 splits the peer Codex role without naming a release executor.

**Recommended change:** Add GOV-03. The executor may be deterministic CI/CD, a narrow release service, or owner-invoked automation, but cannot be Builder or Verifier and cannot alter the approved candidate.

**Alternative considered:** Treat Fable’s “integration owner” label as implicit execution authority.  
**Consequence if unchanged:** The pipeline stalls at approval or silently fuses credentials into an unspecified reasoning component.

## H-06 — Review packet integrity and build base are incomplete

**Severity:** Medium  
**Affected:** Export snapshot, Part D starting condition, manifest/checksums, v1.1 acceptance gate, GOV-02

**Problem:** The packet claims commit `7099ff9`, but the embedded Task Packet references `da152ca`; v1.1 is still proposed; one baseline checksum fails; and the new plan/source files lack a complete top-level hash manifest.

**Evidence:** The review checksum run produced 21/22 passes. `06_Decision_Trail_Addendum.md` actual SHA-256 is `58cdc81271046596cdebd9803b42f43071a61964e0e52e6564d4ef0fa1e1ccb0`, while the baseline checksum file records `1e76406451000d4b3b5698af8e8951de6b333c24bb0f8d386bc8f073c421c196`.

**Recommended change:** Every verifier export includes a top-level snapshot manifest with repository, commit, tree hash, clean/dirty status, export command/time, and hashes for every file. Branch the final Builder packet from the exact accepted v1.1 tag/commit. A provisional diff may be prepared earlier only if nonpublishable and subject to rebase plus full re-verification.

**Alternative considered:** Rely on the filename, README, and post-build regenerated checksums.  
**Consequence if unchanged:** Builder and verifier may compare different baselines, and the audit cannot prove which inputs were changed.

## H-07 — Disposable worktrees do not contain execution authority or side effects

**Severity:** High  
**Affected:** CP-06, CP-08, APP-09/10, Manual §§11A.2–11A.7 and 12.4

**Problem:** A worktree prevents checkout clobbering but does not stop unreviewed code, package hooks, tests, or browser automation from reading credentials, accessing production data, reaching external services, or emitting writes.

**Evidence:** CP-08 adopts worktrees but omits the source guide’s temporary-data, external-integration-isolation, and secret-handling controls.

**Recommended change:** Add APP-10: ephemeral least-privilege sandbox, synthetic data, no production secrets, default-denied external writes, controlled egress, pre-execution inspection of branch-controlled hooks, and independent logging.

**Alternative considered:** Rely on worktree isolation and reviewer caution.  
**Consequence if unchanged:** Review can exfiltrate secrets, mutate live systems, or corrupt its own evidence boundary.

## H-08 — C-07 canonical-state cleanup is incomplete in proposed v1.1

**Severity:** High  
**Affected:** CP-04, N-3, Manual §§4.4, 4.5, 7.2, 11.7, Appendix A, Appendix B, ADR-013, ATT-02

**Problem:** The proposed v1.1 Manual declares one canonical state model but still uses noncanonical Status values and the retired term `Needs Attention` in authoritative sections. Adding `release_state` would compound an unresolved state model.

**Evidence:** §4.4 defines `work_status` as Queued/Running/Waiting/Blocked/Paused/Failed/Completed and `attention` as None/Briefing/Hub/Needs Owner/Critical. §7.2 and Appendix B still list `Working` and `Needs Owner` as Status values. §§4.5 and 11.7, Appendix A, the glossary, and ADR-009 retain `Needs Attention` despite its stated retirement.

**Recommended change:** Correct every authoritative occurrence before v1.1 acceptance or through an explicit v1.1-final erratum; machine-check canonical vocabulary and mappings before adding release state.

**Alternative considered:** Treat all legacy words as display labels.  
**Consequence if unchanged:** The Decision Engine and renderers inherit contradictory enums, and High finding C-07 is not truly closed.

## H-09 — Decision-trail entry 52 is preallocated to separate events

**Severity:** Medium  
**Affected:** Part C, `06_Decision_Trail_Addendum.md`, owner acceptance history, version sequencing

**Problem:** The plan and placeholder reserve entry 52 for CP-v1.2-A review/dispositions, while the handoff accompanying this packet reserves entry 52 for the separate v1.1 owner-acceptance event.

**Evidence:** Part C and the addendum placeholder assign 52 to this review; the current owner handoff says a standalone “I accept v1.1” will be recorded as entry 52.

**Recommended change:** Never preallocate future trail numbers. Allocate atomically when recorded, with separate events for v1.1 acceptance, verifier review, owner CP disposition, build, post-build verification, and integration.

**Alternative considered:** Combine or renumber after the fact.  
**Consequence if unchanged:** The authority trail becomes ambiguous about which act passed AUD-01 and which approved v1.2 work.

---

# 5. Regression and contradiction check against v1.1

| v1.1 mechanism | Result as written | Required disposition |
| --- | --- | --- |
| Five-dimension canonical state model | **Direct unresolved baseline conflict plus conditional CP-04 conflict.** | Complete H-08; keep `release_state` optional/build-specific; use APP-08. |
| Operational DB owns task identity/state | **Direct conflict** from CP-07. | H-01 and revised APP-02/05. |
| Independent/tamper-evident evidence | **Direct conflict** if CP-02 record is authoritative. | H-02 and revised APP-06. |
| Stage-gate/accepted-plan traceability | **Under-specified** in CP-01 and Part D. | H-03 and revised APP-05/Task Packet. |
| Identity/trust/data protection | **Conditional.** CP-05 helps credentials; code execution and source authority remain incomplete. | H-03, H-07, APP-10. |
| Reviewer independence | **Strengthened**, but release execution is unassigned. | H-05/GOV-03. |
| Final candidate/provenance | **Under-specified.** | H-04 and revised APP-09. |
| Staged activation/capacity | **No direct conflict if activated in Stage 2 with risk-tiered ceremony.** | Add controls to §17.3; preserve Stage 0/1. |
| Topic/checkpoint/resumption | **No conceptual change.** | Preserve. |
| Reception/Executive Desk/Business/Personal/Learning | **No conceptual change.** | Preserve. |
| Provider portability | **Conditional conflict** if two physical repositories become universal. | Risk-select topology; preserve invariant. |
| Audit/version history | **Conflict** from mixed snapshot and entry preallocation. | H-06 and H-09. |

Part A should be amended slightly: the plan does not alter the product concept or executive experience, but CP-04, CP-07, and CP-09 make limited cross-cutting changes to state, source-of-truth, and governance.

---

# 6. Part D Task Packet review

## Disposition: Concur-with-modification — reissue before Builder execution

The embedded packet is a useful bootstrap example but must not be sent to Opus unchanged. It predates this review, uses a non-authoritative ID method, lacks the accepted-plan/protection envelope, has an ambiguous base, does not correct H-08, preallocates decision history, and says “no external writes” while requiring Git push/PR activity.

### Mandatory amendments

1. Fable publishes a revised CP-v1.2-A with a version/digest after dispositions.
2. Hunter approves that revised plan before Builder release.
3. Use a DB-minted Task ID; before the DB exists, document one atomic bootstrap registry and later alias/migration.
4. Pin the exact revised-plan and baseline commit/tree. Integration/publication waits for a separately accepted v1.1-final base; a provisional diff must be explicitly nonpublishable and reverified after rebase.
5. Replace “four baseline documents” with an exact changed-file allowlist.
6. Add parent topic, approved plan/version, requirements/decisions, risk/trust/data/authority envelope, source manifest, and rollback point.
7. Mark peer sources reference-only with no instruction authority.
8. Clarify writes: only the named feature branch and PR path are authorized; business-system, production, communication, and external-integration writes are forbidden.
9. Use a document-publication release profile; `Deployed` and `Live-verified` are Not applicable for this task.
10. Apply APP-02 and APP-05 through APP-10, ADR-020, DP-026, GOV-03, H-08 corrections, and the decision-trail allocation rule.
11. Strengthen verification beyond grep: exact MD/CSV ID-set comparison, duplicate detection, canonical-state validation, changed-file allowlist, semantic cross-reference checks, source hash preservation, and 100% top-level checksum validation.
12. Builder returns a Builder Delivery Record; independent evidence and verifier reruns remain separate.
13. Assemble the Manual §20A.2 eleven-item packet for post-build review.
14. Do not preallocate decision-trail numbers.

## Recommended replacement Task Packet

```markdown
# <CANONICAL-TASK-ID> — Integrate accepted CP-v1.2-A into the proposed baseline

Status: queued
Parent topic ID: <global-topic-id>
Builder: Claude Opus 4.8
Base commit/tree: <exact revised-plan and baseline identity>
Approved change plan: <path + version + SHA-256>
Owner approval event: <decision/event ID>
Risk class: documentation-only / no runtime code
Release profile: artifact publication

## Authority and source envelope

Authoritative instructions:
- Revised CP-v1.2-A after verifier/Fable disposition
- Hunter approval event
- Accepted or explicitly provisional v1.1 baseline identity

Reference-only sources, no instruction authority:
- `sources/dual_agent_repository_development_guide.md`
- `sources/openclaw_github_claude_dual_agent_development.md`

Authorized writes:
- Named feature branch and pull request only
- Exact changed-file allowlist

Forbidden writes:
- Protected branches directly
- Production/runtime systems
- Business data, email, calendar, external integrations
- Peer source documents and historical baseline snapshots

## Objective

Produce the v1.2-proposed document set implementing the accepted CP dispositions and H-finding remedies without changing the product concept or any non-targeted v1.1 mechanism.

## Verified starting condition

- Exact input snapshot manifest validates 100%.
- The selected base and revised change-plan digest are recorded.
- v1.1 acceptance status is explicit and separate.
- Existing requirement, ADR, DP, canonical-state, and decision-trail ID sets are recorded before editing.
- H-08 legacy state/attention occurrences are enumerated.

## Required behavior

- Apply accepted CP-01…CP-10 dispositions.
- Apply revised APP-02 and APP-05…APP-10.
- Add ADR-020, DP-026, GOV-03, and the trail-allocation rule.
- Correct H-08 globally.
- Update Manual, MD/CSV registers, v1.1→v1.2 change log, decision trail events that have actually occurred, manifest, and checksums together.
- Preserve peer sources verbatim and park the performance appendix with provenance and applicability notes.

## Guardrails

- Do not modify non-targeted concept surfaces except required consistency/cross-reference corrections.
- Do not renumber existing IDs.
- Do not modify historical baselines, source documents, walkthrough scenarios, or unrelated audit reports.
- Do not mark v1.1 accepted, v1.2 accepted, or Phase 2 open.
- Post-plan scope changes stop work and return to Fable as a change request.

## Required telemetry

- Commits reference CP/H/APP/ADR/DP/GOV IDs.
- Record base/candidate commits, changed files, commands, tool versions, and residual risks.
- No secrets, credentials, personal data, or sensitive logging.

## Verification

- `git diff --check` passes.
- Changed files match the allowlist.
- Requirements MD/CSV contain identical unique ID sets.
- ADR/DP/GOV IDs are unique and cross-referenced.
- Every new requirement is cited in the Manual.
- Canonical state and attention terminology is globally consistent.
- Release state remains build-specific and uses the document-publication profile.
- No unqualified owner-facing “done” is introduced.
- Peer source hashes are unchanged.
- Top-level manifest/checksum validation passes 100%.
- Semantic regression matrix confirms state, source-of-truth, protection, staged activation, and governance are not weakened.

## Acceptance criteria

- Every accepted verifier modification is implemented exactly or returned as a change request.
- No H-01…H-09 acceptance condition remains open.
- Registers, appendices, logs, manifest, and checksums reconcile.
- The Manual §20A.2 post-build gate packet is complete.

## Handoff requirements

Return a Builder Delivery Record containing canonical IDs, branch, base and candidate commits, changed-file list, command outputs, source/checksum results, external-write disclosure, incomplete/untested areas, residual risks, and immutable references to independent evidence locations. Do not claim acceptance.
```

---

# 7. Acceptance conditions and gate recommendation

## Change-plan gate

**Pass with changes.** The adoption concept is approved in principle. No CP item requires abandoning the owner’s product concept, Discord-first experience, recursive topic model, governed learning, Business/Personal structure, or provider-independent roles.

Before Hunter releases work to the Builder, Fable must:

1. Incorporate all `Concur-with-modification` dispositions.
2. Add and disposition H-01 through H-09.
3. Replace Part C text with the accepted versions above or return contested items to Hunter with both costs.
4. Add APP-10 and GOV-03.
5. Correct H-08 in the v1.1-final path before owner acceptance, or present it as an explicit High-severity exception; the verifier recommends correction.
6. Reissue a clean standalone Task Packet against a named snapshot.
7. Export a top-level manifest/checksum set that validates 100%.

## Build gate

**Blocked pending revised plan and owner approval.** Opus 4.8 should not execute the embedded Part D packet unchanged.

## v1.1 acceptance

**No acceptance action is taken by this review.** v1.1 acceptance remains a separate owner decision against a clean, restamped v1.1-final snapshot. H-08 should be corrected before that event or explicitly accepted as a known High-severity exception. v1.2 may be reviewed and prepared in parallel, but cannot become the accepted successor baseline until version-history authority is explicit.

## Post-build verification

ChatGPT should receive the exact revised-plan snapshot, Builder Delivery Record, independent evidence references, complete diff, updated registers, Fable dispositions, and clean manifest/checksums. The post-build review will verify both semantic adoption and absence of regression before Fable integration.

---

**Final disposition:** `CP-v1.2-A | PASS WITH CHANGES`
