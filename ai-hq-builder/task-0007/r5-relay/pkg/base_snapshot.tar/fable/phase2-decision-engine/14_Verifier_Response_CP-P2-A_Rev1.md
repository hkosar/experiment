# ChatGPT Verifier Response — CP-P2-A Revision 1

**Review target:** `fable/phase2-decision-engine/13_CP-P2-A_Design_Phase_Change_Plan.md`  
**Target SHA-256:** `6049f60d352bc3363fabe3702a700b26e46de0cf771c587b658892e768e1fa16`  
**Gate commit:** `0c2a7c79a0a2d6b3c9588bc2d2ad2a76304d2543`  
**Gate tree:** `0e07a04693d2aaef66c19c8fa4a64838cd57e420`  
**Review type:** Design-phase plan review; no design execution or Builder authorization  
**Verifier:** ChatGPT  
**Owner decisions not reopened:** OD-1, OD-2 with DE-R8 modification, OD-3, and discovery acceptance recorded at trail entry 82

---

## 1. Verdict

# **PASS WITH CHANGES**

The plan carries the accepted discovery forward in the correct direction. It preserves S1/S2/S3 as viable candidates, keeps S2 as a leading hypothesis rather than a selected architecture, honors the external-evidence boundary, retains Business/Personal partitioning, and correctly separates Fable-owned design from separately authorized Builder work.

No plan item receives a Dissent. However, Revision 1 is not yet sufficiently precise to serve as the owner-approved execution contract for a high-leverage design phase. The main defects are:

1. Part B compresses fourteen design tracks into one paragraph without item-level outputs, dependencies, tests, evidence, or closure rules.
2. The design authority and accepted-requirement surface are referenced but not frozen into a plan-specific traceability contract.
3. Several proposed DE-R texts prematurely hard-code incomplete or unsafe mechanics.
4. DE-R8 correctly carries the owner's automatic-expansion direction, but its current text lacks the bounded policy and independent evidence controls needed to make automatic expansion safe.
5. The post-design gate sequence omits the correction/re-verification steps required before the owner decision package.

**Gate consequence:** Fable should issue Revision 2 and return it for a narrow scoped confirmation. Owner plan approval and design execution remain blocked until that confirmation.

---

## 2. Independent Packet Verification

```text
Uploaded ZIP SHA-256
 d48bc5cd49b6c0d3747179bdd782741740167e4607a67d835ead615bd74bcaee

Review-target SHA-256
 6049f60d352bc3363fabe3702a700b26e46de0cf771c587b658892e768e1fa16

Top-level checksum file
 12 / 12 passed

Export-manifest repository files
 12 / 12 passed

Export-manifest evidence files
 1 / 1 passed

Git bundle
 Valid; complete history

Gate commit
 0c2a7c79a0a2d6b3c9588bc2d2ad2a76304d2543

Gate tree
 0e07a04693d2aaef66c19c8fa4a64838cd57e420

Commit-to-tree binding
 Independently reproduced — PASS

Fresh checkout
 Clean

Git diff check
 Passed

Phase 2 internal checksums
 24 / 24 passed

Phase 1 checksums
 24 / 24 passed
```

The packet is adequate for substantive review. The accepted v1.3 Manual and Requirements Register are present in the complete Git history and their identities match the manifest declarations.

---

## 3. Plan-Item Dispositions

| Plan item | Disposition | Governing finding |
| --- | --- | --- |
| Item 0 — standing-role refresh | **Concur with modification** | P2A-10 |
| B1 — S1/S2/S3 comparison | **Concur with modification** | P2A-01, P2A-02 |
| B2 — field-authority contract | **Concur with modification** | P2A-06 |
| B3 — identity/dedup design | **Concur with modification** | P2A-03 |
| B4 — serialization design | **Concur with modification** | P2A-04 |
| B5 — degraded-mode ladder | **Concur with modification** | P2A-05 |
| B6 — tier/policy function and DE-R8 | **Concur with modification** | P2A-06, P2A-09 |
| B7 — attention/OD-1 policy | **Concur with modification** | P2A-06 |
| B8 — policy-object representation | **Concur with modification** | P2A-07 |
| B9 — event model and replay | **Concur with modification** | P2A-08 |
| B10 — partitioned queue mechanics | **Concur** | — |
| B11 — ritual integration | **Concur** | — |
| B12 — six design-gate tests | **Concur with modification** | P2A-01, P2A-11 |
| B13 — INT-01/owner-package templates | **Concur** | — |
| B14 — operational-DB schema first cut | **Concur with modification** | P2A-01, P2A-08 |
| Part C — DE-R1 through DE-R8 | **Concur with modification** | P2A-03 through P2A-09 |
| Part D — execution and gate sequence | **Concur with modification** | P2A-02, P2A-11, P2A-12 |

---

## 4. Findings

## P2A-01 — High — Part B is not an auditable design-execution contract

**Affected:** Part B, phase acceptance criteria, B1–B14

**Problem:** Fourteen design tracks are compressed into one sentence. The plan does not state, for each track, the authoritative inputs, artifact outputs, dependencies, decision boundaries, required tests, independent evidence, acceptance rule, falsifier, or completion status. The final paragraph then gives phase-wide criteria that explicitly require only GAP-2, DE-R2, E2E-1, and check 4 to pass. B5, B7, B8, B10, B11, B14, and DE-R8 could therefore remain paper-complete without a checkable design-gate result.

**Required change:** Revision 2 must expand B1–B14 into item-level contracts. Each item should contain:

```text
Objective
Accepted authority and requirement IDs
Inputs and dependencies
Output artifact path(s)
Alternatives that must remain viable
Decision owner
Required scenarios/tests
Expected evidence and independent reproduction method
Acceptance criteria
Falsifier / reopen condition
Downstream dependencies
```

The phase gate must include a requirement-to-artifact-to-test matrix and explicitly state which criteria must pass at design gate versus which remain build-gate obligations.

**Acceptance condition:** A reviewer can determine, without inference, whether every B item is complete, incomplete, blocked, or deliberately deferred.

---

## P2A-02 — High — The design authority corpus and accepted-requirement surface are not frozen

**Affected:** Authority paragraph, Part B, Part D, APP-02/GOV-02 compliance

**Problem:** The plan cites trail entry 82, the corrected discovery set, and proposal `05_`, but it does not define one immutable design authority snapshot or a plan-specific applicability matrix. The discovery matrix is labeled for discovery and cannot silently become the design checklist. The plan also lacks a canonical parent-topic declaration even though TOPIC-0002 is the governing object.

**Required change:** Revision 2 must add or name:

1. **Canonical parent:** `TOPIC-0002`.
2. **Design Authority Manifest:** accepted v1.3 Manual/register, frozen discovery artifacts, owner gate entry 82, approved plan revision, source hashes, exclusions, and later-entry admission rule.
3. **Design Requirements Applicability Matrix:** all 125 accepted requirements, plus proposed DE-R items, mapped to `Binding / Design subject / Deferred / N/A`, B-item owner, artifact, and gate test.
4. **Change-control rule:** later owner signals or new evidence enter only through a versioned plan amendment or bounded MEM-09 admission—not by reading the growing live trail opportunistically.

**Acceptance condition:** The design can be reproduced from a single hash-bound corpus, and every accepted requirement has one explicit treatment.

---

## P2A-03 — High — DE-R1 incorrectly requires all five identity fields on every input

**Affected:** DE-R1, B3, routine no-case path

**Problem:** The accepted discovery deliberately preserved routine processing that may create no Decision Case and no action. Some sources also provide no native event ID. Requiring all five fields “per input lifecycle” would force fabricated or meaningless case IDs and action idempotency keys, recreating the record pollution the discovery avoided.

**Required replacement:** 

> **DE-R1 (identity and deduplication)** — The Decision Engine MUST preserve five distinct identity **concepts** and instantiate each only when applicable: a local ingestion ID for every accepted input; a source-native event ID when the source supplies one; a versioned deduplication fingerprint when deduplication evaluation applies; a case/correlation ID when the input is linked to a case, topic, or multi-event activity; and an action idempotency key for each emitted ActionRequest. Absence MUST be explicit and MUST NOT be replaced with fabricated authoritative values. Deduplication MUST be source-aware, fingerprint-version-aware, and uncertainty-aware; an uncertain match creates a review/link candidate and MUST NOT silently merge or drop either event. Identity semantics MUST remain independent of model and normalization versions. Acceptance tests include no false merge of distinct legitimate identical events, transformed-redelivery detection, routine no-case processing, source-without-native-ID processing, and one idempotency key per action attempt contract.

---

## P2A-04 — High — DE-R2 prematurely selects a per-topic total-order mechanism

**Affected:** DE-R2, B4, B1 candidate neutrality

**Problem:** Inputs can arrive before placement exists, can affect several topics, can change policies or queues, and can involve cross-object corrections. “Every event affecting one topic passes a per-topic serialization point that assigns a total order” both misses those cases and prematurely chooses a mechanism while serialization remains an open design problem. It may also impose unnecessary global latency.

**Required replacement:**

> **DE-R2 (concurrency and ordering)** — Events capable of mutating the same authoritative consistency boundary MUST be serialized or protected by versioned compare-and-swap / optimistic-concurrency controls such that every tested interleaving prevents lost updates and records unresolved conflicts. The design MUST define consistency boundaries for pre-placement intake, topic/object state, policy and queue state, and cross-object operations; record causal and source ordering separately; and state when a total order is required versus when conflict detection and reconciliation are sufficient. Capture acknowledgment MUST occur only after a durable intake commit and MUST remain within a declared latency bound protecting DP-001; downstream classification and policy evaluation may continue asynchronously. Acceptance tests cover unplaced inputs, same-topic conflicts, cross-topic reclassification, policy changes racing with evaluation, duplicate delivery, and multi-object fold-back.

---

## P2A-05 — High — DE-R3’s degraded-mode ladder is ambiguous and permits unsafe T1 side effects

**Affected:** DE-R3, B5, A10/A15

**Problem:** `capture-only → read-only → refuse-consequential` is not one monotonic ladder; the available safe mode depends on which dependency failed. The statement “No T2+ action executes” leaves room for T1 actions with external or state-changing side effects even when evidence, identity, policy, or logging infrastructure is unavailable. Capture-only is safe only if an independent durable queue is actually available.

**Required replacement:**

> **DE-R3 (degraded operation)** — Degraded behavior MUST be defined as a dependency-by-capability matrix rather than a single assumed sequence. The system MUST NOT acknowledge capture unless the input is durably persisted to an intake store that remains available independently of the failed dependency. When canonical state, policy, identity, append-only logging, or evidence services are missing, stale, disputed, or unverifiable, the engine may provide only the capture and read capabilities explicitly proven safe for that failure mode; it MUST NOT perform external mutation or autonomous side-effecting action at any tier. Consequential requests are refused and recorded. Kill/revoke remains effective in every mode. Recovery MUST reconcile queued inputs, uncertain outcomes, and derived projections before ordinary authority resumes. Tests cover each dependency independently, combined failures, queue unavailability, stale snapshots, kill during degradation, and recovery with duplicate/conflicting events.

---

## P2A-06 — High — DE-R4/DE-R5 do not fully preserve the trust and routing contracts

**Affected:** DE-R4, DE-R5, B2, B6, B7, TRS-01/02/03, WF-09

**Problem:** “Missing control inputs fail closed (T3 trusted origin; quarantine untrusted)” is too broad and too vague. Only mandatory authority-bearing controls should invoke the fail-closed path. External-untrusted content must remain usable as semantic data while retaining zero instruction authority; blanket quarantine would break the corrected injection oracle and ordinary email/call classification. The proposed outputs also omit several accepted routing dimensions and owner/domain context needed for attention.

**Required replacement for DE-R4:**

> **DE-R4 (tiers and deterministic policy evaluation)** — Input disposition MUST be computed by a versioned deterministic policy function over a verified mandatory control envelope, the applicable canonical state/checkpoint versions, and the active policy/schema/function/calibration versions. Recorded model outputs are semantic proposals only: they may increase scrutiny, lower the authority ceiling, or escalate to owner review, but may never raise authority, relax a mandatory trust/data/attention floor, or supply identity, instruction authority, policy, or verification state. Missing, stale, disputed, or unknown **mandatory authority-bearing controls** produce a no-action fail-closed result with an explicit reason. Trusted owner-origin input may be routed to T3 when owner judgment is required; external-untrusted content remains semantically analyzable with zero instruction authority and is quarantined only when the governing policy requires it. The function outputs the processing tier, maximum authority, attention band, placement/relationship/blocking/disposition recommendations, and required receipt/evidence contract.

**Required replacement for DE-R5:**

> **DE-R5 (attention)** — Attention MUST be a deterministic function of the processing tier, action-class risk, blocking relationships, aging, domain partition, current owner mode, system health/degradation state, and the active interrupt/quiet-hour policy. Critical may be emitted only when an owner-ratified policy maps verified evidence into the accepted ATT-01 boundary; model output alone can never qualify an event as Critical or suppress a qualifying event. Attention recalibration occurs only through governed PolicyVersionEvents, and no recalibration may weaken a non-overridable protection floor.

---

## P2A-07 — High — DE-R6’s replay basis and exception authority are incomplete

**Affected:** DE-R6, B8

**Problem:** Behavior cannot be deterministically replayed from only `(normalized input, policy version)`. Decisions also depend on the control envelope, canonical state, applicable policy set and precedence, schema/function/calibration versions, recorded model outputs, and time-effective facts. “Exception authority (owner-only)” also incorrectly implies every policy can be overridden; accepted AUT-06 permits override only when allowed, and protection floors may be non-overridable.

**Required replacement:**

> **DE-R6 (policy objects and precedence)** — Policies MUST be versioned typed objects carrying scope, authority domain, explicit priority, applicability predicate, effective window, conflict behavior, non-overridable protection floors, exception authority **only where exceptions are permitted**, explicit supersession target, schema compatibility, and rollback pointer. Changes travel exclusively through governed PolicyVersionEvents. A policy decision MUST be replayable from the complete recorded decision basis: normalized input record, identity/trust/data/verification envelope, relevant canonical state and checkpoint versions, the complete applicable policy set and versions, policy-function/schema/calibration versions, and recorded model outputs. Policy rollback changes future evaluation; prior actions and receipts remain historical facts and require separate reconciliation. The design gate compares the four carried precedence alternatives, including equal-priority fail-closed and owner-scoped exceptions that cannot supersede a declared protection floor.

---

## P2A-08 — High — DE-R7’s replay target and cross-store integrity are too weak

**Affected:** DE-R7, B9, B14, LOG-01/02, MEM-01

**Problem:** Reproducing “UI-observable state” is necessary but not sufficient. A hidden divergence in authority ceiling, emitted ActionRequests, policy applicability, or verification linkage can remain invisible until it creates an external consequence. The plan also does not require a cross-store atomicity/outbox/reconciliation design for separately owned records.

**Required replacement:**

> **DE-R7 (events, evidence linkage, and replay)** — Every input, normalization, recommendation, policy evaluation, decision/approval, attention change, override, ActionRequest, verification linkage, reconciliation, correction, learning, fold-back, aging, degradation, and authoritative state transition MUST be represented by an append-only event or versioned canonical record with stable IDs and provenance. Cross-store creation and linkage MUST use a defined transactional-outbox, compare-and-swap, or reconciliation mechanism that exposes partial failure rather than hiding it. Executed and verified state derives only from externally owned ExecutionReceipts and VerificationRecords referenced by ID. Replay consumes recorded events and recorded model outputs—never model re-invocation—and MUST reproduce canonical state, authority ceilings, decisions, emitted action requests, queue/attention projections, and all UI-observable state. Any divergence is a gate failure.

---

## P2A-09 — High — DE-R8 automatic expansion lacks a bounded, independently evidenced safety contract

**Affected:** DE-R8, B6, owner OD-2 modification, AUT-02/AUT-12, IDN-02/03

**Problem:** The owner explicitly authorized automatic cap expansion from observed resolution patterns. Revision 1 carries that intent, but “correction, reversal, and failure rates” alone do not define a safe automatic authority-changing policy. A global T2 cap could be expanded from sparse, delayed, self-reported, cross-category, or incomplete evidence. “Owner override absolute” must be limited to the cap parameter’s authorized domain; it cannot bypass kill/revoke, step-up, legal/safety floors, or action-class authority ceilings.

**Required replacement:**

> **DE-R8 (automatic T2 volume expansion)** — Each eligible T2 action class and scope MUST have an independent, pre-authorized, versioned cap policy specifying: initial cap; hard owner-approved maximum; eligible evidence sources and coverage requirements; minimum verified sample size; observation window; correction/reversal/failure definitions; delayed-outcome treatment; confidence or uncertainty rule; maximum step size; cooldown; exclusion rules for duplicate, owner-accepted-but-unverified, disputed, degraded-telemetry, and externally untrusted evidence; automatic contraction and freeze thresholds; and the action-class/risk/data/authority ceiling that may never be crossed. Expansion uses independently owned outcome and verification evidence and MUST NOT rely on engine self-attestation, raw model confidence, overflow volume alone, or missing/incomplete telemetry. Every cap change is a PolicyVersionEvent with an owner-visible receipt and reversal path. Owner override applies within the permitted cap domain, requires the applicable identity/step-up control, cannot override a non-overridable protection floor, and is subordinate to IDN-03 kill/revoke. New action classes, tier changes, or authority-ceiling changes remain governed by AUT-12 and the ordinary policy workflow.

**Required design tests:** sparse sample, delayed regression, cross-category contamination, missing provider telemetry, manipulated success labels, cap oscillation, maximum-bound enforcement, owner reduction, owner increase with step-up, automatic contraction, and kill/revoke during expansion.

---

## P2A-10 — Medium — Item 0 must preserve decision history and provider portability

**Affected:** Item 0, GOV-01, §12.1/§12.1.1, §20A.1, ADR-019

**Problem:** The owner-authorized Opus 5 substitution is real and should be reflected in current-facing configuration. It is not a purely mechanical rewrite of the 2026-07-25 ADR-019 decision. Replacing “Opus 4.8” inside the accepted ADR as though it had always said Opus 5 rewrites history. The stated scan also omits the current-facing §12.1 Builder mapping.

**Required change:**

- Amend GOV-01 with an explicit `Amended v1.4` status and APP-01 portability note.
- Update current-facing role/configuration tables, including the §12.1 Builder mapping when it is presented as current.
- Preserve historical Phase 1 current-state inventory and TASK-0001 records.
- Do not silently rewrite ADR-019. Append a dated amendment/supersession note or create a new ADR stating that the Builder assignment changed to Claude Opus 5 at trail entry 69 while role boundaries remained unchanged.
- Use an explicit included-path/excluded-path scan report rather than an unqualified repository-wide zero-count claim.

**Suggested GOV-01 form:**

> **GOV-01** — Standing program roles: Fable (architect/designer, project manager, integration owner, stage-gate approver), ChatGPT (independent verifier), Builder role currently assigned to Claude Opus 5 under APP-01 provider portability, Sonnet (reader/context librarian), and owner (final authority), with the boundaries of Manual §20A.1.

---

## P2A-11 — High — Design-test data and execution-environment controls are missing

**Affected:** B12, E2E-1, separation-falsifier sample, Part D

**Problem:** The plan requires a “real-input sample” and may authorize Builder-created validators, prototypes, and test harnesses, but it does not define the trust/data classes, source authorization, redaction, retention, model exposure, network/tool permissions, or sandbox boundary for those tests. “No external-action authority” does not eliminate data-exposure or untrusted-content risk.

**Required change:** Revision 2 must define a design-test environment contract:

- Synthetic fixtures are the default.
- Real-input sampling requires a separately listed source, owner authorization, data-class policy, minimization/redaction, retention/deletion rule, and provider/model eligibility.
- External-untrusted content has no instruction authority and runs in reduced-tool isolated context.
- No production mutation credentials or outbound communication capability.
- Builder tasks use APP-05 trust/data/action envelopes and isolated workspaces.
- Test output must not copy restricted raw content into ordinary Git, Discord, or verifier packets.
- The separation-falsifier denominator, sampling method, and privacy-preserving evidence format must be specified before execution.

---

## P2A-12 — Medium — Owner approval and the post-design gate sequence need explicit boundaries

**Affected:** Part C, Part D

**Problem:** Owner approval of this plan should authorize the design work, not accept DE-R1 through DE-R8 as final requirements. The Part D pipeline also jumps from design-gate verifier review directly to the owner package, omitting Fable dispositions, corrections, and scoped re-verification.

**Required change:** Add explicit statements that:

1. Owner approval of CP-P2-A authorizes scope, controls, and execution—not the final record shape, policy precedence, schema, or DE-R texts.
2. Material changes to DE-R8’s owner intent require owner decision; technical refinements within the accepted intent remain Fable/verifier work.
3. The post-design sequence is:

```text
design deliverables
→ verifier review
→ Fable keyed dispositions
→ corrections / Builder rework where applicable
→ scoped re-verification
→ concise owner decision package for owner-level choices and residual risk
→ owner design acceptance
→ v1.4-proposed build change plan / Task Packet authorization
```

4. No v1.4 release or owner acceptance is implied by design acceptance alone.

---

## 5. Required Revision 2 Structure

Revision 2 should remain a plan artifact, not begin design. At minimum it should contain:

```text
1. Canonical identity and frozen authority manifest
2. Plan-specific 125-requirement applicability/traceability matrix
3. Item 0 versioned role-refresh method
4. B1–B14 item-level execution contracts
5. Revised DE-R1 through DE-R8 texts
6. Candidate-neutral comparison scorecard and selection rule
7. Design-test and evidence matrix
8. Real/synthetic data and sandbox contract
9. Owner-decision and change-control boundaries
10. Complete post-design correction/re-verification pipeline
11. Exact deliverable paths and final gate packet contents
12. Version, rollback, capacity, spend, and exclusion statements
```

The candidate comparison should remain neutral:

- S1, S2, and S3 receive equivalent authority, evidence, persistence, concurrency, and projection capabilities.
- Common processing policy is held constant.
- Selection criteria and weights are declared before results.
- A hybrid S2+projection result does not count as an independent S3 evaluation.
- S2 may remain the leading hypothesis, but it is not selected before the gate evidence exists.

---

## 6. Scoped Re-Verification Requirements

The next packet may be narrow. It should include:

1. CP-P2-A Revision 2.
2. Keyed dispositions for P2A-01 through P2A-12.
3. Exact Revision 1 → Revision 2 diff.
4. Design Authority Manifest and requirements matrix.
5. Revised DE-R texts in a machine-comparable block.
6. Complete Git bundle with commit/tree binding.
7. 100% validating packet manifest/checksum set.
8. Proof that the accepted v1.3 Manual and register remain unchanged.
9. No owner-approval or design-execution claim.

A full rediscovery review is not required unless Revision 2 changes the accepted discovery conclusions, owner decisions, candidate set, or DE-R8 intent.

---

## 7. Gate State

```text
Accepted v1.3 baseline:             UNCHANGED
Discovery acceptance:               VALID
OD-1 / OD-2(+DE-R8) / OD-3:        NOT REOPENED
CP-P2-A Revision 1 direction:       CONCUR
CP-P2-A plan gate:                  PASS WITH CHANGES
Owner plan approval:                BLOCKED
Design execution:                   BLOCKED
TASK-0003+ Builder authorization:   BLOCKED
Revision 2 scoped confirmation:     REQUIRED
Next actor:                         Fable
```

The standing program separation remains controlling: Fable owns architecture, planning, dispositions, and project management; ChatGPT independently verifies; Claude Opus 5 performs only separately authorized Builder work; Hunter retains owner-level decisions and final acceptance.
