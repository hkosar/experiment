# 23 — TASK-0003 Rework Packet R1 (APP-07): P2S-01 Behavioral Simulator

**Purpose:** return the TASK-0003 Builder delivery for rework, per the Task Packet's own failure clause (`22_` §Failure: "any harness defect discovered post-delivery returns as an APP-07 Rework Packet from Fable, naming the finding, the failing behavior, and the smallest required correction"). This packet does exactly that and nothing else. **`22_` remains the governing Task Packet; every contract in it (allowlist, anti-circularity, determinism, handoff requirements) applies unchanged to the rework.**

---

## Identity and authority

- **Task:** TASK-0003 (OPEN) — rework cycle R1.
- **Instruction authority for the rework:** `22_TASK-0003_Task_Packet_P2S01_Behavioral_Simulator.md` + this packet only.
- **Delivery under review:** `TASK0003_Builder_Return.zip`, SHA-256 `f04a3b7071795e3865ef97cd044bbbf0ca36d16583bb2a62d56db6e30f1f5981`; Builder Delivery Record SHA-256 `55c75ec656e027f179fec053edbfbaa7447a9f62885662f17cde4f805b224d03`; RETURN_MANIFEST 25/25 verified; Delivery Record file table 25/25 verified.
- **Review provenance:** Fable independent verification (mechanics, execution, reproduction) plus two independent Fable-side review passes — (i) scenario-encoding faithfulness against the fixture corpus, (ii) engine fidelity against the hash-bound design documents plus predicate-vacuity mutation probing. Recorded at decision-trail entry 93.
- **Not reopened by this packet:** the design gate verdict, any owner decision, any design document, the fixture corpus, or the `22_` acceptance criteria. If the Builder believes a **design document** itself is defective, that returns as a change request per `22_` §Scope-deviation — do not encode a private fix.

## Independent verification summary — what STANDS (do not rework)

| Verified independently by Fable | Result |
| --- | --- |
| Return mechanics (zip fingerprint, manifest 25/25, record-table 25/25, no extra/missing files, allowlist paths) | PASS |
| Anti-circularity (criterion 1): token-level analysis of engine/scenario code; structural `Stimulus` split; checker output reproduced byte-identically | PASS — the boundary is real |
| Determinism + reproduction (criterion 12): two Fable-executed runs of the full suite from the **repository's** frozen corpus, byte-identical; all 9 delivered outputs byte-identical to Fable's independent runs | PASS |
| Seeded-defect minimum suite (criterion 8): 8/8 defects flip ≥1 previously-passing combination | PASS (see RW-02 for the coverage gap) |
| Byte hygiene (trail-67 rule): 0 CR bytes, 0 trailing whitespace, clean final LF, 25/25 files | PASS |
| Supersession compliance: no superseded rule text encoded (D-SM rows checked) | PASS |
| D-B2 §3 mandatory-control enumeration; P2S-07 eligibility rules and both tests; P2S-06 ordering keys/phases/tie-break and fold receipt-ownership; E2E-1 two-normalizer independence | PASS — faithful |
| Engine hardcoding: no fixture-ID conditionals in `engine_core`/`events`/`fold`/`judge` | PASS (one oracle-side instance — RW-07) |

These results carry forward. The rework must **preserve** them; re-run and re-prove all of them in the R1 return.

## Findings requiring rework

Severity-ordered. Each: **finding → failing behavior → smallest required correction.** File:line references are to the delivered return.

### RW-01 (High — scenario faithfulness, safety-critical case vacated): A7 encodes the fired external call as a refusable request
- **Failing behavior:** the fixture's input side states "external call fired; death before receipt recorded" — an accomplished fact. `scenarios.py:259` encodes it as a `RequestedAction`, which `simulate.py:282-289` then refuses (system-internal envelope ⇒ ceiling below `act-with-receipt`). Delivered `results.json` confirms: A7 produced a `RefusalEvent`, zero action requests, no `ReconciliationEvent`. The ACT-01 halt / Needs-Review / reconcile-before-retry behavior this fixture exists to test (D-B4 §2.3 rule 5) never executed, yet the suite reports pass.
- **Smallest correction:** encode the fired call as an in-flight accomplished fact in the stimulus (side effect fired pre-crash, no receipt at recovery), so the engine must compute the halt + Needs-Review + reconcile-before-retry path; the related predicates (e.g. "auto-retry pre-reconciliation") must become satisfiable and defect-reachable.

### RW-02 (High — predicate vacuity, systemic): 51 of 56 forbidden-phrase predicates cannot fire
- **Failing behavior:** mutation probing across production plus each seeded defect shows only 5 of 56 distinct predicates ever return True; ~153 of the "171 forbidden predicates evaluated" cannot distinguish a correct engine from a broken one. Sub-classes with representative instances: structurally unsatisfiable conjunctions (`oracle.py:81-82`, `94-95`, `97-99`, `101-102`, `114-118`, `124-125`, `134-135`, `137-142`, `168-173`, `211-212`, `234-236`, `238-239`, `264-265`); predicates reading only scenario inputs, never the computed result (`oracle.py:157-159`, `164-166`, `185-187`, `214-215`, `227-229`, `300-307`); scenario tautologies where a spec flag scripts an unconditional event the predicate then finds (`oracle.py:131-132`, `161-162`, `175-176`, `197-198`, `217-218`, `231-232`, `245-246`, `251-252`, `257-262`); and fixtures whose encodings prevent the tested situation from arising at all (S6/A10/A12/A15 consequential-lifecycle predicates: `oracle.py:77-78`, `87-92`, `144-151`, `224-225`, `272-273`). Four distinct phrase pairs also collapse to one shared predicate. This is the Builder's own falsifier row 4 exposure, now measured — and it reproduces the program's known failure class: an evaluated-count headline exceeding what the evidence can discriminate.
- **Smallest correction:** every forbidden predicate must (a) read the **computed** result, and (b) be proven defect-reachable — extend the seeded-defect catalogue so at least one defect flips each predicate family, reported per-predicate. Where a phrase is genuinely outside the simulator's modeled scope, report it explicitly as `NOT-EVALUABLE` with rationale and **exclude it from the evaluated count** — an honest smaller number over a padded larger one, per the standing evidence discipline ("evidence must be able to FAIL"). Fixtures whose consequential lifecycle never runs (S6, A10, A12, A15, A7) need stimuli that let the approve→execute→receipt→verify path actually execute where the fixture's narrative requires it.

### RW-03 (High — P2S-05 traces self-asserting): traces 3 and 5, and half of trace 2, assert literal constants
- **Failing behavior:** `run_p2s05.py:117-132` (trace 3) sets `accepted` as a literal dict and derives `passed` from it; the PolicyPlane's post-acceptance commit result is unused; `history_rewritten: False` is a literal. `run_p2s05.py:153-170` (trace 5): `halted`/`needs_review`/`auto_retry` are literals; the acquired lease is never consulted. `run_p2s05.py:103-113` (trace 2): `completed = True` and `reconciliation_notes_epoch: True` are literals. Three of the five acceptance-criterion-10 verdicts cannot be False for any implementation.
- **Smallest correction:** compute every trace verdict field from the actual PolicyPlane/lease/event objects the trace manipulates, and add a seeded defect per trace family that flips it. Traces 1 and 4 (genuine serialization, epoch rejection, lease bound) are the standard to match.

### RW-04 (High — engine fidelity defect, latent): policy composition lets a non-floor policy overwrite a protection floor's render class
- **Failing behavior:** `engine_core.py:249-250` assigns `render_class = p.render_class` last-writer-wins with no output-ownership check. Empirically verified: `floor(render_class="masked")` composed with a non-floor `render_class="full-content"` yields `full-content` — the exact leak D-B8 P2G-10 rule 5 / PC-10 forbids (structural refusal required). It is invisible in the delivered runs only because `scenarios.py` gives `render_class` exclusively to floors, and A13's input-only predicate (RW-02) could not catch it either.
- **Smallest correction:** enforce per-output ownership in `compose_policies` (a non-protection policy cannot write a protection output; floors are not overwritable), add a PC-10 composition test, and add a seeded floor-overwrite defect proving the check fires.

### RW-05 (Medium — scenario faithfulness): S2's tier discriminator is authored under a false sourcing claim
- **Failing behavior:** `scenarios.py:130` sets `derived={"routine_filing": True}` under the module claim (`scenarios.py:49`) that derived facts are D-B2 §2.3 computed fields; D-B2 §2.3 enumerates exactly `domain`/`aging`/`blocking` — `routine_filing` is hand-authored, and `engine_core.py:387` maps it directly to the T2-vs-T3 tier decision. The fixture's input side never states the tier. Additionally the input's attributed-hearsay element ("quoting Cole's mention") is unencoded, so the provenance-marks-hearsay criterion passes vacuously.
- **Smallest correction:** re-source the discrimination per D-B6 AUT-05 (compute in-scope routine filing from the placement proposal's subtree scope, not a hand flag); encode the hearsay attribution input-side; correct the `scenarios.py` module docstring to state honestly which derived keys are authored encodings vs D-B2 §2.3 computed facts.

### RW-06 (Medium — scenario faithfulness set): A4, A8, A13, A15 drop or reshape input-side facts, vacating each fixture's central hazard
- **Failing behavior:** A4 (`scenarios.py:101-109, 234-238`): "two policy **versions** claim effect" is encoded as two distinct policy IDs at equal priority — the forbidden "silent newest-wins" failure mode is unconstructible, and the composed result (T1 via `tier_max` clamp, per delivered `results.json`) is not the fixture's fail-closed T3. A8 (`scenarios.py:264-268`): start_state "OD-1 policy PENDING" unencoded — the case degenerates to an unconditional watchdog-interrupt demo. A13 (`scenarios.py:305-309`): "phone notification preview generated" unencoded — the stricter notify surface (D-B2's separate enforcement point) is unexercisable. A15 (`scenarios.py:319-323`): "kill during an **active T2 batch**" carries no in-flight work — "zero actions execute after kill" and "in-flight T2 halted" are vacuously true.
- **Smallest correction:** re-encode each with the missing input-side fact (A4 as two versions of one policy ID; A8 with OD-1-pending status affecting interrupt authorization; A13 with a notification-preview surface the composed render/notify floors govern; A15 with in-flight T2 actions the kill must halt and list), and make the corresponding predicates read the computed results (RW-02 overlap noted — fixing both together is expected).

### RW-07 (Medium — oracle hardcoding): literal fixture-ID conditional in a predicate
- **Failing behavior:** `oracle.py:229` contains `... if c["stim"].id == "S1" else False` inside "silence without watchdog," and the predicate otherwise reads only scenario input — a fixture-keyed constant, the single literal fixture-ID branch in the codebase.
- **Smallest correction:** replace with a behavioral check over the computed watchdog/schedule state; no fixture-ID conditionals anywhere in oracle or judge code.

### RW-08 (Medium — store-ownership fidelity): kill-plane events folded through the policy store
- **Failing behavior:** `events.py:80` maps `KillCommandEvent → ("policy", PHASE_CONTROL)`; D-B9 P2G-11 row 9 assigns kill-plane commands to the external control-service journal precisely so kill never depends on the engine/policy log. The independence property P2S-03 exists to protect is collapsed in replay.
- **Smallest correction:** model the control-service journal as its own store in the fold basis with the D-B9 row-9 ownership, and show replay preserving kill-plane/engine-log separation.

### RW-09 (Low — declared-scope honesty, D-B8 layers): exception displacement, effective windows, PC-6 rejection, and rule-4 priority resolution are dead schema or unencoded
- **Failing behavior:** `engine_core.py:164-263` declares `exception_authority`/`supersession_target` but never reads them; no `effective_window` filtering exists; priority never resolves a contradiction (equal-priority differences fail closed; unequal priorities still min-combine — a safe-direction deviation, but not D-B8's written layer-3 mechanism); contradiction detection covers only `ceiling`/`tier_max`.
- **Smallest correction:** either implement the layers the simulator is implicitly credited with encoding, or declare them explicitly `NOT-SIMULATED` in the README and gate report so no PC-3/PC-4/PC-6/PC-11 credit is implied. Do not leave dead schema implying coverage.

### RW-10 (Low — miscellaneous honesty/fidelity set)
- `judge.py:197-202`: `required_evidence` reduces to `len(events) > 0` — materially weaker than "evidence of the named kinds"; check the named kinds or report the limit.
- `oracle.py:322-352`: 15 of 27 fixtures map `expected.authority` to `None` (no authority comparison at all); map them or report them as such per fixture.
- `engine_core.py:303-308`: blanket quarantine on unknown mandatory controls vs D-B6 §2.2's policy-scoped quarantine ("not a blanket quarantine, P2A-06"); only A3 exercises the path today, but encode the rule as written.
- `events.py:109-121`: `ingest_seq` (the declared P2S-06 IngestionEvent ordering key) is carried but unused; use it or document the order-compatible substitution. `events.py:56-57`: `NormalizationRecord`/`RecommendationRecord` classed canonical/phase-3 vs D-B9's recorded-model-output phase-2; both are never emitted — align or remove.
- `simulate.py:140-182`: stage order runs 1→3→2→4 vs D-B6 §2.2's 1→2→3→4; the model-free-ceiling-first invariant is preserved — document the reordering and why it is equivalence-preserving, or match the written order.

## Residual-risk disclosure carried to the verifier (not a rework item)

The engine's disposition rule table (`engine_core.base_disposition`) contains branches whose reason strings closely mirror specific fixtures' expected routes (e.g. the A3 quarantine route, the E2E-1 financial-restricted branch). Each traces to a design-document source, so it passes the anti-circularity contract — the fixtures and the engine share the design corpus as a common ancestor — but the rule table's discriminating power beyond this corpus is untested. This will be disclosed to the verifier as a stated limit of the evidence; an out-of-corpus fixture probe is a legitimate future verifier ask. No action required in R1.

## Rework return requirements

Per `22_` §Handoff, unchanged, plus:

1. All 14 `22_` acceptance criteria re-proven in the R1 return (including two-run byte-identical determinism and the anti-circularity checks — RW corrections must not regress them).
2. A **per-finding disposition table** in the updated Builder Delivery Record: RW-01..RW-10 → what changed, where, and the proof (test/defect/output) that the failing behavior is corrected.
3. The honest evaluated-count restatement (RW-02): predicates evaluated / defect-reachable / NOT-EVALUABLE-with-rationale, per fixture.
4. Per-predicate defect-flip evidence (which seeded defect flips which predicate) in the seeded-defect report.
5. Same allowlist (`design/traces/behavioral/` new/modified files only), same return format (zip + RETURN_MANIFEST + Delivery Record with reflexive falsifier element).
6. Scope-deviation rule unchanged: a defect in a **design document** or the **fixture corpus** returns as a change request, never a silent workaround.

**Nothing in this packet reopens `22_`'s scope or adds new requirements beyond correcting the delivered harness to what `22_` already required.**
