# ChatGPT Scoped Confirmation — CP-P2-A Revision 2

**Review target:** `fable/phase2-decision-engine/13_CP-P2-A_Design_Phase_Change_Plan.md`  
**Target SHA-256:** `2666b87598fb45a0f072cb527bf0b57a0df0e47bce74d8dec4657b274c125a1e`  
**Gate commit:** `54179e799a4ec2fc5932d9c41a64f0856b4820a7`  
**Gate tree:** `fc2ef1492abeec361ca0b8f45cf1899df5b186a9`  
**Uploaded packet SHA-256:** `3fa1b0ad93cbdde0b358381bdb8700b8a1c1a80e63fc7b9df0952c46219efafc`  
**Review type:** Narrow scoped confirmation of Revision 2; no design execution or Builder authorization  
**Verifier:** ChatGPT  
**Owner decisions not reopened:** OD-1, OD-2 with DE-R8 modification, OD-3, and discovery acceptance at trail entry 82

---

## 1. Verdict

# **PASS WITH TWO PRE-AUTHORIZED CONTROL CORRECTIONS**

Revision 2 materially closes the twelve Revision 1 findings. The Decision Engine design direction, candidate neutrality, authority boundary, proposed DE-R texts, data/sandbox protections, owner-decision boundary, and post-design gate sequence are fit to proceed.

The plan is not rejected and no discovery conclusion or owner decision is reopened. Two remaining control gaps must be corrected before Hunter approves the plan:

1. The design-gate status, evidence-reproduction, and scorecard-calibration contract is not yet fully machine-checkable.
2. The accepted CAP-01 through CAP-04 requirements are not fully operationalized by the applicability matrix and stage contract, especially CAP-04.

Fable may apply the corrections in §5 without another verifier round when every condition is met exactly and no other plan semantics change. Hunter may then approve the corrected plan and authorize design execution. Any contested disposition, altered owner intent, changed candidate set, weakened DE-R language, or material expansion returns only the affected scope for review.

---

## 2. Independent Packet Verification

```text
Uploaded ZIP SHA-256
 3fa1b0ad93cbdde0b358381bdb8700b8a1c1a80e63fc7b9df0952c46219efafc
 Matches owner/Fable-declared value: YES

Packet checksum entries
 9 / 9 passed

Review-target SHA-256
 2666b87598fb45a0f072cb527bf0b57a0df0e47bce74d8dec4657b274c125a1e

Git bundle
 Valid; complete history

Gate commit
 54179e799a4ec2fc5932d9c41a64f0856b4820a7

Gate tree
 fc2ef1492abeec361ca0b8f45cf1899df5b186a9

Commit-to-tree binding
 Independently reproduced: PASS

Fresh checkout
 Clean

Revision 1 → Revision 2 git diff check
 PASS

Packet copies versus repository files
 4 / 4 byte-identical

Revision 1 → Revision 2 plan patch
 Byte-identical to independently generated git diff

Design Authority Manifest pre-approval objects
 19 / 19 files exist and SHA-256 values match

Accepted v1.3 Manual/register identities
 3 / 3 SHA-256 values match
 3 / 3 Git blob identities match

Design Requirements Applicability Matrix
 125 accepted rows
 125 unique accepted IDs
 Exact accepted-register order
 53 Binding
 67 Design subject
 3 Deferred
 2 N/A
 8 proposed rows, exactly DE-R1 through DE-R8
 Validator result: PASS

Verifier replacement requirement texts
 DE-R1 through DE-R8: 8 / 8 verbatim matches
 DE-R8 required-test list: verbatim substantive match

Acceptance/release claims
 No owner-plan approval claimed
 No design execution claimed
 No TASK-0003+ authorization claimed
 No architecture selection claimed
 No v1.4 acceptance or release claimed
```

I also inspected the complete gate-commit change set. The accepted v1.3 Manual and Requirements Register remain unchanged. The additional changes are control-plane records, checksums/manifests, the preserved verifier response, the applicability matrix/validator, the Revision 2 plan, dispositions, and TOPIC-0002 status history.

---

## 3. Prior Finding Dispositions

| Finding | Scoped result |
| --- | --- |
| P2A-01 — Item-level execution contracts | **Substantively closed.** B1–B14 now carry objective, authority, dependencies, outputs, alternatives, decision owner, tests, evidence, acceptance, falsifier, and downstream fields. The final status/evidence mechanism needs the bounded P2A-13 correction below. |
| P2A-02 — Frozen authority and requirement surface | **Closed.** TOPIC-0002, the 19-object pre-approval authority corpus, exclusions, later-entry rule, 125-row matrix, validator, bundle, and commit/tree evidence are present and valid. |
| P2A-03 — DE-R1 identity semantics | **Closed.** Verifier replacement adopted verbatim and carried into B3 tests. |
| P2A-04 — DE-R2 concurrency/ordering | **Closed.** Verifier replacement adopted verbatim; consistency boundaries and interleaving tests are explicit. |
| P2A-05 — DE-R3 degraded operation | **Closed.** Dependency-by-capability design and failure tests replace the single-ladder presumption. |
| P2A-06 — DE-R4/DE-R5 trust, routing, and attention | **Closed.** Mandatory authority controls, lower/escalate-only model influence, semantic use of untrusted content, full routing output, and ATT-01-constrained attention are preserved. |
| P2A-07 — DE-R6 policy objects/precedence | **Closed.** Complete replay basis, permitted-exception boundaries, protection floors, rollback semantics, and four alternatives are carried. |
| P2A-08 — DE-R7 events/evidence/replay | **Closed.** Canonical state, ActionRequests, projections, UI state, external receipts, and partial-failure exposure are included. |
| P2A-09 — DE-R8 automatic expansion | **Closed.** Owner intent is preserved inside a bounded, per-class, independently evidenced policy with all eleven required design tests. |
| P2A-10 — Standing-role refresh | **Closed at plan level.** GOV-01 amendment text, current-facing scope, ADR-019 historical preservation, and included/excluded scan method are explicit. |
| P2A-11 — Design-test data/sandbox controls | **Closed.** Synthetic default, controlled real sampling, redaction/retention/model eligibility, untrusted-content isolation, no mutation/outbound authority, APP-05 envelopes, and packet hygiene are explicit. |
| P2A-12 — Owner boundary and post-design sequence | **Closed.** Plan approval is separated from design acceptance and v1.4 acceptance; dispositions, correction, and scoped re-verification precede the owner design gate. |

---

## 4. New Bounded Findings

## P2A-13 — Medium — Design-gate status, reproducibility, and score calibration are not fully closed

**Affected:** Plan §§4, 6, 7, and 11; `13M_Design_Requirements_Applicability_Matrix.md`; `13V_validate_design_matrix.py`

**Problem:**

Revision 2 says every item will resolve to `complete / incomplete / blocked / deliberately deferred`, and §11 requires an “updated `13M_` completion column.” The current matrix has no completion/status field. `D-B12` will carry per-B-item status, but there is no machine-validated requirement-level status/evidence overlay showing how all 133 accepted/proposed rows resolve at the final gate.

The common B-item contract also promises “evidence and independent reproduction,” but the item templates do not yet establish one mandatory reproduction record. Finally, the candidate scorecard freezes criteria and weights but not the scoring scales, direction, missing-evidence rule, or tie/near-tie handling. Those omissions permit post-result calibration even if the named criteria remain unchanged.

**Required correction:**

Before owner approval, add a common gate-evidence contract with all of the following:

1. **Requirement-level gate status:** either add machine-validated `Gate status`, `Evidence pointer`, and `Test result` columns to `13M_`, or create a generated companion such as `13G_Design_Gate_Status_and_Evidence_Matrix.md`. It must preserve all 133 IDs in order.
2. **Allowed status enum:** `Not started / Complete / Incomplete / Blocked / Build-gate deferred / Deliberately deferred / N/A`.
3. **Final-gate rule:** every Binding, Design subject, and proposed DE-R row must be `Complete` or an explicitly permitted `Build-gate deferred` item cited to §7. `Not started`, `Incomplete`, and `Blocked` block the design gate. `Deliberately deferred` requires the plan-authorized rationale and gate disposition.
4. **Independent-reproduction record:** every B artifact must state input/object hashes, exact procedure or commands (or deterministic line-cited reasoning procedure for non-executable analysis), tool/environment versions, expected result, actual result, trace/evidence hashes, falsifier outcome, and known coverage limits.
5. **Scorecard preregistration:** before the first candidate-specific execution, freeze the scoring scale and direction for criteria 7–11, measurement method and evidence source, missing-evidence treatment, tie/near-tie threshold, and selection-versus-deferral rule. After the first candidate trace, any change requires §1.4 amendment and invalidates affected comparisons.
6. **Validator update:** the relevant validator must check the status overlay/columns and scorecard-preregistration artifact before the final gate.
7. **§11 wording:** replace the nonexistent “updated `13M_` completion column” reference with the exact artifact selected above.

**Acceptance condition:** An independent verifier can determine every B-item and requirement-row gate result, reproduce the supporting evidence, and recompute the candidate recommendation without relying on Fable’s narrative judgment.

---

## P2A-14 — High — CAP-01 through CAP-04 are not fully operationalized

**Affected:** Plan §§2, 7, 11, and 12; matrix rows CAP-01 through CAP-04; B9, B10, B11, B12, and B14

**Problem:**

The matrix marks all four CAP requirements Binding but maps them only to general §12 capacity/spend statements. That is incomplete:

- **CAP-01** requires declared maximum standing load across active work, queue size, aging, owner decision-minutes, spend, and concurrency. Revision 2 declares only three active design branches, named owner gates, and a not-measured spend disclosure.
- **CAP-02** requires a measurable gate with a cost-side comparison and explicit stop/continue decision. The design gate has quality tests, but no complete actual-versus-cap record.
- **CAP-03** may defer live provider collection to the build gate, but the Decision Engine design still needs the coverage-disclosed, source-replaceable telemetry/evidence contract and schema by which that evidence enters the system.
- **CAP-04** is not merely a stage-spend disclosure. It requires an economic retirement/redesign review flag at AUD-03, without automatic disablement and with protected control classes exempt from cost-only retirement. The current plan does not assign or test that Decision Engine behavior.

**Required correction:**

1. **Design-phase capacity contract:** add exact numeric maxima—or explicit `0`/`N/A` with rationale—for active design branches, queued Builder tasks, concurrent workers, open verifier findings/rework items, review-item aging, owner decision-minutes, and the available spend/session proxy. State the pause/park rule when a cap is exceeded.
2. **Gate capacity record:** add a required design-gate artifact, either standalone or inside `D-B12`, reporting actual values against each cap, coverage gaps, rework/failure burden, and an explicit `stop / continue / redesign` disposition.
3. **CAP-03 traceability:** map CAP-03 to B9/B11/B14 for a provider-independent telemetry/evidence record, coverage and billed/estimated/inferred fields, source provenance, event linkage, and schema representation. Live provider collection may remain a §7 build-gate obligation.
4. **CAP-04 traceability:** map CAP-04 to B9/B10/B11. Add a synthetic design-gate case proving that cost-over-value evidence creates the correctly partitioned AUD-03 review item, never auto-disables the automation, and does not retire safety, resilience, security, audit, or legally required controls solely because they are cost centers.
5. **Matrix/validator:** update the four CAP rows, treatment ownership, artifacts, and tests; recalculate counts only if treatment categories change; update `13V_` as needed.

**Acceptance condition:** The design plan both governs its own standing load and ensures that the future Decision Engine can receive coverage-disclosed cost evidence and raise the accepted CAP-04 review event correctly.

---

## 5. Pre-Authorized Correction Path

Fable may apply P2A-13 and P2A-14 without another verifier response when all of these conditions are satisfied:

1. The eight DE-R blockquotes and DE-R8 test list remain byte-identical.
2. S1, S2, and S3 remain equally viable under the existing neutrality preconditions.
3. OD-1, OD-2 with DE-R8 modification, OD-3, and discovery acceptance are not reopened.
4. No accepted v1.3 Manual or register content is changed by the plan-correction commit.
5. The corrections add only the gate-evidence/status contract, scorecard-preregistration rule, CAP stage controls, CAP traceability, and corresponding validator/matrix updates.
6. All hashes and commit/tree evidence are regenerated and validate 100%.
7. The corrected matrix still contains exactly 125 accepted IDs in accepted-register order plus DE-R1 through DE-R8.
8. The owner-approval record binds the corrected plan, matrix/status artifact, and validators by exact SHA-256 and commit/tree.
9. Nothing claims design execution before Hunter approves the corrected plan.
10. Any material semantic departure or contested finding returns only that affected scope for targeted review.

The corrections may be presented directly inside Hunter’s plan-approval package. Hunter’s approval then authorizes the design work under the corrected limits and evidence contract; it does not select a record shape, accept DE-R1 through DE-R8, authorize a v1.4 release, or accept v1.4.

---

## 6. Gate State

```text
Accepted v1.3 baseline:             UNCHANGED
Discovery acceptance:               VALID
OD-1 / OD-2(+DE-R8) / OD-3:        NOT REOPENED
P2A-01 through P2A-12:              SUBSTANTIVELY CLOSED
CP-P2-A Revision 2 direction:       PASS
P2A-13 / P2A-14 corrections:       PRE-AUTHORIZED
Additional verifier round:          NOT REQUIRED IF EXACT
Owner plan approval:                AUTHORIZED AFTER CORRECTIONS
Design execution:                   BLOCKED UNTIL OWNER APPROVAL
TASK-0003+ Builder authorization:   BLOCKED UNTIL OWNER APPROVAL
Record-shape selection:             NOT MADE
DE-R1 through DE-R8 acceptance:     NOT MADE
v1.4 release / acceptance:          NOT AUTHORIZED
Next actors:                        Fable → Hunter
```

The standing separation remains controlling: Fable owns architecture, planning, dispositions, and project management; ChatGPT independently verifies; Claude Opus 5 performs only separately authorized Builder work; and Hunter retains owner-level decisions and final acceptance.
