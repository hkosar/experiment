# 01 — Decision Engine Discovery Report (Revised — correction cycle per P2D-01..12)

**Status:** Discovery execution artifact — **nonbinding**; revised after the post-discovery verifier review (`07_`, PASS WITH CHANGES) with all twelve findings concurred (`08_`). Awaiting scoped re-verification, then the owner gate. Nothing here alters the accepted v1.3 baseline.

## 1. Method compliance and disclosures

Evidence pass over the corrected single-tree authority corpus (`04_`, 13 files at gate commit `fa01b9d…`, validated 100% by `04V_`; intent frozen at trail entry 75 — **the prior trail-77 citation is removed, P2D-01**). Three normalized candidate shapes × orthogonal tier policy carried through **27** fixtures (`03F`): 10 owner scenarios, 16 adversarial/boundary including four added protection cases (A13–A16), and one end-to-end substitution case (E2E-1). Branches used 3/3; owner questions during discovery 0; spend not measured (approved disclosure; 2 Fable working sessions, 0 Builder); applicability-matrix changes from initial population: 0.

## 2. Evidence-pass result (unchanged in substance)

The recorded intent (trail 1–75, walkthrough) and the accepted requirement layers are **mutually consistent**: no contradiction requiring owner arbitration was found. (One contradiction was found in Fable’s own draft recommendation, not in the corpus: the initial OQ-07 queue proposal violated accepted PER-02/EX-03 and was corrected per P2R-01.) The engine's obligations derive cleanly: capture-first, impact-based escalation, recommendation-with-alternatives, proportional attention under the accepted **ATT-01** boundary, outcome-not-code approvals, resumable failure, preservation and momentum, self-generated observation. Full mapping: `00A_`.

## 3. Candidate result (recalibrated per P2D-03)

**No shape was eliminated.** Under normalized definitions (equal persistence, concurrency, external-evidence references, read projections; tiers as policy), the **26 discovery cases** yield **23 full passes and 3 pass-conditionals shared by all shapes** (GAP-2 dedup design, DE-R2 serialization, OD-1 owner policy); the one **design-gate fixture (E2E-1) pends** by design. Counts machine-reconciled: `03R_Replay_Count_Report.txt`. **S2 (Decision Case linking separately-owned records) is Fable's technically reviewed recommendation and the leading hypothesis** on the tradeoff basis in `03_` §4 — clearest evidence-authority boundaries and source-of-truth alignment at moderate read complexity — **not an accepted design**. S1 is a viable fallback if read latency dominates; S3's projection pattern is adoptable inside S2.

## 4. Replay result (recalibrated per P2D-04)

26 discovery cases + 1 design-gate fixture, each input carrying a structured control envelope (P2R-02; `03V_` validation 35/35), with per-case transition traces, actual-vs-expected results, and pass rules (`03F`). Verdicts: **23 all-shape full PASS; 3 PASS-CONDITIONAL on named open items; E2E-1 pending at the design gate.** The twin-input injection oracle (A2) now proves the correct property: external content is usable semantic data while embedded instructions carry zero authority (TRS-02). Protection coverage now spans IDN (A1, A15), TRS (A2, A3), DAT (A13), LOG (A16), ACT (A7), SCH (A14), RES (A10) — every family P2-06 made mandatory.

## 5. Core hypothesis (recalibrated per P2D-05)

**Conclusion: NOT FALSIFIED under fixed normalization; the end-to-end boundary remains a design-gate test.**
Checks 1–5: hold on paper under the field-authority contract (`02_` OQ-02) — control fields from authoritative sources only; model-proposed fields may lower authority or escalate, never raise; missing/stale control → fail closed; evidence separation structural (A16); corrections stay weak evidence (A9). Check 6 falsifier (named, carried): >10% of real inputs requiring raw-content consultation beyond normalized dimensions for tier assignment; plus E2E-1's stronger form — a model change raising the maximum authorized action from identical **raw** input falsifies the boundary. Both are design-gate tests with defined procedures; discovery claims no more than the paper result.

## 6. Stage-gate self-check (corrected per P2D-12 — as of this snapshot)

| # | Criterion | State |
| --- | --- | --- |
| 1 | Authority manifest verifies | **PASS** (`04V_` 13/13) |
| 2 | All 125 requirements dispositioned | **PASS** (0 execution changes) |
| 3 | Every OQ complete (7 fields) | **PASS** (revised `02_`) |
| 4 | Every replay has oracle/actual/pass-fail/gap | **PASS** for the 26 discovery cases (recorded outcomes/gaps in `03F`); **E2E-1 explicitly PENDING** under the design-gate hypothesis test |
| 5 | No Critical/High gap deferred without owner acceptance | **PASS** (GAP-1 → OD-1; GAP-2 open-blocking, not deferred) |
| 6 | Candidates visibly nonbinding; v1.3 unaltered | **PASS** |
| 7 | Concise owner package | **PASS** (rebuilt `04_`) — presentation **PENDING** verifier re-verification |
| 8 | §20A.2 gate items | see index below — items pending by nature at this stage |

**§20A.2 gate index (eleven items):** 1 scope statement — PASS (plan §2) · 2 requirement applicability — PASS (matrix) · 3 evidence/artifacts — PASS (this set + fixtures) · 4 source manifest — PASS (`04_`/`04V_`) · 5 verifier response — **PENDING** (this correction cycle's re-verification) · 6 Fable dispositions — PASS (`08_`) · 7 unresolved disagreements — NONE (all twelve concurred) · 8 owner decisions — **PENDING** (OD-1/2/3 at owner gate) · 9 residual risks — PASS (§7 below) · 10 capacity/cost disclosure — PASS (§1) · 11 next-stage recommendation — PASS (`05_`).

## 7. Residual risk statement

(1) The recommendation/policy separation is paper-validated only; its two falsifiers are explicit and scheduled. (2) Dedup/identity design (GAP-2) is open and blocking — wrong design risks double actions or lost events; objective acceptance tests are defined. (3) Serialization latency (DE-R2) could tax the capture experience if mis-designed. (4) OD-1 mis-setting could over- or under-interrupt; every miss is mandatory review input. All four are named, owned, and testable; none is silent.

## 8. What the design phase inherits

Corrected inputs: S2 leading hypothesis + tradeoff table; field-authority contract; five-way identity separation with GAP-2 acceptance tests; complete event/record set with recorded-output replay; policy-object requirements with four precedence alternatives (unresolved by design intent); queue admission by owner-action + attention contract; ritual envelopes; all six hypothesis checks as design-gate tests; DE-R1..R7 intents with acceptance sketches (`05_`).
