# 03 — Scenario and Adversarial Replay Matrix (Revised per P2D-03/04/06/07/08)

**Status:** Discovery execution artifact — nonbinding; correction-cycle revision. **Per-case reproducible fixtures live in `03F_Replay_Fixtures.json`** (machine-readable: normalized input, envelope, start state, policy version, candidate transition traces, actual results distinct from expected, pass rules, verdicts, linked gaps/falsifiers). This document holds the candidate contracts, the two-axis analysis, tradeoffs, and the verdict/gap summary.

## 1. Two axes (P2D-03 — confound removed)

**Axis 1 — record/authority shape** (all three normalized with equivalent capabilities: durable persistence independent of any session; optimistic-or-serialized concurrency; **external references to evidence records — no shape may embed or author harness evidence**; materialized/derived read projections permitted):
- **S1 — Aggregate root:** one persistent case root with append-only child records.
- **S2 — Decision Case:** a case identity linking separately-owned canonical records.
- **S3 — Independent records/events:** no aggregate; materialized read projections provide case views (projections are never authoritative).

**Axis 2 — processing disposition (policy, applies identically to every shape):** T0 record-only · T1 deterministic fast path (no case record) · T2 recommend-and-act with receipt · T3 owner decision · T4 consequential chain. The prior analysis wrongly attributed tier behavior (e.g., A11 no-case path) to shape; it is policy.

**Withdrawn:** the Revision-1 structural eliminations of S1 (S5/A6/A11/A12) — each failure followed from an artificially weak S1 definition, not from aggregation itself.

## 2. Candidate contracts (transition rules an independent reviewer applies to the fixtures)

Common pipeline events: `IE` ingest+envelope → `NR` normalization (recorded, with provenance) → `RR` recommendation (recorded, with model/context/version) → `PE` policy evaluation (versioned; emits tier + authority ceiling + attention band) → `DE` decision event (auto/owner) → `PL` placement / `AR` action request (idempotency key) → external `XR` execution receipt / `VR` harness verification → `RE` reconciliation → derived state. **All shapes:** control fields come only from authoritative sources (field-authority contract, `02_` OQ-02); evidence records are external and append-only; replay consumes recorded `NR`/`RR` outputs, never re-invocation. **Shape deltas:** S1 stores pipeline records as append-only children of a root; S2 links them by case ID across owning stores; S3 correlates independent records and serves reads from projections (freshness is a design obligation).

## 3. Replay results (fixtures `03F`, 27 cases)

- **S1–S10 owner scenarios:** all three shapes **PASS** all ten under the normalized contracts. S1/S9 carry a projection-freshness/indexing design obligation for S3 (and a description-index obligation for all shapes). S2's capture provenance corrected: **source = owner note (trusted-internal) quoting Cole's mention — attributed hearsay, not Cole as source** (P2D-04).
- **A1–A12 adversarial:** all shapes **PASS** A1–A4, A7, A9–A12; **A2 rewritten as the twin-input oracle** (identical legitimate content ± injected instruction → identical semantic placement, zero authority effect — external content is usable data per TRS-02, only embedded commands are inert); **A5 PASS-CONDITIONAL** on GAP-2 (dedup design **OPEN** — reclassified per P2D-08); **A6 PASS-CONDITIONAL** on DE-R2 (serialization latency untested); **A8 PASS-CONDITIONAL** on OD-1 (operating policy within the accepted **ATT-01** boundary — P2D-06).
- **A13–A16 protection coverage (added per P2D-07):** DAT restricted-render/notification-preview (A13), SCH stale-envelope refusal (A14), IDN-03 kill/revoke + emergency read-only (A15), LOG-02 evidence-tamper rejection (A16) — all shapes **PASS**; the invariants hold structurally (store-side authority, not engine promises).
- **E2E-1 (added per P2D-05):** end-to-end model substitution from **raw** input — **DESIGN-GATE TEST**: the paper trace holds under the field-authority contract (model-proposed fields may lower or escalate, never raise authority), but the claim is limited to *not falsified under fixed normalization*; the end-to-end boundary must be proven at the design gate.

**Honest summary: no shape is eliminated.** The set is **26 discovery replay cases plus one design-gate fixture (E2E-1)**. Result: **23 full passes, 3 pass-conditional (A5 → GAP-2, A6 → DE-R2, A8 → OD-1), and 1 pending design-gate test** — machine-reconciled in `03R_Replay_Count_Report.txt`. Every fixture input carries a fully structured control envelope (P2R-02; validated by `03V_`, 35/35 envelopes; schema version renamed SV-1); envelope structuring changed no verdict.

## 4. Tradeoffs (what actually distinguishes the shapes — P2D-03 acceptance basis)

| Dimension | S1 aggregate root | S2 Decision Case | S3 events + projections |
| --- | --- | --- | --- |
| Consistency | Strongest locally (single root) | Per-record stores + case link (moderate) | Eventual at projections; strong at records |
| Read/latency complexity | Lowest | Moderate (link assembly / cached view) | Highest (projection maintenance) |
| Correction (COR-01) | Append child; simple | Append linked record; simple | Append event; projections must reconverge |
| Concurrency | Root contention point (optimistic OK) | Per-record independence + DE-R2 point | Naturally append-serial; conflicts at projection |
| Evidence-authority clarity | Requires discipline (root *references* external evidence) | **Clearest** — ownership boundaries are the design | Clear at records; projections must not masquerade as authority |
| Source-of-truth separation (5.2.1) | Risk of root becoming a shadow store | Aligned by construction | Aligned; projection governance needed |
| Migration/evolution | Root schema changes ripple | Record types evolve independently | Most flexible; tooling-heavy |

**Recommendation: S2 remains the leading hypothesis** — best evidence-authority clarity and source-of-truth alignment at moderate read complexity — now grounded in tradeoffs rather than eliminations. S1 is the fallback if read-latency dominates; S3's projection pattern is adoptable *inside* S2 for hot views. Final selection is a design-gate decision with the E2E-1, check-4, GAP-2, and DE-R2 tests in hand.

## 5. Gap register (corrected)

- **GAP-1 (High → owner decision OD-1):** Critical-interrupt *operating policy* undefined **within the accepted ATT-01 boundary** (the boundary itself is accepted requirement text and not in question — P2D-06). Closes at the owner gate.
- **GAP-2 (High — OPEN blocking design requirement, P2D-08):** event identity/deduplication design. Five identity concepts separated; dedup must be source-aware and uncertainty-aware; **no formula canonized**. Acceptance tests: no false-merge of distinct legitimate identical events; transformed redeliveries caught; identity independent of normalization version.
- **GAP-3 (Medium — open design):** per-topic serialization (DE-R2) with a latency bound to validate.
- **GAP-4 (Medium — requirement carried):** degraded-mode ladder DE-R3 (capture-only → read-only → refuse-consequential), exercised in A10/A15.
- **GAP-5 (Low — owner-tunable):** T2 pre-calibration daily cap with defined overflow (see `04_` OD-2).

Severity rule compliance: no Critical gaps; the High gaps carry the two permitted closures (owner decision; open blocking design requirement with objective tests) — **neither is claimed resolved**.
