# Discovery Source and Exclusion Manifest (P2-01; rebuilt per P2D-01)

**Snapshot definition (single, reproducible):** the discovery authority corpus is **exactly the blobs of the files listed below as they exist in the tree of discovery-gate commit `fa01b9d84f5f8015493557c30487274709841e17`** (tree `0779ead294acb8aa8082876d0ca63d421a55c1e4`). This supersedes the earlier plan-gate (`a7ac2e1…`) binding, which was internally inconsistent (P2D-01): several corpus files did not yet exist at that commit. Every file below carries its Git blob ID at the gate commit, its SHA-256, and the last commit that modified it. Validation: `04V_validate_authority_corpus.py` reconstructs and checks 100% of this table from the full-history bundle with one command.

**Snapshot boundary (unchanged in substance):** trail authority for entries 41+ is **only** the frozen file `06_Frozen_Authority_Trail_41-75.md`. Later plan-review, approval, and execution-control events — **including trail entries 76 and 77** — are NOT part of the discovery intent corpus. (P2D-01 correction: the prior artifacts cited entry 77 as calibration evidence; that citation is removed everywhere rather than admitted, as it was not load-bearing.) A later owner-intent statement enters only through a versioned update of this manifest or the bounded MEM-09 owner-input process.

## Authority corpus (per-file provenance)

| Source | Role | Git blob @ gate | SHA-256 | Last modified in |
| --- | --- | --- | --- | --- |
| `baseline/chatgpt-phase1-v1.0/08_Phase_1_Conversation_Decision_Trail.md` | Intent: original decision-trail entries 1–40 (verbatim baseline) | `2880ec9f2c023184…` | `85e0745928420045f3afe55a9e330e3716869252ed44d32c49338ac4beda2e1d` | `31ee1045328e` |
| `fable/phase2-decision-engine/06_Frozen_Authority_Trail_41-75.md` | Intent: frozen addendum snapshot, entries 41–75 (the ONLY authoritative trail source for 41+; the live addendum path is control-plane and excluded) | `d3247de74c73315f…` | `60c55ee0f0db610208ee90a55c64550172612012ce6f6b7b253782e470999828` | `34a917ba356f` |
| `fable/phase1-audit-v1.0/04_Proposed_Operating_Manual_v1.1.md` | Authority: accepted v1.3 Operating Manual (incl. ADRs, DPs, ATT-01 boundary) | `2bbb3904fce278c0…` | `30b020c5724308373c289c28c030c48e8cbdb6d317062dea0e9197a69219f867` | `81731fc43a99` |
| `fable/phase1-audit-v1.0/05_Requirements_Register_v1.1.md` | Authority: accepted v1.3 register (Markdown) | `f5d49b4417591f49…` | `972be5cad10061e66b855425e97de44edc196d845a57710aa36f407fdcc95046` | `81731fc43a99` |
| `fable/phase1-audit-v1.0/05_Requirements_Register_v1.1.csv` | Authority: accepted v1.3 register (CSV) | `0785b81d64e6388e…` | `8fb88b6b6bd762029703f24a8a0bbb5f61284f58a9c3a9eceb69c5c010ffb24c` | `81731fc43a99` |
| `fable/phase1-audit-v1.0/10_Concept_Experience_Walkthrough.md` | Intent: ten owner-reviewed scenarios | `62c74fd7539210a9…` | `20552a4175d215c9eb2d6fcdd37c890649b71e2e0099bf915ae31ab1cfde3393` | `102fa5293b18` |
| `fable/phase1-audit-v1.0/02_Consensus_Issue_Register.md` | Reference: consensus dispositions cited by discovery | `2758d19541f04410…` | `9ececb44e7513dbc9698f1a50621b1ec3b6af6eed7e7f8c3c92db36407fcc014` | `da152ca82243` |
| `baseline/chatgpt-phase1-v1.0/04_Phase_1_Architecture_Decision_Records.md` | Reference: historical v1.0 ADR source | `f8212e92255ee321…` | `2cb6f2619516b32424bf201819ca42e3a9148d789a8fe59aa24430d394b480e6` | `31ee1045328e` |
| `baseline/chatgpt-phase1-v1.0/03_Phase_1_Design_Principles.md` | Reference: historical v1.0 design principles | `32a113f8de4a7d4c…` | `4b82b1589a855db8eed757481ed6ad171ad8d8a6854dc1b16e3fe54c81cb0f1b` | `31ee1045328e` |
| `baseline/chatgpt-phase1-v1.0/06_Open_Questions_and_Phase_2_Backlog.md` | Reference: original Phase 2 backlog (OQ ancestry) | `de5872ae1166a225…` | `ba63ec91645544b22bfba74cfb9417c0fc05fcace1250760792ce2a17efb6097` | `31ee1045328e` |
| `fable/phase2-decision-engine/00_Phase2_Discovery_Plan.md` | Control: the owner-approved plan (Revision 2) | `d959c9fcbb83a438…` | `75c636801ef112f08876c17f5dde28caa0d628c838fed8d8d917c19ce3bc7c99` | `a7ac2e19efb2` |
| `fable/phase2-decision-engine/03_Requirements_Applicability_Matrix.md` | Control: execution checklist (post-P2-10 corrected form) | `4de67cc86889eb0d…` | `9808f318ced90a433d99752b4b3365e1910aa50814a8ec2a2eae96b1b5d484f1` | `34a917ba356f` |
| `fable/v1.2-ideas-pass/bootstrap_id_registry.md` | Control record (non-intent): TOPIC-0002 allocation; live lifecycle state | `e8d86dc8557e51e0…` | `603474ad2c23018b48be048febe132720d9801c1dcb0a4e21cf46915a3ac168f` | `c4c32b4e89e8` |

## Intentional exclusions (with rationale)

| Excluded | Rationale |
| --- | --- |
| Live `fable/phase1-audit-v1.0/06_Decision_Trail_Addendum.md` (entries 76+) | Control-plane record growing with gate events; superseded for discovery intent by the frozen snapshot |
| `fable/v1.2-ideas-pass/sources/**` | External-untrusted peer sources; adopted content already lives in the accepted baseline |
| TASK-0001/0002 gate and verifier records (`fable/v1.2-ideas-pass/00..22`) | Process evidence, not Decision Engine intent |
| `fable/v1.2-ideas-pass/14_NateHerk_Comprehensive_Review.md` | Reference-only research register; adopted ideas are accepted baseline text |
| `fable/phase1-audit-v1.0/03_Auditor_Reports/**` | Audit working papers; findings merged via the consensus register |
| `baseline/**/archive, *.docx, templates` | Superseded drafts, binary mirrors, process templates |
| Narrative/status docs (`00_/01_/07_/07a/07b/08_/09_/09a` and manifests) | Derivative of trail/Manual/register; orientation only, never authority |

Every discovery conclusion cites stable identifiers (trail entry number, requirement ID, Manual section) resolvable against this corpus.
