# 25 — TASK-0003 Rework Packet R3 (APP-07): P2S-01 Behavioral Simulator

**Purpose:** third and intended-final correction round. **R2's core is verified genuine** — independent re-execution reproduces every shipped output byte-identically; adversarial probing of the rewritten witness pairs found **no answer-injection channels among the 56**; the composition suite drives the real `compose_policies` with input-level defects; the scenario deltas are faithful. Nothing in R2's shipped PASSes is dishonest. What remains is one thing, applied consistently: **the falsifier discipline has not yet been applied to the suite's own newest layer.** Four judge checks, two counterfactual switches, and one mutation exist whose ability to fail is asserted (and was proven only by the reviewer's manual experiments) rather than demonstrated in shipped evidence — and the integrity check's self-description claims more than it delivers. R3 closes exactly that. `22_` + `23_` + `24_` + this packet are the sole instruction authority.

---

## Identity and authority

- **Task:** TASK-0003 (OPEN) — rework cycle R3.
- **Delivery under review:** `TASK0003_Builder_Return_R2.zip`, SHA-256 `c4b0bdd57d72740146f0012d044b3321dd5459a496e51db371e920af659b0a54`; 28 files, allowlist-clean, manifest 28/28, record identity verified.
- **Review provenance:** Fable independent verification (including direct comparison of the two packet-quoted rules against the actual D-B5 and D-B7 — see below) plus a third-cycle adversarial delta review. Recorded at decision-trail entry 95.

## Closures from Fable's side (no Builder action)

- **Falsifier row 5 (packet-quoted rules) is CLOSED:** Fable holds D-B5 and D-B7 and verified both encodings. The D-B7 §3 interrupt-policy citation rule is faithful. The D-B5 encoding is **correct for A10's case** and conservative overall: it refuses consequential classes under *any* degradation, where D-B5's matrix assigns per-failure-row safe modes ("the available safe mode is a function of which dependency failed — there is no single ladder"). The row-level granularity is a stated limit Fable will carry to the verifier; your blanket rule needs no change — but it does need a real falsifier (RW-19).
- The `verification_arrives` restructuring on S6/A12 is accepted (the per-action XR→VR→RE chain is verified in the event stream); A12's thin input-side support for it will be carried as a Fable disclosure, not a rework item.

## What R2 verified as genuine (carries forward; do not regress)

Mechanics 28/28; anti-circularity clean across six engine-side modules; determinism 9/9 byte-identical (Fable-executed, twice, from the repository corpus); all three new event mechanisms conditioned on stimulus facts with content-reading predicates (stale-heartbeat and recall-miss corruptions fire, verified); all four RW-12 predicate rewrites reading computed state with mechanism-level mutations; composition suite 11/11 through the real mechanism with input-level defects, PC-10 through the composition path; A12 preview removed; masked-render reading the computed render-application record; the receipt-masking hole closed per-evidence-event; `_receipt_overwrite` keyed on (action, kind), verified in both directions.

## Findings requiring rework

### RW-19 (Medium — RW-15's mechanism has no falsifier; counterfactual switch unwired): deleting the D-B5 degradation rule is undetectable
- **Failing behavior:** `Defects.ignore_degradation` (`simulate.py:49`) appears in no runner. Applied manually to A10 the judged verdict does not flip — with the degradation rule disabled, A10's `internal-write` envelope refuses the consequential action anyway. The Delivery Record's RW-15 proof line ("with `ignore_degradation` seeded → 0") describes an event-count change, not a shipped, discriminating pass/fail flip. No fixture pairs degradation with an otherwise-permissive envelope, so the mechanism is load-bearing nowhere on this corpus — the same "guarded by accident" shape RW-15 diagnosed, one level up. Undisclosed in NOT-SIMULATED.
- **Smallest correction:** follow the composition-suite precedent — a harness self-test (clearly labeled as such, not a fixture) that drives a degraded-stores case with an otherwise-sufficient envelope through the **real** action-emission path: clean run refuses citing degradation; `ignore_degradation` seeded → the action would emit → FAIL. Wire the switch into the shipped falsifier run and report it; state the corpus limitation in one plain sentence.

### RW-20 (Medium — RW-16's pending/ratified distinction has no detector; dead mutation)
- **Failing behavior:** `pending-policy-cited-as-ratified` corrupts the status, but the only reader (`judge.py:207-212`) accepts either status and the evidence matcher checks presence only — verified: A8 passes under the mutation. The rule "a PENDING policy is citable as pending, never as ratified" has an emission and no detector. Also, `"interrupt_policy": "OD-1"` is an unconditional constant on every DecisionEvent of every fixture; only the status is stimulus-conditioned.
- **Smallest correction:** the judge check (or a predicate) must fail when the computed policy status contradicts the stimulus (pending cited as ratified); wire the mutation into shipped evidence with the flip demonstrated. Either condition the citation's presence on stimulus interrupt-policy relevance or disclose it as a constant-by-design with rationale.

### RW-21 (Medium — four judge pass-rule checks have no demonstrated falsifier in shipped runs)
- **Failing behavior:** `prove_reachability` pairs mutations with **forbidden predicates only**; the judge is never run over mutated results. The mutations for `masked_render`, `hearsay_provenance`, `interrupt_policy_cited` exist and DO flip the checks (reviewer-verified manually: A12 True→False under `render-leak`, S2 under `hearsay-provenance-lost`, A8 under `interrupt-policy-uncited`) — but no shipped output demonstrates it, and `Defects.render_leak` is in no runner. Falsifiability of the newest evidence layer is asserted, which is the exact property this suite exists to demonstrate.
- **Smallest correction:** extend the reachability prover (or add a parallel judge-falsifier section) so every judge pass-rule check is demonstrated flippable in shipped evidence, with named witnesses, same reporting shape as `predicate_reachability`. Wire all orphaned defect switches into runners or remove them.

### RW-22 (Medium — integrity check oversold; two residual answer-key writes)
- **Failing behavior:** `run_defects.py:60-91` AST-matches exactly two write patterns; the reviewer evaded it five ways (`extras.update(...)`, `setattr`, `+=`, aliasing, wholesale reassignment) with zero violations reported. The docstring ("Prove no mutation writes an artifact channel") and README ("checked structurally, not asserted") claim proof; your own Delivery Record falsifier row 1 states the honest version — align the code and README with it. Two residuals inside the blind spot: `normalizer-authority-leak` (`mutations.py:493-499`) sets `authority_invariant=False` directly — the key its predicate reads — instead of perturbing the M2 ceiling and letting the flag be recomputed by the production writer (`simulate.py:589-592`); `evidence-tamper-succeeds` (`mutations.py:518-520`) still writes a `"tampered": True` confession token read by its predicate's first disjunct (the honest second disjunct is the real witness — drop the token and the first disjunct or make the first disjunct computed).
- **Smallest correction:** re-describe the check honestly as a regression tripwire for the two known patterns (extend coverage if cheap — e.g. also match the evasion forms — but do not re-claim proof); fix the two mutations to perturb computed state and let the summary keys be recomputed.

### RW-23 (Low — accounting completeness): PC-12 unlisted; synthetic-only coverage said plainly
- **Failing behavior:** `README.md:29` / `run_composition.py:1` say "PC-1..PC-12"; the suite holds 9 PC cases + scope + predicate; PC-5/PC-8 are declared not-simulated, but **PC-12 appears in neither list** (it is mechanically PC-2's shape and exercised fixture-side via A4 — say so, don't leave it unaccounted). Additionally: `scope`/`applicability_predicate`/`effective_window` execute **only** in the synthetic composition suite — no fixture-driven path uses them. The `exercised_by_composition_suite` list implies this; state it in one plain sentence.
- **Smallest correction:** account PC-12 explicitly; correct the label; add the one-sentence synthetic-only statement.

### RW-24 (Low — residual honesty/fidelity set)
- `simulate.py:527-530`: `WatchdogHeartbeatEvent` hard-codes `fresh: True`; the transcribed fact `derived["watchdog_fresh"]` (`scenarios.py:212`) has no reader — derive freshness from the recorded fact.
- `simulate.py:536-540`: `FocusPointerEvent.preserved` is asserted whenever a focus exists (no displacement mechanism) — derive it or declare preservation as asserted-not-modeled.
- S4: a silently dropped `OverrideEvent` is undetected (its only readers are the >1 nagging count and a matcher-less evidence fallback) — give "unlogged override" an OverrideEvent-presence leg or declare the limit.
- `scenarios.py:9-25`: complete the Builder-added stimuli enumeration (S2/A5/A9 `actions` tuples; `verification_arrives` on S6/A12).
- `fold.py:218-246`: R1's "receipt referenced but absent from the basis" branch was dropped in the per-evidence rewrite — restore it or justify its removal.
- `oracle.py:437-438`: the "suppression record" evidence matcher is vacuously satisfiable (every run emits an AttentionChangeEvent) — fix or declare.
- PC-3 floor substitution (DAT render vs the table's untrusted-quarantine floor) and PC-7 third-domain substitution — mechanism-equivalent; add a one-line note each so the suite's mapping to D-B8's table is exact about its substitutions.

## Rework return requirements

Per `22_`/`23_`/`24_`, unchanged, plus:
1. Per-finding disposition table RW-19..RW-24 with shipped-evidence proof per row (no "verified manually" claims — if it can fail, a shipped run must show it failing under its seeded defect).
2. No orphaned defect switches: every `Defects` field appears in at least one shipped runner, or is removed.
3. Judge-check falsifier section in shipped output, same shape as `predicate_reachability`.
4. All criteria re-proven; determinism; anti-circularity; hygiene; allowlist.

**Scope note:** every item above is correctable inside `design/traces/behavioral/`. Fable expects R3 to be the final round: the defect class has narrowed each cycle (R0 circular evidence → R1 padded counts → R2 undemonstrated falsifiability of auxiliary checks), and R3's list is the tail of that sequence. If anything in this packet is ambiguous, return a change request rather than interpreting.
