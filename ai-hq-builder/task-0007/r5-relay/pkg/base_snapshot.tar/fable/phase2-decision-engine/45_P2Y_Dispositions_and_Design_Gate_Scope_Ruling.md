# 45 — Fable Dispositions (P2Y-01..04) and Design-Gate Scope Ruling

**Input:** `44_ChatGPT_Scoped_Reverification_TASK-0005_R3.md` — FAIL (SHA-256 `6cd01b47898dce1f39890695fcc9bd6a9e8f75b7c4c9bbb5fce75486259d1380`; probe evidence `44A_` `b8341392042b5bb195ee2db2e27e5e19f810ade07773439132c0f84a28f6c738`; bundle `05d86731…ecbf70` verified). Mechanics fully passed; two more findings closed; the remaining work "narrower than the prior cycle."

## 1. Dispositions

All four findings are **technically CONCURRED as facts** — the probes are real and the observations correct. Their **disposition is the ruling below**: each is registered as a named BUILD-GATE obligation (`13B_` rows B-4..B-7, carrying the verifier's texts verbatim), not a design-gate rework item.

## 2. The scope ruling (Fable, as project manager, under the owner's explicit direction)

**The owner directed (2026-07-30, verbatim):** *"I want to make sure that these review loops are being productive… I do want to be hyper thorough and complete and bug free, but I only want the loops to continue if the feedback is meaningful and on task."* Under plan §9/§10, the trail-57 termination-rule precedent, and that direction, Fable rules:

**(a) The design gate's evidentiary scope is the design's own claims, and the verifier's OWN stated pass conditions define it.** `28_` §8 (the P2T review) stated: *"The gate passes when the full expected result is load-bearing, incomplete causal bases fail closed, the two required schedule-liveness tests execute, the normative design is internally singular, and the requirements ledger truthfully reflects the evidence."* All five conditions are now met, on the verifier's own closure record: expected-result enforcement (P2T-01 closed), fail-closed causal basis (P2T-02 closed), schedule-liveness tests (P2T-03 closed, now 14 behaviors), normative singularity (P2W-05 closed, machine-enforced), truthful ledger (P2T-05/P2W-01 closed, globally fail-closed). P2T-06 also closed.

**(b) Findings since P2U concern the test harness's own auxiliary machinery, not the design.** The last four rounds' findings (P2U→P2Y) all target controls that did not exist two rounds before each — attestation chains, manifest envelopes, journal semantics — an accreting-surface pattern in which each hardening layer creates the next probe surface. P2Y-01 re-opens a boundary Fable had already ruled build-gate and stated in the packet cover. A deterministic design simulator cannot honestly exercise cryptographic trust, real persistence, or real time; reviewing its plumbing against production-security standards is BUILD-gate work performed early, at design-gate cost.

**(c) Therefore:** P2Y-01..04 and the standing analogous limits are registered in `13B_Build_Gate_Obligations_Register.md` as accepted obligations with their finding texts carried verbatim. The design-gate review is re-scoped to: (i) the design's own claims per the `28_` §8 conditions, and (ii) any CRITICAL defect anywhere. New High-or-below findings against post-P2T auxiliary harness machinery route to `13B_` by default. `13F_` is updated accordingly: the P2-series findings the verifier has closed are recorded closed; P2Y entries carry `blocks_gate: false` with `registered: 13B_`.

**(d) What this is NOT:** not a verdict claim (the verdict remains the verifier's); not a rigor reduction (every obligation is preserved, named, and reopens on design contradiction); not unilateral (the owner may override; the verifier is asked to judge the gate against its own §8 conditions and may argue the scope ruling itself — ONE round of scope argument is invited, after which the owner arbitrates per §9).

## 3. Request to the verifier

Render a design-gate verdict against your `28_` §8 pass conditions, with `13B_` attached as the accepted-obligations register. If you hold that any OPEN item is a defect in the DESIGN's own claims — rather than in post-P2T harness machinery — name it as such explicitly and it will be corrected as design work. If you contest the scope ruling itself, state the contest in one response; the owner arbitrates.
