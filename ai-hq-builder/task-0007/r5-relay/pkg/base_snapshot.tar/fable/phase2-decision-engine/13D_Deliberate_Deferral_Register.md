# 13D — Deliberate-Deferral Gate-Disposition Register (P2S-08)

**Purpose:** one enumerated, machine-validated gate disposition per `Deliberately deferred` requirement row in `13G_` — replacing free-text rationale cells as the gate evidence. Authority for each deferral is the named plan clause **plus this register entry as the recorded gate disposition**. `13V_` fails if any `13G_` deferred row lacks an entry here or any entry lacks a field.

| ID | Authority | Rationale | Destination | Dependency | Reopening trigger |
| --- | --- | --- | --- | --- | --- |
| BUS-02 | Plan §12 out-of-scope (integration detail) + this register | Data HQ is a distinct subsystem; the engine consumes its registry events via the BUS-10 record | Future Data HQ change plan under a new TOPIC | BUS-10 registry schema (done) | Any engine design element found requiring Data HQ internals |
| BUS-03 | Plan §12 scope boundary + this register | The lead/ad/call closed loop is business-workflow design; the engine ingests its events and routes its review items | Future business-workflow change plan | Event-ingestion contract (done) | A loop workflow needing engine-internal changes |
| BUS-04 | Plan §12 (MCP write boundaries deferred) + this register | MCP boundary design explicitly deferred by the approved plan; engine-side read-only ceilings hold the invariant | MCP-boundary gate at its deferred slot | Action-class ceilings (done) | Any MCP write capability proposal |
| EX-09 | Plan §12 (Discord implementation deferred) + this register | Breadcrumb density is presentation-layer detail of the deferred Discord surface | Discord-implementation change plan | None | Discord implementation opening |
| EX-10 | Plan §12 (Discord implementation deferred) + this register | Navigation rendering is presentation-layer; relationship links are recorded engine-side (done) | Discord-implementation change plan | Recorded links (done) | Discord implementation opening |
| EX-11 | ADR-021 memory-provider gate + plan §12 + this register | Semantic recall is a memory-provider capability; engine records carry the IDs/links retrieval will use | ADR-021 provider-selection gate | Record/link schema (done) | Provider selection opening |
| HW-01 | Manual §19.3 owner-timed deferral + this register | Hardware purchase timing is an owner decision, revalidated at purchase; no design dependency | Owner decision at purchase time | None | Owner initiates purchase |
| LRN-08 | ADR-021 gate + this register | Semantic retrieval is the provider capability; category structure lives in placement records (done) | ADR-021 gate | Category fields (done) | Provider selection opening |
| MEM-04 | ADR-021 gate + this register | The knowledge-provider capability contract is evaluated at provider selection | ADR-021 gate | MEM-08 boundary rules (done) | Provider selection opening |
| MEM-09 | Onboarding-surface scope + this register | Structured-interview persistence is onboarding-layer design; the engine consumes persisted records | Onboarding-surface change plan | None | Onboarding design opening |
| ONB-01 | Onboarding-surface scope + this register | The setup-session/secret-surface design is onboarding-layer; the engine keeps the grant-once/activate-staged data posture (done) | Onboarding-surface change plan | Activation posture (done) | Onboarding design opening |
| PLAT-01 | Plan §12 + this register | Discord-first preference is an interface-implementation matter | Discord-implementation change plan | None | Interface implementation opening |
| PLAT-03 | Plan §12 + this register | Companion dashboard is evidence-gated on demonstrated Discord limits | Post-activation evidence review | None | Demonstrated Discord limitation |
| SEC-02 | Voice-subsystem scope + this register | Owner-voice profile mechanics are a distinct outbound subsystem; engine action-class separation holds the invariant (done) | Voice-subsystem change plan | Action-class ceilings (done) | Any outbound-voice work item |
