# Independent Verifier Response — Phase 2 Decision Engine Discovery Plan, Revision 1

**Review target:** `fable/phase2-decision-engine/00_Phase2_Discovery_Plan.md`  
**Target SHA-256:** `7b2786013e93df5cd50a8f7953a924e44faa07656b6ecdcda5c8224d1955b2f7`  
**Packet:** `P2DP_Rev1_Verifier_Review_Packet.zip`  
**Packet SHA-256:** `fa65bef71b0213c042c4219650d3294d51fface4706673a25b050cabfcea2612`  
**Verifier:** ChatGPT, independent auditor/reviewer  
**Gate type:** Plan-review gate, before Phase 2 discovery work  
**Date:** 2026-07-28

---

## 1. Verdict

# **PASS WITH CHANGES**

The plan is correctly framed as discovery rather than design, preserves the accepted v1.3 baseline, identifies the Decision Engine as the Phase 2 parent topic, and does not authorize implementation or external action. Its core direction is sound:

- test the separation between intelligent recommendation and deterministic policy;
- preserve the ten owner-reviewed experience scenarios as the intent surface;
- terminate the ten open questions rather than permit perpetual refinement;
- keep Fable as planner/architect, ChatGPT as independent verifier, and Opus 5 outside discovery unless a separately governed build task is authorized;
- keep deferred provider and implementation choices out of the discovery scope.

No plan section receives a Dissent. Revision 1 is not yet ready for owner approval because the discovery gate lacks a complete authority corpus, explicit gate acceptance criteria, a neutral decision-record hypothesis, the full accepted routing dimensions, independently falsifiable scenario oracles, and the complete post-discovery disposition sequence.

**Phase 2 discovery work remains blocked pending a scoped Revision 2 verification.** No Builder involvement is required to correct the plan.

---

## 2. Packet Integrity and Evidence Qualification

### Verified

- The ZIP opened successfully.
- All **7 of 7** manifest-declared payload hashes matched.
- The review-target hash matched the value stated by Fable.
- The registry contains `TOPIC-0002` with the expected title and current plan-review state.
- The included v1.3 Manual, Requirements Register, walkthrough, README, registry, and decision-trail addendum are internally consistent on:
  - v1.3 owner acceptance;
  - Phase 2 gate opening;
  - the standing role substitution to Opus 5 through trail entry 69;
  - the owner directive in trail entry 74.

### Not independently proven

- The declared source commit `8f858b7a2515b6ecd6a3898fe82cc50d786f2b56` is not cryptographically bound to source tree `64b6bf9ba6ce46d028317220f82bbd841cbd61ee` inside this packet; no Git bundle or equivalent commit object was included.
- The packet says the context includes the decision trail “through entry 74,” but it includes only the addendum beginning at entry 41. The authoritative original trail for entries 1–40 is not in the packet even though the proposed discovery method requires an evidence pass over entries 1–74.

I could inspect the earlier trail from prior conversation artifacts, so substantive review was possible. The packet itself is not yet self-contained enough to serve as the final plan-gate evidence package.

---

## 3. Section Dispositions

| Plan section | Disposition | Summary |
| --- | --- | --- |
| §1 Objective | **Concur with modification** | Correct discovery/design boundary; remove the implied assumption that one monolithic Decision object spans every pipeline stage. |
| §2 Scope | **Concur with modification** | Correct pipeline and non-goals; explicitly make accepted IDN/TRS/DAT/LOG/ACT/SCH/RES constraints mandatory inputs rather than “security architecture” deferrals. |
| §3 Binding intents | **Concur** | Strong intent set and appropriate reliance on the owner-reviewed walkthrough. Add Business/Personal separation and correction/recall invariants through the traceability matrix rather than expanding the prose list. |
| §4 Open questions | **Concur with modification** | OQ set is useful but OQ-01/OQ-02/OQ-05/OQ-06/OQ-09 need authority, routing-dimension, no-decision-path, precedence, replay, and evidence-store corrections. |
| §5 Method and deliverables | **Concur with modification** | Evidence pass and paper replay are appropriate; add a requirements applicability matrix, scenario oracle/adversarial matrix, source/exclusion manifest, and concise owner decision package. |
| §6 Gates and termination | **Concur with modification** | Convergence is correct; add risk/capacity limits, severity-based closure rules, Fable disposition and correction after verifier review, and scoped re-verification before owner acceptance when findings alter the deliverables. |

---

## 4. Findings

## P2-01 — High — The discovery authority corpus and verifier packet are incomplete

**Affected:** Plan §3, §5(a), packet manifest, GOV-02 / Manual §20A.2 item 4 and item 11  
**Problem:** The plan requires an evidence pass over decision-trail entries 1–74, but the packet contains only entries 41–74. The export also asserts a source commit/tree without including a Git bundle or equivalent commit-to-tree proof. A future verifier cannot reproduce the exact authority corpus from the packet alone.

**Why this matters:** Decision Engine discovery will convert owner intent into the system’s central routing and authority model. Missing early intent is not a cosmetic packet defect; it can change classification, attention, and owner-interaction requirements.

**Required Revision 2 change:**

1. Add a **Discovery Source and Exclusion Manifest** that includes, at minimum:
   - original decision trail entries 1–40;
   - addendum entries 41–74;
   - accepted v1.3 Manual;
   - accepted Requirements Register;
   - ten-scenario walkthrough;
   - applicable issue/register and ADR sources used by the discovery;
   - registry allocation for TOPIC-0002;
   - every intentional exclusion with rationale.
2. Include either:
   - a Git bundle containing the declared source commit and its ancestry; or
   - a complete immutable source projection with enough evidence to bind every file to the declared commit/tree.
3. Require every discovery conclusion to cite stable source identifiers and exact trail/requirement/section references.

**Closure test:** a new reviewer can validate 100% of the source manifest, reconstruct or verify the source commit/tree, and inspect entries 1–74 without relying on a prior chat session.

---

## P2-02 — High — The plan does not yet define a checkable stage-gate contract

**Affected:** Plan §§5–6; GOV-02; Manual §20A.2; CAP-01; CAP-02  
**Problem:** Revision 1 supplies an objective, scope, method, and termination sentence, but it does not declare:

- the stage risk class;
- the accepted requirement/decision IDs in scope and those constrained/deferred;
- measurable acceptance criteria for each deliverable;
- maximum standing load, owner-decision budget, model/concurrency/spend disclosure, or stop condition;
- the authoritative version/rollback point;
- which §20A.2 packet fields are applicable and which are justified `N/A` for a discovery-only stage.

“Every OQ terminated” and “every scenario replayed or gap dispositioned” are not sufficient. A Critical dependency could be deferred-with-rationale and still satisfy the current wording.

**Required Revision 2 change:** Add a **Plan Control and Acceptance** section containing:

```text
Stage risk class:
- Design-governance / high leverage
- Runtime or external-action authority: none

Authority scope:
- Requirement Applicability Matrix covering all 125 accepted requirements:
  In-scope / binding constraint / deferred / N/A, with rationale
- Binding ADRs and decision-trail entries

Capacity:
- Maximum active discovery branches
- Owner-question/decision-minute cap
- Model/provider and spend coverage or explicit “not measured” disclosure
- Stop/park condition if the stage exceeds its declared capacity

Acceptance criteria:
1. Every source in the authority manifest verifies.
2. Every accepted requirement is dispositioned in the applicability matrix.
3. Every OQ carries evidence, alternatives, recommendation, status,
   downstream impact, and a DEC-02 falsifier when consequential.
4. Every ten-scenario and mandatory adversarial replay has a recorded oracle,
   actual result, pass/fail, and gap disposition.
5. No Critical or High gap remains deferred without explicit owner acceptance.
6. Candidate artifacts remain visibly nonbinding and do not alter v1.3.
7. The owner receives a concise decision package with direct links to evidence.
8. The final gate packet satisfies or justifies N/A for all §20A.2 items.
```

**Closure test:** the verifier can issue a pass/fail on objective criteria rather than judging whether the report “feels comprehensive.”

---

## P2-03 — High — The plan prematurely assumes a single Decision object spans every input and stage

**Affected:** Plan §1, §2 “decision-object lifecycle,” OQ-01, OQ-09; Manual §§5.2.1, 11.2, 11A.4, 11A.6; ACT-01; LOG-01/02; AUT-09/10/11; GOV-03  
**Problem:** Revision 1 asks for a minimal “decision-object schema covering all nine stages” and asks what the engine requires before “marking any decision executed.” This risks two pre-decisions:

1. every input becomes a Decision record; and
2. the Decision Engine owns execution truth.

The accepted baseline separates canonical object ownership and independent evidence. Routine capture, deterministic filing, status receipts, and logged no-op events may require no owner or policy “decision.” Likewise, execution state must be derived from an authoritative execution receipt and verification record; the engine cannot self-attest that an action occurred or passed.

**Required Revision 2 change:** Replace the monolithic assumption with an explicit discovery question:

```text
OQ-01 — Decision-case boundary and record model
Which inputs create a Decision Case, which follow a deterministic/no-decision
fast path, and which are rejected, quarantined, or recorded only? Test whether
one aggregate with linked typed records or multiple canonical objects best
preserves source-of-truth separation. Candidate records may include Input Event,
Understanding/Normalization, Recommendation, Policy Evaluation, Decision,
Action Request, Execution Receipt, Verification/Reconciliation, Learning Event,
and Fold-Back event. Discovery must not presume that all stages are mutable
fields on one object.
```

Replace OQ-09 with:

```text
OQ-09 — Execution and verification authority
Which authoritative receipt, evidence-store record, and reconciliation event
permit the Decision Case to derive an executed/verified state? The Decision
Engine may request or observe execution but cannot create independent harness
evidence, overwrite receipts, or self-mark a consequential action as verified.
Uncertain outcomes follow ACT-01 and fail closed.
```

**Closure test:** the Discovery Report includes at least one no-decision path, one owner-decision path, one deterministic policy path, and one consequential external-action path with separate authoritative evidence.

---

## P2-04 — High — OQ-02 omits the accepted routing dimensions and conflates state with routing inputs

**Affected:** Plan §2, OQ-02; Manual §4.4, §8.2.1; WF-03; WF-09; WF-10; WF-11; TRS-01/03; AUT-12  
**Problem:** OQ-02 currently asks how “the five state dimensions plus trust envelope plus action class” produce a deterministic route. The accepted WF-09 model requires the discovery to evaluate independent routing dimensions including placement, relationship, blocking, disposition, attention, authority, and confidence. The five canonical dimensions describe an object’s current state; some may be inputs, some outputs, and some irrelevant to an initial routing event. Treating them as the routing formula risks entrenching the wrong model before discovery begins.

**Required Revision 2 change:** Replace OQ-02 with:

```text
OQ-02 — Routing dimensions and recommendation/policy boundary
Which normalized input dimensions, current-state dimensions, and policy facts
are inputs to routing, and which dimensions are outputs? The candidate set must
explicitly test WF-09 placement, relationship, blocking, disposition, attention,
authority, and confidence; TRS origin/trust/instruction-authority/sensitivity/
verification; domain and source object; action class and risk; applicable policy
and schema versions; current stage/status/focus/health where relevant; and
correction history. Define where probabilistic recommendation ends, where
versioned deterministic policy begins, and what fails closed when context or
policy is missing, stale, disputed, or conflicting.
```

Add to OQ-06:

```text
Policy representation must cover scope, precedence, conflict resolution,
default/deny behavior, version binding, effective dates, exception authority,
change events, rollback, and deterministic replay from the same normalized
input and policy version.
```

**Closure test:** the same normalized event + same control envelope + same policy version reproduces the same policy result even when the recommendation model changes; a policy change can alter behavior only through a governed versioned policy event.

---

## P2-05 — High — Narrative scenario replay is not yet an independently falsifiable test method

**Affected:** Plan §3, §5(c), §6; DEC-02; GOV-02 item 6; IDN; TRS; DAT; ACT; LOG; RES; COR-01  
**Problem:** The ten walkthrough scenarios are a strong owner-intent surface, but they are narrative examples rather than test oracles. “Replay clean” is undefined. A candidate can appear to satisfy a scenario while violating trust, policy, event-ordering, correction, or evidence-authority requirements.

**Required Revision 2 change:** Add a separate **Scenario and Adversarial Replay Matrix**. For each candidate model, every case must state:

- normalized input and source/trust/data/identity envelope;
- starting canonical state and policy/schema versions;
- expected recommendation, policy result, attention, route, action authority, and visible receipt;
- required events and authoritative evidence;
- allowed alternatives;
- forbidden outcomes;
- pass/fail result and linked gap;
- falsifier or reasoned N/A.

The matrix must include the ten owner-reviewed scenarios plus, at minimum, these adversarial or boundary cases:

1. authenticated-channel signal with failed owner identity/session binding;
2. prompt-injection content in email, transcript, web page, or tool output;
3. missing or unknown trust/data class;
4. stale, missing, disputed, or conflicting policy/rule version;
5. duplicate/replayed input event;
6. concurrent events that imply conflicting routes or state changes;
7. worker failure after a possible side effect but before receipt recording;
8. Critical-versus-Needs-Owner during quiet hours;
9. wrong initial filing followed by COR-01 correction and calibration;
10. unavailable/degraded canonical store or evidence store;
11. routine no-decision fast path;
12. consequential action requiring step-up, external receipt, and reconciliation.

**Severity rule:** a Critical/High replay gap blocks the design gate unless resolved or explicitly accepted by Hunter with consequences. It cannot be closed merely as “deferred-with-rationale.”

**Closure test:** another verifier can reproduce each replay and determine pass/fail without relying on Fable’s narrative interpretation.

---

## P2-06 — Medium — The security non-goal can be misread as excluding mandatory Decision Engine constraints

**Affected:** Plan §2 non-goals; Manual §11A; IDN-01/02/03; TRS-01/02/03; DAT-01/02; LOG-01/02; ACT-01; SCH-01/02; RES-01/02/03  
**Problem:** “Security architecture beyond the accepted 11A layer” is reasonably deferred, but the plan does not say plainly that operationalizing the accepted protection layer inside the Decision Engine is mandatory discovery work. The current wording could allow identity, kill/revoke, data rendering, log authority, retry uncertainty, scheduled-run envelopes, or degraded-mode behavior to be treated as later implementation detail.

**Required Revision 2 change:** Replace the relevant non-goal sentence with:

```text
New security architecture and product selection remain deferred. Operationalizing
all accepted IDN/TRS/DAT/LOG/ACT/SCH/RES constraints as Decision Engine inputs,
policy boundaries, failure states, evidence requirements, and replay invariants is
mandatory in this discovery. A discovered incompatibility becomes a blocking gap;
it is not deferred as implementation detail.
```

**Closure test:** the Requirements Applicability Matrix identifies each protection/resilience requirement as in-scope or binding constraint and every candidate replay demonstrates how it is enforced or fails closed.

---

## P2-07 — Medium — Owner-input handling and the post-discovery gate sequence are incomplete

**Affected:** Plan §6; MEM-09; GOV-02; Manual §20A.2; owner interview preference and attention constraints  
**Problem:** The plan says owner attention is spent only at the two owner gates. That is a useful default, but it can force Fable to infer unresolved owner preference or defer questions that could be resolved with one bounded batch. The final pipeline also says “verifier review → owner review,” omitting Fable’s disposition/correction and any scoped re-verification required by material findings.

**Required Revision 2 change:** Add:

```text
Owner-input policy
- No trickle questions during discovery.
- Existing accepted sources are used first.
- If a material owner-intent ambiguity blocks multiple OQs, Fable may prepare one
  consolidated, bounded decision packet at the owner gate (or one earlier blocking
  packet only when proceeding would contaminate the discovery).
- Each answer is persisted immediately under MEM-09 with source, scope, and impact.
- No unanswered preference is silently inferred.

Post-discovery gate
Discovery artifacts → verifier review → Fable dispositions → corrected artifacts
and scoped re-verification where findings affect substance/evidence → Fable gate
recommendation → concise owner decision package → owner acceptance of owner-level
choices and residual gaps → design-phase change plan may open.
```

**Closure test:** no owner-level ambiguity is silently converted into a design assumption, and no verifier finding reaches the owner as if it were already dispositioned.

---

## P2-08 — Medium — Deliverables need explicit traceability and an ADD-compatible owner surface

**Affected:** Plan §5 deliverables; Manual §21.3; EX-02; EX-08; GOV-02  
**Problem:** The three proposed documents can contain the needed material, but they do not guarantee a durable requirements/trail matrix, a test oracle, or a concise owner-facing decision package. A long Discovery Report alone recreates the review burden the operating model is intended to remove.

**Required Revision 2 change:** Revise the deliverable set to include or explicitly embed these controlled artifacts:

```text
00A_Discovery_Authority_and_Traceability_Matrix.md
- every source, accepted requirement, ADR, trail intent, and exclusion

01_Decision_Engine_Discovery_Report.md
- findings, alternatives, candidate models, recommendation boundaries,
  core-hypothesis test and falsifier

02_Open_Question_Dispositions.md
- each OQ: status, evidence, alternatives, recommendation, owner decision if any,
  downstream impact, falsifier/review trigger

03_Scenario_and_Adversarial_Replay_Matrix.md
- ten owner scenarios + mandatory boundary cases, with reproducible oracles

04_Owner_Decision_Package.md
- one-screen summary; only decisions that need Hunter; genuine tradeoffs;
  Fable recommendation; business consequences; residual gaps; direct links

05_Design_Phase_Change_Plan_Proposal.md
- nonbinding draft only; opened for approval after discovery acceptance
```

The GOV-01 / standing-role refresh may appear as an isolated mechanical item, but it must not be presented as a Decision Engine discovery conclusion.

**Closure test:** Hunter can understand what is settled, what needs his judgment, what remains risky, and what opens next without reviewing the full report.

---

## 5. Core-Hypothesis Test Minimum

Revision 2 should state that the recommendation-versus-policy hypothesis is not satisfied by a diagram alone. The Discovery Report’s test plan must include at least these falsifiable checks:

1. **Model substitution invariance:** With the same normalized input, control envelope, and policy version, changing the recommendation model may change suggested ranking or explanation but may not silently change the maximum authorized action.
2. **Policy-version causality:** A change in deterministic behavior is traceable to a governed policy/version event, not prompt drift or model memory.
3. **Missing-control fail-closed behavior:** A missing/stale identity, trust, data, policy, schema, checkpoint, or authority field cannot be filled by model inference for a consequential action.
4. **Evidence separation:** Recommendation, policy result, execution receipt, and verification evidence originate from their accepted authorities; the Decision Engine cannot self-certify execution or verification.
5. **Correction path:** A wrong recommendation or route can be corrected through COR-01 without rewriting history, and the correction becomes bounded learning evidence rather than policy.
6. **Separation falsifier:** The report must name evidence that would show the separation is unworkable—for example, if required policy decisions cannot be made replayable without embedding unbounded model interpretation—and state what architecture question would reopen if that evidence appears.

---

## 6. Required Revision 2 Gate Packet

The next packet may be narrow. It should contain:

1. Revised `00_Phase2_Discovery_Plan.md`.
2. A disposition table for P2-01 through P2-08.
3. The complete source corpus, including original trail entries 1–40.
4. Source/exclusion manifest and commit/tree binding evidence.
5. Requirements Applicability Matrix, even if initially populated as the approved plan’s execution checklist.
6. Exact diff from Revision 1 to Revision 2.
7. Fable’s plan-gate recommendation.

No Opus Builder packet is required. This is Fable-owned plan/control work.

---

## 7. Gate State

```text
Phase 2 gate from accepted v1.3:          OPEN
TOPIC-0002 allocation:                    VALID
P2-DP Revision 1 direction:               CONCUR
P2-DP Revision 1 plan gate:               PASS WITH CHANGES
Owner approval of discovery plan:         BLOCKED
Discovery execution:                      BLOCKED
Builder involvement:                      NOT AUTHORIZED / NOT NEEDED
Next actor:                               Fable
Next action:                              Issue Revision 2 and scoped verifier packet
Required next verifier review:             SCOPED, not a full baseline audit
```

The standing separation remains applicable: Fable plans and architects, ChatGPT independently verifies, Opus 5 builds only from an approved task packet, Sonnet remains read-only context/traceability support, and Hunter retains owner-level acceptance and final authority.

---

## 8. Final Verifier Position

The plan has the right center of gravity and should be revised rather than redesigned. The necessary changes make discovery **auditable and neutral**:

- complete the authority corpus;
- define the gate before doing the work;
- avoid assuming every input is one Decision object;
- restore all accepted routing dimensions;
- derive execution truth from independent evidence;
- turn narrative scenarios into falsifiable oracles;
- operationalize the accepted protection layer;
- preserve the owner’s attention with a bounded decision surface;
- keep the post-discovery verifier/disposition/owner sequence intact.

Once those conditions are incorporated and verified, Phase 2 discovery may begin.
