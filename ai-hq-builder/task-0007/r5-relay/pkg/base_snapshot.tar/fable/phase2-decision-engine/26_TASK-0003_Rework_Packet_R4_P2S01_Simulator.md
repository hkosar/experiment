# 26 — TASK-0003 Rework Packet R4 (APP-07): P2S-01 Behavioral Simulator — final completion round

**Purpose:** R3 is **accepted in substance**. The fourth-cycle adversarial review's verdict, quoted: *"Against a three-cycle history of the evidence being weaker than the claims, R3's evidence is for the first time exactly as strong as the claims — with one exception."* This packet carries that one exception, two small disclosure/fix residuals, and one scoped completion of the original Task Packet's requirement 4 — **the change request you yourself surfaced and offered.** Fable expects this to be the last instruction document of TASK-0003. `22_` + `23_` + `24_` + `25_` + this packet are the sole instruction authority.

---

## Identity and authority

- **Task:** TASK-0003 (OPEN) — rework cycle R4 (final).
- **Delivery under review:** `TASK-0003_Builder_Return_R3.zip`, SHA-256 `d2e9f4c908e1d078475fd33f21397bab5a3ddff8f3138058da71e39c6d0ea4e4`; 28 files, manifest 28/28, record hash verified, allowlist-clean.
- **Review provenance:** Fable independent verification (all 15 criteria reproduced byte-identically; the five R2 evasion forms re-probed against the extended tripwire — all caught) plus a fourth-cycle adversarial delta review that live-verified ten witness pairs, both RW-20 derivation paths, layer E's production-path claim, and the S3 threshold against D-B7. Recorded at decision-trail entry 96.

## Closures from Fable's side (no Builder action)

- **The S3 focus-displacement threshold is RATIFIED.** Fable verified your reading against D-B7 §2.1, which you could not see. The band definitions: *"**Critical** (interrupt now) · **Needs-Owner** (queue admission, next natural session) · **Briefing** (scheduled digest) · **Record-only** (filed, findable)."* Only Critical interrupts; Needs-Owner is by definition queued. Your reasoning ("needs-owner means queue for the owner, not seize the foreground") is the documented semantics — and your handling (disclose the failed first attempt, correct the threshold, disclose the missing band comparison rather than papering over it) was exactly right.
- **Layer E, layer D, RW-20's status derivation, RW-22's normalizer repair, the extended tripwire, and all scenario deltas are verified GENUINE.** Complete witness sets confirmed (the targeted witnesses appear beside the blunt ones — the masking R2's first-hit search would have hidden is gone). The restored fold branch and repaired suppression matcher were live-verified with their witnesses. Zero regressions across all 81 combinations.

## Findings — final round

### RW-25 (Low — claim accuracy): the "tampered" disjunct was not removed; the R3 record says it was
- **Failing behavior:** `oracle.py:122` still reads `any(bool(e.payload.get("tampered")) ...)` — byte-identical to R2. Your R3 Delivery Record's RW-22 row claims the confession token *"and the disjunct that read it are both gone."* Only the token is gone; the disjunct is now dead code — a latent confession-token channel the tripwire cannot see (payload keys are not a tripwire channel). Functionally the mutation discriminates correctly through the second, computed disjunct (verified live). The defect is the claim, in the cycle whose theme is claims matching code.
- **Smallest correction:** delete the first disjunct at `oracle.py:122` (or make it computed); include a corrected disposition line in the R4 record acknowledging the R3 misstatement.

### RW-26 (Low — residual detector hole + two disclosure entries)
- **(a) Citation identity leg (demonstrated hole):** `judge.py:229-233` derives the expected *status* from the stimulus but builds its search from the **engine-emitted** policy id — a fabricated citation `ZZ-9 / ratified` passes (verified live). **Fix (preferred over disclosure — it is small):** derive the expected policy id from the stimulus as well and fail an id mismatch; add a mutation perturbing the cited id, with its witness in layer D.
- **(b) OD-1 rule 2 unmodeled and unlisted:** the new quiet-hours suppression (`simulate.py:433-445`) encodes D-B7 §3 rule 1 (verified danger interrupts through quiet hours) only. Rule 2 — quoted for you, since D-B7 is not in your snapshot: *ambiguous physical-danger/security signals fail **toward interrupting**; all other ambiguity holds to the briefing* — has no path and no NOT-SIMULATED entry. Inert on this corpus (A8's trigger is watchdog-confirmed, rule 1). Add the NOT-SIMULATED entry; do not implement it (no fixture exercises it — implementing without a fixture would be untestable code).
- **(c) Standalone-runner gate:** `run_defects.py:615-617` does not fail its exit code on `judge_checks_not_falsifiable > 0` (run_gate.py criterion 13 does, so the shipped gate is sound). Add the condition to the standalone runner so the two agree.

### RW-27 (Medium — requirement-4 completion; the change request you offered, hereby issued): compare the computed attention band against `expected.attention`
- **Basis:** `22_` §Required Behavior item 4 — *"Compares the computed actual result against the expected result and pass rule."* All 27 fixtures carry `expected.attention`; none is compared. You surfaced this honestly at R3 (the S3 exposure), disclosed it in three places, and offered it as a change request. Fable accepts the offer: close the last uncompared expected dimension before this evidence goes to the verifier.
- **Required behavior:**
  1. An oracle-side mapping parses each fixture's `expected.attention` string into a computable expectation (band, and presentation surface where stated — e.g. `"display-only"`, `"Needs Owner"`, `"None (brief line only)"`, `"Briefing"`, `"display + one suggestion max"`). Ground band semantics in the D-B7 §2.1 definitions quoted above.
  2. The judge compares the computed band (and stated surface aspects) against the mapped expectation for all 81 combinations. Values the mapping cannot make computable are reported per-fixture as explicitly unmapped — same honest-coverage shape as the `expected.authority` mapping — never silently skipped and never counted as compared.
  3. **Any combination the new check fails must be diagnosed and dispositioned, not papered over:** encoding defect vs engine defect vs mapping defect, each with its cited basis, per the standing discipline. Scenario changes must remain input-side faithful; engine changes must cite a design rule (packet-quoted rules count); mapping choices must cite D-B7 §2.1. If a fixture's expectation appears to contradict a design rule, that is a change request back to Fable — do not reinterpret either side.
  4. The new check's falsifiability is demonstrated in layer D with named witnesses, like every other judge check; coverage counts restated honestly in the gate report, README, and Delivery Record.

## Rework return requirements

Per all prior packets, unchanged, plus: per-finding disposition table RW-25..RW-27 with shipped-evidence proof per row; the RW-25 errata line; the full battery re-proven (all criteria, determinism, anti-circularity, tripwire, hygiene, allowlist); zero regressions in the 81 baseline combinations except where RW-27 diagnosis legitimately corrects a mapping/encoding/engine defect — each such change individually dispositioned.

**On finality:** R3's packet said "intended-final" and R4 exists anyway — for one misstated claim, two residuals, and a completion you yourself proposed. That is the process working, not failing: each cycle's defect class has shrunk (circular evidence → padded counts → undemonstrated falsifiability → one inaccurate sentence and one missing comparison). R4's list is short enough that nothing smaller than it would justify a cycle at all. If anything here is ambiguous, return a change request rather than interpreting.
