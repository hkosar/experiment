# 37 — TASK-0005 Rework Packet R1 (APP-07): P2V Enforcement Corrections

**Task:** TASK-0005, rework cycle R1. **Instruction authority:** `34_` Task Packet + this packet; governing findings `35_`/`35A_` (the verifier's exact finding and required-correction texts govern — you hold your own return; Fable has not seen it and accepts nothing until its own verification passes); dispositions `36_`. All standing binding rules carry forward (anti-circularity, determinism, hygiene, shipped-evidence-only, no orphaned switches/dead mutations, record-vs-file re-check, scope-deviation ⇒ change request). Allowlist unchanged from `34_`.

## Findings to correct (each must defeat the corresponding `35A_` probe in shipped evidence)

- **RW-28 (P2V-01):** no production-reachable disable path for the global blocking-finding check — remove the public flag; the probe becomes a failing self-test.
- **RW-29 (P2V-02):** `verification_receipt` structurally validated as a hash-bound reference to a registered external record; arbitrary nonempty strings fail closed, shipped.
- **RW-30 (P2V-03):** the external-manifest digest binds every security-relevant control field (enumerated); duplicate external-record identities fail closed; both probes shipped failing.
- **RW-31 (P2V-04):** retired schedule versions cannot re-enter force with pre-retirement horizons; reactivation mints a fresh version + fresh horizon; the verifier's reactivation probe ships failing-then-detected.

## Return requirements — SEQUENCING RESTORED

Per-finding disposition table with shipped-evidence proof; all standing criteria re-proven; APP-06 record with reflexive falsifiers; zip + RETURN_MANIFEST, fingerprint in-channel. **The return comes to FABLE, not to the verifier** — Fable independently verifies, integrates on acceptance, and assembles the verifier packet itself, per the standing pipeline the last relay bypassed. Failure clause: further APP-07 rework from Fable.
