# 13B — Build-Gate Obligations Register

One row per obligation deferred from the design gate to the build gate, each carrying its source and reopening trigger. Machine-referenced by the design-gate scope ruling (`45_`). These are ACCEPTED obligations, not open defects: each names machinery the build phase implements with real credentials, persistence, or cryptography that a deterministic design simulator cannot meaningfully exercise.

| # | Obligation | Source | Carried text / trigger |
| --- | --- | --- | --- |
| B-1 | Live two-model (real LLM) substitution run for check 1 / E2E-1 | Plan §7; D-B12 | Executes at build verification with real models |
| B-2 | Real-input separation-falsifier sample (redacted content) | P2G-14; plan §8 | Owner-gated; executes at build with authorization |
| B-3 | Cryptographic attestation of external evidence (trust roots, signatures; collusion resistance beyond structural separation) | Fable ruling, trail 106; Builder falsifier rows | Envelope already carries trust-root/key fields |
| B-4 | Receipt-purpose taxonomy with authorized assignment (consumer purposes granted by policy, not self-declared) | P2Y-01 (`44_`, carried verbatim) | Extends the design-gate declared-purpose-equality contract |
| B-5 | Journal transaction completeness/scope enforcement (full transactional envelope semantics) | P2Y-02 (`44_`, carried verbatim) | Extends the eight design-gate replay invariants |
| B-6 | Recurrence-definition validation at admission into the durable authority | P2Y-03 (`44_`, carried verbatim) | Extends journal admission checks |
| B-7 | Temporal validity of run receipts (no pre-satisfaction of future deadlines; clock/epoch discipline) | P2Y-04 (`44_`, carried verbatim) | Requires real time semantics a logical-tick simulator cannot honestly exercise |
| B-8 | Watchdog retirement persistence contract | Builder R1 falsifier row 4; Fable durable-identity ruling (trail 105) | The journal is the single artifact a real implementation persists |
| B-9 | Per-entry journal identity (beyond txn id + deterministic order) | Builder R3 falsifier row 3; Fable ruling trail 108 | Build-time schema decision |
| B-10 | D-B5 degraded-operation row-level granularity beyond the blanket rule | Fable stated limit, trail 98 | Per-F-row safe modes exercised when fixtures exist |
| B-11 | Projection-plane design document (P2U-01 preferred option); optional `closed` list in `13F_` | Builder TASK-0005 change requests | Authored during build change-planning |
| B-12 | ActionContext-to-payload binding: the consuming event's declared action keys bound to the canonical ActionRequest payload/real effect (a caller cannot describe a delete as a benign display to obtain a benign contract) | `48_` routed residual (verifier-routed under the termination rule, carried verbatim) | Build implements payload-derived action classification |
| B-13 | Policy-artifact selection binding: which evidence-policy artifact (and version) governs a given action must be bound to an authoritative source outside the fold input — a caller holding two validly bound, internally coherent policies at different versions must not be able to choose which one judges it | Builder TASK-0005 R5 change request (Delivery Record §7); Fable-routed as the B-12 family (trail 113) | Build derives the governing policy binding from the durable authority (journal/control plane), not the caller; same executor-derivation family as B-12 |

Reopening rule: any build-gate obligation whose implementation reveals a DESIGN contradiction returns to a governed design change — none may be silently absorbed.
