# ChatGPT Independent Verifier Response — Phase 2 Decision Engine Discovery Deliverables

**Review target:** `P2_Discovery_Deliverables_Review_Packet.zip`  
**Gate commit:** `fa01b9d84f5f8015493557c30487274709841e17`  
**Gate tree:** `0779ead294acb8aa8082876d0ca63d421a55c1e4`  
**Verifier role:** Independent auditor/reviewer; no implementation or integration authority  
**Date:** 2026-07-28

## 1. Verdict

# **PASS WITH CHANGES**

The discovery produced a useful and directionally strong design-input package. The recommendation/policy separation remains a sound hypothesis, the Decision Case concept is a credible leading candidate, the protection and evidence boundaries are materially better than a conventional monolithic agent design, and the owner-facing intent is generally preserved.

The post-discovery gate does **not** pass yet. Several conclusions are stronger than the supplied evidence supports, the frozen authority boundary was breached, the candidate comparison does not isolate the architecture choices it claims to compare, and the owner decision package contains one direct conflict with the accepted baseline.

No Builder work is required. Fable should revise the discovery artifacts, rerun the affected paper analysis under corrected candidate definitions and replay oracles, disposition the findings below, and return a scoped packet for re-verification.

**Candidate B is not rejected.** It should remain the leading design hypothesis, but it is not yet established as the accepted record model.

## 2. Artifact Dispositions

| Artifact | Disposition | Primary conditions |
| --- | --- | --- |
| `00A_Discovery_Authority_and_Traceability_Matrix.md` | Concur-with-modification | Correct the frozen-corpus breach and snapshot provenance; strengthen stable-source traceability. |
| `01_Decision_Engine_Discovery_Report.md` | Concur-with-modification | Downgrade unsupported pass claims; revise the candidate result and core-hypothesis conclusion after corrected analysis. |
| `02_Open_Question_Dispositions.md` | Concur-with-modification | Complete the plan-mandated disposition fields and correct OQ-04, OQ-05, OQ-06, and OQ-07. |
| `03_Scenario_and_Adversarial_Replay_Matrix.md` | Concur-with-modification | Normalize the candidate comparison, add reproducible transition traces, correct trust semantics, and add missing protection-layer cases. |
| `04_Owner_Decision_Package.md` | Concur-with-modification | Do not present the current version to Hunter; rebuild it after technical dispositions and remove owner certification of technical architecture. |
| `05_Design_Phase_Change_Plan_Proposal.md` | Concur-with-modification | Keep it nonbinding; expand it only after discovery acceptance to cover all carried tests and unresolved design questions. |

## 3. Independent Packet Verification

The packet is usable and its main provenance assertions were independently checked.

```text
Uploaded ZIP SHA-256
9e309d90d551be01bb02f86f092d3f8fb932df62689db392f58b2661aab1c1fb

Export-manifest payload hashes
19 / 19 passed

Git bundle
Valid full-history bundle

Declared gate commit
fa01b9d84f5f8015493557c30487274709841e17

Independently resolved gate tree
0779ead294acb8aa8082876d0ca63d421a55c1e4

Requirements applicability matrix
125 rows / 125 unique IDs
Exact accepted-register order
No missing or extra requirement IDs

Owner-approval commit to discovery gate
No accepted Manual or Requirements Register content changed
Only discovery deliverables and control records changed
```

**Qualification:** the exported `fable/phase2-decision-engine/checksums.sha256` contains 13 entries, but three referenced verifier/control files are absent from the extracted ZIP and exist only inside the Git bundle. Running `sha256sum -c` directly in the exported folder therefore fails. This is addressed in P2D-12.

---

## 4. Findings

## P2D-01 — High — Frozen authority boundary and snapshot provenance are internally inconsistent

**Affected artifacts:** `00A_`, `01_`, `04_Discovery_Source_and_Exclusion_Manifest.md`, `05_`

**Problem:** The approved source manifest freezes discovery intent at trail entry 75 and explicitly excludes later approval/control events unless they enter through a versioned source-manifest update or bounded MEM-09 process. The discovery artifacts nevertheless use trail entry 77 as owner-intent calibration evidence.

- `00A_` includes entry 77 in its binding-intent table while its own line 54 says entries 76+ are excluded.
- `01_` and `05_` use the “trail-77 layman-package precedent” as a design input.
- The source manifest says the frozen trail file exists at commit `a7ac2e1...`; it does not. The frozen file was added later.
- The applicability-matrix hash stated by the manifest is also not the matrix at `a7ac2e1...`.
- The bootstrap-registry hash comes from the earlier commit while other corrected authority files come from later commits. The declared authority corpus is therefore a cross-commit composition, not one reproducible plan-gate tree as claimed.

**Evidence:**

- `04_Discovery_Source_and_Exclusion_Manifest.md:3-5`
- `00A_Discovery_Authority_and_Traceability_Matrix.md:30-42,52-54`
- `01_Decision_Engine_Discovery_Report.md:3,53`
- `05_Design_Phase_Change_Plan_Proposal.md:14`

**Required change:**

1. Remove trail-entry-77 intent from the discovery conclusions, **or** formally admit its narrowly scoped content through MEM-09 and a versioned source-manifest event.
2. Bind the discovery authority corpus to one exact commit/tree or explicitly define a composite snapshot with a complete per-file provenance table.
3. Correct the frozen-file commit/blob assertion, matrix binding, and bootstrap-registry binding.
4. Reissue `00A_` and every downstream reference affected by the correction.

**Acceptance condition:** one command or supplied script reconstructs the exact authority corpus and validates every declared file/hash from the declared snapshot definition.

---

## P2D-02 — High — The OQ disposition artifact does not satisfy the approved disposition contract

**Affected artifacts:** `02_`, `01_`

**Problem:** Plan §5.2 and acceptance criterion 3 require each OQ to include status, evidence, alternatives, recommendation, owner decision if any, downstream impact, and a falsifier/review trigger. OQ-01 substantially does this. Most of OQ-02 through OQ-10 do not provide explicit alternatives and downstream impact; several omit both. The report nevertheless records criterion 3 as PASS.

**Evidence:**

- `00_Phase2_Discovery_Plan.md:88-90,135-140`
- `02_Open_Question_Dispositions.md:13-68`
- `01_Decision_Engine_Discovery_Report.md:38-49`

**Required change:** add the missing fields for every OQ and revise the self-check. Alternatives must be genuine architecture or policy alternatives, not merely “do nothing.” Where no owner decision is required, state that explicitly.

**Acceptance condition:** a deterministic completeness check confirms all ten OQs contain every required field, with direct links to the evidence and downstream deliverables.

---

## P2D-03 — High — The candidate comparison confounds independent design choices and structurally disadvantages A and C

**Affected artifacts:** `01_`, `02_` OQ-01, `03_`, `04_`, `05_`

**Problem:** The analysis claims to compare record models, but Candidate B bundles several independent decisions: linked records, an aggregate case identity, external evidence ownership, event-style history, and T0-T4 processing tiers. Candidate A is defined as one mutable record per input and is then failed for properties that are not inherent to an aggregate. Candidate C is denied a materialized read model and then failed on read-time experience economy.

Examples:

- S5 says Candidate A loses worker state with the session. A persisted aggregate does not inherently do that.
- S6/A12 treat a single aggregate as necessarily self-certifying; an aggregate can reference external immutable evidence.
- A6 assumes last-writer-wins; an aggregate can use optimistic concurrency or append-only child records.
- A11 assumes every input creates a Decision record; that is a processing-disposition choice, not a necessary aggregate property.
- Candidate C can support materialized/derived case views without making the view the authority.

**Evidence:**

- `01_Decision_Engine_Discovery_Report.md:13-19`
- `03_Scenario_and_Adversarial_Replay_Matrix.md:3,15-24,30-49`
- `02_Open_Question_Dispositions.md:5-11`

**Required change:** separate at least two axes:

```text
Record/authority shape
- aggregate root with append-only linked records and external evidence references
- Decision Case linking separately owned canonical records
- independent canonical records/events with materialized read projections

Processing disposition
- T0/T1 no-owner/no-case paths
- T2 receipt path
- T3 owner-decision path
- T4 consequential-action path
```

Re-run the candidate comparison with equivalent safety, evidence, persistence, concurrency, and read-projection capabilities. Candidate B may remain recommended, but its recommendation must rest on measured tradeoffs rather than built-in handicaps.

**Acceptance condition:** the revised matrix demonstrates which conclusions arise from record shape versus tier policy and includes at least consistency, latency/read complexity, correction, concurrency, and evidence-authority tradeoffs.

---

## P2D-04 — High — The “22/22 replay pass” is an analytical assertion, not the reproducible actual-result record required by the plan

**Affected artifacts:** `03_`, `01_`

**Problem:** The matrix supplies expected outcomes, required evidence, forbidden outcomes, and emoji verdicts. It does not supply a candidate-specific transition trace or actual result that another reviewer can replay. The core checks are often declared to “hold by construction.” This is useful paper analysis, but it does not satisfy the plan’s stated actual-result and reproducibility standard strongly enough to eliminate architectures or close High gaps.

One concrete data error reinforces the issue: S2 starts as an owner-authored note but its required kickoff provenance says `source: Cole` without source authority for that attribution.

**Evidence:**

- `00_Phase2_Discovery_Plan.md:102-108,135-145`
- `03_Scenario_and_Adversarial_Replay_Matrix.md:5-9,13-49`
- `01_Decision_Engine_Discovery_Report.md:21-36,38-49`

**Required change:** for each case, provide a reproducible paper trace or machine-readable fixture containing:

- normalized input and immutable source/control envelope;
- starting object/event state and policy/schema versions;
- candidate-specific transition sequence;
- resulting authoritative records and visible output;
- exact pass/fail rule and evaluator rationale;
- linked gap or falsifier.

No runtime code is required. A structured analytical replay is sufficient, but “expected outcome” and “actual candidate result” must be distinguishable.

**Acceptance condition:** an independent reviewer can take the candidate contract plus the case fixture and reproduce the verdict without inferring missing candidate behavior.

---

## P2D-05 — High — The end-to-end recommendation/policy separation has an unresolved normalization-authority gap

**Affected artifacts:** `01_` §5, `02_` OQ-02, `03_`

**Problem:** The model-substitution test holds the normalized input fixed, while the pipeline under discovery includes Understanding/Normalization and candidate classifications. Tier, authority ceiling, and attention depend on fields such as action class, risk, relationship, and confidence. If those fields are model-derived, a model substitution can change authority even though the deterministic policy function remains unchanged.

The current claim that model substitution can change “ranking/rationale only” is therefore true only after an unproven fixed-normalization assumption.

**Evidence:**

- `00_Phase2_Discovery_Plan.md:19-29,54-56,106-108`
- `01_Decision_Engine_Discovery_Report.md:25-36`
- `02_Open_Question_Dispositions.md:15-19`

**Required change:** define field authority before the hypothesis is called supported:

- authoritative control fields supplied by identity, trust, data, policy, and source systems;
- deterministic derived fields;
- model-proposed semantic fields;
- fields that may reduce authority but may not raise it without verification;
- disagreement/unknown behavior.

Add an end-to-end substitution case beginning from the same raw input—not only the same normalized input. A model change must not increase maximum authority solely because it produced a different semantic classification.

**Acceptance condition:** revise the conclusion to either (a) “not falsified under fixed normalization; end-to-end boundary remains a design-gate test,” or (b) support the stronger conclusion with the additional field-authority contract and replay evidence.

---

## P2D-06 — High — The proposed Critical/quiet-hours policy conflicts with accepted ATT-01

**Affected artifacts:** `02_` OQ-04, `03_` A8, `04_` OD-1

**Problem:** OQ-04 and the owner package state that no accepted requirement defines Critical. ATT-01 already defines the binding outer boundary: immediate physical, legal, financial, security, or comparably consequential danger.

The proposed list narrows that accepted requirement to system death/breach, uncertain money movement, and any message from named contacts. It omits immediate physical and legal danger and makes sender identity—not urgency—the potential basis for Critical.

**Evidence:**

- Accepted requirement `ATT-01`
- `02_Open_Question_Dispositions.md:27-32`
- `03_Scenario_and_Adversarial_Replay_Matrix.md:37`
- `04_Owner_Decision_Package.md:9-12`

**Required change:** ATT-01 must remain the binding category boundary. OD-1 should ask Hunter to select or modify the operating policy *within* that boundary, including:

- category-specific trigger conditions;
- confidence/verification requirements;
- quiet-hour suppression exceptions;
- emergency-contact handling as a signal, not automatic proof of urgency;
- fallback when urgency is ambiguous.

**Acceptance condition:** the owner decision package no longer asks Hunter to approve a policy that contradicts an accepted requirement.

---

## P2D-07 — High — Trust semantics and mandatory protection-layer replay coverage are incomplete

**Affected artifacts:** `03_`, `02_` OQ-02/OQ-10, `01_`

**Problem A — trust semantics:** A2’s falsifier says injected text naming a topic must not even bias placement. TRS-02 says external content is data, not instructions. External content’s legitimate subject matter **must** be usable for summarization and classification; only its embedded commands lack instruction authority. The current oracle would prohibit useful email/call classification or create false confidence by treating all semantic influence as injection.

**Problem B — coverage:** P2-06 makes operationalization of all accepted IDN/TRS/DAT/LOG/ACT/SCH/RES constraints mandatory. The current cases cover substantial parts of IDN, TRS, ACT, LOG, and RES, but do not provide explicit adversarial coverage for:

- DAT restricted-class Discord rendering and notification-preview leakage;
- SCH stale/mismatched scheduled context envelope and schema version;
- IDN-03 kill/revoke and emergency read-only recovery;
- LOG-02 attempts by a worker/engine to alter or suppress evidence.

**Evidence:**

- `00_Phase2_Discovery_Plan.md:29-33,102-108`
- `03_Scenario_and_Adversarial_Replay_Matrix.md:30-41`
- Accepted requirements `TRS-02`, `DAT-01`, `DAT-02`, `IDN-03`, `LOG-02`, `SCH-01`, `SCH-02`

**Required change:**

1. Rewrite A2 so two inputs with identical legitimate content but one added malicious instruction produce the same semantic placement while the malicious instruction produces zero authority/action effect.
2. Add protection-layer replay cases for DAT, SCH, IDN-03, and LOG-02, or provide an equivalent trace proving the binding invariant.

**Acceptance condition:** every mandatory protection family named by P2-06 has an explicit oracle, authoritative evidence source, forbidden outcome, and candidate result.

---

## P2D-08 — High — Event identity, replay, and gap closure are under-specified

**Affected artifacts:** `02_` OQ-05, `03_` A5/A6/A12, `01_`, `04_` OD-3, `05_`

**Problem:** OQ-05 claims a replay guarantee but its event list omits several state-changing facts required by the candidate chain and LOG-01, including normalization, recommendation, policy evaluation, owner decision/approval, attention change, override, verification result linkage, reconciliation, and fold-back. A pure fold cannot reconstruct state if those facts are mutable records without versioned events.

The proposed input identity key—normalized content hash + source + time window—is also unsafe as a general identity rule. It can merge two legitimate identical events, miss transformed redeliveries, and makes identity depend on normalization. Source-native event IDs, ingestion IDs, dedup fingerprints, correlation IDs, and action idempotency keys are separate concepts.

Finally, “same inputs, same state” cannot mean rerunning an LLM and expecting identical output. Replay must consume the recorded normalization/recommendation result with model, context, and version provenance.

**Evidence:**

- `02_Open_Question_Dispositions.md:34-38`
- `03_Scenario_and_Adversarial_Replay_Matrix.md:34-41,51-56`
- `01_Decision_Engine_Discovery_Report.md:21-23,51-53`
- `04_Owner_Decision_Package.md:19-25`
- Accepted requirements `LOG-01`, `LOG-02`, `ACT-01`, `SCH-01`

**Required change:**

- Treat source event ID, local ingestion ID, dedup fingerprint, case/correlation ID, and action idempotency key as distinct fields.
- Make dedup strategy source-aware and uncertainty-aware; do not canonize the content-hash/window formula during discovery.
- Define the minimum event/record provenance needed to reconstruct state without re-invoking a nondeterministic model.
- Reclassify GAP-2 as an open blocking design requirement with objective acceptance tests, not a High gap already “resolved” by the current formula.

**Acceptance condition:** OD-3 and the report accurately distinguish a requirement-level closure from an unvalidated algorithm, and the replay model accounts for every authoritative state transition.

---

## P2D-09 — Medium — Queue semantics and the owner decision package misplace owner judgment

**Affected artifacts:** `02_` OQ-07, `04_`

**Problem:** OQ-07 says only T3 cards and ratified review items enter the owner queue. T4 consequential approvals also require the owner, as do some verification exceptions, uncertain outcomes, and policy conflicts. Queue admission should follow the `attention: Needs Owner`/Critical and owner-action contract, not a tier number alone.

The owner package also:

- labels the engine shape “settled” before technical acceptance;
- asks Hunter through OD-3 to accept technical engineering resolutions, even though AUT-04 says owner approval should focus on business effect, outcome, and consequential risk;
- gives an inaccurate OD-2 tradeoff (“lower cap = more receipts”) without defining what happens when the cap is reached.

**Evidence:**

- `02_Open_Question_Dispositions.md:46-50`
- `04_Owner_Decision_Package.md:3-25`
- Accepted requirements `ATT-02`, `AUT-04`, `QUE-01`, `ACT-01`

**Required change:**

- Define owner-queue admission by required owner action and attention policy, including T4 and exception paths.
- Present Candidate B as Fable’s technically reviewed recommendation, not already settled.
- Convert OD-3 into a business-facing residual-risk acceptance, while technical closure remains Fable/verifier responsibility.
- Define OD-2 overflow behavior and explain the real burden/risk tradeoff.

---

## P2D-10 — Medium — Policy precedence is prematurely fixed and insufficiently tested

**Affected artifact:** `02_` OQ-06

**Problem:** “specific-over-general; equal specificity → newest-effective” is a consequential policy-resolution algorithm. It does not account for policy authority, explicit priority, deny-overrides, protection-layer floors, or conflicts between owner-approved exceptions and system safety policy. No replay case compares these alternatives.

**Evidence:** `02_Open_Question_Dispositions.md:40-44`.

**Required change:** discovery should conclude that policy objects need explicit scope, authority, priority/precedence, effective dates, conflict behavior, and rollback—not select newest-effective as the tie-breaker. Carry at least these alternatives to design:

- explicit priority + authority domain;
- deny/safety-floor precedence for protection policy;
- unresolved equal-priority conflict fails closed;
- owner-approved scoped exception with explicit supersession target.

---

## P2D-11 — Medium — The design-phase proposal does not carry the complete accepted test and OQ surface

**Affected artifact:** `05_`

**Problem:** The proposal includes scripted tests for hypothesis checks 1–3 and a definition for check 4, but omits execution of check 5 (correction path) and check 6 (separation falsifier). It also does not clearly carry OQ-07 queue mechanics and OQ-08 ritual integration into design scope. The document says DE-R1..DE-R7 are drafted, but only labels—not proposed requirement texts and acceptance criteria—are present.

**Evidence:**

- `00_Phase2_Discovery_Plan.md:106-108`
- `05_Design_Phase_Change_Plan_Proposal.md:9-16`

**Required change:** after discovery acceptance, the real CP-P2-A must include all six hypothesis checks, queue/ritual integration, exact proposed requirement texts, acceptance criteria, risk class, rollback, and traceability to corrected OQ/gap dispositions.

---

## P2D-12 — Medium — The stage-gate evidence self-check is not yet accurate or self-contained

**Affected artifacts:** `01_`, `checksums.sha256`, `EXPORT_MANIFEST.json`

**Problem:** The report marks all §6 criteria PASS before verifier review and claims the §20A.2 gate packet is satisfied by a “gate-packet table in the verifier export manifest.” The manifest contains execution disclosures, but not an explicit eleven-item §20A.2 disposition table. Items such as verifier response, Fable disposition, unresolved disagreements, and owner decisions are necessarily pending at this stage.

The direct packet checksum file also references three files that were omitted from the extracted ZIP. They are recoverable from the full-history bundle, so evidence is not lost, but the exported checksum set is not directly runnable.

**Evidence:**

- `01_Decision_Engine_Discovery_Report.md:38-49`
- accepted Manual §20A.2
- exported `fable/phase2-decision-engine/checksums.sha256`

**Required change:**

- Change self-check outcomes to `PASS`, `PENDING`, or `FAIL` as of the report snapshot.
- Add an explicit §20A.2 gate index with justified N/A/pending states.
- Include every checksummed file directly or create a packet-specific checksum file limited to exported members, with a separate bundle verification script.

---

## 5. Required Corrected Packet

Fable may keep the correction cycle scoped to discovery artifacts and evidence. No Opus task is authorized or needed.

The corrected packet should contain:

1. Revised `00A_` and source manifest with one reproducible authority-corpus definition.
2. Revised `01_` with calibrated claims and corrected gate self-check.
3. Revised `02_` with complete OQ fields and corrected OQ-04/OQ-05/OQ-06/OQ-07.
4. Revised `03_` plus reproducible candidate transition traces or fixtures.
5. Revised `04_` owner package after technical dispositions.
6. Revised `05_` design-plan proposal reflecting the corrected discovery surface.
7. Fable’s keyed dispositions for P2D-01 through P2D-12.
8. A full-history bundle and an export manifest/check script that validates 100% from the packet.

The replay rerun must cover all 22 existing cases after candidate normalization. Additional protection-layer cases may be appended without reopening owner discovery.

## 6. Gate State

```text
Accepted v1.3 baseline:                 UNCHANGED
Phase 2 discovery execution:            SUBSTANTIALLY COMPLETE
Post-discovery verifier gate:           PASS WITH CHANGES
Candidate B:                             LEADING HYPOTHESIS, NOT ACCEPTED DESIGN
OD-1 / OD-2 / OD-3 owner decisions:     BLOCKED pending corrected package
Discovery owner acceptance:             BLOCKED
Design-phase change plan opening:        BLOCKED
Builder involvement:                     NOT AUTHORIZED / NOT NEEDED
Next actor:                               Fable
Next action:                              Disposition P2D-01..P2D-12,
                                          revise/rerun affected discovery analysis,
                                          return scoped verification packet
```

## 7. Convergence Boundary

This is not a request to expand Discovery into implementation. Corrections are limited to:

- source authority and traceability;
- fair candidate definitions;
- reproducible paper replay;
- accepted protection and attention constraints;
- technical-versus-owner decision boundaries;
- exact design-input completeness.

Provider selection, runtime code, database product selection, Discord implementation, MCP write authority, and hardware remain deferred exactly as the approved plan states.

