# 31 — TASK-0004 Closure Note: review residue M-1/M-2 (+ three Low items)

**Context:** Fable's independent verification of the TASK-0004 return (zip SHA-256 `67773a39d7c7680b4fca749a56ffc9a9d7e640dc81b0a02f292488cfdd766c1b`) is complete and **the return is genuine — zero Critical or High findings.** All nine §2 dispositions verified GROUNDED (M1 confirmed continuous with the previously accepted oracle reading); the A11 refusal SOUND; all four `28A_` probes re-verified end-to-end through corrupted corpus files (gate exit 1 each time); 26 contradiction witnesses sampled, all genuine borrows; the corpus-shrink experiment fail-closed; the P2S-04 suite honoring D-KR rule 1 structurally; the basis validator's `external_basis` whitelist verified unabusable today (zero production events set it — carried as a residual-risk note); both validators exercised against the real repository including what the Builder could not run (full `13V_`: plain PASS, `--final-gate` correctly blocking the four finding-named rows with `13F_` live). Fable's D-SM row 14, added after the snapshot, was picked up by the runtime parser with zero code change — the design's central claim, directly confirmed.

**This note is the closure micro-round** (C1 precedent). Fix the following; nothing else.

## M-1 (Medium — the enumeration registry is wrong again, third recurrence)
`scenarios.py` docstring (lines 9–47) claims the Builder-added-stimuli set "is exhaustive" but omits the two TASK-0004 additions (S3 `actions`; S10 `placement_scope`/`proposed_action_class`), and the S3 inline comment claims the action is "enumerated in the docstring above" — false. The Delivery Record disclosed both, so nothing is hidden; but the in-file registry is the disclosure guarantee your own falsifier row 3 leans on, and this exact lapse class has now recurred three times (RW-24, RW-27, here). **Fix:** add both entries; correct the inline claim; and add a structural guard so a fourth recurrence is impossible by construction — e.g. the anti-circularity checker (or a small self-check) fails when a `ScenarioSpec` carries an `actions`/`placement_scope`/`proposed_action_class`-class Builder-added field whose fixture id is absent from the docstring enumeration block. The registry must not depend on remembering.

## M-2 (Medium — supersession checker fails open on malformed D-SM rows)
`check_supersessions.py:134`: a data row with a mangled ID or missing cell is silently dropped from enforcement (demonstrated: corrupting a row ID went 10→9 patterns with no warning). A checker whose purpose is fail-closed enforcement must not fail open on its own input. **Fix:** any table line with ≥4 cells whose first cell is neither a digit nor a header separator FAILS the run (or at minimum emits a counted warning that `--self-test` covers); add a malformed-row case to the self-test.

## Low items to take in the same pass
- **L-1:** `simulate.py:434` — the E2 refusal fires on any `proposed_ceiling` and labels it "rejected-ceiling-raise"; compare against the base ceiling first so a lowering proposal is not mislabeled.
- **L-2:** `fold.py:163` — `Tuple` annotation without import; import it or drop the annotation.
- **L-7:** `13V_` — a malformed finding token in a dependency cell silently becomes a non-reference; warn (self-test case included), and remove the dead `got` variable.

## Carried as disclosed limits (no action)
L-3 (the §1 P2T-02 row's "each ships its defect witness" is true for 7/8, recorded honestly in the JSON — erratum line in the closure record); L-4 (13-vs-14 D-SM rows — snapshot-true); L-5 (basis-validator loosenesses vs D-B9's table); L-6 (map-derived patterns artifact-scoped; structural families global); the PRESENTATION-kind receipt interchangeability (inside the disclosed falsifier-row-1 limit); criterion 16's label enforcing via judged failures + criterion 2 rather than its own boolean.

## Return requirements
Closure return: the fixes above; all 20 criteria re-proven (two-run determinism, anti-circularity incl. any new self-check, hygiene, allowlist); per-item disposition with shipped-evidence proof; the L-3 erratum line; the record-vs-file re-check applied to every claim. Same allowlist; same return format; fingerprint quoted in-channel.
