# 38 — ChatGPT Scoped Re-Verification: TASK-0005 R1

**Review target:** `TASK-0005_R1_Packet_5.zip`  
**Scope:** P2V-01 through P2V-04, Fable’s P2U-04 consolidation, and any Critical/High defect directly introduced or exposed by those corrections.  
**Verifier role:** Independent reviewer. No implementation or integration authority exercised.

# Verdict

## **FAIL — TASK-0005 R1 is not accepted; the design gate remains open**

The packet is mechanically strong and the correction cycle is converging. The exact prior bypass flag is gone, duplicate external identities are rejected, resolver-state tampering is detected, ordinary retired-version re-entry is refused, the full-history bundle is valid, and all supplied tests reproduce.

Independent falsifier testing nevertheless found five High-severity defects. Three are the same control-boundary problem one layer deeper; one is a direct final-gate bypass; one is the still-unresolved normative contradiction Fable reported as corrected.

No rediscovery or owner-decision reopening is required. Fable should disposition P2W-01 through P2W-05 and issue one narrowly scoped correction cycle.

---

# 1. Independent Packet and Repository Verification

```text
Uploaded ZIP SHA-256
4f2ae42fd4e3b9589abd969ec616aed56960aa1ce29ab8b81c95220789b051e3

checksums.sha256
48 / 48 passed

EXPORT_MANIFEST.json
48 / 48 payload hashes passed
No missing or undeclared payloads after excluding the manifest and checksum file themselves

Gate commit
0e906694b7298e12596cbbef6c989300da54ad31

Gate tree
db0b7746465a5f1a521b7c345b9ff0ab9f11b63e

Git bundle
Fresh clone passed
git fsck --full passed
Required base and ancestry present
Fresh checkout clean

Supplied patch
SHA-256 aa3b07c3b053773d94f04b5145a9b1e3ed19d9f9b40abce2c28e390c85d5aaf3
Byte-identical to an independently generated plain git diff from bbc58dc6... to HEAD
git apply --check passed forward on the base and reverse on the candidate

git diff --check
Passed
```

The behavioral gate ran twice with byte-identical stdout and byte-identical output files. The supplied `13V_` self-test, end-to-end probe, and normal final-gate behavior also reproduced exactly.

---

# 2. What Passed

## 2.1 P2V-01 — partial improvement

The specific `--p2u05-defect-witness` switch no longer disables check 9 when used by itself. The three other shipped bypass spellings also do not disable it in the tested open-findings case.

## 2.2 P2V-02 — partial improvement

A receipt must now parse as a structured reference, resolve to a registered record, match version and content hash, avoid self-reference and cycles, and remain within the depth bound. Arbitrary non-reference strings and missing referenced records fail.

## 2.3 P2V-03 — material partial closure

The following defects are closed:

- `resolver_state` and `resolver_known_ids` are now digest-bound.
- Editing resolver state under the old digest is detected.
- Duplicate `store:object_id` identities are rejected before lookup.
- Record order is canonicalized before hashing.
- The manifest-dataclass field enumeration detects an added manifest field that is neither bound nor explicitly exempt.

## 2.4 P2V-04 — partial improvement

The exact prior v1→v2→v1 path through `change_schedule()` is refused when v1 was properly retired. `reactivate()` mints a new version with an empty horizon in the supplied path.

## 2.5 Packet self-containment

The prior packet/bundle defect remains closed. The full-history bundle is usable and the candidate is reproducible.

---

# 3. Findings

## P2W-01 — High — `--final-gate` is still bypassable through mode combination

### Problem

The old dedicated bypass flag was removed, but the CLI does not enforce one mutually exclusive mode. The script checks `--self-test` before it evaluates the real repository gate and exits from the self-test branch.

A caller can therefore invoke:

```text
python3 13V_validate_design_matrix.py --final-gate --self-test
```

while six gate-blocking findings are open and receive exit code `0`.

The reverse ordering also passes:

```text
python3 13V_validate_design_matrix.py --self-test --final-gate
```

### Independent falsifier

Against the actual candidate repository:

```text
--final-gate
exit 1 — six blocking findings correctly stop the gate

--final-gate --self-test
exit 0 — self-test PASS; repository final gate never runs

--self-test --final-gate
exit 0 — same bypass
```

Against a complete synthetic repository, an entirely unknown option is also silently accepted:

```text
--final-gate --definitely-unknown
exit 0 — final gate PASS
```

This violates the prior required correction that every supported final-gate invocation enforce the gate and that unknown or prohibited bypass options fail rather than being ignored.

### Required correction

Use strict CLI parsing with explicit, mutually exclusive modes:

```text
--structural
--final-gate
--self-test
--end-to-end-probe
```

Requirements:

1. Exactly one mode may be selected.
2. `--final-gate` combined with any test/debug mode must fail before any test executes.
3. Unknown arguments must fail with a nonzero usage error.
4. The regression suite must include the mixed-mode probes above, not only renamed versions of the deleted flag.
5. The isolated counterfactual may remain in test-only code, but no production CLI combination may select it or bypass the repository gate.

---

## P2W-02 — High — a same-manifest unattested root still self-certifies external evidence

### Problem

The new receipt chain proves that a named record exists inside the same hash-bound manifest. It does not prove that the receipt is independently owned, authentic, authorized to attest to the target, or even related to the target.

The chain terminates at the first record with no receipt. That record is accepted as an attestation root solely because the same manifest author listed it. The Builder’s Delivery Record correctly discloses this boundary, but the boundary does not satisfy P2V-02’s required correction.

### Independent falsifier

I created:

```text
Target record
provider:action-42@7#aaaa...
verification_receipt -> evidence:unrelated-root@1#bbbb...

Receipt root
No receipt of its own
No signer, subject binding, purpose, authority, signature, revocation state, or independent trust anchor
```

Both records were placed in one manifest and the manifest was bound by its own computed digest.

Result:

```text
manifest integrity problems: []
basis validation problems:   []
fold accepted:                true
```

An unrelated record created by the same manifest author can therefore certify the target.

The parser also accepts eight-hex-character “content hashes” such as `deadbeef` and `cafebabe`; the short-hash target and root passed manifest integrity and resolution.

### Required correction

Adopt one explicit independent-evidence contract:

1. **Separate evidence authority:** target records reference a receipt in a separately controlled, independently bound receipt/evidence registry; or
2. **Cryptographic attestation:** a receipt object carries a subject binding, purpose/action class, issuer identity, signature or MAC under a defined trust root, issuance/version context, and status/revocation evidence; or
3. **Design-gate defer:** if neither contract is designed now, every positive external-basis fold remains fail-closed and is marked build-gate deferred.

A root must not become trusted merely by omitting its own receipt. The positive test must demonstrate independent authority, not only same-manifest registration.

Use a fixed approved cryptographic digest algorithm and full digest length for content identity; do not accept arbitrary 32-bit abbreviated values as authoritative content hashes.

---

## P2W-03 — High — the manifest still does not bind the required authority and snapshot context

### Problem

P2V-03 required a canonical manifest schema binding all security-relevant context, including schema/version, snapshot identity or creation context, and receipt-verification authority/configuration.

The current `ExternalManifest` contains only:

```text
records
resolver_known_ids
resolver_state
declared_digest
```

It cannot represent—therefore cannot hash or verify—at least:

```text
schema_version
snapshot_id / snapshot epoch
source or creation context
receipt-authority identity
receipt-authority version/configuration
trust-root or signature-verification contract
```

Two semantically different authority/snapshot contexts carrying the same rows and resolver state necessarily produce the same digest because the differentiating context does not exist in the schema.

The field-coverage guard is useful but only proves that every field presently declared on `ExternalManifest` is classified. It does not prove that the manifest declares all fields the accepted contract requires, nor does it cover future fields added to `ExternalRecord.as_row()` incorrectly.

### Required correction

Define and validate a canonical versioned manifest envelope. At minimum it must include and bind:

- Manifest schema and canonicalization version
- Snapshot ID / epoch and source identity
- Creation or capture context where operationally relevant
- Record-identity tuple and uniqueness rule
- Approved digest algorithm and length
- Resolver identity/state/version
- Receipt/evidence authority identity and verification configuration
- Trust-root or key version where cryptographic attestations are used
- Revocation/status snapshot where receipts can be revoked

The validator must reject unknown schema versions, missing required controls, unsupported algorithms, ambiguous identities, and any post-binding change to the complete envelope.

---

## P2W-04 — High — schedule versions remain reusable through unguarded paths and restart state loss

### Problem

The supplied test covers one proper retirement path, but the implementation does not enforce the stated invariant that versions are strictly monotonic and never reused.

Three independent paths reactivated stale coverage.

### Independent falsifier A — same-version mutation

```text
Register v1
Materialize 41 v1 horizon ticks
Call change_schedule() with a different recurrence but version=1
```

Result:

```text
change accepted:       true
version in force:      1
eligible stale ticks:  41
horizon warning:       None
```

`change_schedule()` excludes the current version from retirement and uses `setdefault()` for that same version, so the old horizon remains valid under a changed recurrence definition.

### Independent falsifier B — `register()` replacement bypass

```text
register(v1) + materialize v1 horizon
register(v2)
register(v1) again
```

Result:

```text
register v2 accepted:      true
register v1 again:         true
retired versions:          []
version in force:          1
eligible stale v1 ticks:   41
horizon warning:           None
```

`register()` is not initial-registration-only and does not retire or reject a replaced live version.

### Independent falsifier C — restart loses permanent retirement

The Builder explicitly disclosed that `retired_versions` is in-memory only. I simulated a restart that restored the current spec and materialized horizons but not the retirement list.

Result:

```text
retired before restart:    v1
retired after restart:     absent
change back to v1:         accepted
eligible stale v1 ticks:   41
horizon warning:           None
```

### Required correction

Choose and enforce one durable identity model:

- **Strict monotonic version:** `register()` is initial-only or idempotent for the exact same immutable spec; every change requires a version greater than the highest version ever used for that schedule; same-version and lower-version mutation are rejected; highest-seen and retired state are durably stored and replayed.
- **Activation epoch:** every activation receives a new immutable activation ID included in the spec, ExpectedRun identity, horizon key, journal, persistence record, and replay basis.

Required tests must include:

1. Same-version changed recurrence
2. `register()` replacement of an existing schedule
3. Lower-version and duplicate-version submission
4. Process restart / state restore
5. Rollback and legitimate reactivation
6. Concurrent change attempts
7. Replay from durable events proving the same version/activation decision

“In-memory permanence” cannot satisfy a system designed to survive process failure and replay.

---

## P2W-05 — High — the scheduler-self-notice contradiction remains normative

### Problem

Fable’s cover says P2U-04’s D-B11 contradiction was consolidated. The authoritative document still states near its beginning:

> “a missed/failed run emits its own DegradationEvent-class notice”

Later, the same document correctly states that this mechanism is circular and that missed-run detection is owned by the external watchdog.

The supersession/anti-circularity checker returns PASS despite both statements remaining active in the document. A future implementer can still follow the wrong sentence.

### Required correction

Replace the opening envelope description with one unambiguous current mechanism:

- The scheduled run may emit a failure event only when it is alive and detects its own failure.
- Silence, failure-before-start, and missed recurrence are detected by the independent watchdog from the authoritative schedule definition and receipt stream.
- The scheduler’s rolling horizon is corroborating evidence, not the primary liveness authority.

Update the supersession checker with a pattern or structured normative-section rule that fails when scheduler-self-notice language remains in an active/current section after watchdog ownership is adopted.

---

# 4. Prior-Finding Status After This Review

| Finding | Result |
| --- | --- |
| P2V-01 — production gate bypass | **Open.** Exact old flag closed; mixed-mode bypass remains under P2W-01. |
| P2V-02 — independent receipt verification | **Open.** Structured same-manifest chain is not independent evidence; P2W-02. |
| P2V-03 — manifest integrity and identity | **Partially closed.** Resolver-state tampering and duplicate identities closed; authority/snapshot/schema binding remains open under P2W-03. |
| P2V-04 — schedule version reactivation | **Open.** One proper retirement path closed; same-version, register, and restart paths remain under P2W-04. |
| P2U-04 / P2T-04 — normative supersession | **Open.** D-B11 contradiction remains under P2W-05. |
| P2U-05 / P2T-05 — global final gate | **Open.** Normal path is corrected, but P2W-01 still bypasses it. |
| P2T-06 — self-contained packet/history | **Closed.** Bundle and candidate reproduction passed. |

P2U-01’s presentation-accounting correction remains accepted at the simulator-accounting level. The actual Executive Desk/Mailroom/reconnect/monthly-digest behavior remains a disclosed future coverage obligation and must not be counted as behaviorally verified.

---

# 5. Required Next Cycle

Fable should:

1. Disposition P2W-01 through P2W-05.
2. Issue one narrow APP-07 rework packet for the CLI, external-evidence, and schedule corrections.
3. Correct D-B11 and extend the normative supersession check directly in the control plane.
4. Replace the current `13F_` entries with an authoritative open/closed register that preserves historical finding lineage and records which P2T/P2U/P2V findings are superseded by P2W findings.
5. Return one Fable-assembled packet containing:
   - Exact dispositions
   - Corrected code and normative document
   - Independent Fable verification
   - Mixed-mode and unknown-argument CLI probes
   - Independent receipt/trust-root positive and negative cases
   - Manifest-schema and tampering cases
   - Same-version/register/restart schedule cases
   - Updated supersession test
   - Exact diff, full-history bundle, commit/tree binding, manifest, and checksums

No rediscovery is required. No owner decision is needed now.

---

# 6. Gate State

```text
Accepted v1.3 baseline:             UNCHANGED
Accepted Phase 2 discovery:         VALID
Approved CP-P2-A design plan:       VALID
Packet integrity:                   PASS
Supplied test reproduction:         PASS
P2T-06 packet/history defect:       CLOSED
TASK-0005 R1 Builder correction:    NOT ACCEPTED
Design-gate verdict:                FAIL
Record-shape selection:             NOT MADE
DE-R1 through DE-R8 acceptance:     NOT AUTHORIZED
Owner decision package:             BLOCKED
Owner design acceptance:            BLOCKED
v1.4 implementation/release:        BLOCKED
Hunter action required now:         NONE
Next actor:                         FABLE
```

The established separation remains unchanged: Fable owns architecture, dispositions, and project management; the Builder implements only authorized corrections; ChatGPT independently verifies; Hunter retains final authority.
