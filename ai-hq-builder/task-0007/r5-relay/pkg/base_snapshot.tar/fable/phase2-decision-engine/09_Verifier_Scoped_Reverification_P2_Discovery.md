# ChatGPT Scoped Re-Verification — Phase 2 Decision Engine Discovery Corrections

**Review target:** Corrected discovery set at gate commit `80f5dda2875aed77bff60f1a16c5c085d1953620`  
**Gate tree:** `7adb070e860489a0577ac56f3148b86fa25f9dae`  
**Prior discovery gate:** `fa01b9d84f5f8015493557c30487274709841e17`  
**Review type:** Scoped re-verification of P2D-01 through P2D-12; no runtime/build review  
**Verifier:** ChatGPT  

## 1. Verdict

**PASS WITH CHANGES.**

The corrected discovery set materially resolves the twelve prior findings. The authority corpus is reproducible; the candidate comparison is substantially fair; the field-authority boundary, ATT-01 policy boundary, trust semantics, event identity separation, queue-admission classes, policy-precedence alternatives, design-phase test surface, and stage-gate evidence model are all materially improved.

The discovery architecture should be preserved. However, the owner gate remains blocked by two High and three Medium findings identified during this scoped review. These are bounded corrections to the replay contract, accepted-domain separation, evidence-authority wording, count/status accuracy, and design-phase candidate carry-forward. No Builder involvement or full rediscovery is required.

## 2. Independent packet verification

The following checks were independently reproduced:

```text
Uploaded ZIP SHA-256
42083e71fe3c7ce309c0f14aae6d4dc417679f0fea332945c6ac437242323f8a

Export-manifest payload hashes
29 / 29 passed

Export-manifest evidence hashes
1 / 1 passed

Direct packet checksum file
29 / 29 passed from the extracted packet root

Git bundle
Valid; complete history

Gate commit
80f5dda2875aed77bff60f1a16c5c085d1953620

Gate tree
7adb070e860489a0577ac56f3148b86fa25f9dae

Discovery-gate commit
fa01b9d84f5f8015493557c30487274709841e17

Discovery-gate tree
0779ead294acb8aa8082876d0ca63d421a55c1e4

Ancestry
fa01b9d... is an ancestor of 80f5dda... — PASS

Authority-corpus reconstruction
13 / 13 files passed blob and SHA-256 validation
13 / 13 last-modified commit declarations independently matched

Requirements applicability matrix
125 rows / 125 unique IDs
46 Binding constraint
67 In-scope
10 Deferred
2 N/A
No missing or extra accepted requirements

Replay fixture set
27 JSON fixtures
All required fixture keys present
10 owner scenarios
16 adversarial/boundary scenarios
1 end-to-end design-gate fixture

Repository hygiene
Fresh checkout clean
git diff --check passed for fa01b9d...80f5dda...
Accepted Manual and Requirements Register unchanged
```

## 3. Prior-finding disposition

| Prior finding | Scoped result |
| --- | --- |
| P2D-01 — Frozen authority boundary and provenance | **Substantively closed**; one disposition-description cleanup remains under P2R-03. |
| P2D-02 — OQ disposition contract | **Closed.** All ten OQs contain status, evidence, alternatives, recommendation, owner-decision treatment, downstream impact, and falsifier/review trigger. |
| P2D-03 — Confounded candidate comparison | **Substantially closed** in discovery artifacts; the design-phase proposal must restore S3 as a viable alternative under P2R-04. |
| P2D-04 — Non-reproducible replay | **Partially closed.** Transition traces and distinct actual-result fields now exist, but the source/trust/data/identity envelope remains under-specified under P2R-02. |
| P2D-05 — Normalization-authority gap | **Substantially closed.** Field-authority classes and E2E-1 are present; receipt ownership wording requires P2R-05. |
| P2D-06 — ATT-01 conflict | **Closed.** ATT-01 is correctly binding, with OD-1 limited to policy inside that boundary. |
| P2D-07 — Trust semantics and protection coverage | **Substantially closed.** Twin-input semantics and DAT/SCH/IDN/LOG cases are present; explicit control envelopes remain required under P2R-02. |
| P2D-08 — Event identity and replay | **Closed at discovery requirement level.** The five identities are separated; model outputs are recorded; GAP-2 remains openly blocking design work. |
| P2D-09 — Queue and owner-package boundaries | **Partially closed.** Owner judgment and queue-admission classes are corrected, but the proposed queue topology conflicts with accepted Business/Personal separation under P2R-01. |
| P2D-10 — Premature policy precedence | **Closed.** Precedence remains unresolved and the required alternatives travel to design. |
| P2D-11 — Incomplete design proposal | **Partially closed.** All tests and OQ surfaces are carried, but S3 is omitted from the next-stage selection under P2R-04. |
| P2D-12 — Gate evidence and self-check accuracy | **Substantially closed.** The packet is self-contained and directly checkable; replay arithmetic/status language requires P2R-03. |

## 4. New findings

### P2R-01 — High — The queue recommendation violates accepted Business/Personal separation

**Affected:** `02_Open_Question_Dispositions.md` OQ-07; `05_Design_Phase_Change_Plan_Proposal.md` item 10; `01_Decision_Engine_Discovery_Report.md` consistency claim

**Problem:** OQ-07 recommends a “unified queue, domain-tagged.” Accepted requirements are stronger:

- `PER-02`: Personal and Business memory, permissions, records, and priority queues remain separated.
- `EX-03`: Business and Personal priority lists remain segregated inside one unified dashboard frame.
- `QUE-01`: all system-generated review items use one governed queue mechanism.

These can coexist, but a tag-only unified queue is not enough. It can mix records, permissions, ranking, and cognitive presentation across domains—the exact behavior the owner rejected.

**Required change:** define one governed queue **mechanism/service** with hard Business and Personal partitions. Each partition owns its records, permissions, priority ordering, aging state, and visible list. The Executive Desk may show one frame, aggregated counts, and separate Business/Personal sections; it must not interleave the two priority lists. Cross-domain movement is a governed correction/reclassification event.

**Replacement recommendation for OQ-07:**

> Use one governed queue mechanism with hard Business and Personal partitions. The partitions remain separately permissioned and separately prioritized; the Executive Desk renders them in one unified frame without interleaving their items. System-wide capacity metrics may aggregate counts, but record ownership and queue order remain domain-separated.

**Acceptance condition:** OQ-07, the design proposal, and any fixture/owner-facing wording satisfy `PER-02`, `EX-03`, and `QUE-01` simultaneously.

---

### P2R-02 — High — Replay fixtures do not explicitly carry the mandatory control envelope

**Affected:** `03F_Replay_Fixtures.json`; `03_Scenario_and_Adversarial_Replay_Matrix.md`; `01_Decision_Engine_Discovery_Report.md` criterion 4

**Problem:** The approved plan requires each case to state the source/trust/data/identity envelope. Accepted `TRS-01` requires every input to carry `origin`, `trust_class`, `instruction_authority`, `sensitivity_class`, and `verification_state`; the discovery contract additionally relies on data class and identity/session binding.

The fixture currently provides a free-text `envelope` such as `trusted-internal/owner`, `system`, `mixed`, or `external-untrusted`. Most cases omit one or more mandatory fields, and multi-input cases A2, A6, A8, and S7 do not provide one envelope per input. This conflicts with OQ-02’s rule that unknown control fields fail closed: a replay cannot both omit those fields and claim a non-fail-closed result without an explicit default contract.

The fixture’s `schema S1` label also collides with Candidate Shape S1 and should be renamed.

**Required change:** make the replay envelope structurally explicit. Each input event must resolve to fields equivalent to:

```text
origin
source_id / source_type
trust_class
instruction_authority
sensitivity_class
data_class
verification_state
identity_session_state
policy_version
schema_version
```

For multi-input cases, provide an array of independently resolved envelopes. A top-level profile/default system is acceptable only if each case expands deterministically and a validator proves that no mandatory field is missing. A3 may intentionally contain `unknown`, but that unknown must be explicit and must produce the documented fail-closed result.

Rename the schema version from `S1` to a non-colliding value such as `SV-1`.

**Acceptance condition:**

1. A validator confirms all 27 fixtures resolve every required control field for every input.
2. Multi-input cases carry separate envelopes.
3. No implicit unknown is treated as trusted or authorized.
4. The replay verdicts are rerun; any changed verdict returns for targeted verification.

---

### P2R-03 — Medium — Replay counts and gate-status statements are arithmetically inconsistent

**Affected:** `01_Decision_Engine_Discovery_Report.md`; `03_Scenario_and_Adversarial_Replay_Matrix.md`; `02_Open_Question_Dispositions.md` OQ-01; `08_P2D_Dispositions.md`

**Problem:** The 27 fixtures classify as:

```text
23 full passes
3 pass-conditional cases: A5, A6, A8
1 future design-gate case: E2E-1
```

The report and matrix instead state `24/27` full passes plus three conditionals plus E2E-1, which totals 28. Criterion 4 also says 27/27 have a pass/fail result, while E2E-1 is explicitly pending design-gate execution.

There are two related record inaccuracies:

- OQ-01 and P2D-03 disposition refer to 26 cases without explaining that E2E-1 is orthogonal to record-shape comparison.
- P2D-01’s disposition describes the corrected authority corpus as a composite snapshot, while the implemented and validated correction is a single-tree snapshot at `fa01b9d...`.

**Required change:**

- Describe the set as **26 discovery replay cases plus one design-gate fixture**.
- State the discovery result as **23 full passes, three pass-conditional, and one pending design-gate test**.
- Update criterion 4 to say the 26 discovery cases have recorded outcomes/gaps; E2E-1 is explicitly pending under the design-gate hypothesis test.
- Clarify OQ-01’s 26-case evidence boundary.
- Change the P2D-01 disposition from “composite snapshot” to “single-tree snapshot.”
- Describe `PACKET_CHECKSUMS.sha256` as covering the 29 declared payload files; the bundle is separately covered by the export manifest.

**Acceptance condition:** all counts and status claims reconcile mechanically to the fixture JSON.

---

### P2R-04 — High — The design proposal silently drops viable Candidate S3

**Affected:** `05_Design_Phase_Change_Plan_Proposal.md` item 1

**Problem:** Corrected discovery explicitly withdraws every structural elimination and concludes that S1, S2, and S3 remain viable, with S2 only the leading hypothesis. The design proposal nevertheless narrows the next stage to “S2 leading hypothesis vs S1 fallback” and treats S3 only as a projection pattern.

That reintroduces the bias corrected by P2D-03 and allows a viable architecture to disappear before the design-gate comparison.

**Required replacement for item 1:**

> **Record-shape selection and schemas** — carry S1, S2, and S3 as viable normalized alternatives into design, with S2 as the leading hypothesis rather than the selected design. Compare all three against the tradeoff table, interactive-latency requirement, evidence-authority boundary, correction behavior, concurrency behavior, GAP-2, DE-R2, E2E-1, and check 4. S3-style materialized projections may also be combined with S1 or S2, but hybridization does not count as evaluating S3’s independent-record/event shape.

**Acceptance condition:** no candidate is eliminated before the design-gate evidence supports elimination or selection.

---

### P2R-05 — Medium — OQ-02 blurs required receipt output with externally owned execution evidence

**Affected:** `02_Open_Question_Dispositions.md` OQ-02

**Problem:** OQ-02 lists `receipt` among Decision Engine outputs. OQ-09, `ACT-01`, and the candidate contracts correctly require actual `ExecutionReceipt` and `VerificationRecord` evidence to originate outside the engine. The wording can therefore be read as allowing the engine to emit the evidence that advances its own state.

**Required change:** replace `receipt` in the routing-output list with:

```text
required receipt/evidence contract
expected receipt type
or action/evidence requirement
```

Then explicitly state:

> Actual ExecutionReceipt and VerificationRecord objects remain externally owned and cannot be authored or certified by the Decision Engine.

**Acceptance condition:** recommendation/policy output may specify what evidence is required, but only external authorities can supply the evidence used for executed/verified state.

## 5. Correction and re-verification boundary

Fable may keep the correction cycle narrow. No Opus task, runtime code, baseline amendment, or renewed candidate-model discovery is authorized or required.

The next packet should contain only:

1. Revised `01_`, `02_`, `03_`, `03F_`, `05_`, and `08_` as affected.
2. A fixture-envelope validation script and its output.
3. A machine-generated replay-count report.
4. Keyed dispositions for `P2R-01` through `P2R-05`.
5. Exact Git commit/tree binding, diff, and complete packet checksums.
6. Confirmation that the accepted v1.3 Manual and register remain unchanged.

The next review is limited to:

- Business/Personal queue partitioning;
- explicit control-envelope completeness;
- replay arithmetic/status truth;
- S3 carry-forward;
- receipt/evidence ownership wording;
- packet integrity.

Anything else becomes later design backlog unless the correction itself changes a replay verdict, owner decision, candidate recommendation, or accepted requirement interpretation.

## 6. Gate state

```text
Accepted v1.3 baseline:                 UNCHANGED
Discovery correction direction:         CONCUR
Authority corpus:                       PASS
P2D-01 through P2D-12:                 SUBSTANTIALLY RESOLVED
Corrected discovery set:                PASS WITH CHANGES
Candidate S2:                           LEADING HYPOTHESIS, NOT SELECTED
Owner package presentation:             BLOCKED
Owner OD-1 / OD-2 / OD-3 decisions:     BLOCKED
Discovery acceptance:                   BLOCKED
Design-phase change plan:               BLOCKED
Builder involvement:                    NOT AUTHORIZED / NOT NEEDED
Next actor:                             Fable
Next step:                              Apply P2R-01 through P2R-05 and
                                        return one narrow confirmation packet
```

## 7. Overall verifier position

The correction cycle is converging. The remaining findings do not reopen the Decision Engine concept, the recommendation/policy hypothesis, the event model, or the selected discovery method. They prevent five avoidable ambiguities from becoming design inputs:

- cross-domain queue mixing;
- implicit trust/identity/data defaults;
- inaccurate evidence counts;
- silent elimination of a viable candidate;
- engine-authored receipt ambiguity.

Once those bounded issues pass scoped confirmation, the concise owner package may be presented and the owner may decide OD-1, OD-2, OD-3, and discovery acceptance.
