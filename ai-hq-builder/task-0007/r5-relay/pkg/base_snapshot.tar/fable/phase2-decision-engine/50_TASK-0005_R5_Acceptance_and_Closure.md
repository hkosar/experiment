# 50 — TASK-0005 R5 Verified and ACCEPTED; TASK-0005 CLOSED; gate-closure packet issued

**Input:** `TASK0005_R5_Builder_Return.zip`, SHA-256 `1f51431ff7fa64322a12e59c4f8ec407952a1a8eec230b32d75368be663b71d0` (uploaded twice; both copies byte-identical). Relay integrity self-verified 3/3 by the Builder before reading authority. `RETURN_MANIFEST.json` validated **51/51**; the only file outside the manifest is the Delivery Record itself.

## 1. Verification (Fable, independent)

- **Change set exactly as declared:** five source files (`external_basis.py`, `fold.py`, `run_basis.py`, `run_gate.py`, `README.md`) plus the two regenerated outputs (`out/basis_validation.json`, `out/gate_report.json`). The return's `13F_` delta against the repo is snapshot staleness, not a Builder edit — it ships the TASK-0005-snapshot copy unchanged. Allowlist-exact; `03F_Replay_Fixtures.json` byte-identical to the snapshot; corpus frozen.
- **Code review:** `governed_purposes()` now REQUIRES the receipt registry (single call site, `fold.validate_basis`, confirmed by search); refuses on both `48_` §4.1 equalities; absence of either authority-context half is a refusal, not a skipped check. `EvidencePolicy.integrity_problems()` enforces §4.2's first clause (every contract row carries the artifact's own version); the consuming-context clause refuses a version the supplied artifact is not, naming the version. Gate criterion 18b hard-gates on the new C3 result — a silent regression cannot pass.
- **Determinism on a COPY (trail-106 discipline):** two full runs byte-identical; the delivered `out/` matches Fable's own run exactly (`diff -r` clean, 13/13).
- **Gate: 21/21 criteria PASS.** External-basis 53/53 closed; missing-basis 8/8; schedule-liveness 17/17; anti-circularity 4/4 PASS plus Fable's independent token-level check (six engine modules: zero oracle-field hits; the only hits are in `judge.py`, the oracle-side comparison layer, as designed).
- **The three `48_` §4.3 negatives ship failing in exact form,** each refusing with a problem string naming its own defect (receipt-authority collision; P999-artifact/P1-row incoherence; context requesting a version the artifact is not). The positive control now asserts `policy_authority_distinct_from_both`, `policy_version_coherent`, and `action_context_version_matches_policy`, and all three gate `resolved_and_folded`.
- **Section C3 (`r4_contract_witnesses`) verified honest:** the R4 boundary is reconstructed by filtering the shipped integrity list (drift-resistant, not re-typed). Rows 1–2 reproduce the verifier's `48A_` observations exactly (R4 accepted with `problems: []`; now refused naming the defect); row 3 is counted as a change in REASON only (`r4_accepted_count: 2`) — the Builder separated the two kinds instead of padding the count, and disclosed it in §2 of the record.
- **Fable seeded-defect reproduction:** with the registry-collision refusal removed on a scratch copy, the gate FAILS (exit 1), the `48_` §4.3(1) case reopens (52/53), and C3 names exactly the missing probe. The new evidence can fail, and was shown failing under Fable's own hand.

**Zero findings. R5 ACCEPTED and integrated** (7/7 files hash-verified against the return manifest).

## 2. Builder change request (Delivery Record §7) — dispositioned

*Which policy artifact a fold should have been given is not modelled* — a caller holding two validly bound, internally coherent policies at different versions can supply either. **Concur with the Builder's own classification:** this is the B-12 family (a binding the executor must derive from the durable authority rather than accept from the caller), it is outside the `48_` §6 closed scope, and no held design document specifies a selection rule that the simulator could enforce. **Registered as `13B_` row B-13.** Raised proactively instead of resting in a falsifier row — the R4 lesson applied; noted with approval.

## 3. Ledger state after this acceptance

- `13F_`: verdict applied per `48_` §4.4 — P2Y-02/03/04 preserved CLOSED; **P2Y-01 remains open and gate-blocking** until the corrected behavior passes independent re-verification; the `closed` enumeration follows `48_` §7's gate state (only P2Y-01 open).
- `13G_`/`13M_`: **deliberately NOT updated** — `48_` §4.4 orders the matrix updated only after the verifier's pass. `13V_ --final-gate` accordingly still fails, truthfully, on exactly P2Y-01 plus the four held-Incomplete rows.
- `13B_`: B-12 (verifier-routed) and B-13 (this cycle) recorded; B-12 formatting joined into the single register table.
- `design/D-EC_` remains the controlling normative statement (per `48_` §4.4).

## 4. TASK-0005 CLOSED

Five rework cycles (R1–R5) after the sequencing-deviation restart; every cycle's return verified by Fable with the verifier's exact probes reproduced before disposition; final cycle zero-findings. Closed at registry level with this entry (trail 113).

## 5. Gate-closure packet

Issued with this entry under the trail-110/`48_` §6 terminal condition. Scope of the verifier's next review, per `48_` §6 verbatim: the two P2Y-01 corrections, the three negative tests, regression of the accepted terminal evidence, and packet integrity/candidate identity. On pass: P2Y-01 closes, the design gate turns, `13G_` rows are restored with their dependencies, and the owner decision package is rebuilt for design acceptance. No claim of PASS is made here — the verdict is the verifier's.
