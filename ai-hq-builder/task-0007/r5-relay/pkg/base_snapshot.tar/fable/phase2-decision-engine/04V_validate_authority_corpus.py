#!/usr/bin/env python3
"""Validate the discovery authority corpus (04_) against the full-history bundle or repo.
Usage: python3 04V_validate_authority_corpus.py [repo_or_clone_path]
Reconstructs every file at the gate commit and checks blob ID + SHA-256 against the manifest table."""
import re, subprocess, hashlib, sys, os
repo=sys.argv[1] if len(sys.argv)>1 else '.'
man=open(os.path.join(repo,'fable/phase2-decision-engine/04_Discovery_Source_and_Exclusion_Manifest.md'),encoding='utf-8').read()
gate=re.search(r'discovery-gate commit `([0-9a-f]{40})`',man).group(1)
rows=re.findall(r'\| `([^`]+)` \| [^|]+ \| `([0-9a-f]{16})…` \| `([0-9a-f]{64})` \| `([0-9a-f]{12})` \|',man)
ok=True
for path,blob16,s256,last12 in rows:
    blob=subprocess.run(['git','-C',repo,'rev-parse',f'{gate}:{path}'],capture_output=True,text=True).stdout.strip()
    content=subprocess.run(['git','-C',repo,'show',f'{gate}:{path}'],capture_output=True).stdout
    h=hashlib.sha256(content).hexdigest()
    good = blob.startswith(blob16) and h==s256
    print(('PASS ' if good else 'FAIL ')+path)
    ok = ok and good
print(f"{'ALL PASS' if ok else 'FAILURES PRESENT'} ({len(rows)} files @ {gate[:12]})")
sys.exit(0 if ok else 1)
