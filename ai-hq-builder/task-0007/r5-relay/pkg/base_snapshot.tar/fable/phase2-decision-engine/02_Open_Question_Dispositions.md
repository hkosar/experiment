# 02 — Open Question Dispositions (OQ-01..OQ-10) — Revised per P2D-02/05/06/08/09/10

**Status:** Discovery execution artifact — nonbinding; revised for the correction cycle. Every OQ carries all seven plan-mandated fields. Fixtures: `03F_Replay_Fixtures.json`; analysis: `03_`; findings context: `08_P2D_Dispositions.md`.

---

## OQ-01 — Decision-case boundary and record model — **Answered (recommendation)**

**Evidence:** 26-discovery-case replay under normalized candidate definitions (E2E-1 is orthogonal to record-shape comparison and pends at the design gate) (`03_`/`03F`); trail 10/12/18/20/25/28; A11 (record pollution), A12 (evidence authority).
**Alternatives (genuine, all made safety-equivalent per P2D-03):** **S1** aggregate root with append-only child records + external evidence references; **S2** Decision Case linking separately-owned canonical records; **S3** independent records/events with materialized read projections. Orthogonal to all three: the T0–T4 processing-disposition policy (routine no-case paths are a *policy* choice available to every shape).
**Recommendation:** **S2 as leading hypothesis** — on measured tradeoffs (cleanest evidence-authority story, moderate read complexity; see `03_` §4), not by elimination. S1 and S3 remain viable; the tradeoff table travels to design.
**Owner decision:** none required at this gate (record shape is a technical choice; owner sees business consequences only).
**Downstream impact:** design-phase schema work items; DE-R4 tier contract; projection design if S3 traits are adopted.
**Falsifier/review trigger:** if design-phase modeling shows S2's linked-record assembly cannot meet interactive latency for S1/S9 experiences from derived views, revisit toward S1 (materialized aggregate) — a storage decision, never an evidence-authority decision.

## OQ-02 — Routing dimensions and recommendation/policy boundary — **Answered, with the end-to-end boundary carried to design (P2D-05)**

**Evidence:** WF-09/TRS dimension replay across all cases; A1/A2/A3/A4; E2E-1 (raw-input substitution case, added).
**Field-authority contract (new, P2D-05):** (a) **authoritative control fields** — identity/session state, trust class, instruction authority, sensitivity, data class, policy & schema versions, calibration state — supplied by IDN/TRS/DAT/policy stores, never model-writable; (b) **deterministic derived fields** — domain from source mapping, aging, blocking from recorded links; (c) **model-proposed semantic fields** — candidate placements/relationships, action-class *suggestion*, risk *suggestion*, summaries; (d) **authority rule:** model-proposed fields may **lower** effective authority or escalate to owner, but may never raise authority or relax attention without verification against (a)/(b); (e) disagreement or unknown in any control field → fail closed (T3 trusted / quarantine untrusted).
**Alternatives:** strict allowlist normalization (only enumerable fields feed policy) vs. verified-semantic normalization (model fields usable after deterministic cross-checks) — both carried to design; discovery does not pick.
**Recommendation:** inputs/outputs split as recorded (placement, relationship, blocking, disposition, attention, authority, and the **required receipt/evidence contract** (expected receipt type / action-evidence requirement) = outputs; envelope, versions, calibration, correction history, current state = inputs); boundary per the field-authority contract above. **Actual ExecutionReceipt and VerificationRecord objects remain externally owned and cannot be authored or certified by the Decision Engine** (P2R-05; consistent with OQ-09 and ACT-01).
**Owner decision:** none required.
**Downstream impact:** normalization schema and cross-check design; E2E substitution test becomes a design-gate test.
**Falsifier/review trigger:** E2E-1 executed at design gate — a model change that raises maximum authorized action from the same **raw** input falsifies the boundary as specified.

## OQ-03 — Attention calculus — **Answered (recommendation)**

**Evidence:** S1/S4/S8/A8; ATT-01/ATT-02; 18.1 dwell/override measures.
**Alternatives:** deterministic band function over routing outputs (recommended) vs. model-proposed attention within policy-set bands vs. static per-class mapping. The second is retained as a design option **only** below the Needs-Owner boundary; the third fails trail-38 proportionality.
**Recommendation:** attention = deterministic band function of (tier, action-class risk, blocking, aging, quiet-hour policy); **Critical is governed by ATT-01's accepted boundary** (P2D-06); recalibration only via governed policy-version events driven by measured evidence.
**Owner decision:** operating policy within ATT-01 — OD-1 (see `04_`).
**Downstream impact:** band-function spec; 18.1 telemetry wiring.
**Falsifier/review trigger:** measured urgent-item burial at Briefing level (missed same-day items with business cost) → mandatory review, never silent retune.

## OQ-04 — Critical-interrupt and quiet hours — **Needs-owner, within the accepted ATT-01 boundary (P2D-06 corrected)**

**Evidence:** ATT-01 (accepted): *Critical interruption is reserved for immediate physical, legal, financial, security, or comparably consequential danger.* A8; trail 14/38.
**Correction:** the prior claim that no accepted requirement defines Critical was **wrong**; ATT-01 is the binding category boundary and is not narrowable by an operating decision.
**Alternatives (within ATT-01):** conservative triggers (verified events only) vs. sensitive triggers (credible unverified signals interrupt); contacts-as-signal weighting; ambiguity fallback = interrupt vs. hold-to-briefing.
**Recommendation:** OD-1 asks the owner to set, per ATT-01 category (physical / legal / financial / security / comparable): trigger condition, verification/confidence requirement, quiet-hour suppression exceptions, emergency-contact handling as a **signal contributing to category assessment — never proof of urgency**, and the ambiguous-urgency fallback. Proposed defaults in `04_` OD-1.
**Owner decision:** OD-1 (required).
**Downstream impact:** interrupt policy object; A8 oracle finalization; quiet-hour scheduler rules.
**Falsifier/review trigger:** any post-activation incident that should have interrupted and didn't (or inverse) is mandatory review input.

## OQ-05 — Operational-database event model — **Answered at requirement level; identity design carried open (P2D-08 corrected)**

**Evidence:** A5/A6/A7/A12/A16; LOG-01/02; ACT-01.
**Corrected event/record set:** InputEvent, NormalizationRecord, RecommendationRecord (with model/context/version provenance — **recorded, never regenerated**), PolicyEvaluationRecord, DecisionEvent (incl. owner approvals), AttentionChangeEvent, OverrideEvent, ActionRequest, externally-owned ExecutionReceipt and VerificationRecord (linked by reference), ReconciliationEvent, CorrectionEvent, LearningEvent, Fold-BackEvent, AgingEvent, DegradationEvent, PolicyVersionEvent.
**Identity concepts (five, distinct — P2D-08):** source-native event ID · local ingestion ID · deduplication fingerprint (source-aware, uncertainty-aware; **no formula canonized in discovery**) · case/correlation ID · action idempotency key.
**Replay definition (corrected):** state is a fold over recorded events **consuming recorded model outputs with provenance** — replay never re-invokes a model.
**Alternatives:** single event stream vs. per-family streams with a global ordering service — carried to design.
**Recommendation:** the record set + identity separation above as requirement-level inputs; **GAP-2 (dedup design) is an OPEN blocking design requirement** with objective acceptance tests (no false-merge of distinct legitimate events; no missed transformed redelivery; identity independent of normalization version).
**Owner decision:** none required.
**Downstream impact:** DB schema first cut; dedup design + tests; replay harness.
**Falsifier/review trigger:** any UI-observable state not reproducible by the fold is a replay breach (design-phase test).

## OQ-06 — Policy representation — **Answered at requirement level; precedence carried open (P2D-10 corrected)**

**Evidence:** A4/A9; trail 21/22/23/27; Manual 10.2; checks 2/5.
**Correction:** the "specific-over-general; newest-effective tie-break" resolution algorithm is **withdrawn** — it ignored policy authority, explicit priority, deny-overrides, and protection floors.
**Requirements established:** policy objects need explicit scope, **authority domain**, **priority**, effective dates, conflict behavior, exception authority (owner-only), change exclusively via governed PolicyVersionEvents, rollback by version pointer, deterministic replay.
**Alternatives (all carried to design, unresolved):** explicit priority + authority domain; deny/safety-floor precedence for protection policy; unresolved equal-priority conflict fails closed; owner-approved scoped exception with explicit supersession target.
**Recommendation:** adopt the requirement set; select the precedence model in design with dedicated replay cases comparing the four alternatives.
**Owner decision:** none at this gate (a precedence choice with owner-visible consequences may surface later via the design-phase decision package).
**Downstream impact:** policy-object schema; precedence replay suite.
**Falsifier/review trigger:** check 2 remains the continuous invariant — any behavior change without a PolicyVersionEvent is a breach.

## OQ-07 — Queue mechanics — **Answered (P2D-09 corrected)**

**Evidence:** S8; ATT-02, QUE-01, AUT-04, ACT-01.
**Correction:** owner-queue admission is defined by **required owner action + the attention contract**, not tier number alone. Admitted: T3 cards, **T4 consequential approvals**, ACT-01 uncertain-outcome reviews, verification exceptions, policy conflicts escalated by fail-closed rules, and ratified review items.
**Alternatives:** one mechanism with hard domain partitions rendered in one frame (recommended — this is what trail 16’s "unified dashboard presenting the segregated data" actually specifies) vs. tag-only unified queue (violates PER-02/EX-03 — withdrawn) vs. fully separate mechanisms (duplicates governance).
**Recommendation (P2R-01, verifier text adopted):** Use one governed queue **mechanism** with **hard Business and Personal partitions**. The partitions remain separately permissioned and separately prioritized; the Executive Desk renders them in one unified frame **without interleaving their items**. System-wide capacity metrics may aggregate counts, but record ownership and queue order remain domain-separated (PER-02, EX-03, QUE-01 satisfied simultaneously). Cross-domain movement is a governed correction/reclassification event. Aging ladder unchanged per partition; caps from the capacity model.
**Owner decision:** none required.
**Downstream impact:** queue schema; 18.1 queue metrics wiring.
**Falsifier/review trigger:** queue metrics breaching the capacity model two consecutive weeks = mechanism failure, review trigger.

## OQ-08 — Ritual integration — **Answered**

**Evidence:** AUD-03/LRN-09/LRN-10 accepted texts; trail 6; S8/A14.
**Alternatives:** rituals as scheduled T1 producers under SCH-02 envelopes (recommended) vs. owner-triggered rituals (fails C-35/trail-6) vs. always-on continuous evaluation (fails capacity/cost posture).
**Recommendation:** scheduled T1 producers; AUD-03 scorecard routes T2 (file + brief line) or by attention contract when severity crosses; LRN-10 threshold crossings emit observation events feeding the LRN-09 shortlist; LRN-09 output is at most one T3 card per cycle.
**Owner decision:** none required.
**Downstream impact:** SCH-02 envelope instantiation for each ritual; design carries this into scope (P2D-11).
**Falsifier/review trigger:** any ritual that requires owner memory to fire violates C-35 — structural test.

## OQ-09 — Execution and verification authority — **Answered**

**Evidence:** S6/A7/A12/A15/A16; ACT-01; 11.6/11.7; GOV-03; TASK-0001/0002 receipts as live precedent.
**Alternatives:** engine-derived state from external receipts (recommended) vs. engine-attested execution (violates accepted evidence authority — not carried) vs. human-only verification (fails automation-first for eligible classes).
**Recommendation (unchanged, verifier-confirmed direction):** executed/verified is derived from externally-owned ExecutionReceipt + harness VerificationRecord + ReconciliationEvent; the engine may request or observe, never certify; ACT-01 uncertain → halt, Needs Review; classes without idempotency support stay T3/T4 with manual receipts.
**Owner decision:** none required.
**Downstream impact:** receipt/verification linkage schema; check-4 test harness definition.
**Falsifier/review trigger:** check 4 — state advancing without the external receipt in a test is a breach.

## OQ-10 — Coordinator boundary — **Answered**

**Evidence:** D9/EX-04; D5 (trail 53); DAT classes; PLAT-02 (binding); S1/S6/S7; A13 (added render-leak case).
**Alternatives:** strict derived-view rendering with masked sensitive classes (recommended, = accepted D5-A) vs. named-class full rendering (rejected by accepted D5 decision) vs. companion-app-only sensitive access (deferred to Discord-limits evidence per 16.5).
**Recommendation:** Discord renders receipts, briefs, INT-01 cards, breadcrumbs, summaries — derived views only; sensitive DAT classes masked + tap-through; notification previews obey the stricter preview rule (A13); engine internals (candidate sets, confidence values, policy tables, raw evidence) never render; policy changes never travel via chat text.
**Owner decision:** none required (D5 already ratified).
**Downstream impact:** render-policy table per DAT class; notification-preview rules.
**Falsifier/review trigger:** a workflow impossible without exposing an engine internal → designed exception via governed change, never ad-hoc.

---

## Termination summary

8 Answered (2 of them at requirement level with named open design items: OQ-05 identity, OQ-06 precedence) · 1 Needs-owner (OQ-04 → OD-1, within ATT-01) · 1 Answered-with-design-gate-test (OQ-02 end-to-end boundary) · 0 deferred. Field completeness: all ten OQs carry status, evidence, alternatives, recommendation, owner-decision, downstream impact, and falsifier/review trigger.
