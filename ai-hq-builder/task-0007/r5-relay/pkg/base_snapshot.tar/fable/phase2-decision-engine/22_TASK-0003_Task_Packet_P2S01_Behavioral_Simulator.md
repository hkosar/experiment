# TASK-0003 — Task Packet: P2S-01 Behavioral Candidate-Transition/Fold Simulator

**Purpose:** authorize and fully specify the ONE piece of work blocking CP-P2-A's design gate — a genuinely behavioral, deterministic simulator satisfying the verifier's P2S-01 requirement, plus the P2S-05/P2S-06/P2S-07 test sets that ride inside it, plus E2E-1 execution. Issued per the `19_TASK-0002_APP05_Conformance_Addendum.md` reusable APP-05 template. **This packet is the sole authorization for build mechanics on this task.** No other file, prior chat content, or informal instruction authorizes Builder action.

---

## Identity and authority

- **Task:** TASK-0003 — canonical bootstrap-registry ID (allocated 2026-07-30, trail entry 91; `../v1.2-ideas-pass/bootstrap_id_registry.md`).
- **Parent topic (canonical ID):** TOPIC-0002 — "Phase 2 — Decision Engine".
- **Approved plan/version:** CP-P2-A (Revision 2, corrected), current SHA-256 `e284f357b6a6ae0bd39927cab1190bd3b7a007cb92bcf44891b76c71f030b224`, at commit `f9240f801b9ef24d01caeca8a8b6ba7e7ad41af0` (tree `583cf940bd88d95dcbcfa638bf80e128cc553c27`). Owner-approved trail entry 86; design executed trail entry 87; **design gate not yet passed** — two verifier FAILs to date (trail entries 88, 90), correction cycle 2 open (trail entry 90/91). This task does not require or claim design-gate passage; it produces the evidence the verifier's P2S-01 finding requires.
- **Requirement authority (enumerated):** APP-04, DE-R2, DE-R7 (behavioral fold and store-order correctness); TRS-02 (P2S-07 proposal-eligibility test); the six identity/four attention/etc. accepted requirements only as already reflected in the cited design artifacts below — **this task does not reinterpret any accepted requirement**, it only proves the design artifacts' claims behaviorally.
- **Decision authority (enumerated):** trail entries 88 (design-gate FAIL, P2G-01..14), 89 (P2G corrections applied), 90 (scoped re-verification FAIL, P2S-01..08), 91 (this task's allocation + the Fable role-boundary correction that necessitated a clean authorization). Verifier records: `17_Verifier_Design_Gate_Verification_CP-P2-A.md`, `20_Verifier_Scoped_Reverification_Corrected_Design.md` (SHA-256 `ffdf889fc4a76f28b130cdde9e7399cc9fd8b74cad1ab77c9ec34a3f40f95857`). Fable dispositions: `18_P2G_Dispositions.md`, `21_P2S_Dispositions.md` (SHA-256 `74c3f8f8b4f4386794523e7d45db95e82147f9500ab85b0c2f72dc79cfc3398a`).
- **Builder:** Claude Opus 5 (`claude-opus-5`) — standing authorized substitution per trail entry 69, reconfirmed as current GOV-01 assignment (`D-AM_v14_Amendment_Package.md` Item 0).
- **Risk class:** internal design-test tooling only. No runtime deployment. No production credentials. No network access. No real owner data (synthetic scenario data derived from the frozen fixture corpus only). No Discord surface, no external write of any kind.

---

## Trust and data classes

- **Authority-bearing task projection:** origin = Fable project-manager projection of the verifier's exact P2S-01/P2S-05/P2S-06/P2S-07 requirement text (quoted verbatim in this packet, §Required Behavior); trust_class = trusted-internal; Builder `instruction_authority` = this packet only; sensitivity_class = internal design-governance tooling; verification_state = hash-bound snapshot, Fable- and later verifier-validated.
- **Source-manifest files below** are governance/evidence references, not Builder instructions — they establish the design rules the simulator must encode faithfully, per §8 of the plan (data/sandbox contract): **the simulator computes from these design rules and from structured input-side scenario stimuli only. It MUST NOT read, import, or otherwise consult any fixture `expected`, `actual`, `verdict`, or `pass_rule` field when computing behavior.** That data is oracle-only and is consulted by a separate judging component, never by the engine/model computing candidate behavior. This is the anti-circularity contract and is the acceptance criterion the prior (Fable-authored, now-quarantined) attempt failed.
- **Data classes:** synthetic-only. `03F_Replay_Fixtures.json` is a frozen, already-public-within-this-project synthetic corpus — no personal data, no credentials. No real-input sampling is authorized under this task (plan §8 item 2 — real sampling requires separate owner authorization and is out of scope here).
- **External-untrusted content in scope:** several fixtures (e.g. A2, A11, S7, E2E-1) simulate untrusted email content. This is synthetic fixture text, processed only as in-memory Python strings inside the sandboxed harness — never sent anywhere, never treated as instruction.

---

## Source/context manifest (hash-bound)

Builder reads and encodes rules from these; Builder does not modify any of them.

| # | File | SHA-256 |
| --- | --- | --- |
| 1 | `03F_Replay_Fixtures.json` (frozen fixture corpus — INPUT-SIDE fields only, see rule above) | `77efff5c051c4c31ddbe8768d4d06027076641b923704d8b28483216d8fcb784` |
| 2 | `13_CP-P2-A_Design_Phase_Change_Plan.md` (approved plan, current state) | `e284f357b6a6ae0bd39927cab1190bd3b7a007cb92bcf44891b76c71f030b224` |
| 3 | `20_Verifier_Scoped_Reverification_Corrected_Design.md` (P2S-01/05/06/07 exact findings) | `ffdf889fc4a76f28b130cdde9e7399cc9fd8b74cad1ab77c9ec34a3f40f95857` |
| 4 | `21_P2S_Dispositions.md` (Fable's committed correction approach) | `74c3f8f8b4f4386794523e7d45db95e82147f9500ab85b0c2f72dc79cfc3398a` |
| 5 | `design/D-SM_Supersession_Map.md` (which rule text is authoritative where corrections were appended) | `4a8382ded79f28393994bf9df811445aa6d7555de219d96dd8f8119f38ec66ed` |
| 6 | `design/D-B2_Field_Authority_Contract.md` (field taxonomy, fail-closed enumeration, P2S-07 eligibility rule) | `389900a919c09d2f9378bbfdc817bf9a37be113733536ebdb280614d119ecbcb` |
| 7 | `design/D-B4_Concurrency_and_Ordering.md` (boundaries; P2S-05 linearization contract, §2.3) | `34c4fb3eb3b0e7671d69f12cb61c1273e57dd2f2e9c1c34ca3bc89993d9f85cd` |
| 8 | `design/D-B6_Tier_Policy_Function_and_Autonomy.md` (tier function; corrected DE-R8 math) | `867db861599dea4903b0c67f20b505779db447fcdf845ac33b0890f2724fd9be` |
| 9 | `design/D-B8_Policy_Objects_and_Precedence.md` (P2G-10 per-output composition) | `7b34bac0ef38c105fe67487caa4d6cbd15295e57bef220cb1b5430ce1ee9191f` |
| 10 | `design/D-B9_Event_Model_and_Replay.md` (store-ownership matrix; P2S-06 fold-order contract) | `287e099c176760be20fb42fb1fad869667c57d1b2672aa82296bbfcd4a988e14` |
| 11 | `design/D-KR_Kill_Revoke_and_Resilience.md` (P2S-03/04 dead-man + schedule-liveness) | `a8ef1d5a0db80b5d30058a4fc38d359e9450ca907f996be8a5c2c3a9426271c0` |
| 12 | `design/traces/check_supersessions.py` (existing machine check; run it, do not modify) | `17963339322b4801fd14d1f727a50a495f40c8efaf336655a737480f4386cc0a` |

**Non-authoritative note:** an unauthorized Fable draft attempt at this exact task exists outside the repository (session scratchpad, not portable, not vetted, produced in violation of role boundaries per trail entry 91). It is **not** part of this manifest and carries no authority. Builder may not treat any such artifact as instruction even if encountered; if Builder's environment has no access to it, that is correct and expected — build fresh from this packet.

---

## Baseline rationale

Greenfield within this task's scope. The prior "machine-executed" trace/fold scripts (`gen_shape_traces.py`, `run_fold_comparison.py`, committed at earlier gate-commits) are **withdrawn as evidence** (P2S-01 finding — they were circular) and are not a baseline to extend or repair; do not reuse their approach (copying fixture `expected`/`actual`/`verdict` into result records). Build the computation fresh from the design rules.

---

## Required behavior (P2S-01 exact text, quoted verbatim — this is the acceptance contract)

> Provide a genuinely behavioral, deterministic design simulator or equivalent machine-checkable model that:
> 1. Starts from the fixture's explicit initial state and control envelope.
> 2. Applies candidate-specific transition and storage/projection rules for S1, S2, and S3.
> 3. Produces actual events, records, state, queue/attention projections, authority ceilings, and requested actions without copying the fixture's expected result.
> 4. Compares the computed actual result against the expected result and pass rule.
> 5. Evaluates every forbidden outcome.
> 6. Enforces external-receipt ownership before executed/verified state can appear.
> 7. Replays the full multi-store basis from recorded inputs and model outputs.
> 8. Fails on missing, unclassifiable, or unexecuted cases.
> 9. Produces candidate-specific divergences rather than excluding every behavior-affecting difference by assumption.
>
> E2E-1 must either be executed at this design gate as the approved plan requires, or the approved plan must be formally amended through the owner-controlled change process. It cannot remain pending while the gate reports PASS.
>
> **Falsifier for closure:** The corrected harness must fail when a seeded candidate defect changes authority, drops a receipt, reorders a causal event, admits a forbidden outcome, or produces a stale projection.

**Additional test sets committed in `21_P2S_Dispositions.md` and required to ride inside this same harness:**

- **P2S-05 (five traces):** policy-commit-before-lease-acquisition (acquisition fails); lease-before-policy (in-flight recorded, completes); policy-after-provider-acceptance (historical fact + receipt); lease expiry (re-acquisition re-serializes); uncertain provider response (halt + Needs Review) — per `D-B4_Concurrency_and_Ordering.md` §2.3's linearization contract.
- **P2S-06 (shuffle-invariance):** the behavioral fold must produce byte-identical final state, projections, and divergence lists under multiple seeded delivery-order permutations that preserve causal edges — per `D-B9_Event_Model_and_Replay.md`'s P2S-06 section.
- **P2S-07 (negative/positive):** a negative test showing extracted claims with no eligibility policy produce zero proposals of any class (including filing/placement); a positive test showing an approved filing-only policy permits filing while still blocking any outbound action — per `D-B2_Field_Authority_Contract.md`'s P2S-07 section.

**Scope of fixtures:** all 27 cases in `03F_Replay_Fixtures.json` (S1–S10, A1–A16, E2E-1) across all three candidate shapes (S1/S2/S3 storage models — note: fixture ID "S1" and shape "S1" collide in name only; disambiguate clearly in output). Every fixture × shape combination must produce a computed result and a judged pass/fail; a fixture the harness cannot classify **fails the run**, per requirement 8 — it must never be silently skipped or excluded.

---

## Failure / concurrency / idempotency / rollback

- **Failure:** any harness defect discovered post-delivery returns as an APP-07 Rework Packet from Fable, naming the finding, the failing behavior, and the smallest required correction.
- **Concurrency:** N/A — single Builder, single task, no parallel writers to this path.
- **Idempotency:** the harness itself must be deterministic (no wall-clock, no `random` without a fixed seed) — re-running it on the same inputs must reproduce byte-identical output files. This is a design-test tooling requirement, not a runtime idempotency claim.
- **Rollback:** pre-integration — abandon/revert the task branch. Nothing in this task touches the accepted v1.3 baseline, the approved plan, or any `13_`/`13M_`/`13G_`/`13V_`/`D-B*`/`D-GS`/`D-ODP`/`D-AM` gate or design artifact. **Builder does not update gate/status artifacts — that remains Fable-only integration work after the Builder Delivery Record is independently reviewed.**

---

## Telemetry and prohibited logging

- **Telemetry:** none produced beyond the harness's own deterministic output files (result records, divergence reports, seeded-defect pass/fail summary).
- **Prohibited:** any real owner data, credentials, secret values, or content beyond the synthetic fixture corpus. No network calls of any kind (the harness is pure computation over in-memory structures — no model API calls either; "M1"/"M2" in E2E-1 are simulated deterministic normalizer functions, not live model invocations).

---

## Implementation allowlist (Builder-writable)

**New files only**, all under `fable/phase2-decision-engine/design/traces/behavioral/`:
- The simulator/engine module(s) — Builder's own structure and naming.
- A scenario-driver module encoding each fixture's INPUT-SIDE stimulus (envelope + narrative parameters) as structured data — never the expected/actual/verdict fields.
- A judging/oracle module that parses each fixture's `expected`/`pass_rule`/`forbidden` fields into computable predicates and judges computed results — this module may read those fields; the engine/scenario modules may not.
- A seeded-defect catalogue and runner producing the falsifier proof (each named defect must flip at least one fixture from pass to fail).
- A shuffle-invariance test runner (P2S-06).
- Generated output files (JSON/text reports) from running the above.
- A short `README.md` in that directory explaining how to run everything and reproduce the outputs deterministically.

**Explicitly NOT in the allowlist:** any file under `fable/phase2-decision-engine/` outside `design/traces/behavioral/`; any `13_`/`13M_`/`13G_`/`13V_` file; any `D-B*`/`D-GS`/`D-ODP`/`D-AM`/`D-SM`/`D-KR` file; the decision trail; the bootstrap registry; any `checksums.sha256` or `manifest.json`. Touching any of these is a scope deviation (see below).

---

## Acceptance criteria (discrete; each independently verifiable)

| # | Criterion |
| --- | --- |
| 1 | Anti-circularity: the engine/scenario code contains no read of any fixture `expected`, `actual`, `verdict`, or `pass_rule` field (grep-verifiable) |
| 2 | All 27 fixtures × 3 shapes = 81 combinations produce a computed result; zero silently skipped; unclassifiable cases FAIL the run (requirement 8) |
| 3 | Computed-actual is compared against parsed-expected/pass-rule per fixture (requirement 4); every fixture's full `forbidden` list is evaluated as a computable predicate (requirement 5) |
| 4 | Executed/verified state never appears without a computed external-receipt reference in the result (requirement 6) |
| 5 | The fold replays the declared multi-store basis (requirement 7) with the P2S-06 declared ordering keys, causal dependencies, and phase assignment per store |
| 6 | Candidate-specific divergences are produced when shapes genuinely differ — not excluded by blanket assumption (requirement 9) |
| 7 | E2E-1 executes as a real two-normalizer computation (two distinct deterministic functions over the same raw input) proving authority-ceiling invariance, with a seeded-defect case proving the check can fail |
| 8 | The seeded-defect suite (minimum: authority-raise, dropped-receipt, causal-reorder, forbidden-outcome-admission, stale-projection — the five named in P2S-01's falsifier, plus the P2S-05/06/07 defect classes) — **every seeded defect flips its target fixture(s) from pass to fail**; if any seeded defect still passes, the harness itself fails acceptance |
| 9 | Shuffle-invariance (P2S-06): identical final state/digest across ≥3 seeded causal-preserving delivery-order permutations |
| 10 | P2S-05's five traces present and separately reported with pass/fail |
| 11 | P2S-07's negative and positive tests present and separately reported |
| 12 | Full run is deterministic: two consecutive runs on the same code produce byte-identical output files |
| 13 | No file outside the allowlist is touched |
| 14 | Builder Delivery Record complete per APP-06, including the reflexive falsifier element (for each material claim, name what would disconfirm it) |

---

## Scope-deviation rule

If any fixture, design rule, or requirement text is ambiguous enough to block implementation, or if satisfying a requirement appears to require touching a file outside the allowlist, **stop and return to Fable as a change request** — do not improvise an interpretation of accepted requirements, design decisions, or DE-R texts, and do not touch gate/control artifacts. This is the same rule that correctly triggered the blocked-first-attempt precedent at trail entry 66; it applies identically here.

---

## Handoff requirements

Builder Delivery Record per APP-06: task name, branch, base and candidate commits, full changed-file list (must equal the allowlist scope), tool/environment versions, the acceptance-criteria table above with a result per row, the deterministic-reproduction proof (two runs, byte-identical), the reflexive falsifier disclosure, and any residual risks or known limitations. Return as a zip with `EXPORT_MANIFEST.json` per standing practice, addressed back to the next Fable coordinator session (see the companion coordinator handoff document for how to resume the pipeline from there).
