# D-B10 — Partitioned Queue Mechanics

**B-item:** B10 (plan §4). **Status:** Complete. **Authority:** PER-01/02, EX-01..11, QUE-01, ORG-01..07 (verifier P2R-01 partition text, carried unchanged), CAP-04 (P2A-14). **Depends on:** D-B6 (dispositions/admission inputs), D-B7 (bands), D-B9 (events, EconomicReviewEvent). **Feeds:** B13 (queue items render as cards), B12 (re-execution), §18.1 metrics wiring (build layer).

## 1. Objective

One governed queue **mechanism** with **hard Business and Personal partitions** — separately permissioned, separately prioritized, rendered by the Executive Desk in one frame **without interleaving** — with admission defined by required-owner-action + the attention contract, per-partition aging ladders as events, and CAP-04 economic-review admission.

## 2. Mechanism design

- **One mechanism, two partitions (P2R-01 text honored):** a single queue engine (one codebase, one governance surface) instantiated per partition. Partition state is separate storage (D-B4 boundary 3: no cross-partition transactions); permissions are per-partition (PER-02); priority ordering computes within a partition only. System-wide capacity metrics may aggregate counts; record ownership and queue order never aggregate.
- **Admission contract (OQ-07 corrected rule):** an item enters the owner queue iff it requires owner action *and* the attention contract admits it — the admitted classes: T3 cards, T4 consequential approvals, ACT-01 uncertain-outcome reviews, verification exceptions, policy conflicts escalated by fail-closed rules (D-B8 §5 layer 4 residue), ratified review items, and **CAP-04 EconomicReviewEvents as AUD-03 review items in their partition** (P2A-14). Everything else routes to Briefing or Record-only (D-B7 bands) — the queue is for decisions, not awareness.
- **Ordering within a partition:** attention band first (Critical never queues — it interrupts), then policy-versioned priority rules, then aging state. Deterministic from recorded state (replayable projection per D-B9 §4).
- **Aging ladder (per partition, event-carried):** AgingEvents fire at policy-versioned thresholds; escalation strengthens *presentation* (never fabricates urgency into Critical — D-B7 §5); the ladder's terminal step is an explicit stale-item review entry in the weekly AUD-03 ritual, so nothing rots silently. Cross-partition movement is a governed reclassification/correction event only (OQ-07).
- **One frame, no interleaving:** the Executive Desk renders both partitions in one view as **separate blocks** (Business block, Personal block) — never a merged sorted list. Within-block order is the partition's own order. A rendered mock is fixed as the acceptance form: two labeled blocks, per-block counts, no shared ordinal numbering across blocks.

## 3. Required tests — executed (recorded traces)

**Reproduction record (P2A-13):** procedure = trace evaluation against §2's rules over the queue-relevant fixtures (S8 aging, A-series policy-conflict cases; `03F_` SHA-256 `77efff5c051c4c31ddbe8768d4d06027076641b923704d8b28483216d8fcb784`) plus the scenarios below; B12 re-executes. Coverage limit: named scenarios; the §18.1 live metrics wiring is a build-layer obligation.

| Test | Trace | Verdict |
| --- | --- | --- |
| No-interleaving | Business T3 card + Personal T3 card, same instant, same band: rendered in separate blocks, no shared ordering decision exists between them by construction (no comparator crosses partitions) | **PASS** |
| Separate permissioning | A capability scoped to Business filing cannot read or mutate Personal queue state — separate storage + per-partition permission checks (PER-02); no shared handle to leak through | **PASS** |
| Admission contract | Each admitted class maps to a §2 rule; a T1 routine action (no owner action required) cannot enter the queue regardless of band; an unverified "urgent" claim (D-B7 trace 2) lands in Briefing, not the queue | **PASS** |
| Aging ladder per partition | S8 walk: Needs-Owner item ages through thresholds → AgingEvents → presentation escalation → terminal AUD-03 stale-review entry; Personal-partition aging never reorders Business items | **PASS** |
| CAP-04 partitioned admission | EconomicReviewEvent for a Business automation → AUD-03 review item in the Business partition; protected-class exemption already checked upstream (D-B9); no disable path from the queue item — it is a review card only | **PASS** |
| Dual-membership probe (falsifier candidate) | An input plausibly relevant to both partitions (personal purchase on the business card): the *record* lives in one partition per its data-class/domain mapping (D-B6 derived `domain`); the other partition gets a governed cross-reference stub, not co-ownership; if a case genuinely requires simultaneous dual ownership, that is the §4 escalation | **PASS (no dual-ownership case found in the fixture set)** |

## 4. Acceptance criteria — met; falsifier

No fixture shows cross-partition interleaving or permission bleed; every admission maps to the contract. **Falsifier/reopen:** an input requiring *simultaneous membership* in both partitions (not resolvable by primary-home + cross-reference) escalates to the owner package as a partition-policy question (plan §4 B10) — not triggered by the current fixture set; the probe row above documents the closest case and its resolution.
