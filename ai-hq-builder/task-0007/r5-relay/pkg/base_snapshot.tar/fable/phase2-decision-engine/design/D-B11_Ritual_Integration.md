# D-B11 — Ritual Integration (SCH-02 envelopes for AUD-03 / LRN-09 / LRN-10)

**B-item:** B11 (plan §4). **Status:** Complete. **Authority:** SCH-01/02, AUD-03, LRN-01..10, CAP-03/CAP-04 (P2A-14). **Depends on:** D-B9 (events — ritual outputs are governed events), D-B7 §4 (shared schedule-envelope seam). **Feeds:** B12 (A14 oracle re-execution), B13 (ritual outputs render as cards/brief lines).

## 1. Objective

Instantiate the SCH-02 scheduled-run control envelope for the three accepted rituals so each fires without owner memory (C-35/trail-6), produces only governed events, and carries the CAP-04 economic-review surface into the weekly audit.

## 2. Envelope instantiations (SCH-02 fields per ritual)

All three are **scheduled T1 producers** (OQ-08 as answered): deterministic-rule tier, no external side effects, outputs enter the engine only as D-B9 events. The liveness contract, stated once (P2W-05): a scheduled run may emit a failure event only when it is alive and detects its own failure; silence, failure-before-start, and missed recurrence are detected by the independent watchdog from the authoritative schedule definition and receipt stream; the scheduler's rolling horizon is corroborating evidence, never the primary liveness authority.

| Envelope | Schedule | Input scope | Outputs (D-B9 types) | Owner surface |
| --- | --- | --- | --- | --- |
| `ritual.aud03.weekly.v1` | Weekly, owner-tunable slot | The week's events per partition: receipts, corrections, refusals, conflicts, aging terminals, **CostEvidenceRecords and EconomicReviewEvents (CAP-03/04)** | Scorecard record (T2 file + brief line); items crossing severity route by the attention contract; **cost-over-value flags surface as the partition's AUD-03 review items — review cards only, no disable authority (P2A-14)** | Weekly scorecard in Briefing; review items in the queue per D-B10 admission |
| `ritual.lrn10.observe.v1` | Continuous thresholds evaluated on schedule ticks | Recorded correction/override/pattern streams (LRN-10 accepted text) | ObservationEvents on threshold crossings — observations only, zero authority (governed-learning boundary: propose → workflow disposes, hypothesis check 2) | None directly; feeds LRN-09 |
| `ritual.lrn09.shortlist.v1` | Per accepted LRN-09 cycle | Accumulated ObservationEvents | **At most one T3 card per cycle** (accepted LRN-09 bound) proposing a governed change (PolicyVersionEvent draft); everything else holds to next cycle | One card max per cycle in the queue |

## 3. Required tests — executed (recorded traces)

**Reproduction record (P2A-13):** procedure = envelope-field audit + per-ritual trace against the A14 oracle definition (`03_Scenario_and_Adversarial_Replay_Matrix.md`, SHA-256 `520540b535a39fbef331a5fdcd346215b9f49853a8c1a236358786943b3aa72e`) and the scenarios below; B12 re-executes. Coverage limit: envelope/trace level; live schedule execution is build-layer.

| Test | Trace | Verdict |
| --- | --- | --- |
| A14 oracle (ritual fires without owner memory) | All three envelopes carry recorded schedules; **missed-run detection is external — the D-KR watchdog computes deadlines from the authoritative schedule definitions it holds** (P2S-04 section, authoritative) — C-35 structural test. *(The earlier scheduler self-report rule is SUPERSEDED per P2S-02 — a dead scheduler cannot self-report; detection is watchdog-owned.)* | **PASS** |
| Envelope completeness per SCH-02 | Field audit: schedule/scope/permissions/outputs/failure/policy-version present on all three | **PASS** |
| Learning-event fold-back replay | LRN-10 ObservationEvent → LRN-09 shortlist → T3 card → (if owner approves) PolicyVersionEvent: every step is a recorded event; replaying the chain reproduces the card and the version change; no step mutates policy directly (check 2 held) | **PASS** |
| One-card bound | Cycle with five qualifying observations: exactly one T3 card; remainder held with their events intact for the next cycle | **PASS** |
| CAP-04 synthetic gate case (P2A-14 required) | Synthetic CostEvidenceRecords show a Business filing automation costing more than its measured value → EconomicReviewEvent (correct partition) → AUD-03 review item on the weekly scorecard → **the automation keeps running** (no disable path exists in the event, the ritual, or the queue item) → separately, a synthetic cost flag against the kill-switch monitoring control (a protected `security`/`audit` class) → exemption check blocks cost-only retirement; the flag surfaces as informational only | **PASS** |
| Ritual bypass probe | Can any ritual output reach state without the event model? No path: outputs are typed D-B9 events by construction; a ritual writing state directly would violate LOG-01 (falsifier — not present in design) | **PASS** |

## 4. Acceptance criteria — met; falsifier

Each ritual has a complete, validating envelope whose outputs enter the engine only as governed events; the CAP-04 behavior is proven at design level in its required synthetic case (flag, never disable; protected classes exempt). **Falsifier/reopen:** a ritual output that must bypass the event model to function reopens against LOG-01 via plan §1.4 — not triggered.

## P2G-08 correction — the complete ScheduledRunEnvelope and independent missed-run detection

**The prior missed-run rule was circular** (a dead scheduler cannot emit its own failure notice) **and the envelope was materially incomplete.** Corrected design:

### ScheduledRunEnvelope (full SCH-02 field set; schema record in D-B14)

```text
envelope_id, envelope_version, schedule_id
actor_identity + authenticated authority        # who this run acts as, bound per IDN-01
trust_class, data_class                          # of the run's context and outputs
active_scoped_rules[]                            # policy/automation-policy version refs in scope
checkpoint_version, schema_version               # current at envelope issue
permitted_tools[], permitted_action_classes[]    # closed lists; nothing else callable
failure_constraints, idempotency_constraints     # incl. duplicate-tick behavior
rollback_recovery_requirements
evidence_destination, log_destination
context_pack_manifest {source_ids[], content_hashes[], issued_at, valid_until}
```

Fail-closed rule (SCH-02's own words made mechanical): missing, stale (`valid_until` passed), or hash-mismatched mandatory context ⇒ the run refuses before start, emitting a refusal event; the full workspace is never loaded by default — only the manifest's named sources.

### Independent missed-run detection (watchdog-owned recurrence; P2T-04 consolidation — the prior scheduler-written-ExpectedRun-primary model is superseded)

**Primary (D-KR P2S-04):** the **watchdog holds the authoritative, versioned recurrence specifications and computes expected deadlines itself** — no dependency on any per-occurrence registration the scheduler performs. A computed deadline passing without a matching `RunStarted` receipt raises the watchdog's missed-run notice; a scheduler that dies after a run and before registering the next occurrence is still detected, because detection never depended on that registration (behaviorally demonstrated: `traces/behavioral/run_p2s04.py`, scheduler-death case). **Corroboration only:** the scheduler's rolling future-dated `ExpectedRun` horizon remains a cross-check signal; horizon exhaustion is alarmed early, before the next computed deadline (`run_p2s04.py`, horizon case). Versioned schedule changes atomically update the watchdog's expectations — no orphaned old deadline, no missing new one (`run_p2s04.py`, atomic-change case).

### The six required failure tests (deterministic simulation over the contract)

| Test | Expected outcome | Result |
| --- | --- | --- |
| Missing/stale context manifest | Refusal before start + refusal event; no partial run | PASS (fail-closed rule) |
| Duplicate schedule tick | Idempotency constraint: second tick recognizes the first's `RunStarted` receipt; no double execution | PASS |
| Scheduler failure before start | ExpectedRun deadline passes unanswered ⇒ watchdog notice (not self-report) | PASS |
| Failure after partial output | Evidence destination holds partial receipts; recovery reconciles per rollback requirements; rerun under a fresh envelope | PASS |
| Policy/schema change between scheduling and execution | Envelope pins versions; the P2G-05 pre-execution epoch check applies to scheduled actions identically — stricter change ⇒ re-evaluate before start | PASS |
| Independent missed-run notice | As scheduler-failure row; notice carries schedule_id + deadline evidence | PASS |

**Build-verification pending:** live watchdog deployment and a real missed-run drill (SEC-01/activation gate). Ritual behavior rules (one-artifact cap, three-occurrence threshold, exclusions) are unchanged — they now ride in complete envelopes.

## Small-item closures (exact-requirement mechanisms)

- **AUD-03 rubric completeness (exact-text audit):** the self-audit runs on a **versioned rubric object** declaring: dimensions, weights, denominators, and missing-data treatment; the one-screen output carries total score, 3–5 strengths, top-three leverage-ranked gaps, one concrete next step per gap, and evidence references for every deduction; **unknown/unavailable evidence renders as `unknown` — never as a zero score**; independent security/verification/resilience controls are summarized only from their authoritative evidence sources (RestoreDrillEvents, watchdog records, gate records) — the self-audit **cannot self-attest** they passed; the score informs prioritization and never independently passes a gate. Owner-tunable cadence; read-only run under its ScheduledRunEnvelope.
- **LRN-06:** inactivity review — a learned object with no usage events for the threshold window (90-day provisional, owner-tunable) raises a review item in the next AUD-03 sweep; never auto-removed; disposition is a governed lifecycle-state change (LRN-05 states, D-B14).
- **ORG-05:** hub-housekeeping trigger — a hub whose unresolved-children count exceeds its threshold (policy parameter) raises a housekeeping review item into the quarterly sweep.
- **ORG-07:** the three-question structure test (conceptually distinct? touched ≥3×/month, owner-tunable? future routing target?) renders as **advisory coaching** on structure-adding proposals — two affirmatives support adding, otherwise wait; **capture is never gated** (structural: the test attaches to structure proposals, not to intake); quarterly archive sweeps are scheduled AUD-03 runs.
- **WF-12:** protocol/housekeeping management is the sum of the above — rituals, sweeps, aging, and reviews run scheduler-side under envelopes with watchdog liveness; none depends on the owner remembering to administer anything (C-35/trail-6 intent).
