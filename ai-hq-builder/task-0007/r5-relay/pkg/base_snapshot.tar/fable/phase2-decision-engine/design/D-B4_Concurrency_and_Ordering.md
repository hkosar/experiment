# D-B4 — Concurrency and Ordering (DE-R2)

**B-item:** B4 (plan §4). **Status:** Complete. **Authority:** proposed DE-R2 (verbatim, plan §5); MEM-01..03; DP-001 (Manual capture principle); ACT-01. **Depends on:** D-B3 (identities anchor the boundaries); D-B2 (envelope pins `policy_version`/`schema_version` per evaluation). **Feeds:** B1 (boundaries are shape-neutral by construction — a comparison precondition), B5 (degraded behavior per boundary), B9 (event ordering/outbox), B10 (queue state), B14 (schema).

## 1. Objective

Define the authoritative consistency boundaries, the protection mechanism per boundary (serialization point vs. versioned compare-and-swap), where total order is required versus where conflict detection + reconciliation suffices, causal/source-order recording, and the DP-001 capture-latency bound — then execute DE-R2's six acceptance scenarios as recorded interleaving traces.

## 2. Consistency boundaries and mechanisms

DE-R2 (revised) requires boundaries for four domains. No global total order exists anywhere in this design; each boundary declares its own, narrower guarantee.

### 2.1 Boundary 1 — Pre-placement intake

- **Protected state:** the durable intake log (raw accepted inputs before any placement/classification).
- **Mechanism:** append-only log, single logical writer per intake partition; arrival order within a partition **is** the serialization. Total order: per-partition only — sufficient, because pre-placement records reference nothing mutable.
- **Capture rule (DP-001):** capture acknowledgment is issued **only after the durable intake append commits**, and never waits on classification, policy evaluation, or placement — those proceed asynchronously. Declared design latency bound: **ack ≤ 2 s p95, ≤ 5 s p99** under normal operation. (Live measurement is a §7 build-gate obligation; the design-gate obligation is that no synchronous downstream work sits inside the ack path, which §4 scenario 1 traces.)

### 2.2 Boundary 2 — Topic/object canonical state

- **Protected state:** canonical records (topics, cases, decision records) keyed by `cid`/record ID.
- **Mechanism:** **per-object versioned CAS** — every mutation carries the expected object version; a version miss never overwrites (no lost update by construction) and resolves to retry-with-re-evaluation or, if unresolvable, a **ConflictRecord** (a first-class B9 event, surfaced per OQ-07 admission rules). Total order: per-object version chain only; cross-object order is deliberately not promised (Boundary 4 handles multi-object operations).

### 2.3 Boundary 3 — Policy and queue state

- **Protected state:** the active policy set and queue membership/order per partition.
- **Mechanism:** policy changes travel exclusively as PolicyVersionEvents through a **single policy-plane serialization point** (total order over policy versions — required, because DE-R6 replay depends on an unambiguous policy history). Every evaluation **pins** the `policy_version` it read (already a mandatory envelope field, D-B2 §2.1) and is atomic against that snapshot. Queue mutations use per-partition CAS (Business and Personal partitions are separate state, PER-02 — no cross-partition transactions exist, by design).
- **Race rule (evaluation vs. policy change) — decision truth vs. execution authorization separated (P2G-05 correction):** an in-flight evaluation completes under its pinned version and records it — the **DecisionEvent remains historically valid and replayable** (DE-R6 determinism: replay = f(recorded basis)). But a decision is *not* an execution license. The prior flag-for-later-review rule was insufficient for **unexecuted external actions** — review after the side effect is too late. The corrected contract:

  ```text
  decision_basis_policy_version      # pinned at evaluation; historical fact, never rewritten
  action_authorization_policy_epoch  # the policy epoch under which execution is authorized
  authorization_expires_at           # every authorization is time-bounded
  pre_execution_policy_check         # executor MUST re-check the current epoch immediately before the side effect
  executor_compare_and_swap / lease  # one executor holds the attempt lease; epoch mismatch fails the CAS
  revoked_by_policy_event            # set when a stricter PolicyVersionEvent invalidates the pending authorization
  ```

  **Linearization contract (P2S-05 — replaces the earlier overclaimed "cannot produce the side effect" statement, which promised more than the mechanism proved):**

  1. **One serialization point:** policy commits AND authorization-lease acquisitions serialize through the same policy-plane authority store — one total order over both event kinds, so "before/after" between a policy change and a lease is always well-defined.
  2. **Policy-first:** if the stricter PolicyVersionEvent commits before the lease acquisition, the acquisition **fails** (the store rejects a lease against a revoked epoch — same-store atomicity, not a racing check).
  3. **Lease-first:** if the lease commits first, the action is **explicitly recorded as in flight under its epoch**; a later policy change does not — and cannot honestly claim to — prevent it. The in-flight window is bounded: leases are **short-lived and single-use** (declared bound: ≤ 60 s from acquisition to provider submission; expiry ⇒ re-acquisition required, which re-serializes against the current epoch).
  4. **Post-acceptance:** once the provider has accepted the side effect, policy changes govern the *future* only; the executed action follows ACT-01 receipt/reconciliation. **Provider-side kill/revoke (D-KR §1.2 row 1) is the urgent-cancellation path where the provider supports it.**
  5. **Uncertain outcomes:** ACT-01 — halt, Needs Review, reconcile before any retry; never blind retry.

  What is provable: an unexecuted authorization whose epoch is revoked before lease acquisition can never reach a provider (rule 2, same-store atomicity); an in-flight action's exposure is bounded by the lease lifetime (rule 3). What is *not* claimed: prevention of an action already accepted by the provider — that is the kill path's job and ACT-01's aftermath. **Five simulator traces (P2S-05 set):** policy-before-lease (acquisition fails), lease-before-policy (in-flight recorded, completes, reconciliation notes epoch), policy-after-provider-acceptance (historical fact + receipt), lease expiry (re-acquisition re-serializes), uncertain provider response (halt + Needs Review). Suspended requests re-evaluate under the new version — re-authorize, downgrade to T3, or refuse, each a recorded event. Non-stricter changes leave pending authorizations intact (recorded compatible).

  **Race trace (P2G-05 acceptance):** T2 filing ActionRequest authorized under P1 at epoch E1 → stricter P2 commits (scope covers filing) before execution → P2's commit emits `revoked_by_policy_event` on the pending authorization → executor's pre-execution check reads epoch E2, CAS fails, no side effect → re-evaluation under P2 records the new disposition. The P1 DecisionEvent stands unmodified in history; replay reproduces both the P1 decision and the P2-forced non-execution. **PASS by construction of the epoch check; machine-trace re-execution travels with the P2G-02 trace set.**

### 2.4 Boundary 4 — Cross-object operations

- **Protected state:** operations spanning objects: fold-back into multiple topics, cross-topic reclassification, cross-domain (Business↔Personal) moves — the latter being governed correction events per OQ-07.
- **Mechanism:** **intent-then-apply**: (1) a single IntentEvent records the full operation against Boundary 1's log; (2) per-object CAS mutations apply under Boundary 2, each referencing the intent; (3) a reconciliation sweep compares intent vs. applied set and **exposes partial completion** as a visible reconciliation item (never silent partial state) — this is the same exposure contract DE-R7 demands of cross-store writes, and B9's transactional-outbox design plugs into exactly this seam.
- Total order: none across objects; correctness comes from intent visibility + per-object CAS + reconciliation exposure.

## 3. Causal and source ordering (recorded separately, per DE-R2)

Every event records: `ingest_seq` (authoritative arrival order within its intake partition — what the system *knows*), `source_ts` (the source's claimed time — what the source *asserts*, never trusted for ordering authority), and explicit `caused_by` references (event-ID links, the only causal authority). Presentation layers may sort by `source_ts`; nothing authoritative ever does.

**Declared scale assumption:** single logical writer per partition is sufficient at personal/small-business scale; no distributed clocks or vector clocks. **Reopen condition:** if the build phase shards writers within one partition, this boundary design reopens — recorded as an explicit falsifier rather than an unstated assumption.

## 4. DE-R2 acceptance scenarios — executed (recorded interleaving traces)

**Reproduction record (P2A-13):** procedure = deterministic interleaving analysis against §2's mechanisms (line-cited, non-executable analysis form per plan §4); inputs = the six scenario definitions from DE-R2's acceptance list (plan §5) with D-B3 identities; expected/actual per scenario; B12 re-executes the full set against the assembled design. Coverage limit: traces enumerate the named interleavings, not all possible schedules — the mechanisms are argued invariant-style (CAS/append-only properties), with the enumerated traces as witnesses.

| # | Scenario | Interleaving traced | Mechanism engaged | Outcome | Verdict |
| --- | --- | --- | --- | --- | --- |
| 1 | **Unplaced inputs** | Input A arrives; related input B arrives before A is placed | Boundary 1: both durably appended, acks issued from the append alone; placement later assigns `cid`s serially per object | Both captured; no ack waited on placement; no lost update possible (nothing mutable touched pre-placement) | **PASS** |
| 2 | **Same-topic conflict** | Owner edit and engine fold-back target one topic concurrently | Boundary 2 CAS: first commit wins at version *n*; second carries expected-version *n*, misses at *n+1*, retries against fresh state; if semantically unresolvable → ConflictRecord | No overwrite path exists; conflict surfaces as a record, not a loss | **PASS** |
| 3 | **Cross-topic reclassification racing an update** | Reclassify T1→T2 while T1 receives an edit | Boundary 4 intent + per-object CAS: the T1 edit and the T1-side reclassification mutation serialize on T1's version chain; reconciliation sweep sees intent partially applied if interrupted and exposes it | Partial state visible, never silent; both mutations land or the gap is a named reconciliation item | **PASS** |
| 4 | **Policy change racing evaluation** | PolicyVersionEvent P1→P2 commits while an evaluation pinned to P1 is in flight | Boundary 3: the DecisionEvent completes and records P1 (historically valid); **execution authorization follows the §2.3 corrected contract — unexecuted authorizations in P2's scope are invalidated/suspended and the executor's linearized lease check governs the side effect** *(SUPERSEDED text "flag for later review closes the gap" removed per P2S-02 — review-after-the-fact never governs an unexecuted external action)* | Decision truth replayable; execution safety by the §2.3 linearization | **PASS (design contract; simulator traces per §2.3)** |
| 5 | **Duplicate delivery** | The same source event delivered twice, interleaved with processing of the first | Boundary 1: both appends succeed (separate `iid`s — capture is never blocked by dedup, D-B3); dedup resolves post-intake per D-B3 §3.3 (exact-layer → auto-link) | Capture ack fast on both; no double-case, no drop | **PASS** |
| 6 | **Multi-object fold-back** | Fold one captured note into three topics; crash after two of three applies | Boundary 4: IntentEvent names all three; two CAS applies committed; reconciliation sweep exposes the third as pending/failed with the intent as evidence | Partial failure exposed (DE-R7 contract), completable or reversible from the intent record | **PASS** |

## 5. Where total order is required vs. not (DE-R2's explicit statement)

| State | Total order? | Why |
| --- | --- | --- |
| Policy versions (plane-wide) | **Yes** | DE-R6 replay needs one unambiguous policy history |
| Intake, within a partition | Yes (arrival order) | Cheap (append-only) and anchors `ingest_seq` |
| Per-object canonical state | Per-object chain only | CAS version chain is exactly the needed order |
| Cross-object, cross-partition | **No** | Conflict detection + intent/reconciliation suffice; a global order would couple partitions PER-02 requires separated and add latency against DP-001 |

## 6. Acceptance criteria — met

Every tested interleaving prevents lost updates (CAS misses cannot overwrite; appends cannot collide) and records unresolved conflicts as ConflictRecords; all four required boundary domains defined with mechanisms; causal and source ordering recorded separately; capture acknowledgment gated only on durable intake commit within a declared bound protecting DP-001.

## 7. Falsifier / reopen condition

Reopens if: any boundary is found where no carried mechanism prevents lost updates (design-gate blocker per plan §4/B4); the build phase violates the single-writer-per-partition assumption (§3); or measured ack latency at the build gate exceeds the declared bound with the durable-append path alone (which would mean the bound, not the architecture, needs a governed amendment). Not triggered.
