# D-B5 — Degraded Operation Matrix (DE-R3)

**B-item:** B5 (plan §4). **Status:** Complete. **Authority:** proposed DE-R3 (verbatim, plan §5); RES-01..03, IDN-03, MEM-01..08. **Depends on:** D-B4 (boundaries — degradation is defined per boundary dependency); B9 event set (DegradationEvent/refusal events — defined here, consolidated by B9). **Feeds:** B6 (health state is a policy-function input), B7 (system health is an attention dimension per DE-R5), B9 (recovery reconciliation), B10 (queue behavior under degradation), B12 (re-execution).

## 1. Objective

Replace the withdrawn single-ladder presumption (P2A-05) with a dependency-by-capability matrix: for each dependency that can be missing, stale, disputed, or unverifiable, state exactly which capabilities remain provably safe — with kill/revoke effective in every mode, no acknowledgment without durable persistence, no external mutation at any tier in any degraded mode, and recovery reconciliation before ordinary authority resumes.

## 2. Dependencies and capabilities

**Dependencies (failure axes):** D1 durable intake store · D2 canonical state store · D3 policy plane (active policy set/versions) · D4 identity/session services (IDN-01/02) · D5 append-only event log (LOG-01) · D6 evidence services (external receipt/verification linkage) · D7 model/normalization services.

**Capabilities (what might be offered):** C1 capture-with-ack · C2 capture-without-ack-queued (local durable buffer distinct from D1) · C3 read/render existing state · C4 classify/normalize (semantic, no authority) · C5 T0/T1 internal record actions · C6 T2 autonomous actions (external side effects) · C7 T3/T4 owner-decision processing · C8 kill/revoke (IDN-03).

**Non-negotiable invariants (DE-R3):** C6 is **never** available in any degraded mode — no external mutation or autonomous side-effecting action at any tier while anything in D1–D7 is degraded. C8 is available in **every** mode including total degradation — **by the designed D-KR mechanisms** (external control service, two owner paths, provider-side credential disable that works with the engine dead, heartbeat-fresh executor leases): see `D-KR_Kill_Revoke_and_Resilience.md` §1, which is the authoritative kill design. *(SUPERSEDED per P2S-02: the earlier "independent by construction" assertion — independence is designed in D-KR, not asserted here.)* Capture acknowledgment is issued only on durable persistence to a store that is itself healthy (DE-R3's queue-availability clause).

## 3. The dependency-by-capability matrix

Cell values: ✔ available · ◐ available with the stated restriction · ✖ refused (recorded as a refusal event when the event log is up; queued locally when it is not).

| Failure mode | C1 ack'd capture | C2 queued capture | C3 read | C4 classify | C5 T0/T1 internal | C6 T2 external | C7 T3/T4 | C8 kill |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| **F1** D1 intake store down | ✖ (no ack without durable commit) | ◐ local durable buffer only; **if the buffer is also unavailable, capture is refused honestly — no ack, owner-visible degradation notice** | ✔ | ◐ on queued items, marked provisional | ✖ (state writes route through intake ordering) | ✖ | ◐ read/decide only; decisions queue as intents | ✔ |
| **F2** D2 canonical state down | ✔ (intake independent) | ✔ | ✖ (nothing trustworthy to render beyond intake echo) | ◐ classification without placement | ✖ (no state to mutate safely) | ✖ | ✖ (cards need state; queue as intents) | ✔ |
| **F3** D2 stale/disputed snapshot (MEM checkpoint mismatch) | ✔ | ✔ | ◐ render with explicit staleness banner; version shown | ◐ | ✖ (writes against disputed state are lost-update bait — refuse, queue intents) | ✖ | ◐ owner may view; consequential decisions deferred with reason | ✔ |
| **F4** D3 policy plane unavailable/unverifiable | ✔ | ✔ | ✔ | ◐ semantic only — **no tier/authority computation without a verified policy version** (D-B2 §3 fail-closed) | ✖ | ✖ | ◐ intake-echo review only; no policy-derived dispositions | ✔ |
| **F5** D4 identity/session degraded | ✔ for non-owner-origin input | ✔ | ◐ non-sensitive classes only (DAT-02 masking holds without step-up available) | ◐ | ✖ for anything identity-gated | ✖ | ✖ (owner decisions require verified identity — IDN-01/02) | ✔ (per D-KR §1.3: any single pre-registered factor may **suspend** — bounded, rate-limited, receipted; **re-enable requires full step-up**. *SUPERSEDED per P2S-02: the earlier "weaker authentication" phrasing — the authoritative rule is suspend-easy/re-enable-hard with DoS bounds, D-KR §1.3*) |
| **F6** D5 event log down | ◐ capture to intake with local sequence; **no processing beyond capture** (LOG-01: unlogged authority transitions are prohibited — everything else refuses) | ✔ | ◐ reads allowed, flagged unaudited-window | ✖ | ✖ | ✖ | ✖ | ✔ (kill actions journal locally, reconciled after) |
| **F7** D6 evidence services down | ✔ | ✔ | ✔ | ✔ | ◐ internal-only records fine | ✖ (already banned; note: **no executed/verified state can advance** — DE-R7 external-receipt rule) | ◐ decisions allowed; anything awaiting verification holds in awaiting state | ✔ |
| **F8** D7 model services down | ✔ (capture never needs a model) | ✔ | ✔ | ✖ (queue for later classification) | ◐ deterministic-rule T1 only (no model-dependent rules) | ✖ | ◐ owner sees raw capture echo; no model summaries | ✔ |
| **F9** Combined worst-case (all of D2–D7 down, D1 up) | ✔ | ✔ | ◐ intake echo only | ✖ | ✖ | ✖ | ✖ | ✔ |
| **F10** Total (D1 + local buffer down) | ✖ | ✖ | ◐ whatever static state is reachable | ✖ | ✖ | ✖ | ✖ | ✔ |

**Reading the matrix:** the available safe mode is a *function of which dependency failed* — F2 permits full capture but no reads; F1 permits reads but no ack'd capture; there is no single ladder ordering these, which is exactly P2A-05's point. Every ✖ in an owner-visible capability produces a degradation notice; every refusal of a consequential request is recorded (DegradationEvent + RefusalEvent when D5 is up; locally journaled when not).

## 4. Combination rule

For simultaneous failures, capabilities intersect: the offered set is the **cell-wise minimum** across all active failure rows (✖ dominates ◐ dominates ✔). No combination can widen a capability — proven by construction since intersection is monotone. F9 is the precomputed worst-case witness of this rule.

## 5. Recovery reconciliation (before ordinary authority resumes)

Ordered, per DE-R3's closing clause: (1) drain local buffers into D1 with dedup on `iid`/`fp` (D-B3 — duplicates from buffer replay are the exact-layer case); (2) replay the unaudited window into D5, reconciling local journals (including kill actions taken during F6); (3) re-verify canonical state versions against checkpoints (MEM-02/03), disputed objects → ConflictRecords (D-B4); (4) re-pin the policy plane and re-evaluate queued intents under the *current* verified policy version (never the stale one — D-B4 §2.3's stricter-now rule applies to the gap window); (5) resolve awaiting-verification items against D6; (6) only then lift the degradation state — an explicit RecoveryEvent closes the window, and C6 eligibility resumes only at the fully-lifted state. Duplicate/conflicting events discovered during recovery follow D-B3 §3.3 and D-B4 §2.2 — never silently discarded.

## 6. Required tests — executed (recorded traces)

**Reproduction record (P2A-13):** procedure = per-row trace against §2's invariants and §3's cells (deterministic line-cited analysis, plan §4 form); inputs = failure-mode definitions F1–F10, the A10/A15 oracle definitions from the frozen replay matrix (`03_Scenario_and_Adversarial_Replay_Matrix.md`, SHA-256 `520540b535a39fbef331a5fdcd346215b9f49853a8c1a236358786943b3aa72e`); B12 re-executes with the assembled design. Coverage limit: traces cover the enumerated failure modes and the pairwise/worst-case combinations via §4's monotone rule, not every combination individually.

| Test (plan §4 B5 list) | Trace | Verdict |
| --- | --- | --- |
| Each dependency independently | Rows F1–F8: every row yields a defined, safe capability set; no row leaves a capability undefined | **PASS** |
| Combined failures | §4 intersection rule + F9 witness: no combination widens capability; worst case still captures (D1 up) and kills | **PASS** |
| Queue unavailability | F1 with buffer also down → F10 conduct: capture refused honestly, no ack issued for undurable input (DE-R3's "MUST NOT acknowledge" clause), owner-visible notice | **PASS** |
| Stale snapshots | F3: reads bannered, writes refused, T3/T4 consequential deferred with reason — no lost-update path opens | **PASS** |
| Kill during degradation | C8 column is ✔ in all ten rows including F10; F6 kill journals locally and reconciles in §5 step 2 | **PASS** |
| Recovery with duplicate/conflicting events | §5 steps 1–3 route duplicates to D-B3 §3.3 (exact-layer auto-link) and conflicts to D-B4 ConflictRecords; nothing silently discarded | **PASS** |
| A10 oracle (canonical-store loss) | Maps to F2: capture continues, no state mutation, no T2+, owner notified — matches the oracle's required outcome | **PASS** |
| A15 oracle (degraded-mode action attempt) | Any C6 request in any F-row → ✖ + refusal record; matches the oracle's forbidden-outcome list | **PASS** |

## 7. Acceptance criteria — met

No external mutation or autonomous side-effecting action at any tier in any degraded mode (C6 column is ✖ in all rows); every degradation and refusal is an event (or locally journaled when the log itself is down, reconciled at §5 step 2); recovery reconciles before ordinary operation resumes (§5's ordered sequence gates the lift); kill/revoke effective in every mode (C8 column).

## 8. Falsifier / reopen condition

Reopens if any failure mode is found with **no safe capture path and no honest refusal** (then it escalates as an owner-visible availability/safety tradeoff per plan §4 B5 → D-ODP), or if any capability combination is shown to widen under composition (§4 rule violated). Not triggered: F10 is a refusal mode, not a silent-loss mode — the tradeoff already accepted in OD-3's residual-risk framing covers "capture can be refused when literally no durable store is reachable," and that boundary is now explicit rather than implied.
