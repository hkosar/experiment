# D-B13 — INT-01 Card and Owner-Package Templates

**B-item:** B13 (plan §4). **Status:** Complete. **Authority:** INT-01, EX-01..11, AUT-04; calibration precedent: the owner's recorded plain-language preference (trail 77) and `04_Owner_Decision_Package.md` as the accepted format exemplar. **Depends on:** D-B6 (dispositions render), D-B7 (bands/reason-traces render), D-B10 (queue admission classes = card classes). **Feeds:** D-ODP (uses the owner-package template), B12 (instantiation re-check).

## 1. Objective

Fix the INT-01-compliant template for every owner-facing card class and the owner-decision-package template, so every decision surface states — in plain language, on one screen — what is being decided, why now, what each option does, and what happens if nothing is chosen.

## 2. The INT-01 card template (all classes share this skeleton)

```text
[BAND] · [Partition] · [Class label in plain words]
WHAT: one sentence — the decision in owner language (no internal IDs in the headline)
WHY NOW: one sentence — trigger + why it reached you (the D-B7 reason-trace, translated)
OPTIONS: 2–4 buttons, each with a one-line consequence ("Approve — the invoice
  goes out today"; "Hold — parks in your queue, ages per policy")
IF YOU DO NOTHING: the aging/fallback behavior, stated honestly
DETAILS (tap-through): evidence refs, receipts, policy version, sensitive fields
  masked per DAT-02; raw restricted content never inline (render rules, OQ-10)
```

Class-specific required fields on top of the skeleton:

| Card class | Additions |
| --- | --- |
| T3 decision | The recommendation (marked as suggestion) + what the engine would do at each option |
| T4 consequential chain | Step list with the step-up notice (IDN-02) and the exact external effect of "approve" |
| ACT-01 uncertain outcome | What is known/unknown about the attempted action; "retry / verify manually / abandon" semantics |
| Verification exception | What was expected vs received; the external record reference |
| Policy conflict (D-B8 layer-4 residue) | The two colliding rules in plain words + "pick one / keep both and route to review" |
| **DE-R8 cap receipt** | Old cap → new cap, the evidence window summary that justified it, and the one-tap reversal path (AUT-04) |
| CAP-04 economic review | Cost vs value summary, coverage disclosure, "keep / redesign / retire" — with the protected-class note when applicable |

## 3. Owner-decision-package template

Mirrors the accepted `04_` exemplar: one screen; numbered decisions; each = *plain-language what/why/consequence + a recommendation + explicit "accept / modify / reject" language*; technical backing linked, never inline; a final "what your approval does NOT cover" line (the §9 discipline). This is the template D-ODP instantiates.

## 4. Tests — executed (instantiated example cards)

**Reproduction record (P2A-13):** procedure = instantiate each card class from a fixture case and check every skeleton + class field renders from recorded data only; inputs = fixture set (`03F_`, SHA-256 `77efff5c051c4c31ddbe8768d4d06027076641b923704d8b28483216d8fcb784`); B12 re-checks. Coverage limit: template-level; visual/UX polish is build-layer.

| Class | Instantiated from | All fields renderable from recorded data? | DAT-02 masking honored? | Verdict |
| --- | --- | --- | --- | --- |
| T3 decision | A3 (source-classification ask) | ✔ (envelope + reason-trace) | ✔ | **PASS** |
| T4 chain | S6-style consequential approval | ✔ (steps from ActionRequest chain) | ✔ (step-up notice present) | **PASS** |
| ACT-01 uncertain | T5 scenario (D-B3 §4) | ✔ (receipt state + halt reason) | ✔ | **PASS** |
| Verification exception | Check-4 walk (D-B9 §5) | ✔ (expected vs received refs) | ✔ | **PASS** |
| Policy conflict | PC-2 (D-B8 §4) | ✔ (both rules + fail-closed state) | ✔ | **PASS** |
| DE-R8 cap receipt | Test 10 contraction (D-B6 §5.2) | ✔ (old/new cap + window summary + reversal) | ✔ | **PASS** |
| CAP-04 review | D-B11 §3 synthetic case | ✔ (cost/value/coverage + protected-class note) | ✔ | **PASS** |

## 5. Acceptance criteria — met; falsifier

Every owner-facing surface class has a template meeting INT-01; DE-R8 cap changes render owner-visibly with reversal; no card class needs raw restricted content to state its decision basis (masked refs + tap-through suffice). **Falsifier/reopen:** a card class that cannot render its decision basis without raw restricted content reopens against DAT-01/02 via plan §1.4 — not triggered. Presentation *variants* (density, phrasing) remain owner-preference items and ride along in D-ODP as a taste question, not a design gate.

## P2G-03 / EX-02 additions

- **DEC-02 tap-through (every consequential decision card):** a "What would change this decision" element rendering `falsifier_status`, `falsifier_statement` (or the `unknown`/`none identified` rationale), and the review trigger — from the recorded decision fields (D-B9 P2G-03 contract), never generated at render time.
- **EX-02 Executive Desk content contract:** the Desk frame presents, per partition without interleaving (PER-02/EX-03): **recent context** (active topic checkpoints projection), **recent events** (Recent-log projection, LOG-02), **suggested next** (queue-head + disposition recommendations projection), and a **full summary path** (drill-through to hub views). All four are named projections over canonical state (D-B9) — presentation-layer rendering of these projections is the deferred Discord-implementation surface (plan §12); the *content contract* is fixed here.
