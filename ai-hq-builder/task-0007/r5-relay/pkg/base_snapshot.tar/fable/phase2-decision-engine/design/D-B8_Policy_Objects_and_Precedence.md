# D-B8 — Policy Objects and Precedence (DE-R6)

**B-item:** B8 (plan §4). **Status:** Complete (recommendation recorded; final selection is a design-gate record item per plan §6/§9 — see §6 below). **Authority:** proposed DE-R6 (verbatim, plan §5); AUT-06, GOV-02, MEM-09. **Depends on:** D-B2 (control-field authority — policy inputs are §2.1 fields); the four precedence alternatives carried from discovery (OQ-06, de-canonized per P2D-10). **Feeds:** B6 (the policy function evaluates these objects), B7 (OD-1 encoded as these objects), B3 (dedup thresholds are these objects), B9 (PolicyVersionEvents), B12 (re-execution), B13 (owner-visible consequence flagged to the owner package).

## 1. Objective

Fix the policy-object type with every DE-R6-required attribute, compare the four carried precedence alternatives with dedicated replay cases, and produce the evidence-cited recommendation for the design-gate selection — including the floor-protection and exceptions-only-where-permitted semantics that P2A-07 required.

## 2. Policy-object schema (DE-R6 attribute-complete)

| Attribute | Type/semantics | DE-R6 clause served |
| --- | --- | --- |
| `policy_id`, `version` | Stable ID + monotonic version; immutable once committed | versioned typed objects |
| `scope` | Domain partition (Business/Personal — PER-02), source classes, action classes covered | scope |
| `authority_domain` | Which authority plane the policy speaks for: `protection` / `routing` / `autonomy` / `attention` / `calibration` | authority domain |
| `priority` | Explicit integer within its authority domain; no implicit recency/specificity ordering (the withdrawn OQ-06 algorithm stays withdrawn) | explicit priority |
| `applicability_predicate` | Deterministic predicate over D-B2 §2.1 control fields + derived fields only — never over model-proposed fields | applicability predicate |
| `effective_window` | Start/end instants; evaluation checks the window against the pinned evaluation basis | effective window |
| `conflict_behavior` | What this policy asserts when it collides: `defer` / `insist` / `fail-closed` | conflict behavior |
| `protection_floor` | Boolean + floor class (`safety` / `security` / `legal` / `audit` / `resilience`); floor policies are **non-overridable** and align with the CAP-04/P2A-14 protected-class list | non-overridable protection floors |
| `exception_authority` | `none` or `owner-with-step-up` — present **only where exceptions are permitted** (AUT-06); structurally `none` on every floor policy | exception authority only where permitted |
| `supersession_target` | For exception policies: the exact `(policy_id, version)` superseded; **a floor policy is not a legal target** (schema-level constraint) | explicit supersession target |
| `schema_compat` | Envelope/record schema versions this policy evaluates against | schema compatibility |
| `rollback_pointer` | Prior version to restore; rollback changes **future** evaluation only — prior decisions/receipts remain historical facts requiring separate reconciliation | rollback pointer + DE-R6 rollback semantics |

**Change path:** exclusively governed PolicyVersionEvents (Boundary 3, D-B4 §2.3 — total-ordered). **Replay basis:** a policy decision replays from the complete recorded basis per DE-R6 (normalized input record; identity/trust/data/verification envelope; canonical state + checkpoint versions; the complete applicable policy set + versions; policy-function/schema/calibration versions; recorded model outputs). The D-B2 §5 calibration-state gap feeds B9's resolution of where calibration versions live; this schema reserves `calibration_version` in the evaluation-basis record either way.

## 3. The four carried alternatives (pure forms)

- **ALT-1 — Explicit priority + authority domain:** order = authority-domain class, then explicit priority; highest wins.
- **ALT-2 — Deny/safety-floor precedence:** floor policies evaluate first and cannot be outranked by anything; non-floor conflicts then resolve by priority.
- **ALT-3 — Equal-priority fail-closed:** any conflict not strictly resolved by the ordering fails closed (no-action / T3 escalation), never "pick one arbitrarily."
- **ALT-4 — Owner-scoped exception with supersession target:** exceptions are first-class policies naming exactly what they supersede; resolution treats a valid exception as outranking its named target only.

## 4. Dedicated precedence replay cases — executed against all four alternatives

**Reproduction record (P2A-13):** procedure = each case evaluated under each pure alternative's resolution rule as a deterministic line-cited trace (non-executable analysis form, plan §4); inputs = the six case definitions below over §2's schema; expected outcome per DE-R6/AUT-06/accepted protections; B12 re-executes the winning model's cases against the assembled design. Coverage limit: pure-form evaluation isolates each mechanism's failure mode; the composite (§5) is then tested against the full set.

| Case | Setup | ALT-1 | ALT-2 | ALT-3 | ALT-4 | Required-safe outcome |
| --- | --- | --- | --- | --- | --- | --- |
| **PC-1** Priority conflict | Domain-specific stricter filing policy (priority 80) vs. general filing policy (priority 20), same authority domain | Stricter wins ✔ | Stricter wins ✔ (no floor involved) | Resolved by priority, no tie ✔ | No exception involved ✔ | Stricter/higher-priority governs |
| **PC-2** Equal-priority contradiction | Two priority-50 routing policies yield contradictory dispositions for one input | **Unresolved — no tie rule; pure ALT-1 must invent one (arbitrary pick = replay-fragile)** ✖ | Same gap as ALT-1 ✖ | **Fail-closed → no-action + T3 escalation ✔** | No exception involved — same gap ✖ | Fail closed, never arbitrary |
| **PC-3** Exception vs. protection floor | Owner exception attempts to supersede the external-untrusted quarantine floor | Priority alone could let a high-priority exception outrank the floor ✖ | **Floor holds — cannot be outranked ✔** | Not a tie — no help ✖ | **Structurally prevented: floor is not a legal supersession target ✔** | Floor holds (P2A-07/DE-R6) |
| **PC-4** Effective-window edge | An expired policy remains in a cached applicable set | All four: window check against the pinned evaluation basis excludes it before ordering runs — this is a §2 schema property, not a precedence property ✔✔✔✔ | | | | Expired policy inert |
| **PC-5** Rollback semantics | Policy v3 rolled back to v2; decisions were made under v3 | All four: rollback pointer restores v2 for future evaluations; v3 decisions remain historical; reconciliation flags v3-made decisions per D-B4 §2.3's stricter-now rule ✔✔✔✔ (schema property) | | | | Future changes only; history intact |
| **PC-6** Exception where none permitted | Exception attempt against a policy with `exception_authority = none` | ALT-1/2/3: nothing blocks authoring the exception; it must lose at evaluation — weaker, later protection ✖ | | | **Rejected at authoring: no legal supersession path ✔** | Structurally rejected (AUT-06) |

**Findings:** no pure alternative passes all six. ALT-1 alone is unsafe (PC-2, PC-3, PC-6). ALT-2 alone lacks a tie answer (PC-2). ALT-3 alone has no ordering for the ordinary case (it only says what to do at ties). ALT-4 alone governs only exceptions. The four are **complementary mechanisms, not competitors** — which is itself the material design finding of this comparison.

## 5. Recommendation: the layered composite (evidence-cited)

Resolution order for any applicable-policy set (after PC-4's window filtering):

1. **Floors first (ALT-2):** applicable floor policies apply unconditionally; nothing outranks them.
2. **Valid exceptions (ALT-4):** an exception with a legal supersession target displaces exactly its named target version — floors are never legal targets (schema-enforced), exceptions exist only where `exception_authority` permits (PC-6 rejected at authoring time).
3. **Ordering (ALT-1):** explicit priority — **applied only to same-output contradictions within one authority domain** per the P2G-10 correction section (authoritative). *(SUPERSEDED per P2S-02: the earlier global "authority domain class, then explicit priority" winner-take-all reading — cross-domain ordering does not exist; constraints compose per governed output.)*
4. **Residue (ALT-3):** any conflict still unresolved fails closed — no-action result with an explicit reason, escalated per the OQ-07 admission contract (policy conflicts are queue-admissible items).

Re-run of all six cases against the composite: PC-1 ✔ (layer 3), PC-2 ✔ (layer 4), PC-3 ✔ (layers 1+2), PC-4 ✔ (pre-filter), PC-5 ✔ (schema), PC-6 ✔ (authoring-time rejection). **6/6 — no case reaches an arbitrary or unsafe outcome.**

## 6. Selection status and owner visibility (plan §6/§9 discipline)

This artifact records the composite as the **evidence-cited recommendation**; the **selection** is made at the design gate in `D-GS_Design_Gate_Summary_and_Selection_Record.md` after verifier review, per plan §4 B8 ("Decision owner: design gate; owner package if owner-visible"). The composite **is owner-visible** in one respect and is therefore flagged to `D-ODP`: its lived consequence is — *"your exceptions always work where exceptions are allowed, but nothing — including you in the moment — can override a safety/security/legal/audit floor without changing the floor itself through the governed change process; and when two rules genuinely tie, the system stops and asks rather than guessing."* That is a behavioral promise Hunter should see and confirm once, not discover in operation. (It also matches what he already accepted in AUT-06 and the OD-3 protections — this is a confirm-not-decide item, and it is consistent with P2A-09's bounding of "owner override absolute.")

## 7. Acceptance criteria — met

Precedence model recommended (not prematurely selected) on cited traces; protection floors non-overridable in every alternative's traces and in the composite; full DE-R6 attribute set present in the schema; rollback-vs-history semantics fixed; full decision-basis replay defined.

## 8. Falsifier / reopen condition

Reopens if: any replay case shows a floor override surviving the composite's layers; an alternative permitting floor override would otherwise be selected (survives only as documented elimination per plan §4 B8); or all four alternatives had failed a governance invariant (→ §1.4 escalation — did not occur). Not triggered.

## P2G-10 correction — cross-domain composition semantics (winner-take-all withdrawn)

**The layered composite resolved conflicts but wrongly implied one winner across domains; simultaneous non-conflicting policies must ALL apply.** Corrected model:

### Constraint-composition rules

Each policy emits **constraints on named governed outputs** (tier ceiling, action authorization, attention band bounds, render class, queue admission, data-lifecycle rule). Resolution is **per governed output**, not per policy:

1. **Floors intersect:** all applicable protection floors apply simultaneously; the most restrictive value per output stands; floors are non-overridable (unchanged).
2. **Independent constraints conjoin:** policies constraining different outputs (or different fields of one action) all apply — nothing is discarded for losing a priority contest it was never in.
3. **Ceilings combine by minimum:** when several policies bound the same authority ceiling, the lowest bound wins — automatically, without priority.
4. **Priority resolves only same-output contradictions within one authority domain** — the only place ordering exists.
5. **Cross-domain contradiction is structurally excluded by output ownership:** each governed output has exactly one owning domain (routing owns tier recommendation; autonomy owns action authorization; attention owns bands; data owns render/lifecycle) — and **protection is the only cross-domain writer, restrict-only**. A non-protection policy cannot write another domain's output at all, so no cross-domain priority ordering is needed — this answers the undefined-ordering gap by removing the need, not by inventing a hierarchy.
6. **Exceptions replace only their named target and fields** within legal scope (unchanged); **equal-priority same-domain same-output contradictions fail closed** (unchanged).

### Cross-domain replay cases (deterministic simulation)

| Case | Setup | Expected / Result |
| --- | --- | --- |
| PC-7 | Routing policy (tier rec), render policy (mask class), autonomy policy (cap) all apply to one input | All three constraints land; none discarded — **PASS** (rule 2) |
| PC-8 | Two policies constrain different fields of one action (target allowlist vs. volume cap) | Conjunction; both enforced — **PASS** |
| PC-9 | Two floors touch one output (quarantine + render-mask) | Intersection; most restrictive per field — **PASS** (rule 1) |
| PC-10 | Autonomy policy attempts to widen a render class | Refused structurally: render is data-domain-owned; autonomy cannot write it — **PASS** (rule 5) |
| PC-11 | Exception supersedes its named routing target | Only that target/fields replaced; render + cap constraints stand — **PASS** (rule 6) |
| PC-12 | Equal-priority routing policies contradict on tier rec | Fail closed → T3 with reason — **PASS** |

**Acceptance condition met in design:** applying an autonomy policy cannot discard an applicable data-rendering or security policy (PC-7/PC-10); independent constraints compose deterministically (order-free: intersection/min/conjunction are commutative). Machine re-execution of PC-1..PC-12 travels with the P2G-02 trace set. The composite selection remains **not accepted** until the scoped re-review.
