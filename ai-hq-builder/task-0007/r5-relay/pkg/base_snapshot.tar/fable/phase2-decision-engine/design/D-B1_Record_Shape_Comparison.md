# D-B1 — Record-Shape Comparison (rebuilt per P2G-04; scorecard withdrawn)

**Status:** The prior version's scored comparison (S2=18/S1=17/S3=13) and its near-tie outcome are **withdrawn** — P2G-04 showed the scores unsupported or mismeasured (criterion 7 named capture latency but scored read-back; criteria 8–10 assigned shape-specific quality without candidate-specific evidence or a frozen counting method). Under the preregistered missing-evidence rule those criteria score zero and **no total may drive selection**. This rebuild is the two-stage comparison the verifier required. **S1, S2, and S3 all remain viable; S2 remains a leading architectural hypothesis only; no total score exists; no owner item exists** (the former ODG-3 stays withdrawn).

## Stage 1 — Design invariants (all shapes must satisfy; machine-checked where the corpus supports it)

**Evidence status (P2S-01):** *SUPERSEDED — the stage-1 "machine-checked" claims below rested on the circular trace/fold scripts and are suspended; the corpus-recorded per-shape results and structural arguments stand at their honest classes; the P2S-01 behavioral simulator re-executes this stage.* Original text: `traces/shape_traces.json` — 81 machine-readable candidate-specific traces (27 frozen fixtures × 3 shapes, P2G-02 field set) generated from the verifier-confirmed corpus (`03F_`, SHA-256 `77efff5c…8dfc784`), checked by `traces/run_fold_comparison.py`:

```text
PASS: 81 traces, 27 fixtures, 0 divergences
verdict counts reconcile the frozen 03R report exactly: 23 full / 3 conditional / 1 pending (E2E-1)
forbidden-outcome scan: no realized self-certified execution, default-to-trusted,
  silent merge/drop, or cross-partition interleave in any shape's transitions
cross-shape equivalence: for every fixture, S1/S3 route/attention/authority
  outcomes are identical to S2's — storage differs, authority never does
```

| Invariant | Result across S1/S2/S3 | Evidence class |
| --- | --- | --- |
| Identity/dedup (DE-R1 set) | Shape-blind by construction (intake-level, D-B3) | Structural + trace corpus |
| Evidence authority (check 4) | No executed/verified state without an external receipt reference in any of the 81 executed combinations; per-evidence-event receipt-authorship enforcement | Executed (behavioral simulator, fold + judge) |
| Concurrency (DE-R2 boundaries) | Boundaries are shape-neutral (D-B4); A6 rides as one of the 3 recorded conditional cases | Deterministic simulation |
| Replay/protection | Cross-shape authority equivalence executed behaviorally on all 27 fixtures × 3 shapes — authority/policy outputs shape-invariant while storage/projection divergences are computed per shape (TASK-0003 simulator; `traces/behavioral/out/results.json`, `divergences.json`) | Executed (behavioral simulator) |
| Binding-requirement compliance | No `13M_` Binding row is shape-dependent (D-B14 isolates shape variance) | Structural/schema |

**Stage-1 outcome: all three shapes satisfy the invariants on the frozen corpus. No elimination.** The three conditional cases and E2E-1's pending status are the corpus's own recorded qualifiers, reproduced — not resolved away.

## Stage 2 — Measured/countable tradeoffs (units predeclared; measurement at build; NO scoring now)

Per P2G-04, each criterion gets an exact unit and method **before** any measurement; until qualifying evidence exists, no shape receives a number:

| Tradeoff | Exact unit | Method / evidence source | When measurable |
| --- | --- | --- | --- |
| Interactive case-read/render latency (the renamed former criterion 7 — capture latency is shape-identical by design and drops out) | ms, p50/p95, per fixture-derived case view | Normalized prototype per shape on identical hardware/data | Build gate (the named tie-breaker) |
| Recovery workload after degradation | Count of recovery steps + rebuild operations per D-B5 failure mode | Instrumented recovery drill per shape | Build gate |
| Owner-visible staleness | Occurrences of stale-read exposure per fixture-derived Desk session | Rendered candidate prototypes compared under identical event streams | Build gate |
| Structural component census | Count of distinct maintained mechanisms per shape, counted from the D-B14 schema object list under a frozen counting rule (one point per store/projection/maintenance process the shape uniquely requires) | Countable now; counting rule frozen here **before** counting; the count itself is deferred to the corrected-packet review so the rule freezes first | Scoped re-review |
| Portability | Boolean per provider-class (document store / relational / event store) | Schema mapping exercise per D-B14 conceptual types | Scoped re-review |

**Selection rule:** selection (or explicit deferral) happens only when stage-2 evidence exists at the declared units, under the plan §6 preregistration discipline (changes by §1.4 amendment only). Until then the honest state is: **three viable shapes, one leading hypothesis, a frozen measurement plan, and a named build-gate tie-breaker.**

## Reproduction record (P2T-04 consolidation — the prior record naming the withdrawn circular comparator is retired; this replaces it)

Inputs: `03F_` (hash above) + `design/traces/behavioral/` (the TASK-0003 behavioral simulator; deterministic, no clock/randomness). Procedure: `cd design/traces/behavioral && python3 run_gate.py` — two consecutive runs must reproduce byte-identically across all outputs. Coverage limits (stated, standing): the simulator's rule tables share the design corpus as a common ancestor with the fixtures, so discriminating power beyond this corpus is untested; authority/policy outputs are shape-invariant by construction while genuine per-shape divergence appears in storage layout and projection mechanics; runtime measurements remain the build-gate tie-breaker. Falsifier: the seeded-defect and mutation catalogues — every predicate and judge check carries a shipped witness proving it can fail; any shape computing a different tier/ceiling/attention is reported as an authority-divergence.
