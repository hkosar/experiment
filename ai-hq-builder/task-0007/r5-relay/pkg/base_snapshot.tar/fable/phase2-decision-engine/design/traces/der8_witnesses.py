#!/usr/bin/env python3
"""P2G-09: machine-reproducible DE-R8 expansion/contraction witnesses.

Interval method (predefined): exact ONE-SIDED upper 95% Clopper-Pearson
bound on the pooled bad-outcome rate — the largest p is rejected when
BinomCDF(x; n, p) < alpha; UB solves BinomCDF(x; n, UB) = alpha (=0.05).
For x=0 this closes to UB = 1 - alpha**(1/n).
Outcome semantics: an action counts at most once at worst severity among
{failure, reversal, correction}; excluded actions (duplicate, owner-accepted-
unverified, disputed, degraded-telemetry, untrusted-evidence) leave both
numerator and denominator. Maturity: an outcome is mature 7 days after the
action with no correction/reversal; evaluation window: 28 rolling days of
mature actions. Expansion rule: UB < 2.0% AND n >= 149 (the smallest n where
a perfect record clears 2%) AND cooldown (14 d) elapsed => step = +20% of
current cap (floor rounding), never above the owner hard max (flagged 100/d),
never across scope keys. Contraction rule: 14-day regression check — UB > 4%
or any Critical-class failure => contract to prior cap + freeze.
Deterministic; no clock, no randomness. Run: python3 der8_witnesses.py
"""
import json


def binom_cdf(x, n, p):
    # sum_{k=0..x} C(n,k) p^k (1-p)^(n-k), computed stably in log space
    from math import lgamma, exp, log
    if p <= 0:
        return 1.0
    if p >= 1:
        return 0.0 if x < n else 1.0
    s = 0.0
    for k in range(0, x + 1):
        lg = (lgamma(n + 1) - lgamma(k + 1) - lgamma(n - k + 1)
              + k * log(p) + (n - k) * log(1 - p))
        s += exp(lg)
    return min(s, 1.0)


def cp_upper_one_sided(x, n, alpha=0.05):
    if x >= n:
        return 1.0
    if x == 0:
        return 1.0 - alpha ** (1.0 / n)
    lo, hi = x / n, 1.0
    for _ in range(200):
        mid = (lo + hi) / 2
        if binom_cdf(x, n, mid) > alpha:
            lo = mid
        else:
            hi = mid
    return (lo + hi) / 2


def n_min(threshold=0.02, alpha=0.05):
    n = 1
    while cp_upper_one_sided(0, n) >= threshold:
        n += 1
    return n


def evaluate(n_mature, x_bad, current_cap, cooldown_ok, critical_failure=False,
             threshold=0.02, contract_threshold=0.04, hard_max=100):
    ub = cp_upper_one_sided(x_bad, n_mature)
    nm = n_min(threshold)
    if critical_failure or ub > contract_threshold:
        return {"ub": ub, "n_min": nm, "decision": "CONTRACT+FREEZE",
                "new_cap": None, "reason": "regression threshold crossed"}
    if ub < threshold and n_mature >= nm and cooldown_ok:
        new_cap = min(int(current_cap * 1.2), hard_max)
        return {"ub": ub, "n_min": nm, "decision": "EXPAND",
                "new_cap": new_cap, "reason": f"UB {ub:.4%} < {threshold:.1%}, n {n_mature} >= {nm}"}
    return {"ub": ub, "n_min": nm, "decision": "HOLD", "new_cap": None,
            "reason": f"UB {ub:.4%} vs {threshold:.1%}, n {n_mature} (min {nm}), cooldown_ok={cooldown_ok}"}


def main():
    witnesses = {
        "method": "exact one-sided upper 95% Clopper-Pearson; see module docstring for all semantics",
        "n_min_perfect_record": n_min(),
        "positive_witness_first_expansion": {
            "setup": "cap 20/day, 28-day window, 7-day maturity => up to 21*20=420 mature actions; 0 bad outcomes; cooldown elapsed",
            "result": evaluate(420, 0, 20, True),
        },
        "feasibility_note_old_params": {
            "setup": "the FAILED Rev-2 parameters: 14-day window, 7-day maturity => ~140 mature; 0 bad",
            "result": evaluate(140, 0, 20, True),
            "meaning": "reproduces P2G-09: first expansion mathematically unreachable under the old window",
        },
        "negative_witness": {
            "setup": "300 mature, 9 bad (3.0% point rate)",
            "result": evaluate(300, 9, 20, True),
        },
        "contraction_witness": {
            "setup": "14-day regression check: 200 mature, 12 bad (6.0%)",
            "result": evaluate(200, 12, 24, True),
        },
        "critical_failure_witness": {
            "setup": "any Critical-class failure regardless of rate (n=400, x=1, critical)",
            "result": evaluate(400, 1, 24, True, critical_failure=True),
        },
        "hard_max_witness": {
            "setup": "cap 90, perfect record 420/0 => step to 108 capped at owner hard max 100",
            "result": evaluate(420, 0, 90, True),
        },
        "delayed_correction_rule": "a matured action corrected within 90 days re-enters the current window as a bad outcome (re-evaluation event); if the active cap was expanded on since-invalidated evidence, automatic contraction applies",
        "action_class_taxonomy": "one authorized class 'filing-routing' with scope keys {email-filing, doc-filing, note-routing}; caps and evidence pools are per (class, scope_key); cross-scope pooling prohibited (the cross-category test is a cross-scope-key contamination test)",
    }
    out = json.dumps(witnesses, indent=2)
    with open("der8_witnesses.json", "w") as f:
        f.write(out + "\n")
    print(out)


if __name__ == "__main__":
    main()
