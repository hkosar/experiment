# D-B12 — Design-Gate Test Report (rebuilt per P2G-02; honest evidence classes)

**Status:** **The design gate is NOT PASSED** — the verifier's review (`17_`, FAIL, P2G-01..14) is controlling; this rebuild replaces the prior report whose blanket PASS claims and completion counts were overclaimed. **Evidence-class vocabulary (used on every result below, per P2G-02):**

> **CURRENT STATUS SURFACE (P2U-04 consolidation, 2026-07-30):** the ONLY live status sources are `13G_Design_Gate_Status_and_Evidence_Matrix.md` (row statuses + rows-derived summary), `13F_Open_Findings.json` (open findings), and `13V_validate_design_matrix.py` output. Every dated section below is a HISTORICAL snapshot — superseded where later events changed the state — retained as record, not as status. As of this consolidation: 4 rows Incomplete under open P2T/P2U findings; `13V_ --final-gate` FAILS; the design-gate verdict is the verifier's standing FAIL.


- **[A] Analysis** — line-cited reasoning over committed artifacts; weakest class; never sufficient where the plan requires execution.
- **[S] Structural proof** — a property that holds by construction of the design (e.g., a field that cannot be model-written); strong for invariants, silent on behavior.
- **[M] Machine-checked (structural)** — scripted checks over frozen data (e.g., `03V_` envelope validation, `13V_` matrix structure); proves structure, not semantics.
- **[X] Executed trace** — machine-readable candidate-specific transition evidence, independently re-runnable. **Required by the approved plan for B1/B9/B12; NOT YET PRODUCED — the P2G-02 Path A trace set is an open correction item.**

## 1. The checks — honest current state

| Check | Evidence now held | Class | Honest state |
| --- | --- | --- | --- |
| 1 Substitution invariance | Authority derives only from control envelope; model-free ceiling precedes proposals (D-B2 §2.1, D-B6 §2.2) | [S] | Invariant argued structurally; **[X] per-shape traces and the live two-model run outstanding** |
| 2 Policy-version causality | Identical basis ⇒ identical output; change only via PolicyVersionEvents (D-B6 §5.1) | [A]+[S] | **[X] outstanding** |
| 3 Missing-control fail-closed | A3 fixture path; mandatory-control enumeration (D-B2 §3, D-B6 §5.1) | [M] (envelope structure) + [A] (disposition) | **[X] outstanding** |
| 4 Evidence separation | No fold rule yields executed/verified state without an external receipt ID (D-B9 §5) | [S] | **[X] outstanding (fold must actually run — P2G-02/P2G-11)** |
| 5 Correction path | Non-destructive CorrectionEvent + corrections excluded from expansion evidence (D-B9, D-B3) | [A]+[S] | **[X] outstanding; DEC-02 record-level falsifier missing (P2G-03)** |
| 6 Separation falsifier | 0/27 fixture cases needed raw content for tier — per-case audit | [M] over the synthetic corpus | Synthetic result stands as [M]; **real-input run needs a redesigned sample per P2G-14 (minimized/redacted content, not metadata) + owner authorization** |
| E2E-1 | Control envelope identical regardless of normalizing model (D-B2 §2.1) | [S] | **Structural argument only — the plan requires execution; two-normalizer run outstanding (P2G-02)** |

**No check is claimed PASSED at the [X] level.** The prior report's "PASS" labels conflated [A]/[S]/[M] evidence with executed proof; that conflation is withdrawn.

## 2. Per-B-item state — regenerated from the corrected `13G_`

Authoritative per-requirement statuses live in `13G_` (currently: 35 Complete / 11 Binding invariant / 55 Incomplete / 14 Deliberately deferred / 8 Build-gate deferred / 2 N/A across the 125 accepted rows; all 8 DE-R rows Incomplete). Verifier artifact dispositions (`17_` §5) are controlling per item: B2/B3/B8/B10/B13 concur-with-modification (cores useful, named gaps open); B1/B4/B5/B6/B7/B9/B11/B14 incomplete (B4 and B7 have since received their P2G-05/P2G-07 mechanism corrections — remaining gaps tracked in `13G_`); B12 failed (this rebuild is the correction); D-GS not accepted; D-ODP blocked; D-AM blocked.

## 3. Capacity and spend record (CAP-02) — updated actuals

| Dimension | Cap | Actual | Within |
| --- | --- | --- | --- |
| Active design branches | 3 | 1 | ✔ |
| Queued TASK-0003+ Builder tasks | 2 | 1 defined, 0 issued | ✔ |
| Concurrent Builder sessions | 1 | 0 | ✔ |
| Open verifier findings / rework | 15 | **14 (P2G-01..14, all in active correction)** | ✔ (at 93% of cap — no new design work starts until the count falls) |
| Review-item aging | 14 days | 0 days (same-day dispositions) | ✔ |
| Owner decision-minutes | ≤ 30 / gate package | Owner package withdrawn pending corrections — 0 this cycle | ✔ |
| Session proxy | ≤ 12 Fable / ≤ 4 Builder | 3 Fable / 0 Builder | ✔ |

**Disposition: CONTINUE — in correction mode.** The open-findings dimension is the governing constraint: correction work proceeds; no new scope opens.

## 4. Open correction items (the honest work queue)

P2G-02 trace set + executable fold comparator · P2G-03 DEC-02 record falsifiers · P2G-04 evidence-valid shape comparison · P2G-06 kill plane + RES-01/02/03 designs · P2G-08 SCH-02 envelope + independent watchdog · P2G-09 DE-R8 statistics + witnesses · P2G-10 precedence composition · P2G-11 store-ownership matrix · P2G-12 schema completion · P2G-13 untrusted-content isolation/lifecycle · P2G-14 owner-package rebuild (after the above). Applied already: P2G-01 (matrices rebuilt from exact text, this commit), P2G-05 (authorization epochs), P2G-07 (quiet-hour rules).

## Correction-cycle completion update (P2G-01..14 applied)

**Queue state:** all fourteen corrections applied — P2G-01 (matrices from exact text, text-hash-bound), P2G-02 (81 machine-readable per-shape traces + executable fold comparator: `traces/shape_traces.json`, `traces/run_fold_comparison.py` → PASS, 0 divergences, exact 03R count reconciliation 23/3/1), P2G-03 (falsifier contract through taxonomy/schema/cards/replay), P2G-04 (scorecard withdrawn; two-stage comparison with predeclared units), P2G-05 (authorization epochs + pre-execution re-check), P2G-06 (D-KR kill plane + RES designs), P2G-07 (quiet-hour two-rule correction + ten boundary traces), P2G-08 (full envelope + independent watchdog), P2G-09 (statistics + six machine witnesses: `traces/der8_witnesses.json`), P2G-10 (per-output composition + PC-7..12), P2G-11 (store matrix + expanded basis), P2G-12 (schema gaps closed), P2G-13 (isolation/extraction/eligibility + DAT-01 lifecycle), P2G-14 (owner package rebuilt, staged for post-gate presentation).

**Check evidence after corrections (classes per `19_`):**

| Check | Evidence now | Class |
| --- | --- | --- |
| 1 Substitution invariance | Structural (authority from controls) + cross-shape authority-equivalence claim over 81 traces (label withdrawn per the P2S-01 note — the underlying comparator was circular) | Structural + (withdrawn label; see P2S-01 note) · live two-model run = build-verification pending |
| 2 Policy-version causality | Structural (event-sourced policy plane) + PC-case simulations | Structural + deterministic simulation |
| 3 Missing-control fail-closed | A3 trace in the machine corpus + mandatory-control enumeration | Machine-checked (corpus) + structural |
| 4 Evidence separation | Forbidden-outcome machine scan (no realized self-certified execution in any of 81 traces) + store-matrix ingestion rule | (withdrawn label per P2S-01 note) + structural |
| 5 Correction path | CorrectionEvent taxonomy + DEC-02 contract + simulated positive/unknown cases | Structural + deterministic simulation |
| 6 Separation falsifier | 0/27 machine audit on the synthetic corpus; real-content sample redesigned per P2G-14 and owner-gated | Machine-executed (synthetic) · real-sample = owner-gated build item |
| E2E-1 | Structural argument + recorded pending status faithfully reproduced in the trace corpus | Structural · two-normalizer execution = build-verification pending |
| DE-R8 witnesses | Six machine-executed witnesses incl. reachable first expansion and old-parameter HOLD reproduction | Machine-executed |

**Requirement rows (HISTORICAL snapshot at trail 89, SUPERSEDED — see the current status surface above):** the counts and validator states recorded here reflect that moment and were later revised (P2S, P2T, P2U cycles). **Capacity update:** 4 Fable sessions of 12; open findings 14 → 0 applied-and-awaiting-review; disposition CONTINUE to scoped re-verification. **No design-gate PASS is claimed** — that determination belongs to the verifier's scoped review of this corrected set.

## P2S-01 note (2026-07-30) — machine-evidence labels withdrawn

The "machine-executed (corpus)" labels in the completion update above rested on the circular trace/fold scripts the verifier exposed in P2S-01 (*SUPERSEDED — copies of fixture expectations verified against themselves*). Honest current classes: those rows stand at structural / corpus-recorded only. The P2S-01 behavioral simulator (real candidate transition/fold execution, computed-vs-expected comparison, full forbidden-outcome evaluation, seeded-defect falsifiers, E2E-1 two-normalizer run) is the open long-pole item; `13G_` rows depending on it are downgraded to Incomplete pending its results. The DE-R8 witnesses (`traces/der8_witnesses.json`) are unaffected — independently verified by the verifier as credible and reproducible.

## TASK-0003 closure (2026-07-30) — behavioral simulator delivered, independently verified, integrated

The P2S-01 behavioral simulator was built under TASK-0003 (Builder: Claude Opus 5) through five verification cycles (R0 FAIL → R1 → R2 → R3 → R4 → closure C1; trail entries 93–98), each independently verified by Fable with adversarial review, and ACCEPTED at trail entry 98. Evidence now held, by check:

| Check | Evidence now | Class |
| --- | --- | --- |
| 1 Substitution invariance | E2E-1 EXECUTED as a two-normalizer computation (genuinely independent normalizers; authority ceiling invariant while risk classifications differ; seeded normalizer-leak detected via the production re-derivation path) | **[X] executed** · live two-model (real LLM) run remains build-verification |
| 2 Policy-version causality | Policy/lease linearization EXECUTED — five P2S-05 traces with computed verdicts, each discriminating; authorization epochs enforced at acquisition per D-B4 §2.3 | **[X] executed** (simulator) |
| 3 Missing-control fail-closed | A1/A3/A14 fail-closed paths EXECUTED (unbound identity, unknown controls, expired SCH envelope); D-B2 §3 enumeration encoded exactly | **[X] executed** (corpus) |
| 4 Evidence separation | Receipt ownership enforced at fold and per-evidence-event (tampered-receipt masking closed at R2); executed/verified never appears without an external receipt across 81/81 | **[X] executed** |
| 5 Correction path | Correction→policy causality read from real `caused_by` edges with defect-reachable predicate | **[X] executed** (simulator) |
| 6 Separation falsifier | 0/27 synthetic audit stands; real-input sample remains owner-gated per P2G-14 | [M] synthetic · real sample owner-gated |
| E2E-1 | EXECUTED at this gate (design-level two-normalizer run per the verifier's P2S-01 requirement) | **[X] executed** · live-model run build-gate |
| Forbidden outcomes | 171 evaluations over 56 distinct predicates, 56/56 defect-reachable through computed channels, 0 NOT-EVALUABLE with the exclusion machinery live | **[X] executed** |
| expected.attention | 66/81 combinations compared (15 unmapped — expectation names no §2.1 band, reported not guessed); the comparison surfaced and fixed two real defects (S3 encoding, S9 engine) | **[X] executed** with honest coverage |
| D-B8 composition | 11/11 PC cases through the real `compose_policies`, each flipping under a composition-path defect; PC-10 floor-overwrite defect found by review and fixed at R1 | **[X] executed** (synthetic suite) |

**Stated limits (carried to the verifier, not hidden):** the harness's rule tables share the design corpus as a common ancestor with the fixtures — discriminating power beyond this corpus is untested; the D-B5 degradation rule is a conservative blanket over the per-F-row matrix (row granularity unexercised; a labeled harness self-test proves the rule load-bearing); OD-1 rule 2, D-B8 conflict_behavior/rollback/schema_compat, calibration versioning, DP-001 live latency, and 13 registered event types are declared NOT-SIMULATED; the witness-channel check is a tripwire over known channels/write forms, not a proof; the citation check's two parsers are structurally independent but not diverse. Delivery-record accuracy defects occurred at R3, R4, and C1 (each a sentence contradicting the shipped file; each caught, erratum'd on the record, functionally nil) — the durable control is the reviewer diff, per the Builder's own falsifier: "my assurance on record-vs-code is worth less than your diff."

**Requirement rows (HISTORICAL snapshot at trail 98, SUPERSEDED — see the current status surface above):** the counts and validator states recorded here reflect that moment; four rows were later downgraded under open P2T findings and `--final-gate` correctly FAILS. **No design-gate PASS is claimed** — the FAIL verdict of `20_` stands until the verifier's scoped re-verification changes it.
