# D-B14 — Operational Database Schema, First Cut (schema only)

**B-item:** B14 (plan §4). **Status:** Complete (schema only — no runtime build; any executable validation is TASK-0003+). **Authority:** MEM-01..09, ONB-01, PLAT-02/04, LOG-01/02, CAP-03 (P2A-14); proposed DE-R7 cross-store mechanics; bootstrap-registry migration contract. **Depends on:** D-B3 (identities), D-B4 (boundaries), D-B9 (taxonomy — this schema is its storage image). **Feeds:** the build change plan (TASK-0003+); B1 (shape-specific table variants noted, product-portable throughout).

## 1. Objective

A first-cut, product-portable schema covering every D-B9 event/record type, the D-B3 identity fields, policy versions, outbox/reconciliation structures, and provenance — proving representability, not choosing a database product (out of scope, plan §12).

## 2. Schema (logical; illustrative — **as amended by the P2G-12 correction section, which is authoritative for every field it names**; `document` below reads as `document` (conceptual type) per the P2G-12 notation rule — *SUPERSEDED notation retained only inside this illustrative block per P2S-02*)

**Conventions:** every table has a surrogate `id`, `created_at` (recorded, not wall-clock-recomputed), and where applicable the D-B3 identity columns with explicit-absence encoding (`*_absent_reason` paired columns — absence is data, per D-B3 §2). No interface layer stores authority (PLAT-02): these stores are the only authoritative homes.

> **Notation note (P2T-04 consolidation):** the schema below uses the conceptual `document` type throughout (P2G-12); the earlier product notation is fully retired from this artifact.

```text
intake_events(id, iid UNIQUE, ingest_seq, partition, origin, source_type,
  sid, sid_absent_reason, raw_ref, envelope document, received_at)
fingerprints(id, iid FK, fp_version, layer {exact|content}, value, evaluated_at)
dedup_candidates(id, iid_a FK, iid_b FK, layer, confidence_band,
  disposition {open|linked|distinct}, disposed_by_event FK NULL)
canonical_objects(id, object_type, partition, version INT,  -- CAS column (D-B4 §2.2)
  cid, cid_absent_reason, current_state document, updated_by_event FK)
events(id, event_type, iid NULL, object_id NULL, caused_by FK NULL,
  ingest_seq, basis document {policy_version, schema_version, function_version,
  calibration_version}, payload document, appended_at)          -- append-only (LOG-01)
model_outputs(id, event_id FK, model_id, model_version, context_ref,
  output document, recorded_at)                                  -- recorded, never regenerated
policy_objects(id, policy_id, version, authority_domain, priority, scope document,
  applicability document, effective_start, effective_end, conflict_behavior,
  protection_floor BOOL, floor_class NULL, exception_authority,
  supersession_target NULL, schema_compat, rollback_pointer NULL)  -- D-B8 §2 complete
action_requests(id, event_id FK, aik UNIQUE per attempt_epoch, action_class,
  target, params document, cap_policy_ref FK)
external_records(id, kind {execution_receipt|verification_record}, external_ref,
  content_hash, linked_action FK, received_at)               -- referenced, never authored
outbox(id, source_store, tx_ref, event_payload document, relayed_at NULL)  -- D-B9 §3
reconciliation_items(id, intent_event FK, expected document, applied document,
  residue document, status {open|resolved}, resolved_by_event FK NULL)
queue_items(id, partition, card_class, object_ref, band, priority_basis document,
  admitted_by_event FK, aging_state)                          -- per-partition (PER-02)
schedules(id, envelope_id, partition, schedule_spec, tz, last_transition_event FK)
cost_evidence(id, source, coverage_disclosed, amount, basis
  {billed|estimated|inferred}, provenance_ref, linked_events document)   -- CAP-03
id_aliases(bootstrap_id, db_id, migrated_at)                  -- MEM-04/registry contract
```

**Shape variants (B1-neutral):** S1 stores `canonical_objects.current_state` as the aggregate document; S2 as the Decision Case linking record IDs; S3 drops `current_state` to a materialized projection table rebuilt from `events`. All three sit on identical `events`/`model_outputs`/identity columns — the schema is deliberately shape-agnostic below the one column noted, which is what keeps the §6 comparison fair at the storage layer.

## 3. Coverage table (event/record type → home)

All 16 D-B9 transition classes → `events` (typed via `event_type`, payload-schema per type) with these specialized homes: model outputs → `model_outputs`; policy versions → `policy_objects` + PolicyVersionEvent row; actions → `action_requests`; external evidence → `external_records`; cost telemetry → `cost_evidence` + CostEvidenceRecord row; outbox/reconciliation → their tables. **16/16 representable; checked type-by-type against D-B9 §2's table.** Identity concepts: all five (§2 columns + absence reasons). ONB-01: capability activation state is policy-plane data (`policy_objects` with `authority_domain='autonomy'`) — grant-once/activate-staged is a data posture, not a schema change per stage.

## 4. Tests — executed (schema-level checks)

**Reproduction record (P2A-13):** procedure = coverage audit of §3 against D-B9 §2 (16/16), D-B3 §2 (5/5 identity concepts + absence), D-B8 §2 (12/12 policy attributes), CAP-03 field list (5/5), alias-migration walk (bootstrap ID → `id_aliases` → frozen registry per MEM-04); inputs = the named design artifacts at their committed content; B12 re-checks. Coverage limit: logical representability — physical DDL, indexes, and migrations are TASK-0003+ work.

| Check | Result |
| --- | --- |
| Every D-B9 event type representable | 16/16 **PASS** |
| Every D-B3 identity concept + explicit absence | 5/5 **PASS** |
| D-B8 policy-object attributes | 12/12 **PASS** |
| Outbox/partial-failure fields present | **PASS** (`outbox`, `reconciliation_items.residue`) |
| Bootstrap-ID alias migration expressible | **PASS** (`id_aliases`; registry freezes read-only per its own contract) |
| CAP-03 telemetry fields (coverage/basis/provenance/linkage) | 5/5 **PASS** |
| No authority in any interface layer | **PASS** (no Discord/UI-side table exists; render layers consume projections) |
| Product portability | **PASS** (no product-specific types; document notation = any document-capable store; CAS = one integer column) |

## 5. Acceptance criteria — met; falsifier

Coverage as audited row-by-row in the P2G-12 correction table (no unsupported completeness claim — *SUPERSEDED "100%" language removed per P2S-02*); schema product-portable via conceptual types; shape variants isolated to one clearly-marked column. **Falsifier/reopen:** a designed record with no product-portable representation escalates via plan §1.4 — not triggered.

## P2G-12 correction — completed logical schema (every named gap closed)

**Notation rule first:** the prior `document` notation was product-specific. All nested fields below are **`document` (conceptual type)** with the explicit portability constraint: representable in any store offering nested documents *or* normalized side tables; no product is selected (plan §12).

### Named gap closures

| Gap (P2G-12) | Closure |
| --- | --- |
| `action_requests.attempt_epoch` missing | Added: `attempt_epoch` (monotonic per action contract); `aik` uniqueness = `(action_class, target_hash, params_hash, correlation_ref, attempt_epoch)` — plus the P2G-05 authorization fields (`authorization_policy_epoch`, `authorization_expires_at`, `revoked_by_policy_event`) and `preconditions` (document) per ACT-01 |
| `events.ingest_seq` unpartitioned | Logical uniqueness/order contract is `(intake_partition, ingest_seq)`; cross-partition order deliberately undefined (D-B4 §5) |
| `caused_by` singular | `caused_by[]` — multi-cause list of event refs (fold-backs, multi-input decisions); empty list explicit |
| DEC-02 fields absent | Decision records/events carry the full P2G-03 falsifier block (`falsifier_status/statement/evidence_refs[]/review_trigger/rationale/last_evaluated_at`) |
| LOG-01 identity detail absent | Every event: `actor_identity` (true actor: owner/engine-component/delegate), `session_id`, `component_id`, `component_version`; tool calls/outbound/writes/deploys additionally carry `tool_call detail` (tool, args hash, target, result ref) — the full LOG-01 event-kind list maps to typed events in D-B9 |
| LOG-02 enforcement unrepresented | `log_writes` restricted to the single logger service identity (writer-isolation constraint recorded in schema ownership column); tamper evidence = per-partition hash chain (`prev_event_hash` on every event); workers hold no log-write credential |
| Schedule envelope store missing | `scheduled_run_envelopes` store (full P2G-08 field set) + `expected_runs` (schedule_id, scheduled_for, deadline, run_started_ref) — `schedules.envelope_id` now resolves |
| QUE-01 fields missing | Queue items: `cap_policy_ref, batch_group, dedup_link, snooze_until, escalation_step, due_at, aging_state`; per-partition `queue_load_metrics` (counts, age distribution, throughput) |
| CAP-03 fields missing | `cost_evidence_records`: `quantity, unit, currency, amount_class (billed/estimated/inferred), provider, account, coverage_window {start,end}, missing_sources[], source_provenance, event_linkage[]` — content ingestion for cost prohibited (constraint note) |
| Policy body unrepresented | `policy.constraints[]`: per-governed-output constraint entries `{output_id, constraint_kind (floor/ceiling/requirement/replacement), value, fields[]}` — the P2G-10 composition model is now data, not prose |
| DAT-01 lifecycle unrepresented | `data_class_policies`: per class — `collection, storage, retention, model_access, rendering, redaction, notification_preview, export, deletion` rules as policy-plane objects with enforcement points named (intake, render, notify, export, delete) |
| BUS-10 registry missing | `connections_registry`: `mechanism, scope, auth_health_state, last_verified_at, owning_domain, trust_class, data_class, tool_api_version, reference_doc_pointer` — **no secret values** (constraint; secrets only in the secret manager); freshness events feed Data HQ health + AUD-03, never replacing the RES-02 watchdog |
| Learned-object lifecycle (LRN-05) | `lifecycle_state: active/inactive/archived/deleted` on preferences/rules/skills/policies; deletion never default; inactivity-review per LRN-06 |
| Checkpoint field classes (MEM-07) | Checkpoints split `protected` (owner-approved objective/commitment/scope/decisions/acceptance criteria — mutable only via Decision/fold-back events) vs `generated` (versioned, source-linked, diffable) field groups; prior versions retained; changes emit audit events |
| Org structure (ORG-01/02/03) | Nodes carry `role_type` (semantic: Domain/HQ/Initiative/Topic/Group/Task — not fixed slots), arbitrary-depth `parent_ref`, `hub_capable` flag with recorded `promotion_rule`, and `categories[]` orthogonal to the WF-03 state dimensions |
| WF state dimensions (WF-01/02/03/07/08) | Canonical independent dimensions on stateful records: `stage` (free transitions incl. skip/repeat/backward — WF-02), `work_status`, `attention`, `focus` (+ derived health); `pause_state {return_context, impact_refs}` for WF-07 |
| Completion modes (AUT-09) | `completion_mode: verified / owner_accepted / needs_review` on closeout/verification linkage |
| Worker sessions (MEM-06) | `worker_sessions`: identity, heartbeat_at, journal_ref, last_confirmed_side_effect |

**Coverage audit (no "100%" language):** every P2G-12-named field/behavior above maps to a record, constraint, actor, or typed event; remaining deliberately-unrepresented items are exactly the plan-deferred surfaces (memory-provider internals per ADR-021; subsystem stores for BUS-02/03; product-physical schema at build). The audit table is re-checkable row-by-row against the exact requirement texts via the `13M_`/`13G_` hashes.

**IDN-02 per-class step-up representation:** consequential action classes carry a `step_up_required` requirement-kind constraint in the policy `constraints[]` model (protection domain, restrict-only, non-overridable where floor-flagged); routine classes carry none — one-tap stays one-tap. The executor's pre-execution check (D-B4 §2.3) enforces it alongside epoch and kill-flag: an unsatisfied step-up requirement fails the authorization CAS.
