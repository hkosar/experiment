#!/usr/bin/env python3
"""P2G-02 Path A: machine-readable candidate-specific traces for all 27 frozen
fixtures x 3 record shapes (S1/S2/S3), from the verifier-confirmed fixture set.

Evidence class: DETERMINISTIC SIMULATION over the frozen synthetic corpus.
The per-shape transition sequences derive mechanically from each fixture's
recorded common transition skeleton (trace_S2) plus its recorded per-shape
storage/projection deltas (delta_S1/delta_S3) — the P2D-03 normalization made
the three shapes equal-capability on one skeleton, so shape variance is
storage/projection annotation, not behavior. The runtime fold harness remains
TASK-0003+ (build-verification). Output: shape_traces.json.
Deterministic: no clock, no randomness. Run: python3 gen_shape_traces.py
"""
import hashlib
import json

FIXTURES = "../../03F_Replay_Fixtures.json"


def main():
    raw = open(FIXTURES, "rb").read()
    fixtures_sha = hashlib.sha256(raw).hexdigest()
    data = json.loads(raw)
    traces = []
    for case in data["cases"]:
        cid = case["id"]
        skeleton = case.get("trace_S2") or []
        for shape in ("S1", "S2", "S3"):
            if shape == "S1":
                seq = list(skeleton) + [f"storage: {case.get('delta_S1', 'append-only children under one aggregate root')}"]
            elif shape == "S3":
                seq = list(skeleton) + [f"storage: {case.get('delta_S3', 'independent records; materialized projection')}"]
            else:
                seq = list(skeleton) + ["storage: Decision Case linking separately-owned typed records"]
            trace = {
                "fixture_id": cid,
                "candidate_shape": shape,
                "starting_state_and_versions": {
                    "start_state": case.get("start_state", "—"),
                    "policy": case.get("policy", ""),
                },
                "ordered_transition_sequence": seq,
                "produced_records_events": [s for s in skeleton if s],
                "expected_output": case.get("expected", {}),
                "actual_output": case.get("actual", {}).get(shape, ""),
                "forbidden_outcomes_checked": case.get("forbidden", []),
                "evidence_hashes": {"fixture_set_sha256": fixtures_sha},
                "verdict": case.get("actual", {}).get(shape, ""),
                "pass_rule": case.get("pass_rule", ""),
                "case_verdict": case.get("verdict", ""),
            }
            traces.append(trace)
    out = {
        "standard": "P2G-02 trace field set",
        "evidence_class": "deterministic simulation over the frozen synthetic corpus (runtime fold = build-verification pending, TASK-0003+)",
        "fixture_set_sha256": fixtures_sha,
        "trace_count": len(traces),
        "traces": traces,
    }
    with open("shape_traces.json", "w") as f:
        json.dump(out, f, indent=1)
        f.write("\n")
    print(f"wrote shape_traces.json: {len(traces)} traces ({len(data['cases'])} fixtures x 3 shapes); fixture sha {fixtures_sha[:16]}...")


if __name__ == "__main__":
    main()
