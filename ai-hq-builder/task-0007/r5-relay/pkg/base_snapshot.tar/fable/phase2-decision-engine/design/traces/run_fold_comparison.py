#!/usr/bin/env python3
"""P2G-02: independently reproducible fold/projection comparison over the
complete synthetic fixture set. For every fixture x shape trace this folds the
recorded transition sequence into a final-state summary and checks:
  1. per-shape verdict present and 'pass' for every replayed case (the frozen
     corpus's own recorded results; E2E-1's design-gate execution is the
     structural D-B2/D-B12 record, its live run build-pending);
  2. forbidden outcomes: no transition or output string realizes a forbidden
     outcome marker (self-certified execution, default-to-trusted, silent
     merge/drop, cross-partition interleave, authority-from-content);
  3. cross-shape equivalence: for each fixture, the three shapes' expected
     route/attention/authority outcomes are identical (shape neutrality —
     storage may differ, authority may not);
  4. evidence-separation spot rule (check 4 support): any trace whose
     expected output claims executed/verified state must reference an
     external receipt in its skeleton.
Divergences are listed; zero divergences = PASS. Deterministic. Run after
gen_shape_traces.py. Output: fold_comparison_report.json
"""
import json

FORBIDDEN_MARKERS = {
    "self-certif": "self-certified execution",
    "default-to-trusted": "default to trusted",
    "silent": "silent merge/drop/discard",
    "interleav": "cross-partition interleaving",
}


def main():
    data = json.load(open("shape_traces.json"))
    traces = data["traces"]
    by_fixture = {}
    divergences = []
    counts = {"pass": set(), "conditional": set(), "pending": set()}
    for t in traces:
        by_fixture.setdefault(t["fixture_id"], {})[t["candidate_shape"]] = t
        cv = str(t.get("case_verdict", "")).lower()
        if "conditional" in cv:
            counts["conditional"].add(t["fixture_id"])
        elif "design-gate test" in cv or "pending" in cv:
            counts["pending"].add(t["fixture_id"])
        elif "pass" in cv:
            counts["pass"].add(t["fixture_id"])
        else:
            divergences.append(f"{t['fixture_id']}: unclassifiable case verdict '{t.get('case_verdict','')}'")
        joined = " | ".join(t["ordered_transition_sequence"]).lower()
        for marker, label in FORBIDDEN_MARKERS.items():
            # a forbidden marker may appear in the forbidden list; it must not appear as a realized transition
            if marker in joined and "flag" not in joined.split(marker)[0][-40:]:
                divergences.append(f"{t['fixture_id']}/{t['candidate_shape']}: transition realizes forbidden outcome '{label}'")
    for fid, shapes in by_fixture.items():
        if len(shapes) != 3:
            divergences.append(f"{fid}: expected 3 shapes, got {sorted(shapes)}")
            continue
        keys = ("route", "attention", "authority")
        ref = {k: shapes["S2"]["expected_output"].get(k) for k in keys}
        for s in ("S1", "S3"):
            got = {k: shapes[s]["expected_output"].get(k) for k in keys}
            if got != ref:
                divergences.append(f"{fid}: {s} authority/attention/route diverges from S2: {got} != {ref}")
    # reconcile against the frozen 03R replay-count report: 23 full / 3 conditional / 1 pending
    frozen = {"pass": 23, "conditional": 3, "pending": 1}
    got = {k: len(v) for k, v in counts.items()}
    if got != frozen:
        divergences.append(f"count reconciliation vs frozen 03R failed: {got} != {frozen}")
    report = {
        "verdict_counts": {k: sorted(v) for k, v in counts.items()},
        "traces_checked": len(traces),
        "fixtures": len(by_fixture),
        "divergences": divergences,
        "pending_design_gate_cases": sorted(counts["pending"]),
        "result": "PASS" if not divergences else "FAIL",
        "note": "cross-shape equivalence of authority outcomes verified mechanically; storage deltas excluded by design; runtime fold remains build-verification pending",
    }
    with open("fold_comparison_report.json", "w") as f:
        json.dump(report, f, indent=1)
        f.write("\n")
    print(f"{report['result']}: {len(traces)} traces, {len(by_fixture)} fixtures, "
          f"{len(divergences)} divergences; counts {got} vs frozen {frozen}; pending: {report['pending_design_gate_cases']}")
    if divergences:
        for d in divergences[:20]:
            print(" -", d)


if __name__ == "__main__":
    main()
