# D-ODP — Owner Decision Package (DECIDED — design ACCEPTED, trail 116)

**Status:** **ALL ITEMS DECIDED.** Presented trail 115; owner answers recorded trail 116 (verbatim below each item). The corrected design set passed the verifier's gate-closure review (`51_`, PASS, trail 114) with zero open findings (`13F_`) and the machine gate green (`13V_ --final-gate` PASS). The prior withdrawn package's defects (ODG-2/3/4) were corrected per the rebuild rules below before this presentation.

**Rebuild rules honored (P2G-14):** the owner receives only genuine business/experience decisions, each with consequences, residual risks, Fable's recommendation, and verifier status. Anything already fixed by accepted protection requirements is stated as fixed, never asked. Technical closure stays with Fable and the verifier.

---

## Verifier status (applies to every item)

The independent verifier passed the Decision Engine design gate after ten review packets (`51_`). Its scope qualification, quoted in substance: the PASS covers the *design*; production cryptography, live infrastructure, deployment hardening, monitoring, real-world performance, and provider specifics remain build/release concerns. Those live as 13 named obligations in `13B_Build_Gate_Obligations_Register.md` and are the build phase's entry checklist, not open defects.

## Standing residual risks (disclosed, not asked)

- **Common-ancestor limit:** the design simulator's rule tables and its test fixtures share the same design corpus; discriminating power beyond that corpus is untested until build-gate runs with real models and real data (B-1, B-2).
- **Structural, not cryptographic, separation:** authority separation is currently enforced by identifier comparison; two colluding actors (or one actor under two names) defeat it. Cryptographic attestation with trust roots is build-gate B-3 by your arbitrated ruling.
- **Caller-side bindings:** what an action *says* it is, and *which* policy artifact judges it, are executor-derived checks deferred to build (B-12, B-13, verifier-concurred routing).

---

## OD-4 — Rules-of-rules confirmation *(confirm, not decide)*

**Plain language:** the system's non-negotiable floors are **safety, resilience, security, audit, and legally required controls**. No autonomy setting, preference, or exception you grant can cross them. Your exceptions work everywhere exceptions are permitted; when two rules of the same rank truly tie, the system stops and asks you instead of guessing.
**What confirming does:** locks this ordering into the accepted design record. **Residual risk:** none new — this restates what the accepted requirements already enforce. **Recommendation:** confirm.

**Owner decision (trail 116):** CONFIRMED, as recommended.

## OD-5 — ⚑ Autonomy hard maximum + activation timing *(the one open number)*

**Plain language:** you already decided (OD-2) that automatic filing/routing starts at **20 actions/day** and grows itself only from measured evidence (DE-R8) — expansion needs 149 clean, matured, externally verified actions in a rolling 28-day window, grows at most +20% per step with cooldowns, contracts automatically on regression, and freezes when evidence is missing. All of that is designed, machine-witnessed, and not asked again. Also stated as fixed, not asked: raising a cap yourself always requires the step-up identity check (IDN-02).
**What IS asked — two values:**
1. **The hard ceiling** the automation may never grow past without a brand-new decision from you. **Designed default: ⚑ 100/day per partition.** Any number is yours to set.
2. **Activation timing:** whether cap-growth (DE-R8 expansion) is armed from first go-live, or filing/routing runs frozen at 20/day until you separately switch expansion on.
**Consequences:** a higher ceiling pre-authorizes more automation with no further contact (each step still owner-visible with one-tap reversal); a lower one means more future asks. Arming at go-live means first possible expansion after the evidence bar is genuinely met (~5+ weeks of near-perfect record at minimum); deferring keeps a hard 20/day until you act.
**Recommendation:** ratify 100/day and arm expansion at go-live — the evidence bar, contraction, and freeze rules are the real protection; the ceiling is your backstop.

**Owner decision (trail 116):** Hard ceiling set to **5,000/day** (owner's own value, after Fable explained the compounding-growth rationale for having any ceiling at all — see the exchange preceding this record). Expansion **ARMED at go-live**. Applied to `design/D-B6_` §parameter table.

## Record shape — *stated, not asked (removed item, per the corrected design)*

The internal record-storage comparison produced **no owner-visible tradeoff**: all three candidate shapes satisfy every design invariant on the executed behavioral evidence, authority outcomes are shape-invariant, and selection is governed by a frozen build-gate measurement plan (latency, recovery workload, staleness — `D-B1`). The verifier accepted this record ("accepted per governing design record"). Nothing for you here; the selection lands technically at build with the pre-frozen rule.

## OD-6 — Real-data separation test: authorization + timing *(your data, your call)*

**Plain language:** one build-gate test (B-2) needs a small sample of your **real** items to falsify the separation claim honestly — and per the corrected design it must be **minimized/redacted content** (or a content-vs-metadata comparison), because metadata alone cannot test whether content must be read. Exact handling terms: sample drawn only from sources you name, minimized/redacted before use, processed under the §8 data gate, never leaving your controlled storage, discarded after the recorded result.
**What is asked:** (1) do you authorize such a sample at build verification, and (2) from which source(s) / when — now-named or named at build time.
**Consequences:** authorizing enables the strongest form of the separation evidence; declining defers that evidence class and the claim stays design-level only (disclosed as such). **Recommendation:** authorize in principle now, name the source at build time.

**Owner decision (trail 116):** AUTHORIZED in principle. Source **not yet named** — to be specified by the owner at build verification time (B-2 in `13B_`).

## OD-7 — Card format preference *(taste, freely yours)*

**Plain language:** every decision that reaches you renders as a one-screen card: WHAT / WHY NOW / OPTIONS with one-line consequences / IF YOU DO NOTHING / tap-through details (samples: `D-B13` §2). The *structure* is fixed by accepted requirements; the **density and phrasing** are preference: **(a) Compact** (terse lines, minimal prose) or **(b) Conversational** (the D-B13 samples as written — fuller sentences).
**Recommendation:** (b) Conversational — it matches your recorded plain-language preference (trail 77); switchable later without design change.

**Owner decision (trail 116):** **(b) Conversational**, as recommended.

## OD-8 — Design acceptance *(the gate that opens build planning)*

**Plain language:** accepting the design closes the Phase-2 design stage on the record: the CP-P2-A design as corrected through ten review packets, the eight new requirements DE-R1..R8 (your cap-growth mechanism among them, formally adopted on v1.4 acceptance via the prepared amendment package `D-AM_v14_`), and the 13 build-gate obligations as the forward work statement.
**What acceptance does:** authorizes Fable to issue the v1.4-proposed build change plan (build tasks then run under new Builder task packets with the same verification discipline). **What it does not do:** touch the accepted v1.3 baseline (byte-verified unchanged through every packet), or certify production readiness (the verifier's scope qualification stands). **Recommendation:** accept.

**Owner decision (trail 116):** **ACCEPTED**, after review of plain-language example decision cards (provided in-channel per the owner's request). Design phase CLOSED. Build change plan authorized — see `52_v1.4_Proposed_Build_Change_Plan.md`.

---

**Answer format (any plain reply works):** OD-4 confirm/other · OD-5 ceiling number + arm-at-go-live yes/defer · OD-6 authorize yes/no (+ source now or at build) · OD-7 (a)/(b) · OD-8 accept/other.
