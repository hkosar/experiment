# D-B3 — Identity and Deduplication (GAP-2 closure design; DE-R1)

**B-item:** B3 (plan §4). **Status:** Complete. **Authority:** proposed DE-R1 (verbatim, plan §5); ACT-01 (shared with B9), LOG-01 (shared with B9), MEM-04. **Depends on:** D-B2 (authority classes of identity fields — `source_id`/`source_type` are administrative per D-B2 §2.2, never authority-gating); frozen fixtures `03F_` (SHA-256 `77efff5c051c4c31ddbe8768d4d06027076641b923704d8b28483216d8fcb784`); OQ-05 identity-concept separation. **Feeds:** B4 (identities anchor consistency boundaries), B6 (cid assignment is a policy-function output), B9 (event identity), B14 (schema), B12 (re-execution as gate evidence).

## 1. Objective

Close GAP-2 — the open-blocking dedup design requirement — by giving each of DE-R1's five identity concepts a concrete design with instantiate-only-when-applicable semantics, explicit absence, versioned uncertainty-aware deduplication, and the five DE-R1 acceptance tests executed as recorded design-level traces.

## 2. The five identity concepts — design

| # | Concept | Field | Instantiated when | Minting rule | Absence |
| --- | --- | --- | --- | --- | --- |
| 1 | Local ingestion ID | `iid` | **Every accepted input** — no exceptions | Minted at durable intake commit (B4 boundary 1); opaque, monotonic within intake partition; never derived from content | Never absent |
| 2 | Source-native event ID | `sid` | Source supplies one (email Message-ID, webhook event id, Discord message id) | Stored verbatim inside a namespace triple `(origin, source_type, native_id)` — native IDs are only unique within their source | Explicit `absent(source-provides-none)` — e.g., phone-call transcription, walk-in note |
| 3 | Deduplication fingerprint | `fp` | Dedup evaluation applies per the source-class dedup policy (a B8 versioned policy object, not a constant) | Versioned record `(fp_version, layer, value)` — two layers, §3 | Explicit `absent(dedup-not-evaluated)` |
| 4 | Case/correlation ID | `cid` | The input is linked to a case, topic, or multi-event activity — assigned by the B6 policy function's placement output, **not** at intake | Allocated from the ID authority (bootstrap registry pattern now; DB-minted with alias on migration, MEM-04/B14) | Explicit `absent(not-applicable-no-case)` — the routine T0/T1 no-case path |
| 5 | Action idempotency key | `aik` | One per emitted ActionRequest attempt contract | Deterministic digest over `(action_class, target, normalized_params, cid-or-iid, attempt_epoch)` — same attempt contract ⇒ same key; changed contract ⇒ new key (ACT-01) | Explicit `absent(no-action-emitted)` |

**Absence rule (DE-R1):** absence is always an explicit marker with a reason code from the closed set above — never a fabricated value, never null-without-reason. This is what keeps the routine no-case path clean (the record-pollution failure the discovery avoided).

**Version independence (DE-R1):** `iid` and `sid` are never derived from normalized content, so they are structurally independent of model and normalization versions. `fp` values may change across fingerprint versions, but every `fp` carries its `fp_version`, and cross-version values are never compared directly (§3.3) — so a normalization upgrade can never cause a false merge.

## 3. Deduplication design (uncertainty-aware, two layers)

### 3.1 Exact layer

`fp_exact = digest(origin, source_type, native_id)` — computed only when `sid` exists. An exact-layer match means the *same source event* was delivered again (webhook redelivery, IMAP re-fetch): safe to link as a confirmed duplicate automatically. The duplicate delivery is still recorded (its own `iid`, LOG-01) and linked; nothing is silently dropped.

### 3.2 Content layer

`fp_content = (fp_version, feature-set digest)` over deterministically normalized features: canonicalized sender identity; subject canonicalization (strip reply/forward prefixes, whitespace fold); body similarity shingles (locality-sensitive, threshold-compared, robust to appended footers/banners); attachment content digests. The similarity threshold is a **versioned calibration parameter carried in the dedup policy object (B8)** — not a hard-coded constant — so tuning it is a governed PolicyVersionEvent, replayable per DE-R6.

### 3.3 Match semantics (the DE-R1 uncertainty rule, made mechanical)

| Evidence | Classification | Action |
| --- | --- | --- |
| Exact-layer match | Confirmed duplicate | Auto-link to prior `iid`; record DuplicateDeliveryEvent; no case/action duplication |
| Content-layer match above threshold, **no** exact match | **Uncertain duplicate** | Create a review/link candidate record referencing both `iid`s; **both events retained and processed for capture**; merge only by explicit disposition (owner or a T1 rule the owner has ratified for that source class) |
| Content-layer near-threshold band (declared band around the threshold) | Uncertain duplicate (low confidence) | Same as above; the band exists so threshold tuning shifts *classifications*, never silently *drops* |
| No match | Distinct | Normal processing |
| Cross-`fp_version` comparison | **Structurally prohibited** | Re-fingerprint under the current version first; never compare raw values across versions |

Silent merge and silent drop are unreachable outcomes by construction: every path either retains both records or links them under an explicit, recorded disposition.

## 4. DE-R1 acceptance tests — executed (design-level recorded traces)

**Reproduction record (P2A-13):** procedure = deterministic line-cited reasoning traces against the mechanism specified in §2–§3 (non-executable analysis form, as permitted by plan §4); inputs = the scenario definitions below plus the frozen fixture set (hash in header) for cross-reference; expected/actual per test; re-execution at B12 with the full design assembled is a §7 gate obligation. No tool execution was required beyond document analysis; coverage limits stated per test.

### T1 — No false-merge of distinct legitimate identical events

- **Scenario:** a vendor deliberately sends the same invoice-reminder email twice (their process re-sends), distinct Message-IDs, byte-identical bodies.
- **Trace:** two intake events, two `iid`s (§2 row 1). `sid` differs ⇒ `fp_exact` differs (§3.1: digest includes `native_id`) ⇒ no exact match. `fp_content` matches ⇒ **uncertain duplicate** per §3.3 row 2 ⇒ review/link candidate; both retained.
- **Expected:** both events retained; linked for review; neither dropped or silently merged. **Actual (trace):** exactly that path — §3.3 row 2 is the only reachable row. **PASS.**
- **Coverage limit:** the trace proves the classification path; the *disposition UX* (how the owner resolves the candidate) is B10/B13 surface work.

### T2 — Transformed-redelivery detection

- **Scenario:** the same email re-arrives through a forwarding service — new Message-ID, `Fwd:` subject prefix, appended footer.
- **Trace:** `fp_exact` misses (new `native_id`). `fp_content`: sender canonicalization survives forwarding headers; subject canonicalization strips the `Fwd:` prefix; shingle similarity is robust to the appended footer ⇒ above-threshold match ⇒ **uncertain duplicate** candidate surfaced.
- **Expected:** flagged as a candidate — not silently merged (it *could* be a genuinely new forward with added context) and not missed. **Actual (trace):** §3.3 row 2. **PASS.**
- **Coverage limit:** robustness depends on the calibrated threshold; the threshold is policy-versioned (§3.2) precisely so a miss in practice is a governed recalibration, not a design failure. A build-gate test with real transformed samples (under the §8 data contract) is the stronger check and is noted for the build change plan.

### T3 — Routine no-case processing

- **Scenario:** a newsletter arrives; policy disposition is T0 record-only.
- **Trace:** `iid` minted; `sid` present; `fp` evaluated (newsletters are a dedup-eligible class); `cid = absent(not-applicable-no-case)`; `aik = absent(no-action-emitted)`.
- **Expected:** no fabricated case ID, no fabricated idempotency key, full record still durable and replayable. **Actual (trace):** absence markers per §2 rows 4–5. **PASS.** (This is the exact record-pollution scenario P2A-03 was written to prevent.)

### T4 — Source-without-native-ID processing

- **Scenario:** a phone-call note captured by voice; the source has no native event ID.
- **Trace:** `iid` minted; `sid = absent(source-provides-none)`; `fp_exact` not computable (declared absent, not zero-valued); `fp_content` computed; processing proceeds normally.
- **Expected:** absence explicit; no synthetic `sid` invented; dedup still functions on the content layer. **Actual (trace):** per §2 row 2 and §3.1's sid-conditional rule. **PASS.**

### T5 — One idempotency key per action attempt contract

- **Scenario:** a T2 filing action's outcome is uncertain (timeout mid-execution); later the same filing is retried; separately, a *different* filing (changed target) is issued.
- **Trace:** first attempt emits `aik₁`. Uncertain outcome ⇒ ACT-01: automatic retry halts, Needs Review raised (OQ-09). A ratified retry of the *same attempt contract* reuses `aik₁` — the external executor can recognize and deduplicate. The changed-target filing is a new contract ⇒ `aik₂`.
- **Expected:** same contract ⇒ same key; changed contract ⇒ new key; uncertain ⇒ halt not auto-retry. **Actual (trace):** the `aik` digest inputs (§2 row 5) make this deterministic: identical inputs reproduce `aik₁`; the changed `target` changes the digest. **PASS.**
- **Coverage limit:** presumes the external executor honors idempotency keys "where supported" (ACT-01's own scoping); classes without support stay T3/T4 per OQ-09 — a B6 tier-policy obligation, cross-referenced there.

### T6 (version-independence, DE-R1 closing clause)

- **Scenario:** normalization upgrades from v1 to v2 between two related events.
- **Trace:** `iid`/`sid` untouched (never content-derived). `fp` under v2 carries `fp_version=2`; §3.3 row 5 prohibits raw cross-version comparison; the earlier event is re-fingerprinted under v2 before any comparison.
- **Expected/Actual:** no cross-version false merge is reachable. **PASS.**

## 5. GAP-2 disposition

GAP-2 ("dedup design with objective acceptance tests") is **closed at design level**: the mechanism exists, its five acceptance tests pass on recorded traces, and its calibration points are governed policy objects rather than buried constants. Residual (honest): trace-level passes are necessary but weaker than executed-harness passes; B12 re-executes these tests against the assembled design, and the real-sample transformed-redelivery check is a declared build-gate obligation. This residual travels to the owner decision package only if B12 changes the result.

## 6. Acceptance criteria — met

All five DE-R1 acceptance tests (plus the version-independence clause) executed with recorded traces; absence semantics explicit in the schema (§2); no identity concept instantiated where inapplicable; uncertainty surfaces as review candidates, never silent merges/drops (§3.3).

## 7. Falsifier / reopen condition

Reopens if any legitimate stream is shown indistinguishable from a duplicate under **every** carried fingerprint design (then GAP-2 escalates to the owner package as residual risk per plan §4/B3), or if a silent-merge/silent-drop path is found reachable in §3.3. Not triggered.
