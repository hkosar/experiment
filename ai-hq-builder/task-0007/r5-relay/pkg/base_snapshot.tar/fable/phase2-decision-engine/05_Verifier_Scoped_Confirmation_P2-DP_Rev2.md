# Independent Verifier Response — Phase 2 Decision Engine Discovery Plan, Revision 2

**Review target:** `fable/phase2-decision-engine/00_Phase2_Discovery_Plan.md`  
**Target SHA-256:** `75c636801ef112f08876c17f5dde28caa0d628c838fed8d8d917c19ce3bc7c99`  
**Packet:** `P2DP_Rev2_Scoped_Confirmation_Packet.zip`  
**Packet SHA-256:** `6aee1e125958d5ad4637d291ede83c39508751955b39486bd5392106543b4064`  
**Verifier:** ChatGPT, independent auditor/reviewer  
**Gate type:** Scoped Revision 2 plan confirmation, before owner approval and discovery execution  
**Date:** 2026-07-28

---

## 1. Verdict

# **PASS WITH TWO PRE-AUTHORIZED CONTROL CORRECTIONS**

Revision 2 substantively closes **P2-01 through P2-08**. The plan is ready for owner consideration after Fable applies the two bounded corrections in §4.

No further pre-approval verifier round is required if:

1. the plan body remains byte-identical at the target SHA-256 above;
2. the corrections are limited to the source manifest, applicability matrix, their derived checksums/manifests, Git evidence, and ordinary control-plane trail/registry records;
3. the corrected packet passes the fail-closed checks in §5; and
4. no new scope, open question, authority, deliverable, or acceptance rule is introduced.

The corrections do not require Builder involvement. Fable owns them as plan/control-plane work.

---

## 2. Independent Packet Verification

### Passed

- ZIP opened successfully.
- Outer export manifest: **19 of 19 declared payload/evidence hashes passed**.
- Review-target hash matched exactly.
- Git bundle verified as a **complete history**.
- Declared gate commit independently reproduced:

```text
a7ac2e19efb288ef57108f0f7ccaa5030208e064
```

- Declared gate tree independently reproduced:

```text
508784a81e62b6d42918b997d1c673c362905bdb
```

- Revision 1 review commit is an ancestor of the gate commit.
- `rev1_to_rev2_plan.patch` is byte-identical to the independently generated Git diff.
- Original decision-trail entries **1–40** are present.
- Addendum entries **41–75** are present, contiguous, and without duplicates.
- Requirements Applicability Matrix contains:
  - 125 rows;
  - 125 unique IDs;
  - no missing or extra IDs relative to the accepted register;
  - the same ID order as the accepted register.
- Revision 2 does not claim owner approval, discovery execution, a design decision, build authorization, or a baseline change.

### Evidence defect found

The internal Discovery Source and Exclusion Manifest does not validate 100%:

```text
Source:
fable/phase1-audit-v1.0/06_Decision_Trail_Addendum.md

Declared SHA-256 inside 04_Discovery_Source_and_Exclusion_Manifest.md:
7bff3b3f293734f8c9fe85a724eb4b2e61736d26a6bd15ade767fe5070081f0a

Actual SHA-256 of the exported entries-41-through-75 file:
60c55ee0f0db610208ee90a55c64550172612012ce6f6b7b253782e470999828
```

The outer export manifest and Phase 1 checksum file carry the correct actual hash. The stale value is confined to the internal discovery-source manifest, but it prevents P2-01’s closure test and Revision 2 acceptance criterion 1 from passing as written.

---

## 3. Prior Finding Closure

| Finding | Disposition at scoped confirmation | Basis |
| --- | --- | --- |
| P2-01 — Complete authority corpus and reproducible snapshot | **Closed subject to P2-09** | Full corpus, entries 1–75, exclusions, bundle, commit/tree evidence, and stable citations are present. One internal source hash and snapshot-boundary statement require correction. |
| P2-02 — Checkable stage-gate contract | **Closed subject to P2-10** | Risk, authority scope, capacity, stop rules, eight acceptance criteria, rollback, and all 125 requirement rows are present. Matrix semantics and several obvious classifications require bounded cleanup. |
| P2-03 — No monolithic Decision-object presumption | **Closed** | Objective and OQ-01 are record-shape neutral; routine no-decision paths and independent execution evidence are mandatory candidate cases. |
| P2-04 — Full routing dimensions and policy boundary | **Closed** | OQ-02 and OQ-06 contain the required WF-09, TRS, state, policy, schema, correction, precedence, replay, and fail-closed dimensions. |
| P2-05 — Falsifiable scenario/adversarial replay | **Closed** | The oracle field set, ten owner scenarios, twelve mandatory boundary cases, and severity rule are explicit and independently checkable. |
| P2-06 — Accepted protection layer is mandatory | **Closed** | IDN/TRS/DAT/LOG/ACT/SCH/RES constraints are mandatory inputs, boundaries, failure states, evidence rules, and replay invariants. |
| P2-07 — Bounded owner input and complete post-discovery sequence | **Closed** | No-trickle default, one bounded blocking exception, MEM-09 persistence, no silent inference, Fable disposition, correction, scoped re-verification, and owner gate are present. |
| P2-08 — Traceability and ADD-compatible owner surface | **Closed** | All six required controlled deliverables are named with the required content and the role-refresh item is isolated from discovery conclusions. |

The six minimum tests for the recommendation-versus-policy hypothesis are also present and materially faithful to the prior verifier requirements.

---

## 4. New Scoped Findings and Pre-Authorized Corrections

## P2-09 — Medium — The authority snapshot is internally stale and its mutable-trail boundary is not explicit

**Affected:** `04_Discovery_Source_and_Exclusion_Manifest.md`; P2-01; Revision 2 §5.1 and §6 acceptance criterion 1  
**Problem:** The internal source manifest declares the pre-entry-75 hash for the addendum while describing entries 41–75. The decision trail is a living control-plane file, so later review and owner-approval events will continue changing the current-path file unless discovery is explicitly bound to a frozen authority snapshot.

**Required correction:**

1. Replace the stale addendum hash with:

```text
60c55ee0f0db610208ee90a55c64550172612012ce6f6b7b253782e470999828
```

2. Make the snapshot boundary explicit. The source row or manifest preamble must state substantially:

```text
Discovery authority uses the decision-trail addendum through entry 75 as it
exists at the approved plan-gate snapshot. Later plan-review, approval, and
execution-control events are not silently added to the discovery intent corpus.
A later owner-intent statement enters only through a versioned source-manifest
update or the bounded MEM-09 owner-input process defined by the plan.
```

3. Bind that snapshot to the exact Git commit/blob or export an immutable `through-entry-75` copy. Do not rely on the latest mutable path after owner approval.
4. Regenerate affected checksums, export manifest, bundle/evidence, and commit/tree declarations.

**Closure test:** every source listed inside `04_` validates 100%; the approved discovery process can identify exactly which trail snapshot is authoritative after later control-plane events are appended.

---

## P2-10 — Medium — The applicability matrix mixes “subject of discovery” with “optional to honor” and defers several active constraints

**Affected:** `03_Requirements_Applicability_Matrix.md`; P2-02; Revision 2 §6  
**Problem:** The matrix calls itself the “approved plan’s” checklist before owner approval. Its category definitions also leave uncertainty about whether an `In-scope` accepted requirement remains binding while its operationalization is explored. In addition, the blanket APP and PLAT deferrals incorrectly defer requirements that directly constrain this discovery.

**Required correction:**

1. Replace the status statement with substantially:

```text
This is the candidate initial population. It becomes the discovery execution
checklist only after owner approval. Every accepted baseline requirement remains
authoritative. “In-scope” means discovery determines how the requirement is
operationalized and interacts with other requirements; it does not authorize
ignoring or reopening its accepted outcome. “Binding constraint” means every
candidate must satisfy the requirement as an invariant. Deferred and N/A rows
require explicit rationale, and a discovered dependency must be escalated and
logged rather than silently omitted.
```

2. Reclassify, at minimum:

| ID | Corrected initial disposition | Rationale |
| --- | --- | --- |
| APP-01 | Binding constraint | Model/provider substitution invariance is an explicit core-hypothesis test. |
| APP-02 | Binding constraint | Discovery plans, decisions, reviews, and closeouts must remain durable, versioned artifacts keyed to stable IDs. |
| APP-04 | Binding constraint | Candidate behavior and discovery state cannot depend on one surviving worker/model session. |
| PLAT-02 | Binding constraint | OQ-10 may determine presentation, but Discord cannot become the authoritative state store. |
| PLAT-04 | Binding constraint | Decision Engine candidates must remain portable across interface, model, memory, and host providers. |

3. Keep APP-05 through APP-10 deferred unless a separately authorized build task is created. APP-03 may remain deferred/N/A for this no-Builder stage because GOV-02 supplies the independent plan-review gate.
4. Clarify CAP-03’s rationale: cost telemetry is a binding future integration requirement, while this discovery stage uses the explicitly approved “not measured” disclosure and session-count evidence. This avoids implying that §6 currently satisfies the runtime telemetry requirement.
5. Recalculate the category counts after correction.

**Closure test:** no accepted requirement is described as optional merely because its implementation details are under discovery; every deferred row is genuinely outside the stage rather than an active invariant.

---

## 5. Fail-Closed Correction Evidence

Fable may proceed to owner plan approval without another verifier response only if the corrected control packet demonstrates all of the following:

```text
1. 00_Phase2_Discovery_Plan.md SHA-256 remains:
   75c636801ef112f08876c17f5dde28caa0d628c838fed8d8d917c19ce3bc7c99

2. P2-09 and P2-10 are dispositioned Concur with no semantic expansion.

3. Internal 04_ source-manifest validation: 100% pass.

4. Requirements matrix:
   - 125 rows
   - 125 unique IDs
   - no missing/extra IDs
   - corrected category semantics
   - required reclassifications present
   - counts recalculated accurately

5. Full export manifest: 100% pass.

6. Git bundle/commit/tree evidence binds the corrected control artifacts.

7. Exact diff shows no change outside:
   - 03_Requirements_Applicability_Matrix.md
   - 04_Discovery_Source_and_Exclusion_Manifest.md
   - derived checksums/manifests/evidence
   - ordinary decision-trail/registry/control records

8. No owner approval or discovery-execution claim is written before Hunter’s event.
```

If any substantive plan text, open question, scope, authority, deliverable, replay rule, acceptance criterion, or owner-input rule changes, the affected scope returns for targeted verifier review.

---

## 6. Gate State

```text
Accepted v1.3 Phase 2 gate:          OPEN
TOPIC-0002 allocation:               VALID
P2-DP Revision 2 substantive plan:   PASS
P2-01 through P2-08:                 CLOSED, subject to two control corrections
Apply P2-09/P2-10 corrections:       AUTHORIZED
Additional pre-approval review:      NOT REQUIRED if §5 passes exactly
Owner plan approval:                 AUTHORIZED after corrections
Discovery execution:                 BLOCKED until owner approval
Builder involvement:                 NOT AUTHORIZED / NOT NEEDED
Next actor:                          Fable, then Hunter
```

The standing program separation remains unchanged: Fable plans and architects, ChatGPT independently verifies, Opus 5 builds only under a separately approved Task Packet, Sonnet remains read-only context/traceability support, and Hunter retains final authority.

---

## 7. Final Verifier Position

Revision 2 is not a redesign candidate. It is a sound, bounded discovery plan with the prior eight findings substantively resolved. The two remaining defects are control-plane exactness problems that have a finite, pre-authorized correction path.

After those corrections pass §5 and Hunter approves the plan, **Phase 2 Decision Engine discovery may begin** under the declared three-branch capacity, bounded owner-input policy, falsifiable replay standard, and post-discovery verifier gate.
