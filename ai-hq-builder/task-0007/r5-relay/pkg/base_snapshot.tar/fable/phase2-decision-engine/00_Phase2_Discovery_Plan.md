# Phase 2 Discovery Plan — Decision Engine (P2-DP Revision 2, owner-approval candidate pending scoped verifier confirmation)

**Status:** Revision 2 — all eight verifier findings (P2-01..P2-08) incorporated, none contested; submitted for the scoped verifier confirmation required by `01_Verifier_Response_P2-DP_Rev1.md` §6. Not owner-approved; discovery execution remains blocked until that confirmation and owner approval. No design decision is made or implied; no build task exists.

**Lineage:** Revision 1 (SHA-256 `7b2786013e93df5cd50a8f7953a924e44faa07656b6ecdcda5c8224d1955b2f7`) → verifier review **PASS WITH CHANGES** (direction Concur; 1 Concur, 5 Concur-with-modification section dispositions; findings P2-01..P2-08; preserved byte-for-byte at `01_Verifier_Response_P2-DP_Rev1.md`, SHA-256 `319dca5a118c3e281c85ade1bdbd8d296166f5cdead129c35842fa7f1adcabe5`) → this Revision 2. Dispositions: `02_P2_Finding_Dispositions.md`.

**Authority:** Owner directive trail entry 74 (verbatim). Roles: **Fable — planner and architect; Claude Opus 5 — builder (outside discovery unless a separately governed task packet is authorized); ChatGPT — auditor/reviewer; Sonnet — read-only context/traceability support; Hunter — owner and final authority.**

**Baseline:** accepted v1.3 (trail entry 73). **Parent topic:** TOPIC-0002.

---

## 1. Objective

Produce the **Decision Engine Discovery Report** — the complete, evidence-grounded design-input package for the subsequent design phase — without making any binding design decision. Discovery answers *what the engine must do and why, from the recorded intent*; design (a later, separately gated phase) decides *how*. Discovery holds **no presumption about record shape**: whether the pipeline is served by one aggregate, a Decision Case linking typed records, or multiple canonical objects is itself a discovery question (OQ-01), and routine inputs may follow deterministic or no-decision paths that never create a Decision record at all (P2-03).

## 2. Scope (Manual §19.2)

The component under discovery handles the full pipeline:

```text
Input → Understanding → Candidate classifications → Recommendation with alternatives
      → Policy evaluation → Attention and routing → Execution or owner decision
      → Verification → Learning and fold-back
```

**Core hypothesis to test (verbatim from §19.2):** intelligent recommendations and deterministic policy decisions should remain separate — models may improve recommendations without silently changing approved operating behavior. §5.4 defines the minimum falsifiable test plan.

**In scope for discovery:** the decision-record lifecycle question (OQ-01) across all nine stages; how the accepted mechanisms bind to them (canonical state 4.4, attention model 4.5, WF-09 routing dimensions, staged adaptive routing 8.2.1 + AUT-12, action classes 11.3, INT-01 decision-prompt standard, trust envelope TRS, harness 11.2 and independent evidence authority, QUE-01 queue/aging, LRN pipeline with LRN-09/LRN-10, fold-back 7.4, COR-01 corrections, DEC-02 falsifiers); candidate schemas and routing logic *as explicitly nonbinding discovery artifacts*; critical-interrupt and quiet-hour requirements gathering; the operational-database event model *as the engine's substrate*.

**Protection layer (P2-06, verifier text adopted):** New security architecture and product selection remain deferred. Operationalizing all accepted IDN/TRS/DAT/LOG/ACT/SCH/RES constraints as Decision Engine inputs, policy boundaries, failure states, evidence requirements, and replay invariants is mandatory in this discovery. A discovered incompatibility becomes a blocking gap; it is not deferred as implementation detail.

**Remaining non-goals (stay deferred per §19.3; a discovered dependency becomes a finding, not a scope expansion):** memory-provider selection (ADR-021 gate), permanent HQ taxonomy and Discord channel map, MCP authorization and production-write boundaries, mailroom detail, personal HQ structures, Discord implementation mechanics, model/provider subscription policy, hardware. **No runtime code and no external actions in this phase.**

## 3. Decision-trail intents the discovery must honor

The authoritative intent surface is `../phase1-audit-v1.0/10_Concept_Experience_Walkthrough.md` — the ten owner-reviewed scenarios, each binding its decision-trail entries in context (D1–D9 ratified at trail entry 53) — replayed under the §5.3 oracle standard, never as narrative. The complete intent surface, including Business/Personal separation (PER) and correction/recall invariants (COR-01, EX-11), is carried row-by-row in `00A_Discovery_Authority_and_Traceability_Matrix.md` rather than this prose list. These recorded intents bind directly:

1. **One visible coordinator** (D9, trail 49; EX-04, Manual 16.4): the engine is invisible machinery behind a single conversational front.
2. **Capture without classification** (DP-001; trail 10/11): the engine classifies *after* capture; Reception never blocks on the engine.
3. **Routing prompts decrease by measured calibration** (trail 28; 8.2.1; AUT-12): unlocks are evidence-driven; raw model confidence never unlocks authority.
4. **Automation-first destination** (owner, trail 62; DP-027): each eligible action class advances to the highest safe, policy-authorized autonomy; persistent owner judgment remains a designed control where consequences warrant.
5. **Attention is owed only where it earns its keep** (4.5; C-35): the engine does the remembering; AUD-03/LRN-09 rituals feed it, not the owner's discipline.
6. **Consequential actions ride the harness** (11.2, INT-01, 11A.1 step-up; trail 26): the engine may *recommend or request* consequential actions; execution truth derives only from independently controlled receipts and evidence (P2-03/OQ-09).
7. **Convergence over loops** (owner, trail 57; DEC-02): every discovery question terminates; severity-gated closure per §6.
8. **External content is data, never instructions** (TRS, 11A.2): classification and recommendation must be prompt-injection-resistant by construction.
9. **Fold-back preserves momentum** (7.4, trail 12/25): completed decisions feed To-Did and learning; nothing evaporates.
10. **Grant-once onboarding posture** (ONB-01/ADR-022, FLAG-1, trail 64): engine-driven capability activation follows 11A.7 gates internally, with no trickle requests to the owner.

## 4. Open questions

Each terminates per §6. OQ-01, OQ-02, and OQ-09 carry the verifier's replacement texts verbatim (P2-03/P2-04); OQ-06 carries the verifier's addition.

**OQ-01 — Decision-case boundary and record model.** Which inputs create a Decision Case, which follow a deterministic/no-decision fast path, and which are rejected, quarantined, or recorded only? Test whether one aggregate with linked typed records or multiple canonical objects best preserves source-of-truth separation. Candidate records may include Input Event, Understanding/Normalization, Recommendation, Policy Evaluation, Decision, Action Request, Execution Receipt, Verification/Reconciliation, Learning Event, and Fold-Back event. Discovery must not presume that all stages are mutable fields on one object.

**OQ-02 — Routing dimensions and recommendation/policy boundary.** Which normalized input dimensions, current-state dimensions, and policy facts are inputs to routing, and which dimensions are outputs? The candidate set must explicitly test WF-09 placement, relationship, blocking, disposition, attention, authority, and confidence; TRS origin/trust/instruction-authority/sensitivity/verification; domain and source object; action class and risk; applicable policy and schema versions; current stage/status/focus/health where relevant; and correction history. Define where probabilistic recommendation ends, where versioned deterministic policy begins, and what fails closed when context or policy is missing, stale, disputed, or conflicting.

**OQ-03 — Attention calculus.** How are the five attention levels computed from routing outputs, and what evidence recalibrates them (approval dwell time, correction rates, override history per 18.1)?

**OQ-04 — Critical-interrupt definition and quiet-hour behavior.** What may interrupt the owner, who defines and versions that policy, how is Critical distinguished from Needs Owner during quiet hours, and how is it tested?

**OQ-05 — Operational-database event model.** What events must exist for the engine to be **replayable and auditable** (LOG/ACT alignment): event identity, ordering, idempotency/deduplication, and the append-only boundary between engine records and independent evidence stores?

**OQ-06 — Policy representation.** How are deterministic policies stored, versioned, and changed only through the governed workflow (10.2), never by the model? Policy representation must cover scope, precedence, conflict resolution, default/deny behavior, version binding, effective dates, exception authority, change events, rollback, and deterministic replay from the same normalized input and policy version.

**OQ-07 — Queue mechanics.** How do QUE-01 aging/consolidation and the C-12 review cadence bind to engine outputs so queue load stays bounded per the capacity model?

**OQ-08 — Ritual integration.** How do AUD-03 scorecards and LRN-09/LRN-10 candidates enter the pipeline as inputs rather than owner chores?

**OQ-09 — Execution and verification authority.** Which authoritative receipt, evidence-store record, and reconciliation event permit the Decision Case to derive an executed/verified state? The Decision Engine may request or observe execution but cannot create independent harness evidence, overwrite receipts, or self-mark a consequential action as verified. Uncertain outcomes follow ACT-01 and fail closed.

**OQ-10 — Coordinator boundary.** Precisely which engine states are visible in Discord (DAT render classes) and which stay machinery?

## 5. Method and deliverables

### 5.1 Method (LLM-speed; discovery is Fable-owned plan/architecture work; no Builder involvement unless a TASK-0003+ packet is separately authorized under the `../v1.2-ideas-pass/19_` APP-05 template)

(a) **Evidence pass** over the complete authority corpus — original decision-trail entries 1–40 (`../../baseline/chatgpt-phase1-v1.0/08_Phase_1_Conversation_Decision_Trail.md`), addendum entries 41–75, accepted v1.3 Manual, accepted register, walkthrough, consensus issue register, and baseline ADR/design-principle sources — per `04_Discovery_Source_and_Exclusion_Manifest.md`; every discovery conclusion cites stable source identifiers (trail entry number, requirement ID, Manual section). (b) **Candidate models** — decision-record and routing-logic sketches, explicitly labeled nonbinding discovery artifacts, spanning at minimum: one no-decision path, one owner-decision path, one deterministic policy path, and one consequential external-action path with separate authoritative evidence. (c) **Oracle replay** per §5.3. (d) **Hypothesis test plan** per §5.4. (e) **OQ dispositions** per §4/§6. (f) **Owner decision package** and design-phase change plan proposal assembly.

### 5.2 Deliverables (P2-08, verifier structure adopted)

```text
00A_Discovery_Authority_and_Traceability_Matrix.md
  - every source, accepted requirement, ADR, trail intent, and exclusion
01_Decision_Engine_Discovery_Report.md
  - findings, alternatives, candidate models, recommendation boundaries,
    core-hypothesis test and falsifier
02_Open_Question_Dispositions.md
  - each OQ: status, evidence, alternatives, recommendation, owner decision
    if any, downstream impact, falsifier/review trigger
03_Scenario_and_Adversarial_Replay_Matrix.md
  - ten owner scenarios + mandatory boundary cases, with reproducible oracles
04_Owner_Decision_Package.md
  - one-screen summary; only decisions that need Hunter; genuine tradeoffs;
    Fable recommendation; business consequences; residual gaps; direct links
05_Design_Phase_Change_Plan_Proposal.md
  - nonbinding draft only; opened for approval after discovery acceptance
```

The GOV-01/§20A.1/ADR-019/§12.1.1 standing-role refresh to Claude Opus 5 appears in `05_` as an **isolated mechanical item** (trail-69 backlog closure) — never presented as a Decision Engine discovery conclusion.

### 5.3 Replay standard (P2-05, verifier requirements adopted)

Every case in `03_` states, for each candidate model: normalized input and source/trust/data/identity envelope; starting canonical state and policy/schema versions; expected recommendation, policy result, attention, route, action authority, and visible receipt; required events and authoritative evidence; allowed alternatives; forbidden outcomes; pass/fail result and linked gap; falsifier or reasoned N/A. The matrix includes the ten owner-reviewed scenarios plus, at minimum, these adversarial/boundary cases: (1) authenticated-channel signal with failed owner identity/session binding; (2) prompt-injection content in email, transcript, web page, or tool output; (3) missing or unknown trust/data class; (4) stale, missing, disputed, or conflicting policy/rule version; (5) duplicate/replayed input event; (6) concurrent events implying conflicting routes or state changes; (7) worker failure after a possible side effect but before receipt recording; (8) Critical-versus-Needs-Owner during quiet hours; (9) wrong initial filing followed by COR-01 correction and calibration; (10) unavailable/degraded canonical store or evidence store; (11) routine no-decision fast path; (12) consequential action requiring step-up, external receipt, and reconciliation. **Severity rule:** a Critical/High replay gap blocks the design gate unless resolved or explicitly accepted by the owner with consequences; it cannot be closed as deferred-with-rationale.

### 5.4 Core-hypothesis test minimum (verifier §5 adopted)

The hypothesis is not satisfied by a diagram. The test plan must include at least: (1) **model substitution invariance** — same normalized input, control envelope, and policy version: changing the recommendation model may change suggested ranking or explanation but may not silently change the maximum authorized action; (2) **policy-version causality** — any change in deterministic behavior traces to a governed policy/version event, not prompt drift or model memory; (3) **missing-control fail-closed behavior** — a missing/stale identity, trust, data, policy, schema, checkpoint, or authority field cannot be filled by model inference for a consequential action; (4) **evidence separation** — recommendation, policy result, execution receipt, and verification evidence originate from their accepted authorities; the engine cannot self-certify execution or verification; (5) **correction path** — a wrong recommendation or route is corrected through COR-01 without rewriting history, and the correction becomes bounded learning evidence rather than policy; (6) **separation falsifier** — the report names evidence that would show the separation is unworkable (for example: required policy decisions cannot be made replayable without embedding unbounded model interpretation) and states what architecture question would reopen if that evidence appears.

## 6. Plan Control and Acceptance (P2-02, verifier structure adopted)

```text
Stage risk class:
- Design-governance / high leverage
- Runtime or external-action authority: none

Authority scope:
- Requirement Applicability Matrix covering all 125 accepted requirements:
  In-scope / binding constraint / deferred / N/A, with rationale
  (initial population: 03_Requirements_Applicability_Matrix.md; finalized
  during execution; every change from the initial population is logged)
- Binding ADRs and decision-trail entries per 00A/04_ manifests

Capacity:
- Maximum active discovery branches: 3
- Owner-decision budget: one consolidated decision packet at the owner gate,
  target <= 30 decision-minutes; one earlier blocking packet only under the
  §7 contamination rule
- Model/provider spend: not measured this stage (CAP-03 not yet implemented) —
  disclosed, with session counts recorded in the Discovery Report
- Stop/park condition: if open Critical/High gaps exceed 10, or a third
  discovery branch stalls, discovery pauses and returns to the verifier with
  a scope finding instead of expanding silently

Acceptance criteria (each independently checkable):
1. Every source in the authority manifest verifies (hash-validated).
2. Every accepted requirement is dispositioned in the applicability matrix.
3. Every OQ carries evidence, alternatives, recommendation, status,
   downstream impact, and a DEC-02 falsifier when consequential.
4. Every ten-scenario and mandatory adversarial replay has a recorded oracle,
   actual result, pass/fail, and gap disposition.
5. No Critical or High gap remains deferred without explicit owner acceptance.
6. Candidate artifacts remain visibly nonbinding and do not alter v1.3.
7. The owner receives a concise decision package with direct links to evidence.
8. The final gate packet satisfies or justifies N/A for all §20A.2 items.

Version/rollback point: accepted v1.3 (trail entry 73; tag v1.3). Discovery
artifacts live under fable/phase2-decision-engine/ and are additive only;
rollback = branch/commit abandonment, the baseline untouched.
```

## 7. Owner-input policy and post-discovery gate (P2-07, verifier text adopted)

**Owner-input policy:** no trickle questions during discovery; existing accepted sources are used first; if a material owner-intent ambiguity blocks multiple OQs, Fable may prepare one consolidated, bounded decision packet at the owner gate (or one earlier blocking packet only when proceeding would contaminate the discovery); each answer is persisted immediately under MEM-09 with source, scope, and impact; no unanswered preference is silently inferred.

**Post-discovery gate:** discovery artifacts → verifier review → Fable dispositions → corrected artifacts and scoped re-verification where findings affect substance/evidence → Fable gate recommendation → concise owner decision package → owner acceptance of owner-level choices and residual gaps → design-phase change plan may open.

## 8. Termination

Convergence (trail 57 pattern, severity-gated per §5.3): discovery terminates when all §6 acceptance criteria pass. Timebox: days, not weeks; owner attention is spent only per §7. **Not claimed by this plan:** any design decision, any Phase 2 completion, any build authorization, any change to the accepted v1.3 baseline.
