# 00A — Discovery Authority and Traceability Matrix

**Status:** Discovery execution artifact — nonbinding; reissued per P2D-01. Authority corpus per the rebuilt `04_Discovery_Source_and_Exclusion_Manifest.md` (single-tree snapshot at discovery-gate commit `fa01b9d…`; intent frozen at trail entry 75; validated 100% by `04V_`). Trail entries 76–77 are control-plane records outside the intent corpus; the prior entry-77 citation is removed (P2D-01). Every conclusion in deliverables `01/02/03` cites the identifiers below.

## A. Engine-bearing intents from the original trail (entries 1–40, baseline `08_`)

| Trail | Intent (abridged) | Engine obligation | Where treated |
| --- | --- | --- | --- |
| 06 | ADD; systems that demand discipline get abandoned; automate housekeeping | Engine does the remembering; no self-administered protocol | OQ-08; S8 |
| 10 | Project began as rough notes → structure | Capture precedes classification; classification is engine work | OQ-01 tiers; S2 |
| 11 | "Scattered idea to highly structured plan" | Placement + kickoff records are core outputs | OQ-02 outputs; S2 |
| 12 | Ideas die: forgotten, invisible effort, displaced, restart-loops | Preservation, no-build endings, To-Did, fold-back events | OQ-01 record set; S10 |
| 13 | Overwhelm; architect maintains structure | Bounded owner questions; engine organizes | §7 owner-input policy; S8 |
| 14 | Variable day; bed check; overnight failures; email batches; interruptions | Briefing, checkpoint/resume, mailroom triage, interjection routing | S1, S5, S7; A7 |
| 15/16 | Interjections open independent linked work; chaos in, buckets out | Parallel workstream creation without losing foreground | S3; OQ-01 T1/T2 |
| 18 | Context-rich kickoff; one foreground, background states | Kickoff record typed object; focus dimension is input not output | OQ-02; S3 |
| 20 | Stage-as-state; small local, major impacts spawn blocking workflows | Impact/risk class is a routing input; blocking is an output | OQ-02; S4 |
| 21/22 | Preferences/skills route through discovery before activation; rejection prompts inquiry | Observations are weak evidence; learning events never change policy directly | OQ-06; hypothesis check 5 |
| 23 | Scoped rules, exceptions, decay | Policy scope/precedence/effective-dates in policy representation | OQ-06 |
| 25 | Recursive hubs, fold-up, stable state | Fold-back event type; parent rollups derived | OQ-01; S10 |
| 26 | Owner approves problem/process/outcome, not code; impact-based branching | INT-01 cards; harness evidence authority; adaptive automation | OQ-09, OQ-10; S6 |
| 27 | Evidence accumulation before automation-policy proposals | Calibration before unlock; policy change = governed event | OQ-02 boundary; check 2 |
| 28 | Recommend among placements, learn from choice; selective rationale | Recommendation-with-alternatives is the model's product; choice is learning signal | OQ-01 T2/T3; S3 |
| 33/34/35/36 | Delegation scoped; completion evidence by type; auto-verify read-only; owner-accepted closure; non-destructive reopen | Verification stage consumes external evidence; reconciliation events | OQ-09; A12 |
| 37 | Genuine tradeoffs in questions | INT-01 card quality; owner package format | 04_ |
| 38 | Attention without forced interruption; strong override friction with consequences | Attention is deterministic and bounded; overrides logged as evidence | OQ-03; S4 |
| Verbatim: "I don't want to have to notice these patterns" | — | Engine self-generates observation candidates (LRN-10) | OQ-08 |
| Verbatim: "Delegation transfers execution, not accountability" | — | Authority ceilings never transfer by delegation | OQ-02 |

## B. Addendum intents (frozen `06_`, entries 41–75) binding the engine

| Trail | Intent | Engine obligation | Where treated |
| --- | --- | --- | --- |
| 46/47 | LLM-speed; Mac = body not brain; walkthrough-centered review | Days-scale staging; scenario oracles as the test surface | 03_ |
| 49 (D9) | One visible coordinator; per-category agents are config | Engine invisible behind coordinator; no multi-agent owner surface | OQ-10; S1–S10 |
| 53 (D1–D9) | Ratified defaults incl. D4 staged routing, D5 strict render, D6 read-only email first | Tier defaults, render classes, mailroom staging | OQ-01/OQ-10; S3/S6/S7 |
| 57 | Convergence rule; loops terminate | Severity-gated closure; falsifiers | 02_ dispositions |
| 62 | Automation-first destination; memory external; voice four controls | Tier graduation toward highest safe autonomy; SEC-02 boundaries on outbound | OQ-01 T4; A12 |
| 64 (FLAG-1) | Grant-once/activate-staged | Capability activation events are internal, never owner asks | A1; OQ-05 |
| 65/73 | v1.2/v1.3 accepted layers | AUD-03/LRN-09/LRN-10/DEC-02/AUT-12/SCH-02/ONB-01/MEM-08/09 bind as accepted | 03_ checklist |
| 69/74 | Roles: Fable plans, Opus 5 builds, ChatGPT audits | Discovery is Fable-only; Builder outside | 01_ method |
| 75 | Corpus freeze rule adopted | Later control events never silently enter intent | 04_ boundary |

## C. Walkthrough scenarios → replay cases

S1 reconnect (trail 14/24) · S2 capture (10/11) · S3 interjection + D4 (15/16/18/28) · S4 blocker override (20/38) · S5 overnight failure (14) · S6 consequential approval + step-up (26) · S7 email triage + trust rule (14) · S8 bad week (6/13) · S9 recall-by-description (14) · S10 fold-back (12/25). Oracles: `03_Scenario_and_Adversarial_Replay_Matrix.md`.

## D. Requirement families → discovery treatment

Binding families (46 rows) are invariants in every replay case; in-scope families (67 rows) are the subject matter of OQ-01..10; deferred (10) and N/A (2) per `03_Requirements_Applicability_Matrix.md`. **Execution log: zero changes from the initial population were required during discovery** — every case resolved within the approved classifications.

## E. Exclusions honored

Per `04_`: peer sources, TASK-000x gate records, research register, audit working papers, archives — consulted never, cited never. Control-plane trail entries 76+ excluded from intent per the frozen snapshot boundary.
