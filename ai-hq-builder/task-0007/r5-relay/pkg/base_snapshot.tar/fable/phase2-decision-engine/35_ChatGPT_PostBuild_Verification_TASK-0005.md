# 35 — ChatGPT Post-Build Verification: TASK-0005

**Role:** Independent verifier  
**Scope:** TASK-0005 Builder return; P2U-01, P2U-02, P2U-03, and P2U-05; any Critical/High defect directly introduced by those corrections  
**Builder return:** `TASK0005_Builder_Return.zip`  
**External Delivery Record:** `BUILDER_DELIVERY_RECORD.md`

## 1. Verdict

# **FAIL — Builder return not accepted; design gate remains open**

The Builder return is mechanically disciplined and materially improves every assigned work item. The supplied tests reproduce, the output is deterministic, the change set stays inside the Task Packet allowlist, and the Builder is appropriately explicit that no gate passage is claimed.

However, independent falsifier probes found four High-severity enforcement defects:

1. The production-facing final-gate command still exposes a public flag that disables the newly added global blocking-finding check.
2. An arbitrary nonempty `verification_receipt` string is accepted as independent external-basis verification.
3. The external-manifest digest does not bind all security-relevant control fields, and duplicate external-record identities are accepted ambiguously.
4. A retired schedule version can be reactivated with its old horizon, allowing stale coverage to suppress the current activation's liveness warning.

No rediscovery, owner-decision reopening, or architecture restart is required. Fable should disposition P2V-01 through P2V-04 and issue one narrowly bounded APP-07 Rework Packet.

---

## 2. Independent return verification

### 2.1 Transport and manifest integrity

```text
Builder-return ZIP SHA-256
20bf133847d87ca24518dab583f9aaa15534da2531c066ffa5c86c7598f0d89d

External Delivery Record SHA-256
251df0f3374205f82b5d74928bd1cc4be5c94de574a3893841162d8de3c9d38f

Return-manifest payloads
51 / 51 present
51 / 51 SHA-256 hashes passed
51 / 51 byte counts passed

Delivery Record transport
External copy is byte-identical to the copy inside the ZIP
```

### 2.2 Scope and change control

```text
Changed paths
21 total
20 modified
1 added

Allowlist compliance
21 / 21 inside:
- design/traces/behavioral/**
- 13V_validate_design_matrix.py

Out-of-scope paths changed
0
```

Every pre-task hash declared for a changed path matched the corresponding file from the previously reviewed P2T Correction Packet 4 snapshot. The resulting base-to-return diff was independently reconstructed.

### 2.3 Supplied evidence reproduction

The behavioral gate was run twice from the returned files:

```text
Gate executions
2 / 2 exit 0

Generated outputs
13 / 13 byte-identical between independent runs
13 / 13 byte-identical to the shipped output set

Combination results
81 / 81 evaluated
0 supplied judged failures

13V self-test
25 / 25 passed

13V end-to-end synthetic probes
5 / 5 passed as shipped

Changed-file hygiene
0 CR bytes
0 trailing-whitespace lines
Final LF present on every changed source/output file
```

The full structural validator also ran successfully after the returned files were overlaid onto the prior complete repository snapshot. The normal `--final-gate` invocation correctly failed while known gate-blocking findings remained open. That normal-path behavior does not cure P2V-01 below.

---

## 3. Prior-finding status

| Finding | Scoped result | Reason |
| --- | --- | --- |
| **P2U-01** — mapped presentation expectations have no comparator | **CLOSED at simulator-accounting level** | The five presentation values are now explicitly `NOT_SIMULATED`, excluded from mapped/compared counts, and accompanied by rationale. This truthfully narrows coverage rather than claiming a projection surface the simulator does not compute. Fable must carry the resulting Desk/Mailroom presentation gap into the design matrix and later test plan. |
| **P2U-02** — unresolved `external_basis` bypass | **OPEN; materially improved** | References now have a strict grammar, a manifest, version/hash matching, and fail-closed resolver states. Independent receipt verification and complete manifest integrity remain missing under P2V-02 and P2V-03. |
| **P2U-03** — stale schedule horizon after version change | **OPEN; materially improved** | The supplied v1→v2 case now correctly retires v1 coverage and warns on an empty v2 horizon. Reusing or reactivating a prior version makes its historical horizon eligible again under P2V-04. |
| **P2U-04** — normative contradictions | **OUTSIDE THIS BUILDER RETURN** | The Task Packet assigns this work to Fable and does not allow the Builder to modify the controlling design documents. It remains subject to Fable's consolidation and the next gate packet. |
| **P2U-05** — final gate ignores global blockers | **OPEN; normal path fixed** | Missing/malformed findings and open global blockers now fail on the normal path. A public runtime switch disables that protection under P2V-01. |

---

## 4. New findings

### P2V-01 — High — A public CLI flag disables the final gate's global blocker check

**Affected:** P2U-05; `13V_validate_design_matrix.py`; owner-gate integrity

#### Problem

The validator exposes:

```text
--p2u05-defect-witness
```

When supplied with `--final-gate`, this flag skips global check 9. The code describes the switch as a self-test witness, but it is accepted by the ordinary production-facing command and has no enforcement that confines it to an isolated test mode.

A gate whose critical control can be disabled by a caller-provided flag relies on operator vigilance rather than structure.

#### Independent falsifier

A synthetic complete repository contained one finding with:

```json
{"id": "P2U-X", "blocks_gate": true}
```

Observed:

```text
python 13V_validate_design_matrix.py --final-gate
exit 1
FAIL — one global blocking finding open

python 13V_validate_design_matrix.py --final-gate --p2u05-defect-witness
exit 0
PASS — while the output still reports one gate-blocking finding open
```

#### Required correction

No normal or externally invocable final-gate path may disable global findings enforcement.

- Remove the bypass from the production CLI.
- Preserve the defect witness in isolated self-test code, a private legacy function, or a separate test-only fixture that cannot be combined with a real final-gate invocation.
- Add a regression test proving that every supported `--final-gate` invocation fails when a global blocking finding is open.
- Unknown or prohibited bypass flags should fail rather than silently alter gate policy.

---

### P2V-02 — High — `verification_receipt` is asserted, not independently verified

**Affected:** P2U-02; `external_basis.py`; fold authority; evidence ownership

#### Problem

`ExternalRecord.verification_receipt` is accepted when it contains any nonempty string. The manifest binds that string as record content, but no independent receipt store, signed attestation, receipt manifest, or verification routine establishes that the receipt exists or proves the record.

This permits Builder-controlled data to certify its own external basis by naming an invented receipt.

#### Independent falsifier

A record was created with:

```text
verification_receipt = definitely-missing-receipt
```

The manifest was bound, the reference matched its record, and the fold returned:

```text
validation problems: []
fold accepted: true
```

#### Required correction

Use one explicit contract:

1. Resolve the receipt against a separate, hash-bound, independently owned receipt/evidence registry; or
2. Verify a signed/hash-bound receipt object under a defined trust root; or
3. If neither is available at this design gate, fail closed on every external-basis reference and mark positive external-basis execution as build-gate deferred.

A nonempty receipt identifier is not verification. Add positive and negative tests for nonexistent, mismatched, unavailable, revoked, and valid independently resolved receipts.

---

### P2V-03 — High — External-manifest binding is incomplete and record identity is ambiguous

**Affected:** P2U-02; `ExternalManifest`; replay determinism; trust and provenance

#### Problem

`ExternalManifest.computed_digest()` hashes only the sorted record rows. It does not bind at least:

- `resolver_state`
- `resolver_known_ids`
- manifest schema/version
- snapshot identity or creation context
- the receipt-verification authority/configuration

The resolver state can therefore be changed from `unavailable` to `available` without changing the declared digest.

The manifest also accepts duplicate `(store, object_id)` records. `lookup()` returns the first match, so conflicting versions/hashes can be hidden by order rather than rejected.

#### Independent falsifiers

**Control-field tampering:**

```text
Bind manifest while resolver_state = unavailable
Change resolver_state to available
Keep the same declared digest

integrity problems: []
validation problems: []
fold accepted: true
```

**Duplicate record key:**

Two conflicting records with the same store/object identity produced:

```text
integrity problems: []
validation problems: []
fold accepted: true
```

#### Required correction

Define a canonical manifest schema and digest all security-relevant fields, including schema version, resolver/snapshot state, record set, unique identity rules, known-ID evidence where retained, and receipt-verification references.

- Reject duplicate authoritative keys.
- Define whether identity is `(store, object_id)`, `(store, object_id, version)`, or another explicit tuple.
- Canonicalize order before hashing.
- Make any post-binding control-field change invalidate integrity.
- Add tampering, duplicate-key, conflicting-version, and deterministic-order tests.

---

### P2V-04 — High — Reactivating a schedule version reactivates its stale horizon

**Affected:** P2U-03; `run_p2s04.py`; recurrence versioning; watchdog liveness

#### Problem

The corrected v1→v2 transition behaves properly. But `change_schedule()` uses an existing version-keyed horizon when a previously retired version is selected again. Historical coverage for that version becomes eligible without being rematerialized for the new activation.

A version identifier therefore does not uniquely identify one governed activation epoch.

#### Independent falsifier

```text
1. Materialize a long v1 horizon.
2. Change to v2 and materialize v2.
3. Change back to v1.
4. Do not let the scheduler extend the new v1 activation.
```

Observed:

```text
version in force: v1
eligible ticks: historical v1 ticks restored
horizon warning: None
```

The watchdog treats the old v1 activation's horizon as proof that the new activation is alive.

#### Required correction

Use either:

- strictly monotonic, never-reused schedule versions and reject reactivation of a retired version; or
- a distinct activation epoch/generation included in every ExpectedRun identity and horizon key.

At minimum, selecting a schedule definition for a new activation must establish an empty new horizon rather than using `setdefault()` against historical coverage. Add rollback/reactivation, replay, and duplicate-version tests.

---

## 5. Accepted Builder behavior and disclosed limits

### P2U-01 treatment

The Builder's choice to reclassify the five presentation forms as `NOT_SIMULATED` is acceptable under Fable's disposition and the Task Packet. It is more trustworthy than preserving a false mapped-coverage claim.

This closes only the simulator-accounting defect. It does **not** establish the behavior of:

- Executive Desk views
- Desk brief lines
- Mailroom briefs
- reconnect briefs
- monthly digests

Those remain a declared design/build coverage gap and must not be counted as behaviorally verified in the requirements ledger or owner package.

### Evidence qualification

The Builder's Delivery Record explicitly states that the work is built with independent verification pending and claims no design-gate passage. That boundary is correct. The shipped tests are Builder-authored evidence; the new findings above arise from independent probes outside the Builder's declared suite.

---

## 6. Required rework packet

Fable should disposition P2V-01 through P2V-04 and issue narrowly scoped Builder rework for:

1. Removing every production-accessible final-gate bypass while preserving an isolated falsifier witness.
2. Requiring independently verifiable external receipts or failing external basis closed.
3. Canonically binding the full ExternalManifest control envelope and rejecting duplicate/ambiguous identities.
4. Enforcing monotonic schedule versions or activation-epoch horizons, including reactivation tests.

Fable should separately complete:

- P2U-04 normative consolidation and supersession checks.
- The authoritative `13F_` open/closed finding registry and its control-plane status.
- The explicit carried-forward coverage gap for presentation surfaces.

The next packet should contain:

```text
Keyed dispositions for P2V-01 through P2V-04
APP-07 Rework Packet
Corrected Builder return and Delivery Record
Exact base-to-corrected diff
Machine-readable independent/falsifier tests
Complete manifest and hashes
Fable's P2U-04 normative consolidation evidence
Authoritative 13F open/closed state
```

No rediscovery or owner-decision reopening is required.

---

## 7. Gate state

```text
Accepted v1.3 baseline:             UNCHANGED
Accepted Phase 2 discovery:         VALID
Approved CP-P2-A plan:              VALID
Builder-return integrity:           PASS
Builder allowlist compliance:       PASS
Supplied test reproduction:         PASS
P2U-01 simulator accounting:        CLOSED
P2U-02 external basis:              OPEN
P2U-03 schedule horizon:             OPEN
P2U-04 normative consolidation:     FABLE-OWNED / NOT REVIEWED HERE
P2U-05 global finding gate:         OPEN
TASK-0005 Builder return:            FAIL
Design-gate verdict:                FAIL
Record-shape selection:             NOT MADE
DE-R1 through DE-R8 acceptance:     NOT AUTHORIZED
Owner decision package:             BLOCKED
Hunter action required now:          NONE
Next actor:                         FABLE
```

The standing role separation remains intact: Fable owns architecture, dispositions, and project management; the Builder implements only authorized work; ChatGPT independently verifies; and Hunter retains final authority. The Builder's own record correctly leaves gate passage pending independent review. 
