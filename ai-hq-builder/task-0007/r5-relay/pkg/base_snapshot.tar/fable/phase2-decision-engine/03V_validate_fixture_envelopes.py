#!/usr/bin/env python3
"""Validate that every fixture input resolves every mandatory control-envelope field (P2R-02).
Usage: python3 03V_validate_fixture_envelopes.py [path-to-03F json]"""
import json, sys
p=sys.argv[1] if len(sys.argv)>1 else 'fable/phase2-decision-engine/03F_Replay_Fixtures.json'
d=json.load(open(p,encoding='utf-8'))
F=d['envelope_contract']['required_fields']
bad=0; envs=0
for c in d['cases']:
    es=c['envelope'] if isinstance(c['envelope'],list) else [c['envelope']]
    for i,e in enumerate(es):
        envs+=1
        missing=[f for f in F if f not in e or e[f] in (None,'')]
        if missing: bad+=1; print(f"FAIL {c['id']}[{i}]: missing {missing}")
        if e.get('schema_version')!='SV-1': bad+=1; print(f"FAIL {c['id']}[{i}]: schema_version != SV-1")
print(f"{len(d['cases'])} cases, {envs} envelopes checked: {'ALL PASS' if bad==0 else str(bad)+' FAILURES'}")
sys.exit(0 if bad==0 else 1)
