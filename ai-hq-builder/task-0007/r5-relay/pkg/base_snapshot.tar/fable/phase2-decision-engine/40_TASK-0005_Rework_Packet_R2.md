# 40 — TASK-0005 Rework Packet R2 (APP-07): P2W Corrections

**Task:** TASK-0005, rework cycle R2. **Instruction authority:** `34_` + `37_` + this packet; **governing findings `38_`/`38A_` — BOTH RELAYED WITH THIS PACKET** (the R1 relay omission is not repeated): the verifier's exact finding texts, required-correction lists, and probe forms govern. Dispositions `39_`. All standing binding rules carry forward. Allowlist unchanged (`design/traces/behavioral/**` + `13V_validate_design_matrix.py`).

## Findings to correct (defeat every `38A_` probe in its exact form, in shipped evidence)

- **RW-32 (P2W-01):** strict CLI parsing with explicit, mutually exclusive modes per `38_`'s required-correction text; every mode-combination probe in `38A_` ships failing; unknown flags and mode mixtures fail closed.
- **RW-33 (P2W-02):** one explicit independent-evidence contract per `38_`: a same-manifest chain is never independent evidence; the independence source is structural (separate registry/actor), not positional. Your own R1 boundary statement becomes the enforced rule rather than a disclosure.
- **RW-34 (P2W-03):** the canonical versioned manifest envelope with every field `38_` requires bound (authority, snapshot, schema context included); the coverage guard extends to the envelope; unbound-context probes ship failing.
- **RW-35 (P2W-04):** enforce the **Fable design ruling** (this packet is your design authority for it): schedule-version identity is minted once and never reusable — monotonic per schedule id, bound to the authoritative schedule store per D-B9/P2G-11; retirement is a control-journal event; a restarting watchdog REBUILDS its retired set from the journal fold before accepting any registration; the register/change/restart probes in `38A_` all ship failing. No in-memory-only authority anywhere in the liveness path.
- **RW-36 (P2W-05, checker leg only):** D-SM row 15 (committed with `39_`) covers the retired scheduler-self-notice phrase automatically via your runtime-derived checker — verify it fires on a scratch copy carrying the old sentence and ship that as a self-test case. The document fix itself is done (Fable).

## Return requirements
Per-finding disposition with shipped-evidence proof; every `38A_` probe defeated in exact form; all standing criteria re-proven; APP-06 record with reflexive falsifiers; **return to FABLE**. Failure clause: further APP-07 rework.
