# 04 — Owner Decision Package (Decision Engine discovery) — Rebuilt per P2D-06/08/09

**Status:** Nonbinding draft — presented to the owner only after the verifier's scoped re-verification passes. One screen; three decisions; everything technical stays with Fable and the verifier.

## Where things stand (context, not a decision)

The engine's working shape is **Fable's technically reviewed recommendation, independently reviewed by ChatGPT and still being finalized** — not settled: inputs get triaged into five lanes (log-only → routine rule → file-with-receipt → ask-you → full ceremony with second factor and outside proof). The AI suggests; versioned rules decide the lane and the maximum allowed action; anything unclear falls back to asking you. Two engineering problems (duplicate detection; simultaneous-event ordering) are **open, named design requirements with objective tests** — they are Fable's and the verifier's to close, not yours.

## OD-1 — Your interrupt policy (within the already-accepted safety rule)

Your accepted baseline (ATT-01) already fixes the outer boundary: Critical interruption is reserved for **immediate physical, legal, financial, security, or comparably consequential danger**. That boundary is not up for narrowing — what you set is the *operating policy inside it*:

- **Triggers per category:** default = verified events only (watchdog-confirmed system death or breach; money-movement failure or uncertainty; a credible physical/legal danger signal).
- **Verification bar:** default = confirmed/corroborated signals interrupt; single unverified claims wait unless a second signal corroborates.
- **Quiet hours:** default 10 PM–6:30 AM, tunable; qualifying danger interrupts through them, everything else holds for the morning brief.
- **Emergency contacts:** messages from people you name act as a **signal that raises scrutiny** — they never auto-qualify as Critical by identity alone.
- **When urgency is ambiguous:** default = hold to briefing **except** in the physical-danger and security categories, which fail toward interrupting.

**Your call:** accept these defaults, or adjust any line. **Recommendation: accept; name your contacts at activation.**

## OD-2 — Starting autonomy (how much acts without asking)

Default: file-and-route only (the capture experiences), capped at **20 autonomous actions/day** while trust is being measured. **When the cap is reached:** nothing is dropped — further items queue into a single batched ask-you card, and the day's overflow is itself evidence for raising the cap. The real tradeoff: a lower cap means more batched asks landing on you sooner; a higher cap means extending trust before the correction-rate evidence exists. Widening later happens per category through the accepted measured-unlock ladder — proposed to you, never taken silently.
**Recommendation: accept 20/day, filing-and-routing only.**

## OD-3 — Business residual-risk acceptance (not technical sign-off)

You are asked to accept **consequences**, not designs: (1) until the design phase proves the recommendation/policy separation end-to-end, the engine stays paper-validated — meaning activation waits for those tests, which delays live capability but removes the risk of trusting an unproven boundary; (2) the two open engineering problems mean the design phase must pass their objective tests before anything autonomous runs — same trade: later, but proven; (3) if the separation ever fails its named test, the fallback designs keep your approval authority intact — the cost would be redesign time, never silent exposure.
**Recommendation: accept — every risk is named, owned, testable, and none reduces your control.**

**Reply format at the gate:** "OD-1 accept (or: edits…); OD-2 accept (or: cap = N); OD-3 accept."
