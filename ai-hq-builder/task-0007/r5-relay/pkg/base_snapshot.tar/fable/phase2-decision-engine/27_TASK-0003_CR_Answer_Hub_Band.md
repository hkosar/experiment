# 27 — TASK-0003 Change-Request Answer: the `hub` band (S7 / A14)

**Context:** the R4 return correctly froze two comparisons (S7, A14 — 6 combinations) as UNRESOLVED and returned a change request rather than reinterpreting a document outside the Builder snapshot: the engine emits a `hub` attention band that the D-B7 §2.1 vocabulary quoted in `26_` does not contain. Both live possibilities were stated: the band is real and the quotation partial, or the band is a Builder invention. **Fable holds D-B7; here is the ruling.**

## The answer (binding, quoted from D-B7)

The quotation was partial — but not in the way that adds a band. D-B7's band vocabulary is **exactly the four §2.1 bands** (Critical / Needs-Owner / Briefing / Record-only). What the §2.1 quotation omitted is the **ATT-03 explicit-mapping line** (D-B7 line 32, quoted verbatim):

> **Explicit band mappings (ATT-03, made mechanical):** verified successful background completion → hub update (Record-only with hub-visibility flag); safe automatic retry → Briefing; first overdue reminder → Briefing; subsequent overdue steps follow the per-partition aging ladder (B10).

So, the two one-line answers:

1. **`hub` is not a band.** "Hub update" is defined as **band = Record-only, plus a hub-visibility presentation flag.** The engine must not emit `hub` in the band position; where the ATT-03 mapping applies (verified successful background completion), it emits Record-only with `hub_visibility: true`.
2. **A14's `expected.attention: "Hub"` maps to Record-only + hub-visibility flag** — the oracle mapping compares both the band and the flag. S7 then compares normally against its `"Briefing"` expectation under the four-band vocabulary.

## Required closure (final micro-return)

- Engine band vocabulary reduced to the four §2.1 bands; hub-visibility becomes a flag computed where the ATT-03 mapping applies (safe-automatic-retry → Briefing and the overdue mappings are in-scope only if a fixture exercises them — do not implement unexercised branches; extend the NOT-SIMULATED list instead).
- The oracle mapping resolves A14 per answer 2; S7 and A14's 6 combinations move from UNRESOLVED to compared, with pass/fail computed honestly — **if either fails, the standing diagnosis discipline applies** (encoding vs engine vs mapping, cited basis, no papering over).
- Criterion 15's counts restated; the change-request entries in the outputs/README/record replaced by this answer's citation; layer-D witness for the hub-visibility flag if it becomes judge-checked.
- Everything else: the full battery re-proven, zero regressions outside the diagnosed changes, per-finding proof for this closure in the final Delivery Record addendum.

## Addendum — fifth-cycle review result and three erratum lines (fold into the same micro-return)

Fable's fifth-cycle adversarial review of R4 returned **GENUINE on all six audit tasks; acceptance recommended; nothing rises to rework.** Highlights you should know: S3's added AUT-05 fields were probed as load-bearing (a cross-subtree value fails the case) and adjudicated faithful against D-B6 AUT-05 and the S2/A9 precedent; the S9 read path verified general (no fixture keying, accurate D-B7 citation, zero collateral across the other 75 combinations); the ZZ-9 fabricated-id probe now fails with the correct note; the frozen S7/A14 combinations verified to receive no pass credit anywhere.

Three erratum lines — all RW-25-class (text vs shipped file), none functional — to correct in the closure return:

1. **Delivery Record §3:** "Four fixtures (S1, S5, S8, A11) pass under CEILING semantics" — S1 in fact passes under plain equality (its computed band is `none`); ceiling is load-bearing only for S5/S8/A11. The §3 table/"seven combinations" phrasing also conflates fixtures with combinations. Correct the sentence and the count wording in the closure record's erratum section.
2. **README.md:106 and :249:** still say "60-mutation" / "60 candidate defects"; the catalogue is 61 after `interrupt-policy-id-fabricated`.
3. **scenarios.py Builder-added-stimuli enumeration** (lines 9–38): claims exhaustiveness but omits S3's R4-added `placement_scope`/`proposed_action_class`. Add the S3 entry.

Two reviewer observations to carry as disclosures (no code change required): the citation check's two parsers are byte-identical copies — independence is structural (a change to one side cannot drag the other along), not diverse, so a shared parsing blind spot would be invisible; and `hub`'s position in the attention order becomes moot once the band vocabulary shrinks to four, but note it in the closure if any ordering-sensitive code remains.

Nothing else in the R4 return requires Builder action. This document + `22_`..`26_` are the sole instruction authority. The closure micro-return (hub ruling applied + S7/A14 compared + the three errata) is the final Builder deliverable of TASK-0003.
