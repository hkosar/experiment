# ChatGPT Independent Verifier Response
## CP-P2-A Corrected Design Packet — Scoped Re-Verification of P2G-01 through P2G-14

**Verifier:** ChatGPT  
**Review role:** Independent stage-gate verifier; no architecture ownership, implementation authority, or owner-acceptance authority  
**Review scope:** The corrected Decision Engine design candidate at commit `7a324018b046f16c83e25bb53d24e1fcb555af68`, tree `72170dbf6d8c9f0ecf547b98080c53bb57200a66`, against the controlling design-gate findings `P2G-01` through `P2G-14`  
**Packet SHA-256:** `92bd85cca7ca233e59b803ba31fa890ca1ffe26854f7c8e7e42fe3eeec69b86e`  
**Date:** 2026-07-30

---

# 1. Verdict

## **FAIL — corrected design gate remains open**

The correction set is materially better and demonstrates real convergence. Several prior findings are closed, and the core Decision Engine direction remains viable. However, the candidate still does not satisfy the approved design-gate evidence standard or several accepted protection and determinism requirements.

The most important remaining defect is not packet hygiene. It is that the new “machine-executed” cross-shape trace and fold evidence does not actually execute candidate transition logic or fold state. It copies the frozen fixtures' expected outcomes and recorded verdicts into three shape-labeled records, then verifies that those copied expectations agree. The reported `81 traces / 0 divergences` therefore cannot support the claims currently assigned to it.

Several safety and resilience mechanisms are also directionally designed but remain under-specified at exactly the boundaries where authority, liveness, and replay correctness depend on them.

This is a **bounded correction failure**, not a restart:

- Accepted v1.3 remains unchanged.
- Accepted Phase 2 discovery remains valid.
- The approved CP-P2-A plan remains the governing plan.
- OD-1, OD-2 including the DE-R8 modification, and OD-3 remain unchanged.
- S1, S2, and S3 remain viable; no record shape is selected.
- No rediscovery is required.

---

# 2. Independent Packet and Provenance Verification

The packet passed mechanical and provenance verification.

```text
Uploaded ZIP SHA-256
92bd85cca7ca233e59b803ba31fa890ca1ffe26854f7c8e7e42fe3eeec69b86e

Top-level checksum entries
36 / 36 passed

Export manifest
30 / 30 repository-file hashes passed
5 / 5 evidence-file hashes passed

Base commit
20ad093c7535928e07bcc7ef819236a6bed62929

Corrected commit
7a324018b046f16c83e25bb53d24e1fcb555af68

Corrected tree
72170dbf6d8c9f0ecf547b98080c53bb57200a66

Git bundle
Valid; complete history

Commit-to-tree binding
Independently reproduced

Base ancestry
Confirmed

Fresh checkout
Clean

git diff --check
Passed

Packet patch
Byte-identical to independently generated base-to-corrected diff

Accepted v1.3 Manual and Requirements Registers
Byte-identical to the accepted baseline

Phase 1 and Phase 2 checksum sets
Passed

Requirements matrices
133 rows in each
125 accepted requirement IDs + DE-R1 through DE-R8
No missing or duplicate IDs
```

The structural validator also reproduces its reported final-gate result. That result is correctly labeled structural-only; it does not establish semantic satisfaction.

The DE-R8 witness program is deterministic and reproducible. Its corrected one-sided 95% Clopper-Pearson method, `n_min = 149`, first-expansion witness, contraction witness, hard maximum, and old-parameter HOLD witness are credible design evidence for the mathematical portion of `P2G-09`.

---

# 3. Prior-Finding Dispositions

| Finding | Scoped result | Verifier disposition |
| --- | --- | --- |
| **P2G-01** — Semantically invalid requirements gate | **Open** | The ledger is substantially more honest, but it again marks requirements Complete using evidence that does not perform the claimed mechanism; the trace/fold evidence is the most material example. The matrix also diverges from the approved treatment counts and permits unrecorded deliberate deferrals. |
| **P2G-02** — Narrative tests reported as executed | **Open** | The scripts are executable, but the principal comparator does not execute candidate behavior, fold state, compare actual results with expected results, or enforce the complete forbidden-outcome/evidence-separation contract. |
| **P2G-03** — DEC-02 falsifier contract missing | **Substantively closed** | The consequential-decision falsifier fields and owner-card surface are now represented. Final closure depends on consolidating the authoritative schema and removing contradictory earlier text. |
| **P2G-04** — Unsupported record-shape score | **Closed** | The invalid score is withdrawn. S1, S2, and S3 remain viable, and S2 is only a leading hypothesis. |
| **P2G-05** — Stale-policy action race | **Partially closed** | Epoch-bound authorization and pre-execution checking are the right direction, but the policy-commit/execution-lease linearization point and in-flight side-effect semantics are not yet defined tightly enough to prove the claimed guarantee. |
| **P2G-06** — Kill/revoke and resilience asserted, not designed | **Partially closed** | A real control-plane concept, backup contract, watchdog concept, degraded reads, and recovery sequence now exist. The watchdog and kill plane share a common service, and the design still permits a silent engine-plus-watchdog failure window inconsistent with RES-02. |
| **P2G-07** — Quiet-hour behavior contradicted ATT-01 | **Closed** | Verified qualifying danger in every ATT-01 category interrupts through quiet hours; ambiguous fallback is correctly separated. |
| **P2G-08** — Scheduled-run envelope and missed-run detection | **Partially closed** | The envelope is materially improved and missed-run detection is externalized, but recurring-run liveness still depends on the scheduler first writing each `ExpectedRun`. A scheduler that dies before registering the next occurrence may remain silent. |
| **P2G-09** — DE-R8 mathematics | **Closed at design level** | The statistical method and witnesses are now explicit, reachable, reproducible, and consistent with the owner's automatic-expansion intent. Live evidence remains a later build gate as already disclosed. |
| **P2G-10** — Policy composition | **Substantively closed** | Per-output composition, conjoined independent constraints, minimum ceilings, protection floors, scoped exceptions, and fail-closed same-output conflicts are directionally sound. The earlier winner-take-all normative text must be removed or formally superseded in the consolidated artifact. |
| **P2G-11** — Cross-store replay basis incomplete | **Partially closed** | Store ownership and external-evidence ingestion are improved, but the deterministic merge/fold order across separately sequenced authoritative stores is not specified or executed. |
| **P2G-12** — Logical-schema gaps | **Partially closed** | The named missing fields are represented in a correction table, but the artifact retains an earlier conflicting schema and unsupported portability/completeness claims. A single consolidated authoritative schema is still required. |
| **P2G-13** — Untrusted-content isolation and lifecycle | **Partially closed** | Isolation, bounded extraction, provenance, no-outbound floors, and lifecycle enforcement are useful. The default proposal-eligibility rule still conflicts with accepted TRS-02 by allowing filing/summary/placement proposals without an explicit approved policy. |
| **P2G-14** — Owner package asks Hunter to certify technical closure | **Closed** | The prior package is withdrawn and the rebuilt owner surface no longer asks Hunter to waive mandatory controls or certify unsupported architecture scoring. |

---

# 4. Remaining Findings

## P2S-01 — Critical: The machine trace/fold gate is circular rather than behavioral

**Affected:** `D-B12`, `13G`, APP-04, DE-R7, B1/B9/B12 design-gate tests, `design/traces/gen_shape_traces.py`, `design/traces/run_fold_comparison.py`

### Problem

The packet describes an independently runnable fold/projection comparator and machine-executed candidate-specific traces. The supplied programs do not implement that behavior.

`gen_shape_traces.py`:

- Copies each fixture's recorded `trace_S2` sequence.
- Adds only a storage-description string for S1 or S3.
- Copies `expected`, `actual`, `verdict`, and `pass_rule` from the frozen fixture.
- Does not execute an S1, S2, or S3 transition function.

`run_fold_comparison.py`:

- Classifies results by copying `case_verdict` strings from the fixture.
- Compares the three shapes' copied `expected_output` fields, which are necessarily identical because all three came from the same fixture object.
- Scans a limited set of substrings in transition narration.
- Does not fold events into state.
- Does not compare a computed actual state with the expected state or `pass_rule`.
- Does not evaluate the full `forbidden_outcomes_checked` list against a computed result.
- Does not implement the documented external-receipt evidence-separation rule.
- Leaves E2E-1 pending even though the approved plan identifies E2E-1 as a design-gate must-pass test.

Independent inspection confirmed that all 27 fixtures carry identical expected route/attention/authority objects across S1/S2/S3 before the comparator runs. The zero-divergence result is therefore preconstructed rather than discovered.

### Required correction

Provide a genuinely behavioral, deterministic design simulator or equivalent machine-checkable model that:

1. Starts from the fixture's explicit initial state and control envelope.
2. Applies candidate-specific transition and storage/projection rules for S1, S2, and S3.
3. Produces actual events, records, state, queue/attention projections, authority ceilings, and requested actions without copying the fixture's expected result.
4. Compares the computed actual result against the expected result and pass rule.
5. Evaluates every forbidden outcome.
6. Enforces external-receipt ownership before executed/verified state can appear.
7. Replays the full multi-store basis from recorded inputs and model outputs.
8. Fails on missing, unclassifiable, or unexecuted cases.
9. Produces candidate-specific divergences rather than excluding every behavior-affecting difference by assumption.

E2E-1 must either be executed at this design gate as the approved plan requires, or the approved plan must be formally amended through the owner-controlled change process. It cannot remain pending while the gate reports PASS.

### Falsifier for closure

The corrected harness must fail when a seeded candidate defect changes authority, drops a receipt, reorders a causal event, admits a forbidden outcome, or produces a stale projection.

---

## P2S-02 — High: Corrected artifacts retain conflicting normative mechanisms

**Affected:** D-B4, D-B5, D-B6, D-B8, D-B9, D-B11, D-B14, D-GS, 13G

### Problem

Many corrections were appended after the original sections without replacing, restamping, or clearly deactivating the conflicting normative text. A future Builder could implement either rule and cite the same authoritative artifact.

Examples include:

- D-B4's original Scenario 4 still says a stale-policy race is closed by later review, contradicting the new pre-execution authorization rule.
- D-B5 still says kill is available “by construction” and that revocation accepts weaker authentication, while D-KR replaces those claims with a different control design.
- D-B6 retains the old minimum sample, 14-day window, 7-day cooldown, and contraction parameters before appending the corrected 149-sample/28-day/14-day policy.
- D-B8 retains the winner-take-all layered recommendation before appending the per-output composition replacement.
- D-B11 retains scheduler self-report language before appending external watchdog detection.
- D-B14 retains a `JSONB` schema and broad portability/completeness claims before appending a conceptual-type replacement and gap table.

### Required correction

Publish one internally consistent normative design set. Fable may either:

- Rewrite each artifact into a consolidated final form; or
- Add an explicit authoritative supersession map and mark every replaced section non-normative.

The final candidate must contain no active conflicting values or PASS claims. Add a machine check for known superseded phrases and parameter sets.

### Falsifier for closure

A Builder reading only the authoritative artifact must be unable to select two contradictory mechanisms while remaining textually compliant.

---

## P2S-03 — High: RES-02 still has a silent common-mode failure

**Affected:** D-KR §§1 and 3; RES-02; IDN-03; DE-R3

### Problem

The external control service hosts both kill/revoke and the watchdog. The design says the watchdog's own liveness is merely observable by a page the owner can check and that a watchdog outage is surfaced at the owner's next contact. It also discloses a simultaneous engine-plus-watchdog failure window.

That does not satisfy the accepted RES-02 guarantee that a dead system and a quiet system are distinguishable and that silence means safe. If the engine and the shared external control/watchdog service fail together, the owner may receive no notice. Unless action authority also expires without that service, external automation may retain authority during the silent window.

### Required correction

Add an independent dead-man mechanism, such as:

- A separately hosted watchdog-of-watchdog or phone-side heartbeat alarm; and
- Short-lived executor authorization leases that require fresh control-plane heartbeat and fail closed when the control service is unavailable.

The liveness chain, notification path, expiry timing, provider-side revocation, and degraded-read behavior must be explicit. The residual risk cannot be accepted as satisfying RES-02.

### Falsifier for closure

Simultaneous loss of the engine host and primary control/watchdog service must either stop external action within a declared bound and notify the owner independently, or fail the design gate.

---

## P2S-04 — High: Recurring scheduled-run failure can still go undetected

**Affected:** D-B11; SCH-02; RES-02

### Problem

The corrected model writes an `ExpectedRun` “at scheduling time.” That detects failure after an expected occurrence has already been registered. It does not prove detection when the scheduler dies before it registers the next recurrence.

A recurring scheduler could complete today's run, fail before materializing tomorrow's `ExpectedRun`, and leave the watchdog with no overdue record to inspect.

### Required correction

Either:

- Give the independent watchdog the authoritative schedule definition and make it compute expected deadlines itself; or
- Require the scheduler to maintain a rolling, future-dated `ExpectedRun` horizon whose exhaustion is independently alarmed.

Add a deterministic test for scheduler death before next-occurrence registration and a test for horizon exhaustion.

---

## P2S-05 — High: Policy revocation and external side-effect execution lack a defined linearization point

**Affected:** D-B4 §2.3; DE-R2; ACT-01; executor contract

### Problem

The design requires a pre-execution epoch check and CAS/lease “immediately before” the side effect. It does not define an atomic order between:

- The stricter PolicyVersionEvent commit;
- Authorization-lease acquisition; and
- The start of the external side effect.

A policy can change after the check or lease acquisition but before the external provider accepts the side effect. The current statement that an authorization that lost its epoch “cannot” produce a side effect is stronger than the specified mechanism proves.

### Required correction

Define the serialization and in-flight contract:

1. Policy commits and authorization-lease acquisition must serialize through the same authority store or equivalent atomic protocol.
2. If the policy commits first, lease acquisition fails.
3. If the lease is acquired first, the action is explicitly recorded as in flight under that epoch; later policy change cannot claim it was prevented.
4. Leases are short-lived and single-use.
5. Provider-side kill/revoke handles urgent cancellation where supported.
6. Uncertain outcomes follow ACT-01 reconciliation and never blind retry.

Add traces for policy-before-lease, lease-before-policy, policy-after-provider-acceptance, lease expiry, and uncertain provider response.

---

## P2S-06 — High: Cross-store replay has no deterministic merge order

**Affected:** D-B4, D-B9, DE-R7, APP-04

### Problem

The corrected replay basis now includes intake, recorded model output, policy, identity, schedule, connector, evidence-ingestion, and canonical events. The design says the fold consumes them “in recorded order,” but no global recorded order exists:

- Intake order is partition-scoped.
- Policy has its own total order.
- Other authoritative stores have separate sequences.
- `caused_by[]` captures some causality, not every tie.
- Source timestamps are explicitly non-authoritative.

A deterministic replay cannot rely on an undefined cross-store ordering.

### Required correction

Specify one of the following:

- A deterministic causal topological fold with explicit tie-break rules for concurrent independent events; or
- A proof that unordered event effects commute, plus deterministic ordering only for the non-commutative subsets.

Every authoritative event type must declare its ordering key, causal dependencies, conflict behavior, and fold phase. The corrected behavioral harness must reproduce the same result after randomized delivery order that preserves causal edges.

---

## P2S-07 — High: The default proposal rule conflicts with accepted TRS-02

**Affected:** D-B2 P2G-13 correction; TRS-02

### Problem

Accepted TRS-02 says untrusted content cannot directly trigger proposals or outbound actions absent an explicit approved policy. The corrected design instead makes external-untrusted claims eligible by default for filing, summary, and placement proposals and requires owner-ratified policy only for action-triggering proposals.

That silently weakens the accepted requirement.

### Required correction

The default must be:

- Isolated extraction and summarization are allowed as data processing.
- No operational proposal class—including filing or placement—may be triggered directly from untrusted content unless an explicit, versioned, approved eligibility policy permits that proposal class and source class.
- Even when permitted, the untrusted source remains provenance-labeled and cannot increase authority.
- Outbound action remains subject to the separate verified-origin protection floor.

Add a negative test showing that extracted claims without an eligibility policy produce no proposal, and a positive test showing that an approved filing-only policy permits filing while still blocking outbound action.

---

## P2S-08 — Medium: The approved plan, treatment matrix, and deliberate-deferral gate are inconsistent

**Affected:** CP-P2-A §3/§4/§7; 13M; 13G; 13V

### Problem

The approved plan records:

```text
Binding:       53
Design subject: 67
Deferred:       3
N/A:            2
```

The corrected matrix contains:

```text
Binding:        60
Design subject: 60
Deferred:        3
N/A:             2
```

The reclassifications do not appear to relax the gate because both Binding and Design subject are required, but the authoritative plan and execution matrix no longer match.

The plan also states that Binding, Design subject, and proposed DE-R rows must be Complete or explicitly permitted Build-gate deferred. It says Deliberately deferred requires plan-authorized rationale and a recorded gate disposition. The current final-gate validator nevertheless accepts fourteen Deliberately deferred rows without a dedicated, enumerated gate disposition authorizing each deferral.

### Required correction

- Restamp the approved plan's treatment counts or restore the approved matrix allocation through proper change control.
- Create an explicit gate-disposition register for every Deliberately deferred requirement, including authority, rationale, destination topic/change plan, dependency, and reopening trigger.
- Make `13V` validate the deferral register rather than accepting any non-empty rationale cell.
- Regenerate 13G statuses after P2S-01 through P2S-07 are corrected; rows depending on unresolved mechanisms cannot remain Complete.

---

# 5. Directions That Survived Review

The following design directions remain suitable and should be preserved through correction:

- Model proposals are separated from authoritative control fields.
- Identity, source-event identity, ingestion identity, case correlation, and action idempotency remain distinct.
- Business and Personal queues remain structurally partitioned.
- Execution and verification evidence remains externally owned.
- Policy objects are versioned and protection floors are non-overridable.
- Per-output constraint composition is preferable to winner-take-all policy selection.
- Corrections are append-only and preserve original history.
- Verified Critical events honor ATT-01 through quiet hours.
- DE-R8 expansion and contraction use independent evidence and mathematically specified thresholds.
- S1, S2, and S3 remain viable until valid behavioral evidence supports a selection.
- Owner cards remain plain-language surfaces for business judgment rather than technical certification.

---

# 6. Required Next Packet

Fable should return one bounded corrected-design packet containing:

1. Keyed dispositions for `P2S-01` through `P2S-08`.
2. A real deterministic candidate transition/fold simulator and seeded-failure tests.
3. Either completed E2E-1 evidence or an owner-approved plan amendment changing its gate.
4. Consolidated, contradiction-free normative D-B artifacts.
5. A fail-safe kill/watchdog/dead-man contract.
6. Correct recurring-schedule liveness design.
7. A linearized policy-authorization/execution protocol.
8. A deterministic cross-store replay-order contract.
9. TRS-02-compliant proposal eligibility.
10. Reconciled plan/matrix treatments and a machine-validated deliberate-deferral register.
11. Rebuilt 13G status claims from the corrected semantic evidence.
12. Exact base-to-corrected diff, valid Git bundle, commit/tree binding, and complete manifest/checksums.

No rediscovery is required. No owner decision needs to be reopened unless Fable proposes changing the approved plan or accepted requirement semantics. Builder involvement remains unauthorized unless Fable creates a separately scoped, owner-authorized task for a design-test harness.

---

# 7. Gate State

```text
Accepted v1.3 baseline:             UNCHANGED
Accepted Phase 2 discovery:         VALID
Approved CP-P2-A plan:              VALID
Corrected packet integrity:         PASS
P2G-03 / 04 / 07 / 09 / 14:        CLOSED or substantively closed
P2G-01 / 02 / 05 / 06 / 08 / 11:   OPEN or partially closed
P2G-10 / 12 / 13:                   SUBSTANTIVELY IMPROVED; consolidation/correction required
Design-gate verdict:                FAIL
Recommendation/policy hypothesis:   PLAUSIBLE, NOT PROVEN END-TO-END
Record-shape selection:             NOT MADE
DE-R1 through DE-R8 acceptance:     NOT AUTHORIZED
Owner design package:               BLOCKED
Owner design acceptance:            BLOCKED
TASK-0003+ Builder authorization:   BLOCKED
v1.4 amendment/build/release:       BLOCKED
Next actor:                         FABLE
Next verifier action:               SCOPED REVIEW OF ONE CORRECTED CANDIDATE
Hunter action required now:         NONE
```

---

# 8. Termination Rule for This Correction Cycle

The next review remains limited to the findings above and any direct contradiction or Critical/High defect introduced by their corrections.

- Cosmetic improvements, optional refinements, and unrelated features become later backlog items.
- The verifier will not require runtime production proof at a design gate where the approved plan explicitly permits build-gate verification.
- The verifier will require actual behavioral evidence where the approved plan says the design gate itself must pass.
- The design gate passes when the evidence claims are truthful, reproducible, semantically responsive to the exact requirements, and free of unresolved Critical or High defects.

