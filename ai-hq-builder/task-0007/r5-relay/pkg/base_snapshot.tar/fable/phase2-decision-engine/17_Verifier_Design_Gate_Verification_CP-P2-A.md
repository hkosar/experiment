# ChatGPT Independent Verifier Response — CP-P2-A Design Gate

**Review target:** CP-P2-A Decision Engine design-gate packet  
**Packet SHA-256:** `9cf5ce5fbb3e6aed32a962a53ad145cae14155697d5ef1eaff35de4fed43169d`  
**Gate commit:** `20ad093c7535928e07bcc7ef819236a6bed62929`  
**Gate tree:** `37f32c6b1501729df3f00770128431820891a295`  
**Role:** Independent verifier / auditor  
**Date:** 2026-07-29

---

## 1. Verdict

# **FAIL — DESIGN GATE NOT PASSED**

The packet is authentic, reproducible, and internally well assembled. The design direction contains several strong mechanisms worth preserving. However, the central gate claim—**14/14 B items Complete and 133/133 requirement rows resolved**—is not supported by the underlying evidence.

The failure is substantive rather than clerical:

1. The requirement-to-evidence overlay marks many accepted requirements Complete using artifacts that do not implement or test those requirements.
2. The final-gate validator verifies formatting and status presence, not semantic support.
3. Several required “executed” design-gate tests are narrative walkthroughs or structural assertions rather than the machine-checkable traces required by the approved plan.
4. Core protection and control mechanisms remain contradictory or incomplete, including stale-policy execution, degraded-mode kill/revoke, quiet-hour interruption, scheduled-run liveness, automatic cap expansion, event integrity, and authoritative schema coverage.
5. The current owner decision package asks Hunter to approve choices that are either based on unsupported technical evidence or already constrained by accepted protection requirements.

This verdict does **not** reject the Decision Engine concept, the accepted discovery work, or the recommendation-versus-policy separation hypothesis. It means the current design set is not yet sufficiently complete or evidenced for owner design acceptance or build authorization.

---

## 2. Independent Packet Verification

The packet mechanics passed independent reproduction:

```text
Uploaded ZIP SHA-256
9cf5ce5fbb3e6aed32a962a53ad145cae14155697d5ef1eaff35de4fed43169d
Matches supplied value: YES

Packet checksums
24 / 24 passed

Exported repository-file hashes
21 / 21 passed

Git bundle
Valid; complete history

Gate commit
20ad093c7535928e07bcc7ef819236a6bed62929

Gate tree
37f32c6b1501729df3f00770128431820891a295

Commit-to-tree binding
Independently reproduced

Fresh checkout
Clean

git diff --check
Passed

Accepted v1.3 baseline hashes
Manual:   30b020c5724308373c289c28c030c48e8cbdb6d317062dea0e9197a69219f867
Register: 972be5cad10061e66b855425e97de44edc196d845a57710aa36f407fdcc95046
CSV:      8fb88b6b6bd762029703f24a8a0bbb5f61284f58a9c3a9eceb69c5c010ffb24c
All unchanged: YES

13V structural validator
PASS under --final-gate
```

The `13V_` PASS is a **structural** result only. Its code checks exact ID order, allowed treatment/status enums, and the presence of nonempty evidence and result cells. It does not determine whether the cited artifact actually satisfies the accepted requirement. That distinction is central to P2G-01.

---

## 3. What Should Be Preserved

The following design directions remain valuable and should be retained while correcting the gate:

- Separation of authoritative control fields, deterministic derived fields, and model-proposed semantic fields.
- Distinct local-ingestion, source-native, deduplication, case/correlation, and action-idempotency identities.
- Per-object optimistic concurrency plus intent/reconciliation for multi-object operations.
- External ownership of execution and verification evidence.
- Hard Business and Personal partitioning inside one governed mechanism.
- Versioned policy objects, explicit protection floors, and governed exceptions.
- Append-only correction rather than history rewriting.
- A deterministic recommendation/policy boundary in which model output cannot raise authority.
- Owner-facing cards that explain options and consequences in plain language.
- A provider-independent operating model and the decision not to select a database product at this stage.

These are promising components. The findings below concern their completeness, interaction, proof, and accepted-requirement coverage.

---

# 4. Findings

## P2G-01 — Critical — The requirement gate is semantically invalid

**Disposition:** Dissent from `13G_`'s 133/133 resolved claim and D-GS §1's design-gate completion claim.

### Problem

`13M_` and `13G_` repeatedly map materially different accepted requirements to the same generic artifact and test language, then mark each Complete. The cited evidence often has no mechanism or test for the actual requirement.

The validator cannot catch this because `13V_` checks only that a Complete row has nonempty evidence and result text.

### Representative examples

| Accepted requirement | What it actually requires | Current completion evidence | Verification result |
| --- | --- | --- | --- |
| AUT-03 | Tests, independent review, security checks, staging, rollback, and plan comparison | D-B6 autonomy objects and cap overflow | Not responsive |
| AUT-07 | Delegation remains tracked through closeout | D-B6 fail-closed input verification | Not responsive |
| AUT-09 | Verified / owner-accepted / needs-review completion modes | D-B6 owner cap override | Not responsive |
| AUT-10 | Read-only verification and owner-controlled employee correction | D-B6 receipt contract | Not responsive |
| AUT-11 | Later-evidence reconciliation without erasing To-Did history | D-B6 cooldown and step-size bounds | Not responsive |
| BUS-02 | Data HQ connections, health, permissions, definitions, and cross-system data topics | Partitioned autonomy objects and queues | Not designed |
| BUS-03 | Lead/ad/call/transcript/rating/insight/improvement closed loop | Partitioned autonomy objects and queues | Not designed |
| BUS-04 | Read-only MCP beginning and governed write expansion | Partitioned autonomy objects and queues | Not designed |
| EX-01 | Reception accepts unstructured input | Executive Desk partition rendering and cards | Not designed/tested |
| EX-05 | Interchangeable phone/PC operation | Executive Desk partition rendering and cards | Not designed/tested |
| EX-11 | Semantic recall from any surface | Executive Desk partition rendering and cards | Not designed/tested |
| ORG-01 | Arbitrary-depth typed-role tree | Event taxonomy plus queue rendering | Not designed/tested |
| ORG-04 | Layered To-Do/To-Did topic-plus-next-action format | Event taxonomy plus queue rendering | Not designed/tested |
| ORG-07 | Three-question structure test and quarterly archive sweep | Event taxonomy plus queue rendering | Not designed/tested |
| RES-01 | Automated backups and verified restores | Degraded-capability matrix | Not designed |
| RES-02 | Independent watchdog outside host and Discord | Failure-combination matrix | Not designed |
| RES-03 | Read-only access, export, and recovery runbook | Reconciliation sequence | Incomplete |
| SCH-02 | Full authenticated, scoped, hash-bound scheduled-run envelope | Schedule/scope/permissions/output/failure/policy fields | Material fields absent |
| DEC-02 | Consequential Decision records carry a falsifier | Each design artifact has a reopen section | Different requirement |
| QUE-01 | Caps, batching, deduplication, snooze, escalation, aging, and load measures | Admission, ordering, and aging only | Incomplete |

The same pattern affects portions of BUS, EX, LRN, ORG, WF, LOG, DAT, and RES.

### Required correction

Rebuild `13M_` and `13G_` from the **exact accepted requirement text**, not requirement-family shorthand.

Every required row must carry:

```text
requirement_id
exact requirement text or text hash
applicability treatment
specific mechanism or invariant
artifact + exact section
specific test or review method
actual result
remaining dependency
honest gate status
```

A row may be:

- Complete when the actual requirement is designed and evidenced.
- Binding constraint when it remains an invariant but needs no new design.
- Build-gate deferred only where the approved plan permits it.
- Deliberately deferred only with an approved rationale.
- Incomplete when the mechanism is not present.

The validator should continue enforcing structure, but semantic acceptance remains a human-verifier responsibility. It must not describe nonempty-cell validation as proof of requirement completion.

### Acceptance condition

A corrected matrix survives a requirement-by-requirement semantic audit with no material false-positive Complete rows. D-GS and D-B12 counts must be regenerated from that corrected result.

---

## P2G-02 — High — Required design-gate tests are reported as executed without the required evidence

**Disposition:** Dissent from the blanket PASS claims in D-B12 and the “all fourteen B items Complete” claim.

### Problem

The approved plan requires, among other evidence:

- Per-shape machine-checkable replay traces for B1.
- Harness-executed replay reports and an empty divergence log for B9.
- Machine-checkable traces for B12.
- An E2E-1 raw-input substitution run.

The delivered artifacts instead rely heavily on narrative reasoning:

- `03F_` contains prose `actual` strings and shape deltas, not candidate-specific transition logs.
- D-B1 treats those strings as 27/27 per-shape replay evidence.
- D-B9 explicitly defers the executable fold harness to TASK-0003+, yet marks the replay-divergence gate PASS at design level.
- D-B12 “re-executes” checks by citing structural properties in the design documents; it does not produce a separate executed trace set.
- E2E-1 is a structural argument, not a two-normalizer or two-model execution.

### Required correction

Fable must choose one governed path:

**Path A — provide design-gate evidence:** create machine-readable candidate-specific traces with:

```text
fixture_id
candidate_shape
starting state and versions
ordered transition sequence
produced records/events
expected output
actual output
forbidden outcomes checked
evidence hashes
verdict
```

Add an independently reproducible fold/projection comparison over at least the complete synthetic fixture set.

**Path B — amend the plan:** formally reclassify specific executable tests to the build gate, reduce the design-gate claims to “design reviewed,” and obtain the required approval for that changed evidence contract.

The current plan explicitly says these tests must pass at the design gate, so the packet cannot silently use Path B after execution.

### Acceptance condition

D-B12 distinguishes analysis, structural proof, simulation, and executable evidence. Every PASS label accurately identifies which class of evidence supports it.

---

## P2G-03 — High — DEC-02 is not implemented in Decision records

**Disposition:** Dissent from DEC-02 = Complete.

### Problem

DEC-02 requires each consequential **Decision record** to include evidence or conditions that would materially change or reverse the decision, or an explicit `unknown` / `none identified` value with rationale and a review trigger.

The packet instead treats the “falsifier/reopen” section on each design artifact as satisfaction of DEC-02. Those artifact-level reopen rules do not place a falsifier on operational DecisionEvents, Decision records, schemas, or owner surfaces.

D-B9 names `DecisionEvent`; D-B14 provides no falsifier fields; D-B13 cards provide no “what would change this decision” field.

### Required correction

Add a consequential-decision contract such as:

```text
falsifier_status: identified | unknown | none_identified
falsifier_statement
supporting_or_disconfirming_evidence_refs
review_trigger
rationale_when_unknown_or_none
last_evaluated_at
```

Carry it through:

- Decision event/record taxonomy
- Operational schema
- Replay basis
- Owner card tap-through
- Correction/reconciliation path
- At least one positive and one `unknown` test

### Acceptance condition

A consequential Decision replay reproduces its falsifier and review trigger; a later matching event creates the governed re-review path without rewriting the original decision.

---

## P2G-04 — High — The record-shape score and near-tie result are not supported

**Disposition:** Dissent from S2=18 / S1=17 / S3=13 as a valid design-gate comparison and from dropping S3 as a co-leader.

### Problem

The preregistered missing-evidence rule requires an unsupported criterion to score zero and block selection. Several scores are unsupported or measure something other than the named criterion:

- Criterion 7 is named interactive **capture** latency, but D-B1 says capture/ack is identical and then scores read-back/assembly behavior.
- Criterion 8 uses the B5 matrix, which is described as shape-neutral, yet assigns shape-specific quality scores without candidate-specific degraded traces.
- Criterion 9 assigns owner mental-model and visible-staleness scores without rendered candidate prototypes or owner comparison.
- Criterion 10 is a qualitative component/failure-surface judgment without a frozen counting method.
- The discovery fixtures contain short prose outcome labels, not the per-shape machine-checkable traces required by B1.

### Required correction

Separate the comparison into two stages:

1. **Design invariants:** all shapes must satisfy identity, evidence, concurrency, replay, and protection requirements.
2. **Measured or countable tradeoffs:** define exact measurement units and produce normalized candidate artifacts or prototypes.

Candidate 7 should either be renamed to interactive case-read/render latency and measured accordingly, or scored identically if the intended metric is capture latency.

Until qualifying evidence exists:

- S1, S2, and S3 remain viable.
- S2 may remain a leading architectural hypothesis.
- No total score should be used for owner or build selection.
- ODG-3 should not ask Hunter to certify an internal storage choice from this scorecard.

### Acceptance condition

Every nonzero score has a reproducible measurement or a predeclared countable method. Missing evidence produces the preregistered zero/insufficient-evidence result.

---

## P2G-05 — High — The stale-policy race can authorize an action after a stricter policy takes effect

**Disposition:** Dissent from D-B4 Boundary 3 = Complete.

### Problem

D-B4 allows an evaluation pinned to P1 to complete after P2 commits, then flags the result for later review if P2 is stricter. That preserves replayability of the decision, but it does not safely govern an **unexecuted external action**.

A T2 ActionRequest created under P1 could reach the executor after P2 has revoked or narrowed its authority. Post-commit review is too late once the side effect occurs.

### Required correction

Separate durable decision truth from execution authorization:

```text
decision_basis_policy_version
action_authorization_policy_epoch
authorization_expires_at
pre_execution_policy_check
executor_compare_and_swap / lease
revoked_by_policy_event
```

A stricter PolicyVersionEvent must invalidate or suspend unexecuted authorizations in its affected scope. The controlled executor must recheck the current policy epoch immediately before the side effect. Already-uncertain or already-executed actions follow ACT-01 receipt and reconciliation rules rather than being silently retried.

### Acceptance condition

A race trace demonstrates that a P1 DecisionEvent remains historically valid while its pending ActionRequest is prevented from executing after a stricter P2 policy takes effect.

---

## P2G-06 — High — Degraded-mode kill/revoke and resilience are asserted, not designed

**Disposition:** Dissent from D-B5, DE-R3, RES-01, RES-02, and RES-03 = Complete.

### Problem

D-B5 marks kill/revoke available in every failure row, including total failure, by asserting that it is an independent path “by construction.” The independent path is not specified.

Open gaps include:

- Independent transport and control-plane location
- Authentication and recovery when identity services are degraded
- Direct revocation of provider/service credentials or executor authority
- Durable receipt when the event log and local buffer are unavailable
- Independent liveness monitoring
- Recovery and reauthorization semantics

D-B5 also says kill may accept weaker authentication than granting. Without a concrete threat model and recovery control, this can create a denial-of-service path.

The same artifact is used to mark complete three different resilience requirements that actually require:

- Automated backups plus verified restore tests
- A watchdog outside the host and Discord
- Degraded read-only access, export, and a recovery runbook

Those mechanisms are not present.

### Required correction

Design the kill/revoke control plane separately from the Decision Engine data path, including:

- Independent channel/service and protected owner identity
- Fail-safe authentication and account-recovery rules
- Exact authorities it revokes
- Provider/executor-side enforcement
- Receipt and external verification strategy
- Recovery and controlled re-enable sequence
- Abuse/DoS controls

Separately design RES-01 through RES-03: backup/restore contract, independent heartbeat watchdog, degraded read/export surface, and recovery runbook.

### Acceptance condition

Failure traces show kill/revoke operating without depending on the failed components, and resilience rows are supported by their actual mechanisms rather than the generic failure matrix.

---

## P2G-07 — High — Quiet-hour behavior contradicts the accepted owner policy

**Disposition:** Dissent from D-B7 §3 as an accurate instantiation of OD-1.

### Problem

The accepted owner package states:

> Qualifying danger interrupts through quiet hours; everything else holds for the morning brief.

ATT-01 includes immediate physical, legal, financial, security, or comparably consequential danger.

D-B7 §3 instead says only physical-danger and security categories fail toward interrupting during quiet hours and that all others hold to the next briefing. This improperly suppresses already-qualified immediate legal, financial, or comparable danger.

The design appears to have confused two different rules:

- **Verified qualifying danger:** interrupts through quiet hours across the full ATT-01 boundary.
- **Ambiguous urgency fallback:** physical/security may fail toward interruption while other ambiguous claims hold.

### Required correction

Separate the verified-critical rule from the ambiguity fallback. The quiet-hours object must not narrow an already-qualified ATT-01 Critical event.

### Acceptance condition

Boundary traces include verified physical, legal, financial, security, and comparable danger during quiet hours, plus ambiguous examples for each category. Verified qualifying danger interrupts; ambiguity follows the owner-ratified fallback.

---

## P2G-08 — High — Scheduled-run envelopes are incomplete and missed-run detection is circular

**Disposition:** Dissent from SCH-02 and D-B11 = Complete.

### Problem

D-B11 says a due run that does not fire emits its own failure notice. A dead or stalled scheduler cannot reliably emit an event announcing that it failed to run. Missed-run detection requires an independent expected-heartbeat or deadline monitor.

The described ritual envelopes also omit much of SCH-02's mandatory contract, including:

- Authenticated actor and authority
- Trust and data classes
- Current checkpoint and schema versions
- Complete active scoped rules/policies
- Idempotency and failure constraints
- Rollback/recovery requirements
- Evidence and log destinations
- Hash-bound, time-bounded context/source manifest

D-B14 references `schedules.envelope_id` but defines no schedule-envelope record.

### Required correction

Create a full `ScheduledRunEnvelope` schema matching SCH-02 and an independent `ExpectedRun` / heartbeat watchdog that detects a missed deadline without relying on the failed scheduler.

Add tests for:

- Missing or stale context manifest
- Duplicate schedule tick
- Scheduler failure before start
- Failure after partial output
- Policy/schema change between scheduling and execution
- Independent missed-run notice

### Acceptance condition

The SCH-02 field audit covers the exact accepted field set, and a dead scheduler is detected by an independent component.

---

## P2G-09 — High — The DE-R8 expansion rule is statistically underspecified and may be unreachable

**Disposition:** Dissent from D-B6 DE-R8 = Complete.

### Problem

The cap policy requires the 95% confidence-interval upper bound on failure/correction/reversal rate to be below 2%, but it does not define:

- The confidence-interval method
- One-sided versus two-sided treatment
- The denominator when exclusions apply
- How overlapping correction/reversal/failure events count
- How multiple actions for one item count

At the initial cap of 20/day, a rolling 14-day window with actions younger than seven days excluded yields at most about 140 mature actions before the first expansion. With zero failures, a common exact one-sided 95% upper bound is approximately 2.12%; a common two-sided exact upper bound is higher. Under those methods, the first expansion cannot occur despite a perfect record.

The test set includes sparse-sample refusal and maximum enforcement but no positive witness proving that the initial cap can actually expand under the declared parameters.

There is also an action-class inconsistency: the policy is described as one `filing-routing` class, while the cross-category test treats email filing and document filing as distinct action classes.

### Required correction

Predefine:

- Exact interval method and sidedness
- Outcome and denominator semantics
- Mature-event window arithmetic
- Action-class taxonomy and scope keys
- How delayed corrections alter prior evidence
- A positive initial-cap expansion witness
- A negative witness and contraction witness

The parameters must be mathematically capable of producing the owner-requested evidence-driven expansion path.

### Acceptance condition

A machine-reproducible evidence stream demonstrates the first permitted expansion from 20/day and independently reproduces the resulting cap event.

---

## P2G-10 — High — Policy precedence lacks cross-domain composition semantics

**Disposition:** Concur with the layered-composite direction; dissent from its selection as complete.

### Problem

D-B8 says non-floor policies resolve by “authority domain class, then explicit priority,” but it does not define the ordering of authority-domain classes. More importantly, a winner-take-all rule is inappropriate when applicable policies constrain different fields or impose nonconflicting limits.

For example, a routing policy, data-render policy, and autonomy-cap policy may all apply simultaneously. Selecting one “winner” could discard valid constraints from the others.

### Required correction

Define resolution per output/constraint domain:

- Floors compose as an intersection of restrictions.
- Independent nonconflicting constraints all apply.
- Priority resolves conflicts only over the same governed output or constraint.
- Stricter ceilings combine by minimum authority.
- Exceptions replace only the named target and fields within their legal scope.
- Equal-priority contradictions over the same field fail closed.

Add cross-domain, partial-overlap, and multiple-floor cases. Define the authority-domain ordering only where ordering is truly required.

### Acceptance condition

Replay proves that applying an autonomy policy cannot discard an applicable data-rendering or security policy, and that independent constraints compose deterministically.

---

## P2G-11 — High — Event/replay integrity is incomplete across authoritative stores

**Disposition:** Dissent from D-B9 / DE-R7 = Complete.

### Problem

The transactional outbox is defined for canonical-state CAS commits, but the architecture contains other authoritative stores and transitions:

- Intake append
- Policy-plane changes
- Schedule-plane transitions
- Queue admission/aging state
- Identity/session changes
- External receipt/verification ingestion
- Connector/registry changes

The design does not define an atomic event/outbox or reconciliation contract for each owner. A fold over only `events` and `recorded_model_outputs` is insufficient unless all external facts and policy/schedule/identity changes are first captured as immutable ingestion events with exact source identity and content hash.

The assertion that any worker can die without loss is premature until every authoritative mutation is covered by that contract and the fold is actually run.

### Required correction

Produce a store-ownership and transition matrix:

```text
object/transition type
authoritative store
write authority
atomic event/outbox mechanism
source receipt or hash
reconciliation method
replay input
projection outputs
failure behavior
```

Define how external receipts enter the event log without becoming engine-authored evidence. Expand the replay basis to include all recorded policy, identity, schedule, connector, and external-evidence ingestion events.

### Acceptance condition

Every authoritative transition has exactly one owner and one recoverable event/outbox path; the replay harness can rebuild all declared authoritative and visible surfaces from the frozen record set.

---

## P2G-12 — High — The logical schema omits required control, audit, queue, scheduling, and cost fields

**Disposition:** Dissent from D-B14 = Complete and from its 100% coverage claim.

### Material gaps

- `action_requests` declares an `aik` unique per `attempt_epoch` but has no `attempt_epoch` field.
- `events.ingest_seq` has no partition key in the logical uniqueness/order contract.
- `caused_by` is singular and cannot represent multi-cause decisions or fold-backs.
- Decision records have no DEC-02 falsifier fields.
- Event/log records lack true actor identity, session identity, component identity/version, and tool-call/outbound/write/deploy details required by LOG-01.
- No writer-isolation or tamper-evident enforcement represents LOG-02.
- `schedules.envelope_id` points to no defined envelope store and cannot hold SCH-02.
- Queue items lack caps, batching, deduplication, snooze, escalation, due dates, and load metrics required by QUE-01.
- Cost evidence lacks token/usage quantity, currency/unit, provider/account coverage, date range, and missing-source disclosure required by CAP-03.
- Policy objects contain metadata but no explicit policy body/effect or per-output constraint representation.
- DAT-01's collection, retention, model access, rendering, redaction, export, and deletion policy is not represented.
- The claim of product neutrality is overstated: `JSONB` is product-specific notation unless explicitly treated as a conceptual document field with portability constraints.

### Required correction

Revise the logical schema and coverage table against the exact accepted requirement surface. Add constraints and ownership, not only columns. Distinguish conceptual types from product-specific implementation notation.

### Acceptance condition

The corrected coverage audit maps every required field and behavior to a record, constraint, actor, event, or deliberately deferred build mechanism without unsupported “100%” language.

---

## P2G-13 — High — Untrusted-content and data-lifecycle protections are incomplete

**Disposition:** Concur with instruction-authority separation; dissent from TRS-02 and DAT-01 = Complete.

### Problem

B2 proves that untrusted text cannot write the `instruction_authority` field. That is useful but narrower than TRS-02.

TRS-02 also requires reduced tool scopes and isolated context, and says untrusted content cannot directly trigger proposals or outbound actions. D-B6 permits model-produced action-class, risk, placement, and relationship suggestions from semantically analyzed untrusted content. Those suggestions can lower authority or escalate attention and therefore are operational proposals. The design does not define an isolation boundary, an admissible extraction schema, or the policy step that prevents raw untrusted content from directly becoming a proposal or outbound-action basis.

DAT-01 requires per-class lifecycle rules for collection, storage, retention, model access, rendering, redaction, notification preview, export, and deletion. Carrying `data_class` as a field does not implement that lifecycle.

### Required correction

Add:

- Isolated untrusted-content processing context with reduced tools
- Bounded structured extraction outputs
- Provenance on every extracted claim
- Proposal-eligibility policy separating extraction from recommendation
- Rule that no outbound action is authorized solely from untrusted semantic content
- Per-data-class lifecycle policy objects and enforcement points

### Acceptance condition

An adversarial content trace may influence a safe summary or extracted fact, but cannot author a control field, directly create an actionable proposal, widen tool scope, or cause an outbound action without an independently authorized policy path.

---

## P2G-14 — High — The owner decision package is not ready for Hunter

**Disposition:** Block D-ODP owner gate.

### Problems

- **ODG-1** describes safety/security/legal/audit floors but omits the accepted resilience floor used elsewhere in the design.
- **ODG-2** frames step-up confirmation for cap increases as an owner option. IDN-02 is already an accepted protection requirement. Hunter may choose the cap and activation timing; the design should not ask him whether the accepted step-up floor applies.
- **ODG-3** asks Hunter to act on the unsupported S1/S2 score and an internal storage design decision. The technical team and verifier should first produce valid evidence and present only owner-visible consequences.
- **ODG-4** proposes testing whether raw content is necessary using email metadata. Metadata cannot falsify a claim about whether content must be read. A valid test needs minimized/redacted content or a content-versus-metadata comparison under the data gate.
- **ODG-5** is a legitimate owner preference item and may remain.

### Required correction

Rebuild D-ODP only after the corrected design gate. The owner should receive:

- Genuine business/experience decisions
- Consequences and residual risks
- Fable's recommendation
- Verifier status
- Explicit statement of what is already fixed by accepted protection requirements

Hunter should not be asked to certify unresolved technical architecture or waive mandatory controls through a preference card.

### Acceptance condition

Every owner item is both necessary and within the owner's actual judgment value. Technical closure remains with Fable and the verifier.

---

# 5. Artifact-Level Gate Disposition

| Artifact / work item | Verifier disposition |
| --- | --- |
| B1 Record-shape comparison | **Incomplete** — comparison evidence and scoring invalid |
| B2 Field-authority contract | **Concur with modification** — useful core; TRS/DAT boundary incomplete |
| B3 Identity and deduplication | **Concur with modification** — useful core; carry through schema and runtime evidence |
| B4 Concurrency and ordering | **Incomplete** — stale-policy execution race |
| B5 Degraded operation | **Incomplete** — independent kill/resilience not designed |
| B6 Tier/policy/autonomy | **Incomplete** — DE-R8 statistics and trust/action boundaries incomplete |
| B7 Attention/quiet hours | **Incomplete** — contradicts accepted OD-1/ATT-01 behavior |
| B8 Policy objects/precedence | **Concur with modification** — composite direction promising; composition incomplete |
| B9 Event model/replay | **Incomplete** — cross-store coverage and executable proof absent |
| B10 Partitioned queues | **Concur with modification** — partition core sound; QUE/EX/ORG coverage incomplete |
| B11 Ritual integration | **Incomplete** — SCH-02 envelope and independent liveness absent |
| B12 Test report | **Failed** — evidence classes overstated and gate result unsupported |
| B13 Owner/card templates | **Concur with modification** — add DEC-02 and rebuild owner items |
| B14 Logical schema | **Incomplete** — material coverage gaps |
| D-GS selection record | **Not accepted** |
| D-ODP owner package | **Blocked** |
| D-AM v1.4 amendment package | **Blocked** pending corrected design acceptance |

---

# 6. Required Corrected Design Packet

Fable should return a corrected design-gate packet containing:

1. Keyed dispositions for `P2G-01` through `P2G-14`.
2. Rebuilt `13M_` and `13G_` with exact requirement semantics.
3. An updated validator that checks referential integrity and evidence artifacts, while clearly stating that semantic verification is external.
4. Corrected B artifacts and exact diff from gate commit `20ad093...`.
5. Machine-readable design traces or an approved plan amendment reclassifying executable tests.
6. Revised record-shape comparison retaining S1/S2/S3 until qualifying evidence exists.
7. Corrected Decision falsifier, policy-race, degraded-control, attention, schedule, DE-R8, precedence, event, and schema designs.
8. Rebuilt D-B12 with honest evidence labels and regenerated completion counts.
9. Rebuilt D-GS and D-ODP.
10. Full Git bundle, commit/tree binding, packet manifest, and 100% checksums.
11. Proof that the accepted v1.3 Manual and register remain unchanged.
12. Explicit claims not made: no owner design acceptance, no DE-R acceptance, no shape selection, no build authorization, and no v1.4 release.

The next review may remain scoped to these findings if the design's accepted discovery basis and owner decisions are not reopened.

---

# 7. Gate State

```text
Accepted v1.3 baseline:                 UNCHANGED
Accepted Phase 2 discovery:             VALID
CP-P2-A approved design plan:           VALID
Packet authenticity and provenance:     PASS
Design-gate semantic result:            FAIL
Recommendation/policy hypothesis:       PLAUSIBLE; NOT YET PROVEN END-TO-END
Record-shape selection:                 NOT MADE; S1/S2/S3 REMAIN VIABLE
Policy-precedence selection:             NOT ACCEPTED
DE-R1 through DE-R8:                    NOT ACCEPTED
Owner design-decision package:          BLOCKED
Owner design acceptance:                BLOCKED
TASK-0003+ build authorization:         BLOCKED
v1.4 amendment/build/release:            BLOCKED
Builder involvement now:                NOT AUTHORIZED
Next actor:                             FABLE
Next action:                            CORRECT DESIGN SET + SCOPED RE-VERIFICATION
```

---

## 8. Final Verifier Position

The Decision Engine design has moved beyond vague concept work; it now contains several credible architectural mechanisms. That progress is real. The gate nevertheless fails because the current packet converts broad document coverage into claims of complete requirement satisfaction without proving the semantic connection, and because several safety-critical interactions remain unresolved.

The correct response is not to restart discovery. It is to correct the design artifacts, make the evidence honest and reproducible, close the named control gaps, and return a bounded re-verification packet. Once those conditions are met, the owner gate can proceed without reopening the program's accepted foundations.
