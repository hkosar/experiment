# Requirements Applicability Matrix — Phase 2 Decision Engine Discovery (initial population)

**Status (P2-10, verifier semantics adopted):** This is the **candidate initial population**. It becomes the discovery execution checklist **only after owner approval**. Every accepted baseline requirement remains authoritative. **"In-scope"** means discovery determines how the requirement is operationalized and interacts with other requirements; it does not authorize ignoring or reopening its accepted outcome. **"Binding constraint"** means every candidate must satisfy the requirement as an invariant. Deferred and N/A rows require explicit rationale, and a discovered dependency must be escalated and logged rather than silently omitted. Every change from this initial population is logged in the Discovery Report with rationale.

| ID | Initial disposition | Rationale |
| --- | --- | --- |
| ACT-01 | Binding constraint | Idempotency/uncertain-outcome rules — OQ-09 fail-closed |
| APP-01 | Binding constraint | Model/provider substitution invariance is an explicit core-hypothesis test (§5.4 check 1). |
| APP-02 | Binding constraint | Discovery plans, decisions, reviews, and closeouts must remain durable, versioned artifacts keyed to stable IDs. |
| APP-03 | Deferred (not this stage) | No-Builder stage: GOV-02 supplies the independent plan-review gate; binding for any separately authorized build task. |
| APP-04 | Binding constraint | Candidate behavior and discovery state cannot depend on one surviving worker/model session. |
| APP-05 | Deferred (not this stage) | Build machinery — binding only for any separately authorized TASK-0003+ packet; discovery has no build |
| APP-06 | Deferred (not this stage) | Build machinery — binding only for any separately authorized TASK-0003+ packet; discovery has no build |
| APP-07 | Deferred (not this stage) | Build machinery — binding only for any separately authorized TASK-0003+ packet; discovery has no build |
| APP-08 | Deferred (not this stage) | Build machinery — binding only for any separately authorized TASK-0003+ packet; discovery has no build |
| APP-09 | Deferred (not this stage) | Build machinery — binding only for any separately authorized TASK-0003+ packet; discovery has no build |
| APP-10 | Deferred (not this stage) | Build machinery — binding only for any separately authorized TASK-0003+ packet; discovery has no build |
| ATT-01 | In-scope (discovery subject) | Attention model — OQ-03 subject matter |
| ATT-02 | In-scope (discovery subject) | Attention model — OQ-03 subject matter |
| ATT-03 | In-scope (discovery subject) | Attention model — OQ-03 subject matter |
| AUD-01 | N/A (with rationale) | Historical Phase 1 audit gate — passed (trail 53); no discovery role |
| AUD-02 | N/A (with rationale) | Historical audit-scope requirement — satisfied in Phase 1 |
| AUD-03 | In-scope (discovery subject) | AUD-03 ritual feeds the engine (OQ-08); AUD-01/02 historical gates noted per row |
| AUT-01 | In-scope (discovery subject) | Autonomy/rollout mechanics — OQ-02/OQ-03 inputs |
| AUT-02 | In-scope (discovery subject) | Autonomy/rollout mechanics — OQ-02/OQ-03 inputs |
| AUT-03 | In-scope (discovery subject) | Autonomy/rollout mechanics — OQ-02/OQ-03 inputs |
| AUT-04 | In-scope (discovery subject) | Autonomy/rollout mechanics — OQ-02/OQ-03 inputs |
| AUT-05 | In-scope (discovery subject) | Autonomy/rollout mechanics — OQ-02/OQ-03 inputs |
| AUT-06 | In-scope (discovery subject) | Autonomy/rollout mechanics — OQ-02/OQ-03 inputs |
| AUT-07 | In-scope (discovery subject) | Autonomy/rollout mechanics — OQ-02/OQ-03 inputs |
| AUT-08 | In-scope (discovery subject) | Autonomy/rollout mechanics — OQ-02/OQ-03 inputs |
| AUT-09 | In-scope (discovery subject) | Autonomy/rollout mechanics — OQ-02/OQ-03 inputs |
| AUT-10 | In-scope (discovery subject) | Autonomy/rollout mechanics — OQ-02/OQ-03 inputs |
| AUT-11 | In-scope (discovery subject) | Autonomy/rollout mechanics — OQ-02/OQ-03 inputs |
| AUT-12 | In-scope (discovery subject) | Autonomy/rollout mechanics — OQ-02/OQ-03 inputs |
| BUS-01 | In-scope (discovery subject) | Business-domain inputs (registry, mailroom boundary) — OQ-05/OQ-10 context |
| BUS-02 | In-scope (discovery subject) | Business-domain inputs (registry, mailroom boundary) — OQ-05/OQ-10 context |
| BUS-03 | In-scope (discovery subject) | Business-domain inputs (registry, mailroom boundary) — OQ-05/OQ-10 context |
| BUS-04 | In-scope (discovery subject) | Business-domain inputs (registry, mailroom boundary) — OQ-05/OQ-10 context |
| BUS-05 | In-scope (discovery subject) | Business-domain inputs (registry, mailroom boundary) — OQ-05/OQ-10 context |
| BUS-06 | In-scope (discovery subject) | Business-domain inputs (registry, mailroom boundary) — OQ-05/OQ-10 context |
| BUS-07 | In-scope (discovery subject) | Business-domain inputs (registry, mailroom boundary) — OQ-05/OQ-10 context |
| BUS-08 | In-scope (discovery subject) | Business-domain inputs (registry, mailroom boundary) — OQ-05/OQ-10 context |
| BUS-09 | In-scope (discovery subject) | Business-domain inputs (registry, mailroom boundary) — OQ-05/OQ-10 context |
| BUS-10 | In-scope (discovery subject) | Business-domain inputs (registry, mailroom boundary) — OQ-05/OQ-10 context |
| CAP-01 | Binding constraint | Capacity/cost constraints bind the stage-gate contract (§6) |
| CAP-02 | Binding constraint | Capacity/cost constraints bind the stage-gate contract (§6) |
| CAP-03 | Binding constraint | Binding future telemetry integration requirement; THIS stage uses the §6-approved "not measured" disclosure with session-count evidence — the disclosure does not satisfy the runtime requirement. |
| CAP-04 | Binding constraint | Capacity/cost constraints bind the stage-gate contract (§6) |
| COR-01 | Binding constraint | Correction primitives — adversarial case 9, learning boundary |
| DAT-01 | Binding constraint | Data classes — render/admission boundaries (P2-06, OQ-10) |
| DAT-02 | Binding constraint | Data classes — render/admission boundaries (P2-06, OQ-10) |
| DEC-01 | Binding constraint | DEC-02 falsifiers required on consequential conclusions |
| DEC-02 | Binding constraint | DEC-02 falsifiers required on consequential conclusions |
| EX-01 | In-scope (discovery subject) | Executive-experience requirements bind engine outputs (OQ-10) |
| EX-02 | In-scope (discovery subject) | Executive-experience requirements bind engine outputs (OQ-10) |
| EX-03 | In-scope (discovery subject) | Executive-experience requirements bind engine outputs (OQ-10) |
| EX-04 | In-scope (discovery subject) | Executive-experience requirements bind engine outputs (OQ-10) |
| EX-05 | In-scope (discovery subject) | Executive-experience requirements bind engine outputs (OQ-10) |
| EX-06 | In-scope (discovery subject) | Executive-experience requirements bind engine outputs (OQ-10) |
| EX-07 | In-scope (discovery subject) | Executive-experience requirements bind engine outputs (OQ-10) |
| EX-08 | In-scope (discovery subject) | Executive-experience requirements bind engine outputs (OQ-10) |
| EX-09 | In-scope (discovery subject) | Executive-experience requirements bind engine outputs (OQ-10) |
| EX-10 | In-scope (discovery subject) | Executive-experience requirements bind engine outputs (OQ-10) |
| EX-11 | In-scope (discovery subject) | Executive-experience requirements bind engine outputs (OQ-10) |
| GOV-01 | Binding constraint | Program governance binds the process, not the engine content |
| GOV-02 | Binding constraint | Program governance binds the process, not the engine content |
| GOV-03 | Binding constraint | Program governance binds the process, not the engine content |
| HW-01 | Deferred (not this stage) | Owner-timed hardware purchase — §19.3 deferral |
| IDN-01 | Binding constraint | Protection layer — engine must operationalize (P2-06) |
| IDN-02 | Binding constraint | Protection layer — engine must operationalize (P2-06) |
| IDN-03 | Binding constraint | Protection layer — engine must operationalize (P2-06) |
| INT-01 | Binding constraint | INT-01 decision-prompt standard shapes owner-facing outputs |
| LOG-01 | Binding constraint | Append-only log authority — replay/audit substrate (P2-06, OQ-05) |
| LOG-02 | Binding constraint | Append-only log authority — replay/audit substrate (P2-06, OQ-05) |
| LRN-01 | In-scope (discovery subject) | Learning pipeline integration — OQ-08 subject matter |
| LRN-02 | In-scope (discovery subject) | Learning pipeline integration — OQ-08 subject matter |
| LRN-03 | In-scope (discovery subject) | Learning pipeline integration — OQ-08 subject matter |
| LRN-04 | In-scope (discovery subject) | Learning pipeline integration — OQ-08 subject matter |
| LRN-05 | In-scope (discovery subject) | Learning pipeline integration — OQ-08 subject matter |
| LRN-06 | In-scope (discovery subject) | Learning pipeline integration — OQ-08 subject matter |
| LRN-07 | In-scope (discovery subject) | Learning pipeline integration — OQ-08 subject matter |
| LRN-08 | In-scope (discovery subject) | Learning pipeline integration — OQ-08 subject matter |
| LRN-09 | In-scope (discovery subject) | Learning pipeline integration — OQ-08 subject matter |
| LRN-10 | In-scope (discovery subject) | Learning pipeline integration — OQ-08 subject matter |
| MEM-01 | Binding constraint | Checkpoint/memory contracts constrain engine state handling |
| MEM-02 | Binding constraint | Checkpoint/memory contracts constrain engine state handling |
| MEM-03 | Binding constraint | Checkpoint/memory contracts constrain engine state handling |
| MEM-04 | Binding constraint | Checkpoint/memory contracts constrain engine state handling |
| MEM-05 | Binding constraint | Checkpoint/memory contracts constrain engine state handling |
| MEM-06 | Binding constraint | Checkpoint/memory contracts constrain engine state handling |
| MEM-07 | Binding constraint | Checkpoint/memory contracts constrain engine state handling |
| MEM-08 | Binding constraint | Checkpoint/memory contracts constrain engine state handling |
| MEM-09 | Binding constraint | Checkpoint/memory contracts constrain engine state handling |
| ONB-01 | Binding constraint | Grant-once/activate-staged posture binds capability activation |
| ORG-01 | In-scope (discovery subject) | Organization/folding rules interact with placement routing |
| ORG-02 | In-scope (discovery subject) | Organization/folding rules interact with placement routing |
| ORG-03 | In-scope (discovery subject) | Organization/folding rules interact with placement routing |
| ORG-04 | In-scope (discovery subject) | Organization/folding rules interact with placement routing |
| ORG-05 | In-scope (discovery subject) | Organization/folding rules interact with placement routing |
| ORG-06 | In-scope (discovery subject) | Organization/folding rules interact with placement routing |
| ORG-07 | In-scope (discovery subject) | Organization/folding rules interact with placement routing |
| PER-01 | Binding constraint | Business/Personal separation invariant (verifier §3 disposition) |
| PER-02 | Binding constraint | Business/Personal separation invariant (verifier §3 disposition) |
| PLAT-01 | Deferred (not this stage) | Platform/portability — deferred; PLAT portability principles noted as constraints on candidates |
| PLAT-02 | Binding constraint | OQ-10 may determine presentation, but Discord cannot become the authoritative state store. |
| PLAT-03 | Deferred (not this stage) | Platform/portability — deferred; PLAT portability principles noted as constraints on candidates |
| PLAT-04 | Binding constraint | Decision Engine candidates must remain portable across interface, model, memory, and host providers. |
| QUE-01 | In-scope (discovery subject) | Queue/aging mechanics are OQ-07 subject matter |
| RES-01 | Binding constraint | Resilience/watchdog/degraded mode — adversarial cases 10 (P2-06) |
| RES-02 | Binding constraint | Resilience/watchdog/degraded mode — adversarial cases 10 (P2-06) |
| RES-03 | Binding constraint | Resilience/watchdog/degraded mode — adversarial cases 10 (P2-06) |
| SCH-01 | Binding constraint | Scheduled-run control envelope — ritual/cadence inputs (P2-06) |
| SCH-02 | Binding constraint | Scheduled-run control envelope — ritual/cadence inputs (P2-06) |
| SEC-01 | Binding constraint | Owner-voice four-control separation binds outbound routing |
| SEC-02 | Binding constraint | Owner-voice four-control separation binds outbound routing |
| TRS-01 | Binding constraint | Trust envelope — routing input and injection resistance (P2-06) |
| TRS-02 | Binding constraint | Trust envelope — routing input and injection resistance (P2-06) |
| TRS-03 | Binding constraint | Trust envelope — routing input and injection resistance (P2-06) |
| WF-01 | In-scope (discovery subject) | Workflow/routing dimensions — OQ-01/OQ-02 subject matter |
| WF-02 | In-scope (discovery subject) | Workflow/routing dimensions — OQ-01/OQ-02 subject matter |
| WF-03 | In-scope (discovery subject) | Workflow/routing dimensions — OQ-01/OQ-02 subject matter |
| WF-04 | In-scope (discovery subject) | Workflow/routing dimensions — OQ-01/OQ-02 subject matter |
| WF-05 | In-scope (discovery subject) | Workflow/routing dimensions — OQ-01/OQ-02 subject matter |
| WF-06 | In-scope (discovery subject) | Workflow/routing dimensions — OQ-01/OQ-02 subject matter |
| WF-07 | In-scope (discovery subject) | Workflow/routing dimensions — OQ-01/OQ-02 subject matter |
| WF-08 | In-scope (discovery subject) | Workflow/routing dimensions — OQ-01/OQ-02 subject matter |
| WF-09 | In-scope (discovery subject) | Workflow/routing dimensions — OQ-01/OQ-02 subject matter |
| WF-10 | In-scope (discovery subject) | Workflow/routing dimensions — OQ-01/OQ-02 subject matter |
| WF-11 | In-scope (discovery subject) | Workflow/routing dimensions — OQ-01/OQ-02 subject matter |
| WF-12 | In-scope (discovery subject) | Workflow/routing dimensions — OQ-01/OQ-02 subject matter |

**Coverage:** 125 of 125 accepted requirements dispositioned. Counts — Binding constraint: 46; Deferred (not this stage): 10; In-scope (discovery subject): 67; N/A (with rationale): 2.
