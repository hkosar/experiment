# 43 — Fable Disposition: R6 rollback/quarantine, and the final re-check request

**Input:** `TASK0007_R6_Builder_Return.zip`, SHA-256 `57eff9db5bc7e6b29f1a4abefe53f1e0e05fc0212facbc1e59fcc735a4048f70`.

## 1. Structural verification (static only, per the trail-127 practice)

Manifest 97 entries — **96 match, 0 missing, 1 differs** (`stub/out/selftest.json`, the known `out/**` non-determinism ruled benign at trail 139); **0** undeclared files; **immutable denylist 7/7 byte-identical** (harness code plus `r1_`–`r4_reference`); the new `r5_reference/stub_server_r5.py` is **byte-identical to the R5 stub this repository integrated**, so the pin is genuine; stdlib-only; secret scan clean; shipped evidence **190/190** self-test and **34/34** witnesses, zero failures. No suite run and no probe executed by Fable — those counts remain Builder-authored self-claims.

## 2. The fix, confirmed by reading

The bare `except OSError: pass` is gone from the rollback path. It is replaced by `_rollback_capture(...)`, which: removes the **final link first** (explicitly, because it is the one a reader would count as durable evidence), treats `FileNotFoundError` as a *proven* removal, makes the removal itself **durable with its own directory fsync**, and **only then** releases the pool unit. When any of that cannot be established it registers the incident on `STORE.storage_quarantine` and raises `CaptureQuarantine` — and the quota unit is **deliberately not released**, with the reason stated in the source: *the reservation is the only remaining accounting for a record that may still exist.*

Item 3 is implemented as more than a return value: dispatch then refuses **every** further authority transition with `503 refused-storage-quarantine`, while `GET /health` still serves and reports why. That is fail-closed in the strong sense — the service stops asserting authority entirely rather than continuing beside evidence it can no longer vouch for.

Verifier's own rollback probe: **5/5 against R6, 0/5 against pinned R5.** Red-before-green applied, as the standing rule requires.

## 3. The Builder's flagged judgement call — RULED: keep the strict reading

The Builder asks whether "removal succeeded but its directory fsync could not be performed" should quarantine (its choice) or be a softer anomaly, noting it took the strictest available reading and that the alternative is a two-line change.

**Fable confirms the strict reading.** An undurable removal means a crash could resurrect the very record the service has just told its caller does not exist — that is precisely "rollback not established," not a cosmetic gap. `42_` item 1 sequences the fsync *before* the release and item 3 says quarantine when rollback cannot be established; the Builder read both correctly. The asymmetry decides it: a rare false quarantine is **visible, recoverable and loud**, while a false durable record is **silent** — and six rounds of this workstream have been spent eliminating exactly the silent kind. No change.

## 4. Disposition

**R6 STRUCTURALLY ACCEPTED and INTEGRATED** (6 added, 6 modified; `r5_reference/` accepted on the established precedent and added to the immutable denylist). Security posture **NOT independently verified**.

**Next: the verifier's final re-check of SEC-R4-01.** Nothing else in the gate is open — the concurrency architecture is closed, AUDIT-R4-5 was amended by the verifier, and R5's ordinary post-link paths were independently confirmed and must not have regressed. Fable's requested focus: (1) the quarantine path itself — that it cannot be entered spuriously, and that once entered the service genuinely stops asserting authority; (2) the strict-fsync ruling in §3, which is Fable's call and open to challenge; (3) whether any post-link ordering remains that the four boundaries miss; (4) that R5's confirmed behaviours have not regressed, including the legitimate survival of the `prepared` record and its quota unit.

**On this re-check the owner's hands-on POC session unblocks.** It is the only item remaining.
