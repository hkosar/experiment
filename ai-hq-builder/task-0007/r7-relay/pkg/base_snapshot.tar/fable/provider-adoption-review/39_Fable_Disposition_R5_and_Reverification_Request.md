# 39 — Fable Disposition: R5 capture-publication fix, and re-verification request

**Input:** `TASK0007_R5_Builder_Return.zip`, SHA-256 `91f12c47be2a166324ef0763662d5d99acb835c9fb68cb698f09eccbbe939dfc`.

## 1. Structural verification (static only, per the trail-127 practice)

Manifest 91 entries — **89 match, 0 missing, 2 differ** (the known `out/**` non-determinism, ruled benign at trail 139); **0** undeclared files under `poc/`; **immutable denylist intact** — harness code and all three prior pins (`r1_`, `r2_`, `r3_reference`) byte-identical; the new `r4_reference/stub_server_r4.py` is **byte-identical to the R4 stub this repository integrated**, so the new pin is genuine; stdlib-only; secret scan clean; shipped evidence shows **178/178** self-test and **34/34** witnesses, zero failures.

**No adversarial verification by Fable** — no server started, no suite run, no probe executed. The Builder's counts are self-claims, undisputed and independently unconfirmed.

## 2. The fix, confirmed by reading

`write_capture` now sets `published = True` **only after the directory fsync returns**, with the comment *"Only here. Everything above this line is still rollable back."* The rollback path tracks `linked_path` separately so a post-link failure removes the **final** path as well as the temp and releases the pool unit — closing both the directory-fsync/open case and the temp-unlink case. `os.link` is kept, as required. Also preserved from R4 and worth noting: the deliberate `open()` rather than `os.fdopen()`, with the reason stated in the source — *an implementation that routed around the injection would evade the test rather than pass it.* That is the anti-evasion discipline from trail 143 now written into the code as a comment for the next reader.

## 3. The nuance the Builder got right

On the committed-registration case the correct reading is **not** "nothing survives." The `prepared` record published successfully and legitimately remains, holding its own quota unit — A.7 is explicit that an orphan `prepared` is reported uncertain, never complete. What must not survive is the `committed` record, and it does not: `steps=['prepared-artifact-register']`, `registrations=0`, `identity_index=0`, `reserved-owner=1`. Fable concurs. A fix that deleted the `prepared` record too would have destroyed the very evidence A.7 exists to produce.

## 4. Evidence posture

The verifier's two new probes are reported **green against R5 and red against pinned R4**; the Builder's own fault suite 5/5 against R5 and 2/5 against R4. The red-before-green method adopted at trail 143 was applied again, and the Builder reports its own suite passing 2/5 against the defective build before the fix — i.e. it checked that its tests could fail. No stop-and-report findings this round; no contract clause touched; the concurrency architecture untouched, as `36_` §1 requires.

## 5. Disposition

**R5 STRUCTURALLY ACCEPTED and INTEGRATED** (20 added, 5 modified; `r4_reference/` accepted on the established precedent and added to the immutable denylist). Security posture **NOT independently verified**.

**Next: the verifier's re-check of SEC-R4-01 only.** Everything else in the gate is already closed — AUDIT-R4-5 amended by the verifier, SEC-R3-01/02 closed, the 8-way check passed, the concurrency architecture accepted and explicitly not reopened. This is a single-finding re-check, and on it the owner's hands-on POC session unblocks.

Fable's requested focus: (1) the post-link rollback at all four boundaries, including that the **`prepared` record and its quota unit correctly survive** while the `committed` record does not; (2) whether any further post-link ordering exists that the four named boundaries miss; (3) that the fix introduced no new evasion of an injection point — the failure family from trail 143.
